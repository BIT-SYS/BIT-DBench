package libfunc;

import java.util.ArrayList;

public class LibFuncInfo {
    private ArrayList<String> rtlib = new ArrayList<String>();

    public LibFuncInfo(){
//        this.rtlib.add("java.util.ArrayList:java.lang.Object[] toArray(java.lang.Object[])");
//        this.rtlib.add("java.util.HashMap:java.lang.Object get(java.lang.Object)");
//        this.rtlib.add("java.util.Map:java.lang.Object remove(java.lang.Object)");
        rtlib.add("");
    }

    public ArrayList<String> getRtlib(){
        return rtlib;
    }

    public void setRtlib(ArrayList<String> rtlib){
        for(String s : rtlib){
            this.rtlib.add(s);
        }
    }

}
