package config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Config {
    private String fixMethod;

    @Override
    public String toString() {
        return "Config{" +
                "fixMethod='" + fixMethod + '\'' +
                ", targetPath='" + targetPath + '\'' +
                ", jarPath='" + jarPath + '\'' +
                ", variableType='" + variableType + '\'' +
                ", projectAndThirdParty='" + projectAndThirdParty + '\'' +
                ", projectSourcePath='" + projectSourcePath + '\'' +
                ", category='" + category + '\'' +
                ", careField=" + careField +
                ", projectName='" + projectName + '\'' +
                '}';
    }

    private String targetPath;
    private String jarPath;
    private String variableType;;
    private String projectAndThirdParty;

    private String projectSourcePath;
    private String category;

    public HashSet<String> getCareField() {
        return careField;
    }

    private HashSet<String> careField = new HashSet<>();


    private HashSet<String> sqlexec = new HashSet<>(Arrays.asList(
            "java.sql.CallableStatement:boolean execute()",
            "java.sql.CallableStatement:boolean execute(java.lang.String)",
            "java.sql.CallableStatement:java.sql.ResultSet executeQuery(java.lang.String)",
            "java.sql.CallableStatement:java.sql.ResultSet executeQuery()",
            "java.sql.CallableStatement:int executeUpdate()",
            "java.sql.CallableStatement:int executeUpdate(java.lang.String)",

            "java.sql.Statement:boolean execute(java.lang.String)",
            "java.sql.Statement:java.sql.ResultSet executeQuery()",
            "java.sql.Statement:int executeUpdate(java.lang.String)"
    ));

    public HashSet<String> getSqlexec() {
        return sqlexec;
    }

    public String getProjectSourcePath() {
        return projectSourcePath;
    }

    public String getCategory() {
        return category;
    }

    public String getProjectAndThirdParty() { return projectAndThirdParty; }
    public String getFixMethod() {
        return fixMethod;
    }

    public void setFixMethod(String fixMethod) {
        this.fixMethod = fixMethod;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public String getJarPath() {
        return jarPath;
    }

    public void setJarPath(String jarPath) {
        this.jarPath = jarPath;
    }

    public String getVariableType() {
        return variableType;
    }

    public void setVariableType(String variableType) {
        this.variableType = variableType;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    private String projectName;

    public Config(String[] args) {
//        System.out.println(args.length);
        if(args.length == 8){
            fixMethod = args[0];
            projectAndThirdParty = args[1];
            jarPath = args[2];
            variableType = args[3];
            projectName = args[4];
            category = args[5];
            projectSourcePath  = args[6];
            careField.add(args[7]);
            System.out.println(category);
        }
        else if(args.length == 7){
            fixMethod = args[0];
            projectAndThirdParty = args[1];
            jarPath = args[2];
            variableType = args[3];
            projectName = args[4];
            category = args[5];
            projectSourcePath  = args[6];
        }else{
            System.err.println("please input all the information");
        }


    }


//    public Config() {
//        fixMethod = "no.tornado.brap.client.MethodInvocationHandler:java.lang.Object invoke(java.lang.Object,java.lang.reflect.Method,java.lang.Object[])";
//        projectAndThirdParty = "C:\\工作文档\\工作\\数据集构建第一部分\\可编译的程序\\编译的项目\\brap\\80163984601bd8fc30a7222c707293612db53e20\\out\\artifacts\\brap_jar\\brap.jar";
//        jarPath = "C:\\工作文档\\工作\\数据集构建第一部分\\可编译的程序\\编译的项目\\brap\\80163984601bd8fc30a7222c707293612db53e20\\out\\artifacts\\brap_jar2\\brap.jar";
//        variableType = "java.lang.Object";
//        projectName = "brap";
//        category = "npe";
//        projectSourcePath = "C:\\工作文档\\工作\\数据集构建第一部分\\可编译的程序\\编译的项目\\brap\\80163984601bd8fc30a7222c707293612db53e20";
//    }


}
