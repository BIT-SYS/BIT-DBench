import algorithm.searchPaths;
import classgraph.LibClassGraph;
import classgraph.MergeClassGraph;
import config.Config;
import datagraph.GenerateDataGraph;
import dominateAlg.DominantPoint;
import dominateAlg.Rings;
import javafx.util.Pair;
import libfunc.LibFuncInfo;
import org.jgrapht.experimental.dag.DirectedAcyclicGraph;
import org.jgrapht.graph.DefaultEdge;
import pathinfo.AllClassPaths;
import perfectgraph.prefectGraph;
import sourceandsink.NPESourceAndSinkQdox;
import sourceandsink.ResourceleakSourceAndSink;
import sourceandsink.SqlInjectSourceAndSink;
import stat.JCallGraph;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;


//公共父节点测试
public class Main {

    public static void bfs(Map<String, ArrayList<String>> graph, String start, HashSet<String> influnceNode, ArrayList<String> rtlib) {

        Queue<String> queue = new LinkedList<>();//存储访问的节点
        Queue<String> visite = new LinkedList<>();//存储访问过得节点

        queue.add(start);//起始节点添加到队列
        visite.add(start);//标识为访问过

        while (!queue.isEmpty()) {
            String node = queue.poll();//队列头结点出队
            visite.add(node);
//            if(node.contains("getMainSchema")){
//                System.out.println("yes");
//            }
            if (graph.keySet().contains(node) && !rtlib.contains(node)) {
                List<String> set = graph.get(node);//获取所有的直接关联的节点
                if (set.size() != 0) {
                    for (String next : set) {
                        if (!visite.contains(next)) {//不包含说明没有没有被访问
                            queue.add(next);
//                            visite.add(next);
                        }
                    }
                }
            }
        }
        for (String n : visite) {
            influnceNode.add(n);
        }
    }

    public static HashMap<String, ArrayList<String>> getCallGraph_T(HashMap<String, ArrayList<String>> callgraph) {
        HashMap<String, ArrayList<String>> callgraph_t = new HashMap<>();
        for (String node : callgraph.keySet()) {
            for (String value : callgraph.get(node)) {
                ArrayList<String> t = new ArrayList<>();
                if (callgraph_t.keySet().contains(value)) {
                    t = callgraph_t.get(value);
                }
                t.add(node);
                callgraph_t.put(value, t);
            }
        }
        return callgraph_t;
    }

    /**
     * 去除自循环
     * @param graph 原图
     * @return 去除自循环后的图
     */
    public HashMap<String, ArrayList<String>> getAndRemoveSelfRing(HashMap<String, ArrayList<String>> graph){
        HashSet<String> selfRingNodes = new HashSet<>();
        HashMap<String, ArrayList<String>> graph_removeselfring = new HashMap<>();
        for(String key : graph.keySet()){
            if(graph.get(key).contains(key)){
                selfRingNodes.add(key);
            }
            ArrayList<String> valuelist = new ArrayList<>();
            for(String value : graph.get(key)){
                if(!key.equals(value)){
                    valuelist.add(value);
                }
            }
            graph_removeselfring.put(key, valuelist);
        }
//        System.out.println("self ring num is " + selfRingNodes.size());
        return graph_removeselfring;
    }

    public static HashSet<String> getNodesInGraph(HashMap<String, ArrayList<String>> graph){
        HashSet<String> nodesInGraph = new HashSet<>();
        for(String key : graph.keySet()){
            nodesInGraph.add(key);
            for(String val : graph.get(key)){
                nodesInGraph.add(val);
            }
        }
        return nodesInGraph;
    }

    public static Pair<HashSet<String>, HashSet<String>> needSearchOrNot(HashMap<String, ArrayList<String>> graphNoRing, String fixMethodup, String u, HashMap<String, ArrayList<String>> graphHaveRing, HashMap<String, HashSet<String>> nodemap, HashSet<String> careField){
        HashSet<String> noNeedSearchNodes = new HashSet<>();
        HashSet<String> needSearchNodes = new HashSet<>();

        HashSet<String> pathNodes = new HashSet<>();

        searchPaths searchPathsObj1 = new searchPaths();
        searchPathsObj1.getAllPaths(graphNoRing, fixMethodup, u, pathNodes);
        ArrayList<ArrayList<String>> paths = searchPathsObj1.getPaths();

        for(ArrayList<String> path : paths){
            ArrayList<String> temp = new ArrayList<>();
            for(String p : path){
                if(p.contains("[NewNode]")){
                    temp.addAll(nodemap.get(p));
                }
                else {
                    temp.add(p);
                }
            }

            boolean flag = false;
            ArrayList<String> temp1 = new ArrayList<>();
            for(String p : temp){
                if(!p.endsWith(")")){
                    if(careField.size() != 0){
                        if(careField.contains(p)){
                            flag = true;
                            if(graphHaveRing.containsKey(p)) {
                                ArrayList<String> ringNodes = graphHaveRing.get(p);
                                temp1.remove(p);
                                temp1.addAll(ringNodes);
                            }
                        }
                    }
                    else{
                        flag = true;
                        if(graphHaveRing.containsKey(p)) {
                            ArrayList<String> ringNodes = graphHaveRing.get(p);
                            temp1.remove(p);
                            temp1.addAll(ringNodes);
                        }
                    }
                }else{
                    temp1.add(p);
                }
            }
            if(flag){
                needSearchNodes.addAll(temp1);
            }else{
                noNeedSearchNodes.addAll(temp);
            }
        }

        return new Pair(noNeedSearchNodes, needSearchNodes);
    }

    /**
     * 计算时间
     * @param args
     * @throws IOException
     */

    public static void main(String[] args) throws IOException {
        long begintime = System.currentTimeMillis();
        //1.设置参数
//        Config config = new Config();
        Config config = new Config(args);
        //2.加入库函数，我们考虑的库函数
        LibFuncInfo libFuncInfo = new LibFuncInfo();
        //3.得到分析项目的信息：函数个数、class个数、每个class对应的method
        AllClassPaths projectAndExtargetInfo = new AllClassPaths(config.getProjectAndThirdParty());

        //4.得到类型图：标准库的类图+项目的类图+第三方库的类图
        MergeClassGraph mergeClassGraph = new MergeClassGraph();
        LibClassGraph libClassGraph = new LibClassGraph();
        libClassGraph.setLibclassgraph();
        HashMap<String, ArrayList<String>> pclassGraph = projectAndExtargetInfo.getClassgraph();

        mergeClassGraph.setClassgraph(projectAndExtargetInfo.getClassgraph(), libClassGraph.getLibclassgraph());
        DirectedAcyclicGraph<String, DefaultEdge> classGraph = mergeClassGraph.getClassgraph_jgrapht();


        HashSet<String> finalPack = new HashSet<>();

        //6.生成函数调用图
        JCallGraph callGraph = new JCallGraph();
        callGraph.run(new String[]{config.getJarPath()});
        HashMap<String, ArrayList<String>> callgraph = callGraph.getCallGraphMap();

        //7.函数调用图中原本有一些节点，程序中没有，所以将这些节点删除或更正
        prefectGraph prefectGraphObj = new prefectGraph();
        prefectGraphObj.setOrigMethods(callgraph);
        prefectGraphObj.setUsefulMethods(config.getJarPath());
        prefectGraphObj.setPrefectgraph(callgraph);
        callgraph = prefectGraphObj.getPrefectgraph();



        //8. 对特定项目补充函数调用图或更正函数调用图
        if (config.getProjectName().contains("bitcoinj")){
            String node0 = "com.google.bitcoin.core.Wallet:com.google.bitcoin.core.Transaction sendCoinsAsync(com.google.bitcoin.core.PeerGroup,com.google.bitcoin.core.Address,java.math.BigInteger)";
            String node1 = "com.google.bitcoin.core.PeerGroup:java.util.concurrent.Future broadcastTransaction(com.google.bitcoin.core.Transaction)";
            String node2 = "com.google.bitcoin.core.Peer:void sendMessage(com.google.bitcoin.core.Message)";
            String node3 = "com.google.bitcoin.core.NetworkConnection:void writeMessage(com.google.bitcoin.core.Message)";
            String node4 = "com.google.bitcoin.core.BitcoinSerializer:void serialize(com.google.bitcoin.core.Message,java.io.OutputStream)";

            ArrayList<String> t0 = new ArrayList<>();
            if(callgraph.containsKey(node0)){
                t0 = callgraph.get(node0);
            }
            t0.add(node1);
            callgraph.put(node0, t0);

            ArrayList<String> t = new ArrayList<>();
            if (callgraph.containsKey(node1)) {
                t = callgraph.get(node1);
            }
            t.add(node2);
            callgraph.put(node1, t);

            ArrayList<String> tt = new ArrayList<>();
            if (callgraph.containsKey(node3)) {
                tt = callgraph.get(node3);
            }
            tt.add(node4);
            callgraph.put(node3, tt);

            ArrayList<String> ttt = new ArrayList<>();
            if (callgraph.containsKey(node2)) {
                ttt = callgraph.get(node2);
            }
            ttt.add(node3);
            callgraph.put(node2, ttt);


        }

        if(config.getProjectName().contains("H2")) {
            String node1 = "org.h2.engine.Session:void startStatementWithinTransaction(org.h2.command.Command)";
            String node2 = "org.h2.engine.Session:void addTableToDependencies(org.h2.mvstore.db.MVTable,java.util.HashSet,java.util.HashSet)";
            String node3 = "org.h2.table.Table:java.util.ArrayList getConstraints()";

            if (callgraph.containsKey(node1)) {
                callgraph.get(node1).add(node2);
            }
            ArrayList<String> t = new ArrayList<>();
            if (callgraph.containsKey(node2)) {
                t = callgraph.get(node2);
            }
            t.add(node3);
            callgraph.put(node2, t);
        }

        if(config.getProjectName().contains("FacebookGWT")){
            String node1 = "com.denormans.facebookgwt.api.client.graph.js.User:java.util.List getInterestedIn()";
            String node2 = "com.denormans.gwtutil.client.js.EnhancedJSObject:java.util.List convertJsArrayStringToList(com.google.gwt.core.client.JsArrayString)";
            String node3 = "com.denormans.gwtutil.client.js.EnhancedJSObject:java.util.List convertJsArrayStringToList(com.google.gwt.core.client.JsArrayString,com.denormans.gwtutil.shared.Transformer)";
            if(callgraph.containsKey(node1)){
                ArrayList<String> temp = new ArrayList<>(callgraph.get(node1));
                if(!temp.contains(node2)){
                    temp.add(node2);
                }
                callgraph.put(node1, temp);
            }else{
                ArrayList<String> temp = new ArrayList<>();
                temp.add(node2);
                callgraph.put(node1, temp);
            }
        }

        //5.以修改变量类型为起点，寻找类型闭包+类型闭包, 寻找可能的source或者sinK

        HashSet<String> source = new HashSet<>();
        HashSet<String> sink = new HashSet<>();
        if(config.getCategory().equals("npe")){
            finalPack = mergeClassGraph.getFianlMap(projectAndExtargetInfo.getForceconversionedgs(), classGraph, config.getVariableType());
            if(config.getProjectName().contains("bitcoinj")){
                finalPack.add("com.google.bitcoin.core.Transaction");
                finalPack.add("com.google.bitcoin.core.Message");
            }
            NPESourceAndSinkQdox npeSourceAndSink = new NPESourceAndSinkQdox();
            npeSourceAndSink.exec(finalPack, config.getProjectSourcePath(), config.getJarPath());
            source = npeSourceAndSink.getSourceSet();
            sink = npeSourceAndSink.getSinkSet();
            ArrayList<String> rtlib = libFuncInfo.getRtlib();
            for(String k : callgraph.keySet()){
                for(String v : callgraph.get(k)){
                    if(rtlib.contains(v)){
                        source.add(k);
                    }
                }
            }

        }
        else if(config.getCategory().equals("resourceleak")){
            finalPack = new HashSet<>(Arrays.asList("java.io.Reader", "java.io.Writer", "java.io.InputStream", "java.io.OutputStream",
                    "java.io.BufferedReader", "java.io.InputStreamReader", "java.io.FileReader", "java.io.StringReader", "java.io.PipedReader",
                    "java.io.CharArrayReader", "java.io.FilterReader", "java.io.PushbackReader", "java.io.BufferedWriter",
                    "java.io.OutputStreamWriter", "java.io.FileWriter", "java.io.PrintWriter", "java.io.StringWriter",
                    "java.io.PipedWriter", "java.io.CharArrayWriter", "java.io.FilterWriter", "java.io.FileInputStream",
                    "java.io.FilterInputStream", "java.io.BufferedInputStream", "java.io.DataInputStream", "java.io.PushbackInputStream",
                    "java.io.ObjectInputStream", "java.io.PipedInputStream", "java.io.SequenceInputStream", "java.io.StringBufferInputStream",
                    "java.io.ByteArrayInputStream", "java.io.FileOutputStream", "java.io.FilterOutputStream", "java.io.BufferedOutputStream",
                    "java.io.DataOutputStream", "java.io.PrintStream", "java.io.ObjectOutputStream", "java.io.PipedOutputStream", "java.io.ByteArrayOutputStream"
            ));
            ResourceleakSourceAndSink resourceleakSourceAndSink = new ResourceleakSourceAndSink();
            resourceleakSourceAndSink.exec(config.getProjectSourcePath(), config.getJarPath());
            resourceleakSourceAndSink.setSources();
            source = resourceleakSourceAndSink.getSources();
            sink = resourceleakSourceAndSink.getSinks();
        }
        else if(config.getCategory().equals("sqlinject")){
//            finalPack = mergeClassGraph.getFianlMap(projectAndExtargetInfo.getForceconversionedgs(), classGraph, "java.lang.String");
            finalPack = new HashSet<>(Arrays.asList(("java.lang.String")));
            SqlInjectSourceAndSink sqlInjectSourceAndSink = new SqlInjectSourceAndSink();
            sqlInjectSourceAndSink.exec(config.getJarPath());
            source = sqlInjectSourceAndSink.getSources();
            sink = sqlInjectSourceAndSink.getSinks();
        }
        else{
            System.out.println("类型不对");
        }

        HashSet<String> startDataNode = new HashSet<>();
        startDataNode.addAll(source);
        startDataNode.addAll(sink);

        //9.生成数据图
        GenerateDataGraph generateDataGraph = new GenerateDataGraph(finalPack, config.getJarPath(), callgraph);

        HashMap<String, ArrayList<String>> dataGraph_t = generateDataGraph.getDataGraphT();
        HashMap<String, ArrayList<String>> dataGraph_removereturn = generateDataGraph.getDataGraph_removereturn();


        //10.对数据图进行去除环的处理
        HashMap<String, ArrayList<String>> dataGraphtRemoveSelfRing = new Main().getAndRemoveSelfRing(dataGraph_t); //去除自循环，向上搜索的时候保留return边
        Pair<HashMap<String, ArrayList<String>>, HashMap<String, HashSet<String>>> pair1 = new Rings().Ring_exec_removeRing(dataGraphtRemoveSelfRing);

        HashMap<String, ArrayList<String>> dataGraphtNoRing = pair1.getKey();//向上搜索的无环图
        HashMap<String, HashSet<String>> nodemap1 = pair1.getValue();//环对应关系
        //存储在环中的节点
        HashSet<String> nodevalue1 = new HashSet<>();
        for(String k : nodemap1.keySet()){
            for(String v : nodemap1.get(k)){
                nodevalue1.add(v);
            }
        }

        HashMap<String, ArrayList<String>> dataGraph_removereturnRemoveSelfRing = new Main().getAndRemoveSelfRing(dataGraph_removereturn); //去除自循环，向下搜索的时候去除return边
        Pair<HashMap<String, ArrayList<String>>, HashMap<String, HashSet<String>>> pair2 = new Rings().Ring_exec_removeRing(dataGraph_removereturnRemoveSelfRing);

        HashMap<String, ArrayList<String>> dataGraphNoReturnNoRing = pair2.getKey();//向下搜索的无环图
        HashMap<String, HashSet<String>> nodemap2 = pair2.getValue();
        //环中的节点
        HashSet<String> nodevalue2 = new HashSet<>();
        for(String k : nodemap2.keySet()){
            for(String v : nodemap2.get(k)){
                nodevalue2.add(v);
            }
        }


        HashSet<String> up = new HashSet<>();
        String fixMethodup = config.getFixMethod();

        for(String sn1 : source){
            if(nodevalue1.contains(sn1)){
                for(String  k : nodemap1.keySet()){
                    if(nodemap1.get(k).contains(sn1)){
                        up.add(k);
                        break;
                    }
                }
            }
            else{
                up.add(sn1);
            }
        }

        if(nodevalue1.contains(config.getFixMethod())){
            for(String  k : nodemap1.keySet()){
                if(nodemap1.get(k).contains(config.getFixMethod())){
                    fixMethodup = k;
                    break;
                }
            }
        }

//        System.out.println(up);
//        System.out.println(nodemap1.get("[NewNode]4"));
        HashSet<String> down = new HashSet<>();
        String fixMethoddown = config.getFixMethod();
        for(String sn2 : sink){
            if(nodevalue2.contains(sn2)){
                for(String  k : nodemap2.keySet()){
                    if(nodemap2.get(k).contains(sn2)){
                        down.add(k);
                        break;
                    }
                }
            }
            else{
                down.add(sn2);
            }
        }
        if(nodevalue2.contains(config.getFixMethod())){
            for(String  k : nodemap2.keySet()){
                if(nodemap2.get(k).contains(config.getFixMethod())){
                    fixMethoddown = k;
                    break;
                }
            }
        }

        HashSet<String> result = new HashSet<>();

//        ArrayList<ArrayList<String>> pathsAll = new ArrayList<>();
        HashSet<String> noNeedSearchNodes = new HashSet<>();
        HashSet<String> needSearchNodes = new HashSet<>();
        HashSet<String> nodesInGraphUp = getNodesInGraph(dataGraphtNoRing);

        for(String u : up){
            if(!nodesInGraphUp.contains (u)){
                continue;
            }
            Pair<HashSet<String>, HashSet<String>> pairup = needSearchOrNot(dataGraphtNoRing, fixMethodup, u, dataGraphtRemoveSelfRing, nodemap1, config.getCareField());
            needSearchNodes.addAll(pairup.getValue());
            noNeedSearchNodes.addAll(pairup.getKey());
        }


        HashSet<String> nodesInGraphDown = getNodesInGraph(dataGraphNoReturnNoRing);
        for(String d :down){
            if(!nodesInGraphDown.contains(d)){
                continue;
            }
            Pair<HashSet<String>, HashSet<String>> pairdown = needSearchOrNot(dataGraphNoReturnNoRing, fixMethoddown, d, dataGraph_removereturnRemoveSelfRing, nodemap2, config.getCareField());
            needSearchNodes.addAll(pairdown.getValue());
            noNeedSearchNodes.addAll(pairdown.getKey());
        }

        DominantPoint dominantPoint = new DominantPoint();
        HashMap<String, ArrayList<String>> callgraphRemoveSelfRing = new Main().getAndRemoveSelfRing(callgraph);
        HashMap<String, ArrayList<String>> callgrapht = getCallGraph_T(callgraphRemoveSelfRing);

        HashSet<String> searchResult = dominantPoint.domimantPoint_exec(callgraphRemoveSelfRing, callgrapht, needSearchNodes, config.getFixMethod());

        long endtime=System.currentTimeMillis();
        long costTime = (endtime - begintime);
        ArrayList<String> text = new ArrayList<>();
        System.out.println("----------------" + config.getProjectName() + "---------------------");
        System.out.println("程序运行时间：" + costTime);
        System.out.println(config.getFixMethod());
        System.out.println(config.getProjectName());

        text.add("----------------" + config.getProjectName() + "---------------------\n");
        text.add("程序运行时间：" + costTime + "\n");
        text.add("[final type size] " + finalPack.size() + "\n");
        text.add("[final type] " + finalPack + "\n");


        text.add("[source size]" + source.size() + "\n");
        text.add("[source]" + source + "\n");

//        System.out.println("[sink size]" + sink.size());
//        System.out.println("[sink]" + sink);
        text.add("[sink size]" + sink.size() + "\n");
        text.add("[sink]" + sink + "\n");

//        System.out.println("[search nodes size]" + pathNodesAll.size());
//        System.out.println("[no search nodes]" + result.size());
        text.add("[search nodes size]" + needSearchNodes.size() + "\n");
        text.add("[no search nodes]" + noNeedSearchNodes.size() + "\n");

//        System.out.println("[searchResult size]" + searchResult.size());
//        System.out.println("[searchResult]" + searchResult);
        text.add("[searchResult size]" + searchResult.size() + "\n");
        text.add("[searchResult]" + searchResult + "\n");

//        System.out.println("[nosearchResult size]" + result.size());
//        System.out.println("[nosearchResult]" + result);
        text.add("[nosearchResult size]" + result.size() + "\n");
        text.add("[nosearchResult]" + result + "\n");

        result.addAll(searchResult);
        result.addAll(noNeedSearchNodes);
        result.add(config.getFixMethod());
        System.out.println("[result size]" + result.size());
        System.out.println("[result]" + result);
        text.add("[result size]" + result.size() + "\n");
        text.add("[result]" + result + "\n");


        AllClassPaths projectInfo = new AllClassPaths(config.getJarPath());

        System.out.println("项目信息");
        System.out.println("文件数：" + projectInfo.getFilenum());
        System.out.println("函数数：" + projectInfo.getFuncnum());
        text.add("项目信息\n");
        text.add("文件数：" + projectInfo.getFilenum() + "\n");
        text.add("函数数：" + projectInfo.getFuncnum() + "\n");
        text.add("======================================\n\n\n");

        String tempText = String.join("", text);

//        String fileName = "eachProjectsResult" + File.separator + config.getProjectName() + ".txt";
//        writeFileWithBufferedWriter(fileName, tempText);
    }

    static void writeFileWithBufferedWriter(String fileName, String text) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(text);
        writer.close();
    }
}
