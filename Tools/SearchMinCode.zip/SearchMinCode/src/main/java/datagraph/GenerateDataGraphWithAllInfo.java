package datagraph;

import libfunc.LibFuncInfo;
import org.apache.bcel.classfile.*;
import org.apache.bcel.generic.Type;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GenerateDataGraphWithAllInfo {

    private HashMap<String, ArrayList<String>> dataGraph = new HashMap<>();

    private HashMap<String, ArrayList<String>> field2Func = new HashMap<>();//field和函数之间的调用关系

    private ArrayList<String> returnFuncList = new ArrayList<>(); //可以添加return边的图

    private HashSet<String> fieldSet = new HashSet<>();//在类型闭包中的field
    private ArrayList<String> staticField = new ArrayList<>();//在类型闭包中的static field
    private ArrayList<String> noStaticField = new ArrayList<>();//在类型比吧中的非static field


    private HashMap<String, HashSet<String>> classinit2field = new HashMap<>();//应该添加的init函数

    public GenerateDataGraphWithAllInfo(String path, HashMap<String, ArrayList<String>> callGraph) throws IOException {

        JarFile jar = new JarFile(path);
        Enumeration<JarEntry> enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                JavaClass clazz = classParser.parse();
                setfieldSet(clazz);
//                setInfo(clazz, fianlPack);

            }
        }
        enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                JavaClass clazz = classParser.parse();
//                setfieldSet(clazz, fianlPack);
                setInfo(clazz);

            }
        }
        setDataGraph(callGraph);

    }



    public void setfieldSet(JavaClass clazz) {
        Field[] fieldInClass = clazz.getFields();
        for(Field f : fieldInClass){
            String className = clazz.getClassName();
            String fieldName = f.getName();
            String t = className + "." + fieldName;

            this.fieldSet.add(t);
            String fieldInfo = f.toString();
            if(fieldInfo.contains("static")){
                this.staticField.add(t);
            }else{
                this.noStaticField.add(t);
            }
        }
    }

    public void setInfo(JavaClass clazz) {
        String className = clazz.getClassName();
        Method[] methods = clazz.getMethods();

        for(Method method : methods){
            String argutype = "";
            Type[] paratype = method.getArgumentTypes();
            for (Type t : paratype) {
                argutype = argutype + t.toString() + ",";
            }

            if (argutype.length() != 0) {
                argutype = argutype.substring(0, argutype.length() - 1);
            } else {
                argutype = "";
            }

            String methodSig = className + ":" + method.getReturnType().toString() + " " + method.getName() + "(" + argutype + ")";


            if((method.getName().equals("init") || method.getName().equals("clinit"))){
                setClassinit2field(method, methodSig, className);//记录应该调用的init函数
                continue;
            }
            setReturnFuncList(method, methodSig);//记录应该添加return的函数

            if(method.getCode() != null){
                setField2Func(method.getCode().toString(), methodSig);//记录函数和filed的关系
            }

        }
    }


    public void setClassinit2field(Method method, String methodSig, String className) {
        //处理应该被调用的初始化函数
        LocalVariableTable localVariableTable = method.getLocalVariableTable();
        if (localVariableTable == null) {
            return;
        }
        String[] localVariableTableStrList = localVariableTable.toString().split("\n");
        HashSet<String> fieldinit = new HashSet<>();
        for(String str : localVariableTableStrList){
            String[] temp = str.split(" ");
            String name = temp[temp.length - 1].replace(")","");
            if(name.equals("this")){
                continue;
            }
            name = className + "." + name;
            if(this.noStaticField.contains(name) || this.staticField.contains(name)){
                fieldinit.add(name);
            }
        }
        if(fieldinit.size() != 0){
            this.classinit2field.put(methodSig, fieldinit);
        }

    }

    public void setReturnFuncList(Method method, String methodSig) {
        Type retType = method.getReturnType();
        if(method.getCode()!= null && method.getCode().toString().contains("return") && ! retType.toString().equals("void") && method.getGenericSignature() != null){
            this.returnFuncList.add(methodSig);

        }
    }

    public void setField2Func(String methodCode, String methodSig) {
        String[] methodcodelist = methodCode.split("\n");
        for(int i = 0; i < methodcodelist.length; i++){
            if(methodcodelist[i].contains("putstatic") || methodcodelist[i].contains("putfield") ){
                String line = methodcodelist[i].replace("\n","").replaceAll("\t+"," ").replaceAll(" +"," ");
                String field = line.split(" ")[2];
//                if(field.equals("org.basex.data.MetaData.path")){
//                    System.out.println("yes");
//                }
                if(this.staticField.contains(field) || this.noStaticField.contains(field)){
                    ArrayList<String> temp = new ArrayList<>();
                    if(this.field2Func.containsKey(methodSig)){
                        temp = this.field2Func.get(methodSig);
                    }
                    temp.add(field);
                    this.field2Func.put(methodSig, temp);
                }
            }
            else if(methodcodelist[i].contains("getstatic") || methodcodelist[i].contains("getfield")){
                String line = methodcodelist[i].replace("\n","").replaceAll("\t+"," ").replaceAll(" +"," ");
                String field = line.split(" ")[2];

                if(this.staticField.contains(field) || this.noStaticField.contains(field)){
                    ArrayList<String> temp = new ArrayList<>();
                    if(this.field2Func.keySet().contains(field) ){
                        temp = this.field2Func.get(field);

                    }
                    temp.add(methodSig);
                    this.field2Func.put(field, temp);
                }
            }
        }
    }

    public void setDataGraph(HashMap<String, ArrayList<String>> callGraph){
        LibFuncInfo libFuncInfo = new LibFuncInfo();
        ArrayList<String> rtlib = libFuncInfo.getRtlib();
        for(String rt : rtlib){
            this.returnFuncList.add(rt);
        }
        HashMap<String, ArrayList<String>> dataGraph = new HashMap<>();
        setDataGraphCalledge(dataGraph, callGraph, rtlib);
        setDataGraphReturnedge(dataGraph, callGraph);
        setDataGraphFieldedge(dataGraph);
        this.dataGraph = dataGraph;

    }


    public void setDataGraphCalledge(HashMap<String, ArrayList<String>> dataGraph, HashMap<String, ArrayList<String>> callGraph, ArrayList<String> rtlib){
        for(String key : callGraph.keySet()){
            for(String val : callGraph.get(key)){
                //如果被调用函数为我们关心的库函数这inLibFlag=true
                boolean inLibFlag = false;
                for(String lib : rtlib){
                    if(lib.equals(val)){
                        inLibFlag = true;
                        break;
                    }
                }

                boolean inCallFuncList = true;

                boolean inInitFuncList = false;
                if(val.contains("<init>") || val.contains("<clinit>")){
                    if(this.classinit2field.containsKey(val)){
                        inInitFuncList = true;
                        if(this.classinit2field.containsKey(val)){
                            for(String f : this.classinit2field.get(val)){
                                ArrayList<String> tmp = new ArrayList<>();
                                if(dataGraph.containsKey(val)){
                                    tmp = dataGraph.get(val);
                                }
                                tmp.add(f);
                                dataGraph.put(val, tmp);
                            }
                        }
                    }
                }

                if(inLibFlag || inCallFuncList || inInitFuncList){
                    ArrayList<String> tempList = new ArrayList<>();
                    if(dataGraph.containsKey(key)){
                        tempList = dataGraph.get(key);
                    }
                    tempList.add(val);
                    dataGraph.put(key, tempList);
                }
            }
        }
    }

    public void setDataGraphReturnedge(HashMap<String, ArrayList<String>> dataGraph, HashMap<String, ArrayList<String>> callGraph){
        for(String key : callGraph.keySet()){
            for(String val : callGraph.get(key)){ //遍历所有的被调用函数
                if(this.returnFuncList.contains(val)){ //如果return的值是闭包中的，则需要在被调用函数和该函数之间加
                    ArrayList<String> temp = new ArrayList<>();
                    if(dataGraph.containsKey(val)){
                        temp = dataGraph.get(val);
                    }
                    temp.add(key);
                    dataGraph.put(val, temp);
                }
            }
        }

    }

    public void setDataGraphFieldedge(HashMap<String, ArrayList<String>> dataGraph){
        for(String key : this.field2Func.keySet()){ //遍历全局变量
            ArrayList<String> temp = new ArrayList<>();
            if(dataGraph.containsKey(key)){
                temp = dataGraph.get(key);
            }
            for(String val : this.field2Func.get(key)){
                temp.add(val);
            }
            if(temp.size() != 0){
                dataGraph.put(key, temp);
            }
        }
    }

    public HashMap<String, ArrayList<String>> getDataGraph() {
        return this.dataGraph;
    }

}
