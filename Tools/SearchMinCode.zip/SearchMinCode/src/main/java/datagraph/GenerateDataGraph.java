package datagraph;

import libfunc.LibFuncInfo;
import org.apache.bcel.classfile.*;
import org.apache.bcel.generic.Type;

import java.io.IOException;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GenerateDataGraph {

    private HashMap<String, ArrayList<String>> dataGraph = new HashMap<>();
    private HashMap<String, ArrayList<String>> dataGraph_removereturn = new HashMap<>();

    private HashMap<String, ArrayList<String>> dataGraphT = new HashMap<>();
    private HashMap<String, ArrayList<String>> field2Func = new HashMap<>();//field和函数之间的调用关系



    private ArrayList<String> callFuncList = new ArrayList<>(); //可以添加调用边的图
    private ArrayList<String> returnFuncList = new ArrayList<>(); //可以添加return边的图
    private HashSet<String> GenericTypeList = new HashSet<>();//常见的泛型
    private HashSet<String> fieldSet = new HashSet<>();//在类型闭包中的field
    private ArrayList<String> staticField = new ArrayList<>();//在类型闭包中的static field
    private ArrayList<String> noStaticField = new ArrayList<>();//在类型比吧中的非static field


    private HashMap<String, HashSet<String>> classinit2field = new HashMap<>();//应该添加的init函数


    public String gettype(String strline, String p, HashSet<String> methodpara){
        String pattern = p + "<(.*)>";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(strline);
        String revalue = null;
        if(m.find()){
            revalue = m.group(m.groupCount());
            revalue = revalue.replace("<?, ?>", "");
            if(revalue.contains("<") && !revalue.contains(">")){
                revalue = revalue.replace("<", "");
            }else if(revalue.contains(">") && !revalue.contains("<")){
                revalue = revalue.replace(">","");
            }
            if(revalue.contains(",")){
                String[] s = revalue.split(", ");
                for(String ss : s){
                    methodpara.add(ss);
                    revalue = ss;
                }
            }else{
                methodpara.add(revalue);
            }
        }

        for(String s : this.GenericTypeList){
            if(revalue != null && revalue.contains(s)){
                methodpara.add(s);
                methodpara.remove(revalue);
                gettype(revalue, s, methodpara);
            }
        }

        return revalue;
    }

    public GenerateDataGraph(HashSet<String> fianlPack, String path, HashMap<String, ArrayList<String>> callGraph) throws IOException {
        this.GenericTypeList.add("java.util.ArrayList");
        this.GenericTypeList.add("java.util.LinkedList");
        this.GenericTypeList.add("java.util.HashSet");
        this.GenericTypeList.add("java.util.TreeSet");
        this.GenericTypeList.add("java.util.HashMap");
        this.GenericTypeList.add("java.util.TreeMap");
        this.GenericTypeList.add("java.util.Hashtable");
        this.GenericTypeList.add("java.util.concurrent.ArrayBlockingQueue");
        this.GenericTypeList.add("java.util.List");

        JarFile jar = new JarFile(path);
        Enumeration<JarEntry> enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                JavaClass clazz = classParser.parse();
                setfieldSet(clazz, fianlPack);
//                setInfo(clazz, fianlPack);

            }
        }
        enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                JavaClass clazz = classParser.parse();
//                setfieldSet(clazz, fianlPack);
                setInfo(clazz, fianlPack);

            }
        }
        setDataGraph(callGraph);

    }



    public void setfieldSet(JavaClass clazz, HashSet<String> finalPack) {
        Field[] fieldInClass = clazz.getFields();
        for(Field f : fieldInClass){
            HashSet<String> fieldTypeSet = new HashSet<>();//存储每个field的类型
            if(f.getGenericSignature() != null){
                for(String GType : this.GenericTypeList){
                    String fieldStr = f.getGenericSignature().substring(1).replace("<L", "<").replace("/", ".").replace(";", "");
                    if (fieldStr.contains(GType)) {
                        fieldTypeSet.add(GType);
                        gettype(fieldStr, GType, fieldTypeSet);
                    }
                }
            }
            String fieldType = f.getType().toString().replace("[]","");
            fieldTypeSet.add(fieldType);

            String className = clazz.getClassName();
            String fieldName = f.getName();
            String t = className + "." + fieldName;

            for(String type : fieldTypeSet){
                if(finalPack.contains(type) || fieldTypeSet.contains("TT")){
                    this.fieldSet.add(t);
                    String fieldInfo = f.toString();
                    if(fieldInfo.contains("static")){
                        this.staticField.add(t);
                    }else{
                        this.noStaticField.add(t);
                    }
                    break;
                }
            }
        }
    }

    public void setInfo(JavaClass clazz, HashSet<String> finalPack) {
        String className = clazz.getClassName();
        Method[] methods = clazz.getMethods();

        for(Method method : methods){
            String argutype = "";
            Type[] paratype = method.getArgumentTypes();
            for (Type t : paratype) {
                argutype = argutype + t.toString() + ",";
            }

            if (argutype.length() != 0) {
                argutype = argutype.substring(0, argutype.length() - 1);
            } else {
                argutype = "";
            }

            String methodSig = className + ":" + method.getReturnType().toString() + " " + method.getName() + "(" + argutype + ")";

            if(method.getCode() != null){
                setField2Func(method.getCode().toString(), methodSig);//记录函数和filed的关系
            }

//            if((method.getName().equals("init") || method.getName().equals("clinit"))){
//                setClassinit2field(method, methodSig, className);//记录应该调用的init函数
//                continue;
//            }
            setFuncpara2Type(method, methodSig, finalPack); //记录应该添加call的函数
            setReturnFuncList(method, methodSig, finalPack);//记录应该添加return的函数



        }
    }

    public void setFuncpara2Type(Method method, String methodsig, HashSet<String> finalPack) {
        Type[] paratype = method.getArgumentTypes();
        HashSet<String> paraSet = new HashSet<>();
        for (Type t : paratype) {
            String tm = t.toString().replace("[]", "");
            if (!tm.equals("void")) {
                paraSet.add(tm);
            }

        }
        //接下来处理当参数为泛型的情况
        Attribute[] alist = method.getAttributes();
        if(alist.length != 0){
            String astr = alist[0].toString();
            if (astr.contains("LocalVariableTypes")) {
                String[] astrlist = astr.split("\n");
                for (String tempstr : astrlist) {
                    if (tempstr.contains("LocalVariableTypes") && (tempstr.contains("start_pc = 0") || tempstr.contains("startPc = 0"))) {
                        for (String temp_setlist : this.GenericTypeList) {
                            if (tempstr.contains(temp_setlist)) {
                                paraSet.add(temp_setlist);
                                gettype(tempstr, temp_setlist, paraSet);
                            }
                        }
                    }
                }
            }
        }

        for(String p : paraSet){
            if(finalPack.contains(p) || paraSet.contains("TT")){
                this.callFuncList.add(methodsig);
                break;
            }
        }

    }

    public void setClassinit2field(Method method, String methodSig, String className) {
        //处理应该被调用的初始化函数
        LocalVariableTable localVariableTable = method.getLocalVariableTable();
        if (localVariableTable == null) {
            return;
        }
        String[] localVariableTableStrList = localVariableTable.toString().split("\n");
        HashSet<String> fieldinit = new HashSet<>();
        for(String str : localVariableTableStrList){
            String[] temp = str.split(" ");
            String name = temp[temp.length - 1].replace(")","");
            if(name.equals("this")){
                continue;
            }
            name = className + "." + name;
            if(this.noStaticField.contains(name) || this.staticField.contains(name)){
                fieldinit.add(name);
            }
        }
        if(fieldinit.size() != 0){
            this.classinit2field.put(methodSig, fieldinit);
        }

    }

    public void setReturnFuncList(Method method, String methodSig, HashSet<String> finalPack) {
//        if(methodSig.equals("org.eclipse.jetty.server.handler.ContextHandlerCollection:org.eclipse.jetty.server.Handler[] getHandlers()")){
//            System.out.println("yes");
//        }
        HashSet<String> returnTypeSet = new HashSet<>();
        Type retType = method.getReturnType();
        if(method.getCode()!= null && method.getCode().toString().contains("return") && ! retType.toString().equals("void") && method.getGenericSignature() != null){
            String returnType1 = method.getGenericSignature().split("\\)")[1].replace("<L","<").replace("/",".").replace(";","");
            String returnType2 = retType.toString().replace("[]","");
            returnTypeSet.add(returnType2);
            for (String gtemp : this.GenericTypeList) {
                if (returnType1.contains(gtemp)) {
                    returnTypeSet.add(gtemp);
                    gettype(returnType1, gtemp, returnTypeSet);
                }
            }

        }
        returnTypeSet.add(method.getReturnType().toString());
        for(String returntype : returnTypeSet){
            if(finalPack.contains(returntype) || returnTypeSet.contains("TT")){
                this.returnFuncList.add(methodSig); //如果return的类型在闭包中，才加入到应该添加回边的returnmethod中
                break;
            }
        }

    }

    public void setField2Func(String methodCode, String methodSig) {
        String[] methodcodelist = methodCode.split("\n");
        for(int i = 0; i < methodcodelist.length; i++){
            if(methodcodelist[i].contains("putstatic") || methodcodelist[i].contains("putfield") ){
                String line = methodcodelist[i].replace("\n","").replaceAll("\t+"," ").replaceAll(" +"," ");
                String field = line.split(" ")[2];
//                if(field.equals("org.basex.data.MetaData.path")){
//                    System.out.println("yes");
//                }
                if(this.staticField.contains(field) || this.noStaticField.contains(field)){
                    ArrayList<String> temp = new ArrayList<>();
                    if(this.field2Func.containsKey(methodSig)){
                        temp = this.field2Func.get(methodSig);
                    }
                    temp.add(field);
                    this.field2Func.put(methodSig, temp);
                }
            }
            else if(methodcodelist[i].contains("getstatic") || methodcodelist[i].contains("getfield")){
                String line = methodcodelist[i].replace("\n","").replaceAll("\t+"," ").replaceAll(" +"," ");
                String field = line.split(" ")[2];

                if(this.staticField.contains(field) || this.noStaticField.contains(field)){
                    ArrayList<String> temp = new ArrayList<>();
                    if(this.field2Func.keySet().contains(field) ){
                        temp = this.field2Func.get(field);

                    }
                    temp.add(methodSig);
                    this.field2Func.put(field, temp);
                }
            }
        }
    }

    public void setDataGraph(HashMap<String, ArrayList<String>> callGraph){
        LibFuncInfo libFuncInfo = new LibFuncInfo();
        ArrayList<String> rtlib = libFuncInfo.getRtlib();
//        for(String rt : rtlib){
//            this.returnFuncList.add(rt);
//        }
        HashMap<String, ArrayList<String>> dataGraph = new HashMap<>();
        setDataGraphCalledge(dataGraph, callGraph, rtlib);
        setDataGraphReturnedge(dataGraph, callGraph);
        setDataGraphFieldedge(dataGraph);
        this.dataGraph = dataGraph;

        HashMap<String, ArrayList<String>> dataGraph_removereturn = new HashMap<>();
        setDataGraphCalledge(dataGraph_removereturn, callGraph, rtlib);
        setDataGraphFieldedge(dataGraph_removereturn);
        this.dataGraph_removereturn = dataGraph_removereturn;

    }


    public void setDataGraphCalledge(HashMap<String, ArrayList<String>> dataGraph, HashMap<String, ArrayList<String>> callGraph, ArrayList<String> rtlib){
        for(String key : callGraph.keySet()){
            for(String val : callGraph.get(key)){
                //如果被调用函数为我们关心的库函数这inLibFlag=true
                boolean inLibFlag = false;
//                for(String lib : rtlib){
//                    if(lib.equals(val)){
//                        inLibFlag = true;
//                        break;
//                    }
//                }

                boolean inCallFuncList = false;
                if(this.callFuncList.contains(val)){ //如果被调用函数中有参数
                    inCallFuncList = true;
                }

                boolean inInitFuncList = false;
                if(val.contains("<init>") || val.contains("<clinit>")){
                    if(this.classinit2field.containsKey(val)){
                        inInitFuncList = true;
                        if(this.classinit2field.containsKey(val)){
                            for(String f : this.classinit2field.get(val)){
                                ArrayList<String> tmp = new ArrayList<>();
                                if(dataGraph.containsKey(val)){
                                    tmp = dataGraph.get(val);
                                }
                                tmp.add(f);
                                dataGraph.put(val, tmp);
                            }
                        }
                    }
                }

                if(inLibFlag || inCallFuncList || inInitFuncList){
                    ArrayList<String> tempList = new ArrayList<>();
                    if(dataGraph.containsKey(key)){
                        tempList = dataGraph.get(key);
                    }
                    tempList.add(val);
                    dataGraph.put(key, tempList);
                }
            }
        }
    }

    public void setDataGraphReturnedge(HashMap<String, ArrayList<String>> dataGraph, HashMap<String, ArrayList<String>> callGraph){
        for(String key : callGraph.keySet()){
            for(String val : callGraph.get(key)){ //遍历所有的被调用函数
                if(this.returnFuncList.contains(val)){ //如果return的值是闭包中的，则需要在被调用函数和该函数之间加
                    ArrayList<String> temp = new ArrayList<>();
                    if(dataGraph.containsKey(val)){
                        temp = dataGraph.get(val);
                    }
                    temp.add(key);
                    dataGraph.put(val, temp);
                }
            }
        }

    }

    public void setDataGraphFieldedge(HashMap<String, ArrayList<String>> dataGraph){
        for(String key : this.field2Func.keySet()){ //遍历全局变量
            ArrayList<String> temp = new ArrayList<>();
            if(dataGraph.containsKey(key)){
                temp = dataGraph.get(key);
            }
            for(String val : this.field2Func.get(key)){
                temp.add(val);
            }
            if(temp.size() != 0){
                dataGraph.put(key, temp);
            }
        }
    }

    public HashMap<String, ArrayList<String>> getDataGraph() {
        return this.dataGraph;
    }


    public HashMap<String, ArrayList<String>> getDataGraph_removereturn() {
        return this.dataGraph_removereturn;
    }


    public HashMap<String, ArrayList<String>> getDataGraphT() {
        for (String node : this.dataGraph.keySet()) {
            for (String value : this.dataGraph.get(node)) {
                ArrayList<String> t = new ArrayList<>();
                if (this.dataGraphT.keySet().contains(value)) {
                    t = this.dataGraphT.get(value);
                }
                t.add(node);
                this.dataGraphT.put(value, t);
            }
        }
        return this.dataGraphT;
    }

    public ArrayList<String> getCallFuncList() {
        return callFuncList;
    }
    public ArrayList<String> getReturnFuncList() {
        return returnFuncList;
    }
}
