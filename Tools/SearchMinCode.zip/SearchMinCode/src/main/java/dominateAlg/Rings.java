package dominateAlg;

import javafx.util.Pair;

import java.util.*;

public class Rings {


    /***
     * 得到所有的环
     * @param g 图
     * @param node 遍历起点
     * @param visited 是否被访问过
     * @param pre 当前路径
     * @param ringsList 所有的环
     * @param nodeinRing 环中所有的节点
     */
    public void getRing_dfs(HashMap<String, ArrayList<String>> g, String node, HashSet<String> visited, ArrayList<String> pre, ArrayList<ArrayList<String>> ringsList, HashSet<String> nodeinRing){

        if(!g.containsKey(node)) {
            return;
        }
        visited.add(node);
        pre.add(node);

        for(String value : g.get(node)){
            if(pre.contains(value) && visited.contains(value)){
                ArrayList<String> temp = new ArrayList<>();
                int start = pre.indexOf(value);
                int end = pre.size() - 1;
                for(int i = start; i <= end; i++){
                    String t = pre.get(i);
                    temp.add(t);
                    nodeinRing.add(t);
                }
                ringsList.add(temp);
            }
            else if(visited.contains(value) && !pre.contains(value)){
                if(nodeinRing.contains(value)){
                    f : for(String n : pre){
                        for(ArrayList<String> t : ringsList){
                            if(t.contains(n) && t.contains(value)){
                                int fromIndex = t.indexOf(value);
                                int toIndex = t.indexOf(n);
                                ArrayList<String> result = new ArrayList<>();
                                if(fromIndex > toIndex){
                                    List<String> result1 = t.subList(fromIndex, t.size());
                                    List<String> result2 = t.subList(0, toIndex + 1);
                                    result.addAll(result1);
                                    result.addAll(result2);
                                }
                                else{
                                    List<String> result3 = t.subList(fromIndex, toIndex + 1);
                                    result.addAll(result3);
                                }
                                int start = pre.indexOf(n);
                                int end = pre.size() - 1;
                                for(int i = start + 1; i <= end; i++){
                                    String tt = pre.get(i);
                                    result.add(tt);
                                    nodeinRing.add(tt);
                                }
                                ringsList.add(result);
                                break f;
                            }
                        }
                    }
                }
            }
            else{
                getRing_dfs(g, value, visited, pre, ringsList, nodeinRing);
            }
        }
        pre.remove(pre.size() - 1);
    }

    /**
     * 去除重复环
     * @param paths 所有环
     */
    public ArrayList<ArrayList<String>> duplicate(ArrayList<ArrayList<String>> paths){
        int end = paths.size();
        HashSet<Integer> indexlist = new HashSet<>();
        ArrayList<ArrayList<String>> newPaths = new ArrayList<>();
        for(int i = 0; i < end; i++){
            for(int j = i + 1; j < end; j++){
                HashSet<String> set1 = new HashSet<>(paths.get(i));
                HashSet<String> set2 = new HashSet<>(paths.get(j));
                if (set1.equals(set2)) {
                    indexlist.add(j);
                }
            }
        }
        for(int i = 0; i < end; i++){
            if(!indexlist.contains(i)){
                newPaths.add(paths.get(i));
            }
        }
        return  newPaths;
    }
    /**
     * 合并环，根据若干个环新建得到一个无向图，然后bfs遍历得到若干连通分量
     * @param rings 包含所有环
     * @return 返回大环的名字与环中节点的对应关系
     */
    public ArrayList<HashSet<String>> UnionRing(ArrayList<ArrayList<String>> rings, HashSet<String> nodesInRing){
        HashMap<String, HashSet<String>> graph = new HashMap<>(nodesInRing.size());
        for(ArrayList<String> ring : rings){
            for(int i=0;i<ring.size();i++){
                String curNode = ring.get(i);
                String nextNode = i==ring.size()-1?ring.get(0):ring.get(i+1);
                if (graph.containsKey(curNode)){
                    graph.get(curNode).add(nextNode);
                }else {
                    HashSet<String> newHashSet = new HashSet<>();
                    newHashSet.add(nextNode);
                    graph.put(curNode, newHashSet);
                }
            }
        }
        assert graph.keySet().size()==nodesInRing.size();
        //开始用bfs遍历上述根据环建立的无向图
        HashMap<String, Boolean> visited = new HashMap<>(nodesInRing.size());
        for (String node:nodesInRing){
            visited.put(node, false);
        }
        ArrayList<HashSet<String>> result = new ArrayList<>();
        for (String node:nodesInRing){
            if (!visited.get(node)){
                //每次进入该if条件，都意味着有一个新的连通分量被添加到结果集中
                HashSet<String> component = new HashSet<>();
                _bfs(graph, visited, component, node);
                result.add(component);
            }
        }
        return result;
    }

    public void _bfs(HashMap<String, HashSet<String>> graph, HashMap<String, Boolean> visited, HashSet<String> component, String startNode){
        Queue<String> queue = new LinkedList<>();
        queue.add(startNode);
        while (!queue.isEmpty()){
            String headNode = queue.poll();
            component.add(headNode);
            visited.put(headNode, true);
            if (graph.get(headNode).size()!=0){
                for(String child:graph.get(headNode)){
                    if (!visited.get(child)){
                        queue.add(child);
                    }
                }
            }
        }

    }

    /**
     * 检查所有的环，返回所有可作为起始点的环
     * @param rings
     * @param grapht
     * @return
     */
    public ArrayList<HashSet<String>> checkRingCanBeStart(ArrayList<HashSet<String>> rings, HashMap<String, ArrayList<String>> grapht){
        ArrayList<HashSet<String>> startRing = new ArrayList<>();
        for(HashSet<String> ring : rings){
            boolean isRingCanBeStart = true;
            for(String n : ring) {
                assert grapht.containsKey(n);
                ArrayList<String> parentNodes = grapht.get(n);
                for(String s:parentNodes){
                    if (!ring.contains(s)){
                        isRingCanBeStart = false;
                        break;
                    }
                }
                if (!isRingCanBeStart){
                    break;
                }
            }
            if (isRingCanBeStart){
                startRing.add(ring);
            }
        }
        return startRing;
    }

    public HashMap<String, HashSet<String>> useOneNodeReplaceStartRing(ArrayList<HashSet<String>> startRings, HashMap<String, ArrayList<String>> graph){
        int counter = 1;
        HashMap<String, HashSet<String>> newNodeNameRingMapping = new HashMap<>();
        for(HashSet<String> ring : startRings){
            //无需找父节点，因为能作为起始点的环中节点没有除了环中节点之外的父节点
            //对于一个环路，找到所有的节点，这些节点是环中任一节点的子节点
            String newNodeName = "[NewNode]"+counter;
            newNodeNameRingMapping.put(newNodeName, ring);
            HashSet<String> allChildrenOfRing = new HashSet<>();
            for (String node:ring){
                assert graph.containsKey(node);
                allChildrenOfRing.addAll(graph.get(node));
                graph.remove(node);
            }
            ArrayList<String> childrenOfNewNode = new ArrayList<>();
            for(String n:allChildrenOfRing){
                if (!ring.contains(n)){
                    childrenOfNewNode.add(n);
                }
            }
            graph.put(newNodeName, childrenOfNewNode);
            counter++;
        }
        return newNodeNameRingMapping;
    }

    public HashMap<String, HashSet<String>> useOneNodeReplaceStartRing_forallring(ArrayList<HashSet<String>> startRings, HashMap<String, ArrayList<String>> graph){
        int counter = 1;
        HashMap<String, HashSet<String>> newNodeNameRingMapping = new HashMap<>();
        for(HashSet<String> ring : startRings){

            String newNodeName = "[NewNode]"+counter;
            newNodeNameRingMapping.put(newNodeName, ring);
            HashSet<String> allChildrenOfRing = new HashSet<>();
            for (String node:ring){
                if(graph.containsKey(node)){
                    allChildrenOfRing.addAll(graph.get(node));
                }

                for(String key : graph.keySet()){
                    if(graph.get(key).contains(node)){
                        ArrayList<String> temp = graph.get(key);
                        temp.remove(node);
                        temp.add(newNodeName);
                        graph.put(key, temp);
                    }
                }

                graph.remove(node);
            }
            ArrayList<String> childrenOfNewNode = new ArrayList<>();
            for(String n:allChildrenOfRing){
                if (!ring.contains(n)){
                    childrenOfNewNode.add(n);
                }
            }
            graph.put(newNodeName, childrenOfNewNode);
            counter++;
        }
        return newNodeNameRingMapping;
    }

    /**
     * 只将起点在环中时将环合并
     * @param graph
     * @param grapht
     * @param startRings
     * @return
     */
    public Pair<HashMap<String, ArrayList<String>>, HashMap<String, HashSet<String>>> Ring_exec(HashMap<String, ArrayList<String>> graph, HashMap<String, ArrayList<String>> grapht, ArrayList<HashSet<String>> startRings){
        HashSet<String> nodeinRing = new HashSet<>();
        ArrayList<ArrayList<String>> rings = new ArrayList<>();
        HashSet<String> visited = new HashSet<>();
        for(String node : graph.keySet()){
            if(!visited.contains(node)){
                getRing_dfs(graph, node, visited, new ArrayList<String>(), rings, nodeinRing);
            }
        }
        HashSet<String> nodes = new HashSet<>(new ArrayList<String>(nodeinRing));

        ArrayList<HashSet<String>> res = UnionRing(rings, nodes);

        startRings = checkRingCanBeStart(res, grapht);
//        System.out.println("startRings:");
//        System.out.println(startRings);


        HashMap<String, ArrayList<String>> newgraph = new HashMap<>();
        for(String key : graph.keySet()){
            ArrayList<String> value = new ArrayList<>(graph.get(key));
            newgraph.put(key, value);
        }
        HashMap<String, HashSet<String>> newNodeNameRingMapping = useOneNodeReplaceStartRing(startRings, newgraph);
//        System.out.println("new graph:");
//        System.out.println(newgraph);

//        System.out.println("newNodeNameRingMapping:");
//        System.out.println(newNodeNameRingMapping);

        return new Pair(newgraph, newNodeNameRingMapping);
    }

    /**
     * 去除图中的所有环
     * @param graph
     * @return
     */

    public Pair<HashMap<String, ArrayList<String>>, HashMap<String, HashSet<String>>> Ring_exec_removeRing(HashMap<String, ArrayList<String>> graph){
        HashSet<String> nodeinRing = new HashSet<>();
        ArrayList<ArrayList<String>> rings = new ArrayList<>();//存储所有环
        HashSet<String> visited = new HashSet<>();
        for(String node : graph.keySet()){
            if(!visited.contains(node)){
                getRing_dfs(graph, node, visited, new ArrayList<String>(), rings, nodeinRing);
            }
        }

        HashSet<String> nodes = new HashSet<>(new ArrayList<String>(nodeinRing));//在环中的节点

        ArrayList<HashSet<String>> res = UnionRing(rings, nodes);

        HashMap<String, ArrayList<String>> newgraph = new HashMap<>();
        for(String key : graph.keySet()){
            ArrayList<String> value = new ArrayList<>(graph.get(key));
            newgraph.put(key, value);
        }

        HashMap<String, HashSet<String>> newNodeNameRingMapping = useOneNodeReplaceStartRing_forallring(res, newgraph);

        return new Pair(newgraph, newNodeNameRingMapping);
    }

}
