package dominateAlg;

import javafx.util.Pair;

import java.util.*;

public class DominantPoint {
    /** 寻找没有父节点的图中的节点，即求支配点的起点
     * @param g 所需遍历的图
     * @param node 起点
     * @param visited 已经遍历的节点集合
     * @param result 表示没有父节的节点集合
     */
    public void dfs(HashMap<String, ArrayList<String>> g, String node, HashSet<String> visited, HashSet<String> result){
        visited.add(node);
        if(g.containsKey(node)){
            for(String value : g.get(node)){
                if(!g.containsKey(value)){
                    result.add(value);
                }
                if(visited.contains(value)){
                    continue;
                }
                else{
                    dfs(g, value, visited, result);
                }
            }
        }
        else{
            result.add(node);
        }
    }

    /**
     * 在大图中通过深度优先搜索，得到与已知点联通的子图，
     * @param g 原图
     * @param startNode 已知点
     * @param visited 记录是否被访问
     * @param endNode 终点
     * @param subg 子图
     */
    public void dfs_getGraph(HashMap<String, ArrayList<String>> g, String startNode, HashSet<String> visited, String endNode, HashMap<String, ArrayList<String>> subg){
        visited.add(startNode);
        if(g.containsKey(startNode)){
            subg.put(startNode, new ArrayList<String>());
            for(String value : g.get(startNode)){
                subg.get(startNode).add(value);
                if(visited.contains(value) || value.equals(endNode)){
                    continue;
                }
                else{
                    dfs_getGraph(g, value, visited, endNode, subg);
                }
            }
        }
    }

    /**
     * 求在子图上起点到终点的各个点的可支配点
     * @param g 求哪个图中的可支配点 正图
     * @param gt 旋转后的图
     * @param startNode 起点
     * @param endNode 终点 已知点
     * @param nodeName2index 节点名到索引之间的映射
     * @param nodeName2dominantpoints 节点名到可支配点集合之间的映射
     */
    public void bfsforDominant(HashMap<String, ArrayList<String>> g, HashMap<String, ArrayList<String>> gt, String startNode, String endNode,
                               HashMap<String, Integer> nodeName2index, HashMap<String, HashSet<String>> nodeName2dominantpoints){
        //节点编号
        Integer index = 0;
        //存储访问的节点
        Queue<String> queue = new LinkedList<>();
        //存储访问过得节点
        HashSet<String> visite = new HashSet<>();

        queue.add(startNode);
//        visite.add(startNode);

        while (!queue.isEmpty()) {
            //队列头结点出队
            String node = queue.poll();
//            System.out.println(node);
            visite.add(node);
            index = index + 1;
            nodeName2index.put(node, index);
            if(gt.containsKey(node)){
                HashSet<String> dominantPoint = new HashSet<>(); //node节点的可支配节点
                //通过统计若干set中元素的数目，得到若干set的并集
                HashMap<String, Integer> tempMap = new HashMap<>();
                int setCounter = 0;
                for(String vNode : gt.get(node)){
                    if(nodeName2dominantpoints.containsKey(vNode)){
                        HashSet<String> temp = nodeName2dominantpoints.get(vNode);
                        setCounter++;
                        for (String s:temp) {
                            if (tempMap.keySet().contains(s)){
                                tempMap.put(s, tempMap.get(s)+1);
                            }else {
                                tempMap.put(s, 1);
                            }
                        }
                    }
                }
                for (String s:tempMap.keySet()){
                    if (tempMap.get(s)==setCounter){
                        dominantPoint.add(s);
                    }
                }

                dominantPoint.add(node);
                nodeName2dominantpoints.put(node, dominantPoint);
            }
            else{
                HashSet<String> dominantPoint = new HashSet<>();
                dominantPoint.add(node);
                nodeName2dominantpoints.put(node, dominantPoint);
            }

            if (g.containsKey(node)) {
                //获取所有的子节点
                ArrayList<String> valnode = g.get(node);
                if (valnode.size() != 0) {
                    for (String next : valnode) {
                        if (!visite.contains(next) && !queue.contains(next)) { //不包含说明没有没有被访问
                            queue.add(next);
                        }

                    }
                }
            }
            if(visite.contains(endNode)){
                return;
            }
        }
    }

    /**
     * 反转图
     * @param graph 原图
     * @return 反转后的图
     */
    public HashMap<String, ArrayList<String>> reverseGraph(HashMap<String, ArrayList<String>> graph) {
        HashMap<String, ArrayList<String>> reversedGraph = new HashMap<String, ArrayList<String>>();
        for (String key : graph.keySet()) {
            for (String val : graph.get(key)) {
                if (!reversedGraph.keySet().contains(val)) {
                    reversedGraph.put(val, new ArrayList<String>());
                }
                reversedGraph.get(val).add(key);
            }
        }
        return reversedGraph;
    }

    /**
     * 移除只有自循环边的循环边，因为这个点也可以作为起点
     * @param graph 原图
     * @return 移除只有自循环边的循环边后的图
     */
    public HashMap<String, ArrayList<String>> removeEdge(HashMap<String, ArrayList<String>> graph){
        HashMap<String, ArrayList<String>> graph_removeEdge = new HashMap<>();
        for(String key : graph.keySet()){
            if(!(graph.get(key).size() == 1 && graph.get(key).get(0).equals(key)))
            {
                graph_removeEdge.put(key, graph.get(key));
            }
        }
        return graph_removeEdge;
    }

    /**
     * 求已知点到直接支配点之间的所有路径，即所有经历的函数
     * @param graph 在该图中进行dfs
     * @param node 起始节点
     * @param endNode 终点
     * @param visited 记录是否被访问过
     * @param pre 记录当前经过的路径
     * @param dominatePointSet 结果集合set
     */
    private void dfs_getPaths(HashMap<String, ArrayList<String>> graph, String node, String endNode, HashSet<String> visited, ArrayList<String> pre, HashSet<String> dominatePointSet) {
        visited.add(node);
        pre.add(node);

        if (endNode.equals(node)) {
            dominatePointSet.addAll(pre);
            pre.remove(pre.size() - 1);
            return;
        }
        //遍历节点node的所有子节点
        if (graph.containsKey(node)) {
            for (String n : graph.get(node)) {
                if (dominatePointSet.contains(n)) {
                    visited.add(node);
                    dominatePointSet.addAll(pre);
                }
                if (!visited.contains(n)) {
                    dfs_getPaths(graph, n, endNode, visited, pre, dominatePointSet);
                }
            }
        }
        pre.remove(pre.size() - 1);
    }
    /**
     * 求两个节点的最近共同直接支配点的总执行函数
     * @param graph 图
     * @param fixmethodNode 修改函数
     * @param dataNode 一个数据点
     */
    public HashSet<String> getDominantPoints(HashMap<String, ArrayList<String>> graph, String fixmethodNode, String dataNode){
         /*
        1.以两点为起点，使用深度优先搜索算法得到无父节点的节点。
        2.求两点无父节点的节点的交集
        3.以交集中的点为起点，已知点为终点，求已知点的直接支配点
        4.求两个已知点的直接支配点的交集，并在交集中取最近支配点
        5.求最近支配点到两个已知点所经历的路径
     */

        HashSet<String> result = new HashSet<>();
        HashMap<String, ArrayList<String>> reverseg = reverseGraph(graph);
        HashMap<String, ArrayList<String>> g = removeEdge(reverseg);
        HashSet<String> fixmethodDfsResult = new HashSet<>();
        dfs(g, fixmethodNode, new HashSet<String>(), fixmethodDfsResult);

        HashSet<String> datamethodDfsResult = new HashSet<>();
        dfs(g, dataNode, new HashSet<String>(), datamethodDfsResult);

//        System.out.println("datamethodDfsResult is " + datamethodDfsResult);

        //两个深度优先搜索的结果求交集
        HashSet<String> startNodes = new HashSet<>();
        for(String node : fixmethodDfsResult){
            if(datamethodDfsResult.contains(node)){
                startNodes.add(node);
            }
        }
        for(String node : datamethodDfsResult){
            if(fixmethodDfsResult.contains(node)){
                startNodes.add(node);
            }
        }

        //遍历所有无父节点的节点，得到从无父节点到已知点的子图
//        int forNum = 0;
        for(String node : startNodes){

            HashMap<String, ArrayList<String>> subgraph = new HashMap<>();
            dfs_getGraph(graph, node, new HashSet<String>(), fixmethodNode, subgraph);



            HashMap<String, ArrayList<String>> subgrapht = new HashMap<>();
            subgrapht = reverseGraph(subgraph);


            HashMap<String, Integer> nodeName2index_fixmethodNode = new HashMap<>();
            HashMap<String, HashSet<String>> nodeName2dominantpoints_fixmethodNode = new HashMap<>();
            bfsforDominant(subgraph, subgrapht, node, fixmethodNode, nodeName2index_fixmethodNode, nodeName2dominantpoints_fixmethodNode);

            HashSet<String> dominantSet_fixmethodNode = nodeName2dominantpoints_fixmethodNode.get(fixmethodNode);

            //------------------------------------------

            HashMap<String, ArrayList<String>> subgraph_dataNode = new HashMap<>();
            dfs_getGraph(graph, node, new HashSet<String>(), dataNode, subgraph_dataNode);

            HashMap<String, ArrayList<String>> subgraph_dataNodet = new HashMap<>();
            subgraph_dataNodet = reverseGraph(subgraph_dataNode);

            HashMap<String, Integer> nodeName2index_dataNode = new HashMap<>();
            HashMap<String, HashSet<String>> nodeName2dominantpoints_dataNode = new HashMap<>();
            bfsforDominant(subgraph_dataNode, subgraph_dataNodet, node, dataNode, nodeName2index_dataNode, nodeName2dominantpoints_dataNode);

            HashSet<String> dominantSet_dataNode = nodeName2dominantpoints_dataNode.get(dataNode);

            //------------------------------------------
            HashSet<String> dominantSet = new HashSet<>();
            dominantSet.addAll(dominantSet_fixmethodNode);
            dominantSet.retainAll(dominantSet_dataNode);

//            System.out.println("dominantSet : " + dominantSet);

            Integer max = 0;
            for(String dominantNode : dominantSet){
                if(nodeName2index_fixmethodNode.containsKey(dominantNode)){
                    Integer temp = nodeName2index_fixmethodNode.get(dominantNode);
//                        if(max < temp && !temp.equals(nodeName2index_fixmethodNode.get(fixmethodNode))) {
                    if(max < temp) {
                        max = temp;
                    }
                }
            }
            HashMap<Integer, String> index2nodeName = new HashMap<>();
            for(String nodeName : nodeName2index_fixmethodNode.keySet()){
                if(index2nodeName.containsKey(nodeName)){
                    System.out.println("error");
                }
                else{
                    index2nodeName.put(nodeName2index_fixmethodNode.get(nodeName), nodeName);
                }
            }

            //这里是说限制支配点到数据点或修改函数的距离
//            boolean flag1 = false;
//            boolean flag2 = false;
//            Integer dis = 0;
//            Integer limit = 3;
//            DominantPoint n = new DominantPoint();
//            try {
//                n.distance(subgraph, index2nodeName.get(max), dataNode, dis, limit, new HashSet<String>());
//
//            }catch (StopMsgException e){
//                flag1 = true;
//            }
//            try {
//                n.distance(subgraph, index2nodeName.get(max), fixmethodNode, dis, limit, new HashSet<String>());
//
//            }catch (StopMsgException e){
//                flag2 = true;
//            }
            boolean flag1 = true;
            boolean flag2 = true;
            if(flag1 && flag2){
                result.add(index2nodeName.get(max));
            }
        }
        return result;
    }

    static class StopMsgException extends RuntimeException {
    }
    public void distance(HashMap<String, ArrayList<String>> graph, String node1, String node2, Integer dis, Integer limit, HashSet<String> visited){
        dis++;
        if(dis > limit){
            return;
        }
        if(graph.containsKey(node1) && !visited.contains(node1)){
            visited.add(node1);
            if(graph.get(node1).contains(node2)){
                throw new StopMsgException();
            }
            else{
                for (String child : graph.get(node1)){
                    distance(graph, child, node2, dis, limit, visited);
                }
            }
        }

        dis--;
    }

    public HashSet<String> domimantPoint_exec(HashMap<String, ArrayList<String>> graph, HashMap<String, ArrayList<String>> grapht,
                                   HashSet<String> datamethodNodes, String fixmethodNode){
        ArrayList<HashSet<String>> startRings = new ArrayList<>();

        Rings rings = new Rings();
        Pair<HashMap<String, ArrayList<String>>, HashMap<String, HashSet<String>>> p = rings.Ring_exec(graph, grapht, startRings);
        HashMap<String, ArrayList<String>> newgraph = p.getKey();
        HashMap<String, HashSet<String>> newNodeNameRingMapping = p.getValue();

        HashSet<String> startRingNodes = new HashSet<>();
        for (HashSet<String> startRing:startRings){
            startRingNodes.addAll(startRing);
        }
        if(startRingNodes.contains(fixmethodNode)){
            for(HashSet<String> ring : startRings){
                if(ring.contains(fixmethodNode)){
                    for(String key : newNodeNameRingMapping.keySet()){
                        if(newNodeNameRingMapping.get(key).equals(ring)){
                            fixmethodNode = key;
                            break;
                        }
                    }
                    break;
                }
            }
        }
        HashSet<String> resultAll = new HashSet<>();
        HashSet<String> resultDominant = new HashSet<>();
        HashSet<String> dataNodeHaveNoDominant = new HashSet<>();
        HashSet<String> dataNodeHaveDominant = new HashSet<>();
        for(String oneDataNode : datamethodNodes){
            HashSet<String> result = new HashSet<>();
            if(startRingNodes.contains(oneDataNode)){
                for(HashSet<String> ring : startRings){
                    if(ring.contains(oneDataNode)){
                        for(String key : newNodeNameRingMapping.keySet()){
                            if(newNodeNameRingMapping.get(key).equals(ring)){
                                oneDataNode = key;
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            result = getDominantPoints(newgraph, fixmethodNode, oneDataNode);
            for(String r : result){
                HashSet<String> dominatePointSet1 = new HashSet<>();
                HashSet<String> dominatePointSet2 = new HashSet<>();
                dfs_getPaths(graph, fixmethodNode, r, new HashSet<String>(), new ArrayList<String>(), dominatePointSet1);
                dfs_getPaths(graph, oneDataNode, r, new HashSet<String>(), new ArrayList<String>(), dominatePointSet2);
                if(dominatePointSet2.size() == 0){
                    dominatePointSet2.add(oneDataNode);
                }
                resultAll.addAll(dominatePointSet1);
                resultAll.addAll(dominatePointSet2);
            }
//            System.out.println(result);
            resultAll.addAll(result);
            if(result.size() != 0){
                resultDominant.addAll(result);
                dataNodeHaveDominant.add(oneDataNode);
            }else{
                dataNodeHaveNoDominant.add(oneDataNode);
            }


        }


//        System.out.println("the number of dominantPoints is " + resultDominant.size());
//        for(String r : resultDominant){
//            System.out.println(r);
//        }
//        System.out.println("-------------------------------------------------------");
//
//        resultAll.add(fixmethodNode);
//        System.out.println("the number of all functions is " + resultAll.size());
//        for(String r : resultAll){
//            System.out.println(r);
//        }
//        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//
//        System.out.println("the number of dataNodeHavaNoDominant is " + dataNodeHaveNoDominant.size());
//        for(String d : dataNodeHaveNoDominant){
//            System.out.println(d);
//        }
//
//        System.out.println("=========================================================");
//
//        System.out.println("the number of dataNodeHavaDominant is " + dataNodeHaveDominant.size());
//        for(String d : dataNodeHaveDominant){
//            System.out.println(d);
//        }
        return resultAll;
    }
}
