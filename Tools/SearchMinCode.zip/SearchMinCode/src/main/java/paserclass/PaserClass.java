package paserclass;

import com.sun.org.apache.bcel.internal.classfile.ClassParser;
import com.sun.org.apache.bcel.internal.classfile.JavaClass;
import com.sun.org.apache.bcel.internal.classfile.Method;
import com.sun.org.apache.bcel.internal.generic.Type;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class PaserClass {
    public HashSet<String> paserClass(HashSet<String> classNames, String jarPath) throws IOException {
        HashSet<String> initMethods = new HashSet<>();
        JarFile jar = new JarFile(new File(jarPath));
        // 处理当前jar包中的class文件
        Enumeration<JarEntry> enumeration = jar.entries();
        String methodsig = "";
        while (enumeration.hasMoreElements()) {
            JarEntry jarEntry = enumeration.nextElement();
            String jarEntryName = jarEntry.getName();
            if (!jarEntry.isDirectory() && jarEntryName.toLowerCase().endsWith(JavaCGConstants.EXT_CLASS)) {
                // 处理一个class文件
                ClassParser cp = new ClassParser(jarPath, jarEntryName);
                JavaClass javaClass = cp.parse();
                String parserClassName = javaClass.getClassName();
                if(classNames.contains(parserClassName)){
                    Method[] methods = javaClass.getMethods();
                    for(Method method : methods){
                        if(method.getName().equals("<init>") || method.getName().equals("<clinit>")){

                            String methodName = method.getName();
                            Type[] type = method.getArgumentTypes();
                            Type returntype = method.getReturnType();
                            String argutype = "";
                            for (Type t : type) {
                                argutype = argutype + t.toString() + ",";
                            }
                            if (argutype.length() != 0) {
                                argutype = argutype.substring(0, argutype.length() - 1);
                            } else {
                                argutype = "";
                            }
                            methodsig = javaClass.getClassName() + ":" + returntype.toString() + " " + methodName + "(" + argutype + ")";
//                            System.out.println(methodsig);
                            initMethods.add(methodsig);
                        }
                    }
                }
            }
        }
        return initMethods;
    }

    public static void main(String[] args) throws IOException {
        HashSet<String> classNameSet = new HashSet<String>();
        classNameSet.add("org.h2.value.VersionedValue");
        new PaserClass().paserClass(classNameSet, "C:\\Dataset_workspace\\TestProject\\H2-Research-004\\h2\\out\\artifacts\\h2_jar2\\h2.jar");
    }
}
