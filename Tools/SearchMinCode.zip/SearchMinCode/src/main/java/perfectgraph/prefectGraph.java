package perfectgraph;

import org.apache.bcel.classfile.ClassParser;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.Type;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class prefectGraph {

    HashSet<String> usefulMethods = new HashSet<>();

    HashSet<String> origMethods = new HashSet<>();

    HashMap<String, ArrayList<String>> prefectgraph = new HashMap<>();

    public HashMap<String, ArrayList<String>> getPrefectgraph() {
        for(String key : prefectgraph.keySet()){
            HashSet<String> temp = new HashSet<>();
            for(String val : prefectgraph.get(key)){
                temp.add(val);
            }
            ArrayList<String> t = new ArrayList<>(temp);
            prefectgraph.put(key, t);
        }
        return prefectgraph;
    }

    public void setPrefectgraph(HashMap<String, ArrayList<String>> graph) {
        for(String key : graph.keySet()){
            if(this.usefulMethods.contains(key)){
                ArrayList<String> valuelist = new ArrayList<>();
                for(String value : graph.get(key)){
                    if(this.usefulMethods.contains(value)){
                        valuelist.add(value);
                    }
                }
                if(valuelist.size() != 0){
                    this.prefectgraph.put(key, valuelist);
                }
            }
        }
    }

    public HashSet<String> getOrigMethods() {
        return origMethods;
    }

    public void setOrigMethods(HashMap<String, ArrayList<String>> graph) {
        for(String key : graph.keySet()){
            this.origMethods.add(key);
            for(String value : graph.get(key)){
                this.origMethods.add(value);
            }
        }
    }


    public HashSet<String> getUsefulMethods() {
        return usefulMethods;
    }

    public void setUsefulMethods(String path){
        HashSet<String>  haveMethod = new HashSet<>();
        HashSet<String> classNames = new HashSet<>();
        try{
            JarFile jar = new JarFile(path);
            Enumeration<JarEntry> enumFiles = jar.entries();
            while (enumFiles.hasMoreElements()) {
                JarEntry entry = enumFiles.nextElement();
                if (entry.getName().endsWith(".class")) {
                    ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                    JavaClass clazz = classParser.parse();
                    String className = clazz.getClassName();
                    Method[] methods = clazz.getMethods();
                    for (Method method : methods) {
                        String argutype = "";
                        Type[] paratype = method.getArgumentTypes();
                        for (Type t : paratype) {
                            argutype = argutype + t.toString() + ",";
                        }

                        if (argutype.length() != 0) {
                            argutype = argutype.substring(0, argutype.length() - 1);
                        } else {
                            argutype = "";
                        }

                        String methodSig = className + ":" + method.getReturnType().toString() + " " + method.getName() + "(" + argutype + ")";
                        haveMethod.add(methodSig);
                        classNames.add(className);
                    }
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }

        HashSet<String> uselessMethods = new HashSet<>();

        for(String m : origMethods){
            String[] mlist = m.split(":");
            String cName = mlist[0];
            if(!classNames.contains(cName)){
                usefulMethods.add(m);
            }
            else if(haveMethod.contains(m)){
                usefulMethods.add(m);
            }
            else{
                uselessMethods.add(m);
            }
        }

    }
}
