package DOT_parser;

import com.paypal.digraph.parser.GraphEdge;
import com.paypal.digraph.parser.GraphNode;
import com.paypal.digraph.parser.GraphParser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DotParser {

    public HashMap<String, ArrayList<String>> convertDotToHashmap(String filePath) {

        HashMap<String, ArrayList<String>> result = new HashMap<>();
        try {
            GraphParser parser = new GraphParser(new FileInputStream(filePath));

            Map<String, GraphNode> nodes = parser.getNodes();
            Map<String, GraphEdge> edges = parser.getEdges();

            //nodes,认为dot文件中的node是不重复的
            for (GraphNode node : nodes.values()) {
                String nodeid = node.getId().replace(": ",":");
                result.put(nodeid.substring(1, nodeid.length() - 1), new ArrayList<>());
                System.out.println(nodeid.substring(2, nodeid.length() - 2));
            }

            //edges,认为dot文件中的edge也是不重复的
            for (GraphEdge edge : edges.values()) {
                String nodeid1 = edge.getNode1().getId().replace(": ",":");
                String nodeid2 = edge.getNode2().getId().replace(": ",":");
                ArrayList<String> arrayList = result.get(nodeid1.substring(1, nodeid1.length() - 1));
                arrayList.add(nodeid2.substring(1, nodeid2.length() - 1));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return result;
    }

    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> dotMap = new DotParser().convertDotToHashmap("C:\\Users\\18386\\Desktop\\result-Qilin\\callgraph.dot");
        System.out.println(dotMap.toString());
        for (String key:
             dotMap.keySet()) {
            System.out.println(key + "--------");
            System.out.println(dotMap.get(key));
        }
    }
}
