package pathinfo;

import com.sun.org.apache.bcel.internal.classfile.ClassParser;
import com.sun.org.apache.bcel.internal.classfile.JavaClass;
import com.sun.org.apache.bcel.internal.classfile.Method;
import com.sun.org.apache.bcel.internal.generic.Type;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AllClassPaths {

    private Integer funcnum = 0;
    private Integer filenum = 0;
    private HashMap<String, ArrayList<String>> class2methods = new HashMap<String, ArrayList<String>>();
    private HashMap<String, ArrayList<String>> classgraph = new HashMap<String, ArrayList<String>>();
    Map<String, HashSet<String>> forceconversionedgs = new HashMap<>();

    public AllClassPaths(String path) {
        if (path.endsWith(".jar")) {
            setClass2methodswithjar(path);
        } else {
            setClass2methodswithclasses(new File(path));
        }
    }

    private void setClass2methodswithjar(String path) {
        try {
            JarFile jar = new JarFile(path);
            Enumeration<JarEntry> enumFiles = jar.entries();
            while (enumFiles.hasMoreElements()) {
                JarEntry entry = enumFiles.nextElement();
                if (entry.getName().endsWith(".class")) {
                    filenum++;
                    ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                    setClass2methodsandsetClassgraph(classParser);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void setClass2methodswithclasses(File file) {
//        File file = new File(path);
        if (!file.exists() || !file.isDirectory()) {
            return;
        }
        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (!files[i].isDirectory()) {
                if (files[i].toString().endsWith(".class")) {
                    filenum++;
                    String s = files[i].toString();
                    ClassParser classParser = new ClassParser(s);
                    setClass2methodsandsetClassgraph(classParser);
                }
            }
            else{
                setClass2methodswithclasses(files[i]);
            }
        }
    }

    private void setClass2methodsandsetClassgraph(ClassParser classParser) {
        try {
            JavaClass clazz = classParser.parse();
            String className = clazz.getClassName();
            ArrayList<String> parents = new ArrayList<String>();
            for (String jc : clazz.getInterfaceNames()) {
                parents.add(jc);
            }
//            for (String jc : clazz.getSuperclassName()) {
            parents.add(clazz.getSuperclassName());
//            }
//            if(className.equals("javax.persistence.spi.ClassTransformer")){
//                System.out.println(parents);
//            }
            for(String p : parents){
                if(p.equals("javax.persistence.spi.ClassTransformer")){
                    System.out.println(className);
                }
                ArrayList<String> classvaltemp = new ArrayList<>();
                if(classgraph.keySet().contains(p)){
                    classvaltemp = classgraph.get(p);
                }
                classvaltemp.add(className);
                classgraph.put(p, classvaltemp);
            }

            Method[] methods = clazz.getMethods();
            ArrayList<String> methodList = new ArrayList<String>();
            for (Method method : methods) {
                funcnum++;
                String methodName = method.getName();
                Type[] type = method.getArgumentTypes();
                Type returntype = method.getReturnType();
                String argutype = "";
                for (Type t : type) {
                    argutype = argutype + t.toString() + ",";
                }
                if (argutype.length() != 0) {
                    argutype = argutype.substring(0, argutype.length() - 1);
                } else {
                    argutype = "";
                }
                String methodsig = returntype.toString() + " " + methodName + "(" + argutype + ")";
                methodList.add(methodsig);
                class2methods.put(className, methodList);
                setForceconversionedgs(method, methodsig);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private void setForceconversionedgs(Method method, String methodsig) {
        if (method.getCode() == null) {
            return;
        }
        String codes = method.getCode().toString();
        String[] codelist = codes.split("\n");
        for (int index = 0; index < codelist.length; index++) {
            String code = codelist[index];
            //查看是否有强制转化的标识
            if (code.contains("checkcast")) {
                String pattern = "<.*>";
                Pattern r = Pattern.compile(pattern);
                Matcher m = r.matcher(code);
                if (m.find()) {
                    HashSet<String> replaceSet = new HashSet<>();
                    replaceSet.add("[B");
                    replaceSet.add("[C");
                    replaceSet.add("[D");
                    replaceSet.add("[F");
                    replaceSet.add("[I");
                    replaceSet.add("[J");
                    replaceSet.add("[S");
                    replaceSet.add("[Z");
                    replaceSet.add("[V");
                    replaceSet.add("[L");
                    replaceSet.add(";");
                    replaceSet.add(" ");
                    replaceSet.add("<");
                    replaceSet.add(">");
                    replaceSet.add("\\n");
//.replace("<", "").replace(">", "");
                    String totype = m.group(0);
                    for(String rStr : replaceSet){
                        totype = totype.replace(rStr, "");
                    }

                    if (index - 1 >= 0 && codelist[index - 1].contains("load") && !totype.isEmpty()) {
                        //我认为强制转换的上一行必然包含load字段，之后利用load字段和变量表中的索引对应关系得到强制转换之前的类型
                        String line = codelist[index - 1].replace("\n", "").replaceAll("\t+", " ").replaceAll(" +", " ");
                        String[] linelist = line.split(" ");
                        int lenoflinlist = linelist.length;
                        String varindex = "";
                        if (lenoflinlist == 2) {
                            if (linelist[1].contains("_")) {
                                varindex = linelist[1].split("_")[1];
                            }
                        } else if (lenoflinlist == 3) {
                            varindex = linelist[2].replace("%", "");
                        } else {
                            varindex = "100000";
                        }
                        HashMap typearrary = new HashMap();
                        if (method.getLocalVariableTable() != null) {
                            String varblock = method.getLocalVariableTable().toString();
                            for (String variabletable : varblock.split("\n")) {
                                if (variabletable.length() != 0) {
                                    variabletable = variabletable.replace(")", "");
                                    String varibabletable_tail = variabletable.split("index = ")[1].split(" ")[0];
                                    String index_temp = varibabletable_tail.split(":")[0];
                                    String type_temp = varibabletable_tail.split(":")[1];
                                    typearrary.put(index_temp, type_temp);
                                }
                            }
                        }

                        String ortype = (String) typearrary.get(varindex);
                        HashSet<String> temp = new HashSet<>();
                        if(totype.equals("[Ljava.lang.String;")){
                            System.out.println("yes");
                        }
                        if (forceconversionedgs.keySet().contains(totype)) {
                            temp = forceconversionedgs.get(totype);
                        }
                        if (ortype == null) {
                            continue;
                        }
                        temp.add(ortype);
                        forceconversionedgs.put(totype, temp);

                    } else {
                        continue;
                    }
                } else {
//                    System.out.println("NO MATCH");
                }
            }
        }

    }

    public Map<String, HashSet<String>> getForceconversionedgs() {
        return forceconversionedgs;
    }

    public HashMap<String, ArrayList<String>> getClass2methods() {
        return class2methods;
    }

    public HashMap<String, ArrayList<String>> getClassgraph() {
        return classgraph;
    }

    public Integer getFuncnum() {
        return funcnum;
    }

    public Integer getFilenum() {
        return filenum;
    }
}
