package sourceandsink;

import com.sun.org.apache.bcel.internal.classfile.*;
import com.sun.org.apache.bcel.internal.generic.Type;
import com.thoughtworks.qdox.JavaProjectBuilder;
import com.thoughtworks.qdox.model.JavaConstructor;
import com.thoughtworks.qdox.model.JavaField;
import com.thoughtworks.qdox.model.JavaMethod;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ResourceleakSourceAndSink {
    public HashSet<String> getSources() {
        return sources;
    }

    public void setSources() {
        sources.addAll(startFieldSet);
        sources.addAll(startFuncSet);
    }

    HashSet<String> sources = new HashSet<>();

    public HashSet<String> getSinks() {
        return sinks;
    }

    HashSet<String> sinks = new HashSet<>();

    HashSet<String> startFuncSet = new HashSet<>();
    HashSet<String> startFieldSet = new HashSet<>();


    JavaProjectBuilder javaProjectBuilder;

    private HashSet<String> genericTypeList = new HashSet<>(Arrays.asList("java.util.ArrayList", "java.util.LinkedList", "java.util.HashSet",
            "java.util.TreeSet", "java.util.HashMap", "java.util.TreeMap",
            "java.util.Hashtable", "java.util.concurrent.ArrayBlockingQueue", "java.util.List"));

    private HashSet<String> IOType = new HashSet<>(Arrays.asList("java.io.Reader", "java.io.Writer", "java.io.InputStream", "java.io.OutputStream",
            "java.io.BufferedReader", "java.io.InputStreamReader", "java.io.FileReader", "java.io.StringReader", "java.io.PipedReader",
            "java.io.CharArrayReader", "java.io.FilterReader", "java.io.PushbackReader", "java.io.BufferedWriter",
            "java.io.OutputStreamWriter", "java.io.FileWriter", "java.io.PrintWriter", "java.io.StringWriter",
            "java.io.PipedWriter", "java.io.CharArrayWriter", "java.io.FilterWriter", "java.io.FileInputStream",
            "java.io.FilterInputStream", "java.io.BufferedInputStream", "java.io.DataInputStream", "java.io.PushbackInputStream",
            "java.io.ObjectInputStream", "java.io.PipedInputStream", "java.io.SequenceInputStream", "java.io.StringBufferInputStream",
            "java.io.ByteArrayInputStream", "java.io.FileOutputStream", "java.io.FilterOutputStream", "java.io.BufferedOutputStream",
            "java.io.DataOutputStream", "java.io.PrintStream", "java.io.ObjectOutputStream", "java.io.PipedOutputStream", "java.io.ByteArrayOutputStream",
            "java.sql.Connection"
    ));
    private HashSet<String> IOTypeNoNode = new HashSet<>(Arrays.asList("Reader", "Writer", "InputStream", "OutputStream", "BufferedReader", "InputStreamReader",
            "FileReader", "StringReader", "PipedReader", "CharArrayReader", "FilterReader", "PushbackReader", "BufferedWriter",
            "OutputStreamWriter", "FileWriter", "PrintWriter", "StringWriter", "PipedWriter", "CharArrayWriter", "FilterWriter",
            "FileInputStream", "FilterInputStream", "BufferedInputStream", "DataInputStream", "PushbackInputStream", "ObjectInputStream",
            "PipedInputStream", "SequenceInputStream", "StringBufferInputStream", "ByteArrayInputStream", "FileOutputStream", "FilterOutputStream",
            "BufferedOutputStream", "DataOutputStream", "PrintStream", "ObjectOutputStream", "PipedOutputStream", "ByteArrayOutputStream",
            "Connection"
    ));

    public void setJavaProjectBuilder(JavaProjectBuilder javaProjectBuilder) {
        this.javaProjectBuilder = javaProjectBuilder;
    }

    private void traverseJavaFileForJava(File file, HashSet<File> filesJava){
        if (!file.exists() || !file.isDirectory()) {
            return;
        }
        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (!files[i].isDirectory()) {
                if (files[i].toString().endsWith(".java")) {
                    filesJava.add(files[i]);
                }
            }
            else{
                traverseJavaFileForJava(files[i], filesJava);
            }
        }
    }

    public void getType(String line, String gType, HashSet<String> typeSet){
        String pattern = gType + "<(.*)>";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(line);
        String revalue = null;
        if(m.find()){
            revalue = m.group(m.groupCount());
            revalue = revalue.replace("<?, ?>", "");
            if(revalue.contains("<") && !revalue.contains(">")){
                revalue = revalue.replace("<", "");
            }else if(revalue.contains(">") && !revalue.contains("<")){
                revalue = revalue.replace(">","");
            }
            if(revalue.contains(",")){
                String[] s = revalue.split(", ");
                for(String ss : s){
                    typeSet.add(ss);
                    revalue = ss;
                }
            }else{
                typeSet.add(revalue);
            }
        }

        for(String s : genericTypeList){
            if(revalue != null && revalue.contains(s)){
                typeSet.add(s);
                typeSet.remove(revalue);
                getType(revalue, s, typeSet);
            }
        }
    }

    private String matchKeyWord(String strLine){
        String pattern = "putfield\t\t(\\S*)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(strLine);
        String field = null;
        if(m.find()){
            field = m.group(m.groupCount());
        }
        return field;
    }

    public HashSet<String> parserLocalTable(Method method){
        HashSet<String> localVars = new HashSet<>();
        if(method.getCode() != null){
            Attribute[] attributes = method.getCode().getAttributes();
            for(Attribute attribute : attributes){
                if(attribute.getName().equals("LocalVariableTypeTable") || attribute.getName().equals("LocalVariableTable")){
                    String[] attributeList = attribute.toString().split("\n");
                    for(String aLine : attributeList){
                        String[] split1 = aLine.split(":");
                        String[] split2 = split1[split1.length -1].split(" ");
                        String typeObj = split2[0];
                        String varObj = split2[split2.length - 1].replace(")","");

                        HashSet<String> varTypeSet = new HashSet<>();
                        for(String gGType : genericTypeList) {
                            if (typeObj.contains(gGType)) {
                                varTypeSet.add(gGType);
                                getType(typeObj, gGType, varTypeSet);
                            }
                        }
                        varTypeSet.add(typeObj);
                        for(String tp : varTypeSet){
                            if(IOType.contains(tp)){
                                localVars.add(varObj);
                            }
                        }
                    }
                }
            }
            return localVars;
        }
        return null;
    }

    public HashSet<String> setfieldSet(JavaClass clazz) {
        HashSet<String> fieldSet = new HashSet<>();

        Field[] fields = clazz.getFields();
        for(Field f : fields){
            HashSet<String> fieldTypeSet = new HashSet<>();//存储每个field的类型
            if(f.getGenericSignature() != null){
                for(String GType : genericTypeList){
                    String fieldStr = f.getGenericSignature().substring(1).replace("<L", "<").replace("/", ".").replace(";", "");
                    if (fieldStr.contains(GType)) {
                        fieldTypeSet.add(GType);
                        getType(fieldStr, GType, fieldTypeSet);
                    }
                }
            }
            String fieldType = f.getType().toString().replace("[]","");
            fieldTypeSet.add(fieldType);

            String className = clazz.getClassName();
            String fieldName = f.getName();
            String t = className + "." + fieldName;

            for(String type : fieldTypeSet){
                if(IOType.contains(type) || fieldTypeSet.contains("TT")){
                    fieldSet.add(t);
                    break;
                }
            }
        }
        return fieldSet;
    }


    private void parserJavaFile(ClassParser classParser){
        try{
            JavaClass clazz = classParser.parse();
            String className = clazz.getClassName();

            HashSet<String> fields = setfieldSet(clazz);

            com.thoughtworks.qdox.model.JavaClass clazzSource = javaProjectBuilder.getClassByName(className);
            String fieldString = "";
            for(JavaField javaField : clazzSource.getFields()){
                try{
                    fieldString = fieldString + javaField.getCodeBlock();
                }catch (Exception e){
                    continue;
                }

            }

            for(String f : fields) {
                if (f.contains(".")) {
                    String[] fnList = f.split("\\.");
                    String fn = fnList[fnList.length - 1];
                    for(String t : IOTypeNoNode){
                        String pa = fn + "(\\s*)=(\\s*)new(\\s*)" + t;
                        Pattern pat = Pattern.compile(pa);
                        Matcher mat = pat.matcher(fieldString);
                        if(mat.find()){
                            startFieldSet.add(f);
                        }
                    }

                }
            }

            HashSet<String> fieldsOnlyThisClass = new HashSet<>();
            for(String f : fields){
                fieldsOnlyThisClass.add(f);
            }

            Method[] methods = clazz.getMethods();

            com.thoughtworks.qdox.model.JavaClass cls = javaProjectBuilder.getClassByName(className);
            List<JavaMethod> sourcemethods = cls.getMethods();

            for(Method method : methods){
                Type retType = method.getReturnType();
                String argutype = "";
                Type[] type = method.getArgumentTypes();
                for (Type t : type) {
                    argutype = argutype + t.toString() + ",";
                }
                if (argutype.length() != 0) {
                    argutype = argutype.substring(0, argutype.length() - 1);
                } else {
                    argutype = "";
                }

                String methodSig = className + ":" + retType.toString() + " " + method.getName() + "(" + argutype + ")";

                HashSet<String> localVars = parserLocalTable(method);

                if(localVars == null){
                    continue;
                }

                String name = method.getName();
                if(name.equals("<init>") || name.equals("<clinit>")){
                    List<JavaConstructor> constructors = cls.getConstructors();
                    for(JavaConstructor jc : constructors){
                        String code = jc.getSourceCode();
                        setSourceAndSinkInMethod(code, localVars, methodSig, fieldsOnlyThisClass);
                    }

                }else{
                    for(JavaMethod sourcemethod : sourcemethods){
                        if(sourcemethod.getName().equals(name)){
                            String code = sourcemethod.getSourceCode();
                            setSourceAndSinkInMethod(code, localVars, methodSig, fieldsOnlyThisClass);
                        }
                    }
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setSourceAndSinkInMethod(String code, HashSet<String> localVars, String methodSig, HashSet<String> fieldsOnlyThisClass){

        for(String var : localVars){
            String p = var + ".";
            if(code.contains(p)){
                sinks.add(methodSig);
            }
        }
        for(String var : fieldsOnlyThisClass){
            if(var.contains(".")){
                String[] varList = var.split("\\.");
                var = varList[varList.length - 1];
                String p = var + ".";
                if(code.contains(p)){
                    sinks.add(methodSig);
                }
            }
        }

        for(String var : localVars){
            for(String t : IOTypeNoNode){
                String pa = var + "(\\s*)=(\\s*)new(\\s*)" + t;
                Pattern pat = Pattern.compile(pa);
                Matcher mat = pat.matcher(code);
                if(mat.find()){
                    startFuncSet.add(methodSig);
                }
            }
        }
        for(String var : fieldsOnlyThisClass){
            if(var.contains(".")){
                String[] varList = var.split("\\.");
                var = varList[varList.length - 1];
                String p = var + ".";
                for(String t : IOTypeNoNode){
                    String pa = p + "(\\s*)=(\\s*)new(\\s*)" + t;
                    Pattern pat = Pattern.compile(pa);
                    Matcher mat = pat.matcher(code);
                    if(mat.find()){
                        startFuncSet.add(methodSig);
                    }
                }
            }
        }

    }

    public void exec(String sourcePath, String targetPath) throws IOException {
        File file = new File(sourcePath);
        HashSet<File> filesJava = new HashSet<>();
        traverseJavaFileForJava(file, filesJava);
        JavaProjectBuilder javaProjectBuilder = new JavaProjectBuilder();
        for(File f : filesJava){
            try{
                javaProjectBuilder.addSourceTree(f);
            }catch (Exception e){
                continue;
            }
        }

        setJavaProjectBuilder(javaProjectBuilder);

        JarFile jar = new JarFile(targetPath);
        Enumeration<JarEntry> enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                parserJavaFile(classParser);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        String sourcePath = "C:\\WorkSpace\\ParserJavaWorkSpace\\Example\\src\\main\\java";
        String targetPath = "C:\\WorkSpace\\ParserJavaWorkSpace\\Example\\out\\artifacts\\Example_jar\\Example.jar";
        ResourceleakSourceAndSink resourceleakSourceAndSink = new ResourceleakSourceAndSink();
        resourceleakSourceAndSink.exec(sourcePath, targetPath);
        resourceleakSourceAndSink.setSources();
        System.out.println(resourceleakSourceAndSink.getSources());
        System.out.println(resourceleakSourceAndSink.getSinks());

    }

}
