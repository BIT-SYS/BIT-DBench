package sourceandsink;

import com.sun.org.apache.bcel.internal.classfile.*;
import com.sun.org.apache.bcel.internal.generic.Type;
import com.thoughtworks.qdox.JavaProjectBuilder;
import com.thoughtworks.qdox.model.JavaConstructor;
import com.thoughtworks.qdox.model.JavaField;
import com.thoughtworks.qdox.model.JavaMethod;
import com.thoughtworks.qdox.model.JavaType;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NPESourceAndSinkQdox {
    private HashSet<String> sourceSet = new HashSet<String>();
    private HashSet<String> sinkSet = new HashSet<String>();

//    private HashSet<String> startFieldWithoutInitSet = new HashSet<String>();
//    private HashSet<String> startFieldWithNullSet = new HashSet<String>();
    private HashSet<String> startFieldSet = new HashSet<>();
    private HashSet<String> startFuncSet = new HashSet<>();

    private JavaProjectBuilder javaProjectBuilder = new JavaProjectBuilder();

    private HashSet<String> genericTypeList = new HashSet<>(Arrays.asList("java.util.ArrayList", "java.util.LinkedList", "java.util.HashSet",
            "java.util.TreeSet", "java.util.HashMap", "java.util.TreeMap",
            "java.util.Hashtable", "java.util.concurrent.ArrayBlockingQueue", "java.util.List"));

    private HashSet<String> typyPack = new HashSet<>();


    public void setTypyPack(HashSet<String> typyPack) {
        this.typyPack = typyPack;
    }


    public HashSet<String> getStartFuncSet() {
        return startFuncSet;
    }

    public HashSet<String> getStartFieldSet() {
        return startFieldSet;
    }

//    public void setStartFieldSet() {
//        startFieldSet.addAll(startFieldWithoutInitSet);
//        startFieldSet.addAll(startFieldWithNullSet);
//    }



    public void setJavaProjectBuilder(JavaProjectBuilder javaProjectBuilder) {
        this.javaProjectBuilder = javaProjectBuilder;
    }


//    public HashSet<String> getStartFieldWithoutInitSet() {
//        return startFieldWithoutInitSet;
//    }
//
//    public HashSet<String> getStartFieldWithNullSet() {
//        return startFieldWithNullSet;
//    }

    public HashSet<String> getSourceSet() {
        return sourceSet;
    }

    public HashSet<String> setSourceSet() {
        sourceSet.addAll(startFieldSet);
        sourceSet.addAll(startFuncSet);
        return sourceSet;
    }

    public HashSet<String> getSinkSet() {
        return sinkSet;
    }

    private void traverseJavaFile(File file){
        if (!file.exists() || !file.isDirectory()) {
            return;
        }
        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (!files[i].isDirectory()) {
                if (files[i].toString().endsWith(".class")) {
                    String s = files[i].toString();
                    ClassParser classParser = new ClassParser(s);
                    parserJavaFile(classParser);
                }
            }
            else{
                traverseJavaFile(files[i]);
            }
        }
    }

    private void traverseJavaFileForJava(File file, HashSet<File> filesJava){
        if (!file.exists() || !file.isDirectory()) {
            return;
        }
        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (!files[i].isDirectory()) {
                if (files[i].toString().endsWith(".java")) {
//                    String s = files[i].toString();
                    filesJava.add(files[i]);
                }
            }
            else{
                traverseJavaFileForJava(files[i], filesJava);
            }
        }
    }

    private void parserJavaFile(ClassParser classParser){
        try{
            JavaClass clazz = classParser.parse();
            String className = clazz.getClassName();
            HashSet<String> fields = setfieldSet(clazz);

//            if(className.equals("org.basex.io.IO")){
//                System.out.println("yes");
//            }

            com.thoughtworks.qdox.model.JavaClass clazzSource = javaProjectBuilder.getClassByName(className);
            String fieldString = "";
            for(JavaField javaField : clazzSource.getFields()){
                try{
                    fieldString = fieldString + javaField.getCodeBlock();
                }catch (Exception e){
//                    System.out.println(className);
//                    System.out.println(fields);
                    continue;
                }

            }
            for(String f : fields) {
                if (f.contains(".")) {
                    String[] fnList = f.split("\\.");
                    String fn = fnList[fnList.length - 1];
                    String pa = fn + "(\\s*)=(\\s*)null";
                    Pattern pat = Pattern.compile(pa);
                    Matcher mat = pat.matcher(fieldString);
                    if(mat.find()){
                        sourceSet.add(f);
                    }
                }
            }

            HashSet<String> fieldsOnlyThisClass = new HashSet<>();
            for(String f : fields){
                fieldsOnlyThisClass.add(f);
            }

            Method[] methods = clazz.getMethods();
            for(Method method :methods){

                Type retType = method.getReturnType();
                String argutype = "";
                Type[] type = method.getArgumentTypes();
                for (Type t : type) {
                    argutype = argutype + t.toString() + ",";
                }
                if (argutype.length() != 0) {
                    argutype = argutype.substring(0, argutype.length() - 1);
                } else {
                    argutype = "";
                }

                String methodSig = className + ":" + retType.toString() + " " + method.getName() + "(" + argutype + ")";

                if(method.getName().contains("<init>")){
                    String[] codes = method.getCode().toString().split("\n");
                    int codeLineNum = codes.length;

                    HashSet<String> InitFields = new HashSet<>();

                    for(int i = 0; i < codeLineNum; i++){
                        String code = codes[i];
                        if(code.contains("putfield")){
                            String f = matchKeyWord(code);
                            if(fields.contains(f)){
                                InitFields.add(f);
                            }
                        }
                        if(code.contains("aconst_null")){
                            startFuncSet.add(methodSig);
                        }

                    }

                    fields.removeAll(InitFields);
                }
                else if(method.getName().contains("<clint>")){
                    String[] codes = method.getCode().toString().split("\n");
                    int codeLineNum = codes.length;

                    HashSet<String> InitFields = new HashSet<>();

                    for(int i = 0; i < codeLineNum; i++){
                        String code = codes[i];
                        if(code.contains("putstatic")){
                            String f = matchKeyWord(code);
                            if(fields.contains(f)){
                                InitFields.add(f);
                            }
                        }
                        if(code.contains("aconst_null")){
                            startFuncSet.add(methodSig);
                        }

                    }
                    fields.removeAll(InitFields);
                }
                else{
                    Code codesStr = method.getCode();
                    if(codesStr != null){
                        if(codesStr.toString().contains("aconst_null")){
                            startFuncSet.add(methodSig);
                        }
                    }
                }
                startFieldSet.addAll(fields);
            }
            com.thoughtworks.qdox.model.JavaClass cls = javaProjectBuilder.getClassByName(className);
            List<JavaMethod> sourcemethods = cls.getMethods();

            for(Method method : methods){
                Type retType = method.getReturnType();
                String argutype = "";
                Type[] type = method.getArgumentTypes();
                for (Type t : type) {
                    argutype = argutype + t.toString() + ",";
                }
                if (argutype.length() != 0) {
                    argutype = argutype.substring(0, argutype.length() - 1);
                } else {
                    argutype = "";
                }

                String methodSig = className + ":" + retType.toString() + " " + method.getName() + "(" + argutype + ")";
//                System.out.println(method.getCode());
                HashSet<String> localVars = parserLocalTable(method);

                if(localVars == null){
                    continue;
                }

                String name = method.getName();
                if(name.equals("<init>") || name.equals("<clinit>")){
                    List<JavaConstructor> constructors = cls.getConstructors();
                    for(JavaConstructor jc : constructors){
                        String code = jc.getSourceCode();
                        setSinkSet(code, localVars, methodSig, fieldsOnlyThisClass);
                    }

                }else{
                    for(JavaMethod sourcemethod : sourcemethods){
                        if(sourcemethod.getName().equals(name)){
                            String code = sourcemethod.getSourceCode();
                            if(code != null){
                                setSinkSet(code, localVars, methodSig, fieldsOnlyThisClass);
                            }
                        }
                    }
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setSinkSet(String code, HashSet<String> localVars, String methodSig, HashSet<String> fieldsOnlyThisClass){
        for(String var : localVars){
            String p = var + ".";
            if(code.contains(p)){
                sinkSet.add(methodSig);
            }
        }
        for(String var : fieldsOnlyThisClass){
            if(var.contains(".")){
                String[] varList = var.split("\\.");
                var = varList[varList.length - 1];
                String p = var + ".";
//                System.out.println("p: " + p);
//                System.out.println(code);
                if(code != null){
                    if(code.contains(p)) {
                        sinkSet.add(methodSig);
                    }
                }
            }
        }

    }
    public HashSet<String> setfieldSet(JavaClass clazz) {
        HashSet<String> fieldSet = new HashSet<>();

        Field[] fields = clazz.getFields();
        for(Field f : fields){
            HashSet<String> fieldTypeSet = new HashSet<>();//存储每个field的类型
            if(f.getGenericSignature() != null){
                for(String GType : genericTypeList){
                    String fieldStr = f.getGenericSignature().substring(1).replace("<L", "<").replace("/", ".").replace(";", "");
                    if (fieldStr.contains(GType)) {
                        fieldTypeSet.add(GType);
                        getType(fieldStr, GType, fieldTypeSet);
                    }
                }
            }
            String fieldType = f.getType().toString().replace("[]","");
            fieldTypeSet.add(fieldType);

            String className = clazz.getClassName();
            String fieldName = f.getName();
            String t = className + "." + fieldName;

            for(String type : fieldTypeSet){
                if(typyPack.contains(type) || fieldTypeSet.contains("TT")){
                    fieldSet.add(t);
                    break;
                }
            }
        }
        return fieldSet;
    }

    public HashSet<String> parserLocalTable(Method method){
        HashSet<String> localVars = new HashSet<>();
        if(method.getCode() != null){
            Attribute[] attributes = method.getCode().getAttributes();
            for(Attribute attribute : attributes){
                if(attribute.getName().equals("LocalVariableTypeTable") || attribute.getName().equals("LocalVariableTable")){
                    String[] attributeList = attribute.toString().split("\n");
                    for(String aLine : attributeList){
                        String[] split1 = aLine.split(":");
                        String[] split2 = split1[split1.length -1].split(" ");
                            String typeObj = split2[0];
                            String varObj = split2[split2.length - 1].replace(")","");

                            HashSet<String> varTypeSet = new HashSet<>();
                            for(String gGType : genericTypeList) {
                                if (typeObj.contains(gGType)) {
                                    varTypeSet.add(gGType);
                                    getType(typeObj, gGType, varTypeSet);
                                }
                            }
                            varTypeSet.add(typeObj);
                            for(String tp : varTypeSet){
                                if(typyPack.contains(tp)){
                                    localVars.add(varObj);
                                }
                            }
                    }
                }
            }
            return localVars;
        }
        return null;
    }

    public void getType(String line, String gType, HashSet<String> typeSet){
        String pattern = gType + "<(.*)>";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(line);
        String revalue = null;
        if(m.find()){
            revalue = m.group(m.groupCount());
            revalue = revalue.replace("<?, ?>", "");
            if(revalue.contains("<") && !revalue.contains(">")){
                revalue = revalue.replace("<", "");
            }else if(revalue.contains(">") && !revalue.contains("<")){
                revalue = revalue.replace(">","");
            }
            if(revalue.contains(",")){
                String[] s = revalue.split(", ");
                for(String ss : s){
                    typeSet.add(ss);
                    revalue = ss;
                }
            }else{
                typeSet.add(revalue);
            }
        }

        for(String s : genericTypeList){
            if(revalue != null && revalue.contains(s)){
                typeSet.add(s);
                typeSet.remove(revalue);
                getType(revalue, s, typeSet);
            }
        }
    }

    private String matchKeyWord(String strLine){
        String pattern = "putfield\t\t(\\S*)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(strLine);
        String field = null;
        if(m.find()){
            field = m.group(m.groupCount());
        }
        return field;
    }

    public void exec(HashSet<String> typePack, String pathsource, String pathtarget) throws IOException {

//        NPESourceAndSinkQdox npeSourceAndSink = new NPESourceAndSinkQdox();

        File file = new File(pathsource);
        HashSet<File> filesJava = new HashSet<>();
        traverseJavaFileForJava(file, filesJava);
        JavaProjectBuilder javaProjectBuilder = new JavaProjectBuilder();
        for(File f : filesJava){
            try{
                javaProjectBuilder.addSourceTree(f);
            }catch (Exception e){
//                System.out.println(f.toString());
                continue;
            }
        }

        setJavaProjectBuilder(javaProjectBuilder);
        setTypyPack(typePack);

        JarFile jar = new JarFile(pathtarget);
        Enumeration<JarEntry> enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                parserJavaFile(classParser);
            }
        }

        setSourceSet();

//        System.out.println(npeSourceAndSink.getSourceSet());
//        System.out.println(npeSourceAndSink.getSinkSet());
//        System.out.println(npeSourceAndSink.getSourceSet().size());
//        System.out.println(npeSourceAndSink.getSinkSet().size());

    }
}