package sourceandsink;

import com.sun.org.apache.bcel.internal.classfile.*;
import com.sun.org.apache.bcel.internal.generic.Type;
import com.thoughtworks.qdox.JavaProjectBuilder;
import com.thoughtworks.qdox.model.JavaConstructor;
import com.thoughtworks.qdox.model.JavaField;
import com.thoughtworks.qdox.model.JavaMethod;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SqlInjectSourceAndSink {

    public HashSet<String> getSources() {
        return sources;
    }

    HashSet<String> sources = new HashSet<>();

    public HashSet<String> getSinks() {
        return sinks;
    }

    HashSet<String> sinks = new HashSet<>();

    private HashSet<String> usefulAnnotations = new HashSet<>(Arrays.asList("Lorg/springframework/stereotype/Controller;","Lorg/springframework/web/bind/annotation/RequestMapping;"));
    private HashSet<String> usefulSinks = new HashSet<>(Arrays.asList(
            "java.sql.CallableStatement.execute ()Z",
            "java.sql.CallableStatement.execute (Ljava/lang/String;)Z",
            "java.sql.CallableStatement.execute (Ljava/lang/String;[I)Z",
            "java.sql.CallableStatement.execute (Ljava/lang/String;I)Z",
            "java.sql.CallableStatement.execute (Ljava/lang/String;[Ljava/lang/String;)Z",
            "java.sql.CallableStatement.executeQuery (Ljava/lang/String;)Ljava/sql/ResultSet;",
            "java.sql.CallableStatement.executeQuery ()Ljava/sql/ResultSet;",
            "java.sql.CallableStatement.executeUpdate ()I",
            "java.sql.CallableStatement.executeUpdate (Ljava/lang/String;)I",
            "java.sql.CallableStatement.executeUpdate (Ljava/lang/String;[I)I",
            "java.sql.CallableStatement.executeUpdate (Ljava/lang/String;[Ljava/lang/String;)I",
            "java.sql.CallableStatement.executeUpdate (Ljava/lang/String;I)I",
            "java.sql.Statement.execute (Ljava/lang/String;)Z",
            "java.sql.Statement.execute (Ljava/lang/String;[I)Z",
            "java.sql.Statement.execute (Ljava/lang/String;[Ljava/lang/String;)Z",
            "java.sql.Statement.execute (Ljava/lang/String;I)Z",
            "java.sql.Statement.executeQuery (Ljava/lang/String;)Ljava/sql/ResultSet;",
            "java.sql.Statement.executeUpdate (Ljava/lang/String;)I",
            "java.sql.Statement.executeUpdate (Ljava/lang/String;[I)I",
            "java.sql.Statement.executeUpdate (Ljava/lang/String;[Ljava/lang/String;)I",
            "java.sql.Statement.executeUpdate (Ljava/lang/String;I)I"
    ));

    private void parserJavaFile(ClassParser classParser){
        try{
            JavaClass clazz = classParser.parse();

            AnnotationEntry[] annotationEntries = clazz.getAnnotationEntries();
            boolean flag = false;
            for(AnnotationEntry annotationEntry : annotationEntries){
                if(usefulAnnotations.contains(annotationEntry.getAnnotationType())){
                    flag = true;
                    break;
                }
            }

            if(flag){
            String className = clazz.getClassName();
            Method[] methods = clazz.getMethods();//get methods
            for (int j = 0; j < methods.length; j++) {
                Method method = methods[j];

                String methodName = method.getName();
                    Type[] type = method.getArgumentTypes();
                    Type returntype = method.getReturnType();
                    String argutype = "";
                    for (Type t : type) {
                        argutype = argutype + t.toString() + ",";
                    }
                    if (argutype.length() != 0){
                        argutype = argutype.substring(0, argutype.length() - 1);}
                    else{
                        argutype = "";
                    }
                    String methodsig = className + ":" + returntype.toString() + " " + methodName + "(" + argutype + ")";

                    ParameterAnnotationEntry[] ParaAnnotationEntries = method.getParameterAnnotationEntries();
                    for(ParameterAnnotationEntry parameterAnnotationEntry : ParaAnnotationEntries){
                        AnnotationEntry[] subParaAnnotationEntries = parameterAnnotationEntry.getAnnotationEntries();
                        for(int i = 0; i < subParaAnnotationEntries.length; i++){
                            if(subParaAnnotationEntries[i].getAnnotationType().equals("Lorg/springframework/web/bind/annotation/RequestParam;")){
                                sources.add(methodsig);
                                break;
                            }
                        }
                    }
                    if(method.getCode() != null){
                        String code = method.getCode().toString();
                        String[] codelist = code.split("\n");
                        f: if(code.contains("invokeinterface")){
                            for(int i = 0; i < codelist.length; i++){
                                if(codelist[i].contains("invokeinterface")){
                                    for(String s : usefulSinks){
                                        if(codelist[i].contains(s)){
                                            sinks.add(methodsig);
                                            break f;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void exec(String targetPath) throws IOException {
        JarFile jar = new JarFile(targetPath);
        Enumeration<JarEntry> enumFiles = jar.entries();
        while (enumFiles.hasMoreElements()) {
            JarEntry entry = enumFiles.nextElement();
            if (entry.getName().endsWith(".class")) {
                ClassParser classParser = new ClassParser(jar.getInputStream(entry), entry.getName());
                parserJavaFile(classParser);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        String targetPath = "C:\\WorkSpace\\DataSetWorkSpace\\SqlProjects\\BSWeb\\out\\artifacts\\BSWeb_jar\\BSWeb.jar";
        SqlInjectSourceAndSink sqlInjectSourceAndSink = new SqlInjectSourceAndSink();
        sqlInjectSourceAndSink.exec(targetPath);
        System.out.println(sqlInjectSourceAndSink.getSources().size());

    }

}
