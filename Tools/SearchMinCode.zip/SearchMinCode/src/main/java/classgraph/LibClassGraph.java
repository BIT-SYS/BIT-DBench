package classgraph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.*;

public class LibClassGraph {


    private HashMap<String, ArrayList<String>> libclassgraph = new HashMap<String, ArrayList<String>>();

    public boolean setLibclassgraph() throws IOException {
        String basic_children_path = "src/main/java/java_children.txt";
        File filec = new File(basic_children_path);
        if(!filec.exists()) {
            return false;
        }
        else{
            setChildren(basic_children_path);
            return true;
        }
    }

    public void setChildren(String path) throws IOException {
        BufferedReader brClassInherit = new BufferedReader(new FileReader(new File(path)));
        String lineClassInherit = null;
        while ((lineClassInherit = brClassInherit.readLine()) != null) {
            String[] strs1 = lineClassInherit.split("#");
            String pakclass = strs1[0];
            ArrayList<String> children = this.libclassgraph.getOrDefault(pakclass, new ArrayList<>());
            if (!strs1[1].contains(",")) {
                String curChild = strs1[1];
                children.add(curChild);
                this.libclassgraph.put(pakclass, children);
            } else {
                String[] curChildren = strs1[1].split(",");
                for (String curChild : curChildren) {
                    children.add(curChild);
                }
                this.libclassgraph.put(pakclass, children);
            }
        }
    }


    public HashMap<String, ArrayList<String>> getLibclassgraph() {
        return libclassgraph;
    }

}
