package classgraph;

import org.jgrapht.experimental.dag.DirectedAcyclicGraph;
import org.jgrapht.graph.DefaultEdge;

import java.util.*;

public class MergeClassGraph {
    private HashMap<String, ArrayList<String>> classgraph = new HashMap<>();

    public HashMap<String, ArrayList<String>> getClassgraph() {
        return classgraph;
    }

    public HashSet<String> getFianlMap(Map<String, HashSet<String>> FCMap,DirectedAcyclicGraph<String, DefaultEdge> classGraph, String dstClass){
        HashSet<String> finalPack = new HashSet<>();
        if(classGraph.containsVertex(dstClass)){
            Set<String> p_node = classGraph.getAncestors(classGraph, dstClass);
            //得到子节点
            Set<String> c_node = classGraph.getDescendants(classGraph, dstClass);
            //得到祖先

            for(String node : FCMap.keySet()){
                if(FCMap.get(node).contains(dstClass)){
                    finalPack.add(node);
                }
            }

            if(FCMap.containsKey(dstClass)){
                for(String node : FCMap.get(dstClass)){
                    finalPack.add(node);
                }
            }

            for(String p : p_node){
                finalPack.add(p);
            }
            for(String p : c_node){
                finalPack.add(p);
            }
        }

        finalPack.add(dstClass);

        return finalPack;
    }

    public DirectedAcyclicGraph<String, DefaultEdge> getClassgraph_jgrapht() {
        DirectedAcyclicGraph<String, DefaultEdge> g = new DirectedAcyclicGraph<String, DefaultEdge>(DefaultEdge.class);
        for (String key : this.classgraph.keySet()) {
            g.addVertex(key);
            for (String val : this.classgraph.get(key)) {
                g.addVertex(val);
                try {
                    g.addDagEdge(key, val);
                } catch (DirectedAcyclicGraph.CycleFoundException e) {
                    e.printStackTrace();
                }

            }
        }
        return g;
    }

    public void setClassgraph(HashMap<String, ArrayList<String>> classgraph_project,
                              HashMap<String, ArrayList<String>> classgraph_lib) {

        for(String s : classgraph_lib.keySet()){
//            if(s.equals("javax.ejb.MessageDrivenBean")){
//                System.out.println("class1");
//            }
            if(this.classgraph.containsKey(s)){
//                if(s.equals("javax.ejb.MessageDrivenBean")){
//                    System.out.println("class2 " + s);
//                }
                ArrayList<String> t = this.classgraph.get(s);
                t.addAll(classgraph_lib.get(s));
                this.classgraph.put(s,t);
            }else{
                ArrayList<String> t = new ArrayList<>();
                t.addAll(classgraph_lib.get(s));
                this.classgraph.put(s,t);
            }
        }

        for(String s : classgraph_project.keySet()){
//            if(s.equals("javax.ejb.MessageDrivenBean")){
//                System.out.println("project1");
//            }
            if(this.classgraph.containsKey(s)){
//                if(s.equals("javax.ejb.MessageDrivenBean")){
//                    System.out.println("project1 " + s);
//                }
                ArrayList<String> t = this.classgraph.get(s);
                t.addAll(classgraph_project.get(s));
                this.classgraph.put(s,t);
            }else{
                ArrayList<String> t = new ArrayList<>();
                t.addAll(classgraph_project.get(s));
                this.classgraph.put(s,t);
            }
        }
    }

}
