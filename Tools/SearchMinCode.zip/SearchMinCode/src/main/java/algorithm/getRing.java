package algorithm;
import java.util.*;

import com.google.common.collect.Iterators;
import stat.JCallGraph;

public class getRing {
//    public static int num = 0;
    public HashSet<String> getstartNode(HashMap<String, ArrayList<String>> graph){
        HashSet<String> startNodes = new HashSet<>();
        for(String key1 : graph.keySet()){
            boolean flag = false;
            for(String key2 : graph.keySet()){
                if(!key1.equals(key2)){
                    for(String value : graph.get(key2)){
                        if(key1.equals(value)){
                            flag = true;
                        }
                    }
                }
            }
            if(!flag){
                startNodes.add(key1);
            }
        }
        return startNodes;
    }
    public HashMap<String, ArrayList<String>> getAndRemoveSelfRing(HashMap<String, ArrayList<String>> graph){
        HashSet<String> selfRingNodes = new HashSet<>();
        HashMap<String, ArrayList<String>> graph_removeselfring = new HashMap<>();
        for(String key : graph.keySet()){
            if(graph.get(key).contains(key)){
                selfRingNodes.add(key);
            }
            ArrayList<String> valuelist = new ArrayList<>();
            for(String value : graph.get(key)){
                if(!key.equals(value)){
                    valuelist.add(value);
                }
            }
            HashSet<String> temp = new HashSet<>(valuelist);
            valuelist = new ArrayList<>(temp);
            graph_removeselfring.put(key, valuelist);

        }
        System.out.println("【self ring num】 " + selfRingNodes.size());
        return graph_removeselfring;
    }

//    public void getRing_dfs(HashMap<String, ArrayList<String>> g, String node, HashSet<String> visited, ArrayList<String> pre, ArrayList<ArrayList<String>> paths){
//        if (g.get(node)==null) {
//            return;
//        }
//        for(String value : g.get(node)){
////            if(visited.contains(value) && pre.contains(value)){
//            if(visited.contains(value)){
//                System.out.println("-------------------------------------------");
//                System.out.print(paths.size()+" ");
//                System.out.println(node+" ");
//                System.out.println(value);
//                int start = pre.indexOf(value);
//                int end = pre.size() - 1;
//                ArrayList<String> temp = new ArrayList<>(end-start+1);
//                for(int i = start; i <= end; i++){
//                    temp.add(pre.get(i));
//                }
//                paths.add(temp);
////                pre.remove(pre.size() - 1);
////                return;
//            }else if (g.containsKey(node)){//考虑非叶子节点的情况
//                visited.add(node);
//                pre.add(node);
//                getRing_dfs(g, value, visited, pre, paths);
//                visited.remove(node);
//                pre.remove(pre.size()-1);
//            }
//        }
////        pre.remove(pre.size() - 1);
//    }


    public void getRing_dfs(HashMap<String, ArrayList<String>> g, String node, HashSet<String> visited, ArrayList<String> pre, ArrayList<ArrayList<String>> paths, HashSet<String> nodeinRing){

        if(!g.containsKey(node)) {
            return;
        }
        visited.add(node);
        pre.add(node);

        for(String value : g.get(node)){
            if(pre.contains(value) && visited.contains(value)){
                ArrayList<String> temp = new ArrayList<>();
                int start = pre.indexOf(value);
                int end = pre.size() - 1;
                for(int i = start; i <= end; i++){
                    String t = pre.get(i);
                    temp.add(t);
                    nodeinRing.add(t);
                }
                paths.add(temp);
//                duplicate(paths);
                System.out.print(paths.size() + " ");
            }
            else if(visited.contains(value) && !pre.contains(value)){
                if(nodeinRing.contains(value)){
                    f : for(String n : pre){
                        for(ArrayList<String> t : paths){
                            if(t.contains(n) && t.contains(value)){
                                int fromIndex = t.indexOf(value);
                                int toIndex = t.indexOf(n);
                                ArrayList<String> result = new ArrayList<>();
                                if(fromIndex > toIndex){
                                    List<String> result1 = t.subList(fromIndex, t.size());
                                    List<String> result2 = t.subList(0, toIndex + 1);
                                    result.addAll(result1);
                                    result.addAll(result2);
                                }
                                else{
                                    List<String> result3 = t.subList(fromIndex, toIndex + 1);
                                    result.addAll(result3);
                                }
                                int start = pre.indexOf(n);
                                int end = pre.size() - 1;
                                for(int i = start + 1; i <= end; i++){
                                    String tt = pre.get(i);
                                    result.add(tt);
                                    nodeinRing.add(tt);
                                }
                                paths.add(result);
                                break f;
                            }
                        }
                    }
                }
            }
            else{
                getRing_dfs(g, value, visited, pre, paths, nodeinRing);
            }
        }
        pre.remove(pre.size() - 1);
    }

    /**
     * 去除重复环
     * @param paths 所有环
     */
    public static ArrayList<ArrayList<String>> duplicate(ArrayList<ArrayList<String>> paths){
        int end = paths.size();
        HashSet<Integer> indexlist = new HashSet<>();
        ArrayList<ArrayList<String>> newPaths = new ArrayList<>();
        for(int i = 0; i < end; i++){
            for(int j = i + 1; j < end; j++){
                HashSet<String> set1 = new HashSet<>(paths.get(i));
                HashSet<String> set2 = new HashSet<>(paths.get(j));
                if (set1.equals(set2)) {
                    indexlist.add(j);
                }
            }
        }
        for(int i = 0; i < end; i++){
            if(!indexlist.contains(i)){
                newPaths.add(paths.get(i));
            }
        }
        return  newPaths;
    }



    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> graph_input = new HashMap<>();

        String jarPath = "C:\\Dataset_workspace\\TestProject\\H2-Research-004\\h2\\out\\artifacts\\h2_jar2\\h2.jar";
        JCallGraph callGraph = new JCallGraph();
        callGraph.run(new String[]{jarPath});
        HashMap<String, ArrayList<String>> callgraph = callGraph.getCallGraphMap();

        getRing getring = new getRing();
        HashMap<String, ArrayList<String>> graph = getring.getAndRemoveSelfRing(callgraph);

        HashSet<String> startNodes = getring.getstartNode(graph);
        System.out.println("【startNodes】" + startNodes.size());

        int totalNum = 0;

        for(String startNode : startNodes){
            System.out.println("起始点：" + startNode);
            ArrayList<ArrayList<String>> paths = new ArrayList<>();
            if(!graph.containsKey(startNode)) {
                continue;
            }
            HashSet<String> visited =  new HashSet<>();
            ArrayList<String> pre = new ArrayList<>();
            visited.add(startNode);
            pre.add(startNode);
            getring.getRing_dfs(graph, startNode, visited, pre, paths, new HashSet<>());
            ArrayList<ArrayList<String>> newpaths = duplicate(paths);

            totalNum = totalNum + newpaths.size();
        }

        System.out.println("total ring num is " + totalNum);
    }
}
