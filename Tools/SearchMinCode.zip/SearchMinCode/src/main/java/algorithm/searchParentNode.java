package algorithm;

import java.util.*;

public class searchParentNode {

    public HashSet<String> findFatherNodes(HashMap<String, ArrayList<String>> graph, String node1, String node2) {
        HashSet<String> fatherNodes = new HashSet<>();
        if (node1 == null || node2 == null || !graph.keySet().contains(node1) || !graph.keySet().contains(node2)) {
            return fatherNodes;
        }

        //将图中的边的方向反转
        HashMap<String, ArrayList<String>> reversedGraph = reverseGraph(graph);

        //分别找到node1和node2的所有父节点，并取交集
        ArrayList<String> node1FatherNodes = findChildrenNodes(reversedGraph, node1);
        ArrayList<String> node2FatherNodes = findChildrenNodes(reversedGraph, node2);

        HashSet<String> set = new HashSet<>();
        set.addAll(node1FatherNodes);
        set.retainAll(node2FatherNodes);

//        fatherNodes.addAll(set);
        return set;
    }

    //通过bfs找到节点的子节点，其中不包括节点本身
    private ArrayList<String> findChildrenNodes(HashMap<String, ArrayList<String>> graph, String start) {
        ArrayList<String> result = new ArrayList<>();
        Queue<String> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            String node = queue.poll();
            for (String s : graph.get(node)) {
                if (visited.contains(s)) {
                    continue;
                }
                result.add(s);
                queue.add(s);
                visited.add(s);
            }
        }
//        System.out.println(result.toString());
        return result;
    }

    public HashMap<String, ArrayList<String>> reverseGraph(HashMap<String, ArrayList<String>> graph) {
        HashMap<String, ArrayList<String>> reversedGraph = new HashMap<String, ArrayList<String>>();
        for (String key : graph.keySet()) {
            if (!reversedGraph.keySet().contains(key)) {
                reversedGraph.put(key, new ArrayList<>());
            }
            for (String val : graph.get(key)) {
                if (!reversedGraph.keySet().contains(val)) {
                    reversedGraph.put(val, new ArrayList<>());
                }
                reversedGraph.get(val).add(key);
            }
        }
        return reversedGraph;
    }

    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> graph = new HashMap<>();
        graph.put("1", new ArrayList<>(Arrays.asList("1", "2", "3")));
        graph.put("2", new ArrayList<>(Arrays.asList("3", "4", "5")));
        graph.put("3", new ArrayList<>(Arrays.asList("6", "7", "8")));
        graph.put("4", new ArrayList<>(Arrays.asList("6")));
        graph.put("5", new ArrayList<>());
        graph.put("6", new ArrayList<>());
        graph.put("7", new ArrayList<>(Arrays.asList("5")));
        graph.put("8", new ArrayList<>());

        HashMap<String, ArrayList<String>> reversedGraph = new searchParentNode().reverseGraph(graph);
        System.out.println(new searchParentNode().findFatherNodes(graph, "5", "7").toString());
    }
}
