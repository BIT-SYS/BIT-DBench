package algorithm;

import java.util.*;

public class searchPaths {
    private Stack<String> st = new Stack<>();
    private HashSet<String> visited = new HashSet<>(); //标识节点是否被访问

    public ArrayList<ArrayList<String>> getPaths() {
        return paths;
    }

    ArrayList<ArrayList<String>> paths = new ArrayList<>();
    public void getAllPaths(HashMap<String, ArrayList<String>> graph, String startNode, String endNode, HashSet<String> pathNodes){
        if(startNode.equals(endNode)){
            ArrayList<String> path = new ArrayList<String>();
            for(int i = 0; i < st.size(); i++){
                path.add(st.get(i));
                pathNodes.add(st.get(i));
            }
            path.add(endNode);
            paths.add(path);
        }
        visited.add(startNode);
        st.push(startNode);
        if(graph.containsKey(startNode)){
            for(String value : graph.get(startNode)){
                if(!visited.contains(value)){
                    getAllPaths(graph, value, endNode, pathNodes);
                }
            }
        }
        visited.remove(startNode);
        st.pop();
    }

//    public static void main(String[] args) {
//        HashMap<String, ArrayList<String>> graph = new HashMap<>();
//        graph.put("1", new ArrayList<>(Arrays.asList("2", "4")));
//        graph.put("2", new ArrayList<>(Arrays.asList("3")));
//        graph.put("3", new ArrayList<>(Arrays.asList("5")));
//        graph.put("4", new ArrayList<>(Arrays.asList("2","5")));
//        ArrayList<ArrayList<String>> paths = new ArrayList<>();
//        HashSet<String> pathNode = new HashSet<>();
//        searchalg s = new searchalg();
//        s.getAllPaths(graph, "1","3", paths, pathNode);
//        System.out.println(paths);
//
//    }

}
