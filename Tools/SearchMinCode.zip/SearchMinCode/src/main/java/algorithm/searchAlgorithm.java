package algorithm;

import java.util.*;

public class searchAlgorithm {
    public HashSet<String> getParentNodes(HashMap<String, ArrayList<String>> callGraph, String fixMethod, HashSet<String> dataNodes) {

        HashSet<String> fixMethodInflunceNodes = new HashSet<>();
        HashMap<String, ArrayList<String>> fixMethodInflunceGraph = bfs(callGraph, fixMethod, fixMethodInflunceNodes); //nodeset为切片出来的节点

        System.out.println("fixMethodInflunceGraph is ------");
//        drawdot(fixMethodInflunceGraph);
        drawdot_havecenter(fixMethodInflunceGraph, fixMethod);

        HashSet<String> coinfluencenode_eachnode = new HashSet<>();
        for (String node : dataNodes) {
            HashSet<String> visited = new HashSet<>();//访问过的节点
            ArrayList<String> pre = new ArrayList<>();//存放当前走过的路径，数据结构也可以是Stack或Queue
            HashSet<String> paths = new HashSet<>(); //所有路径


            HashSet<String> commonnodes = new HashSet<>();//触碰到的边界点

            dfs(callGraph, node, fixMethodInflunceNodes, visited, pre, paths, commonnodes);
            coinfluencenode_eachnode.addAll(paths);

            visited = new HashSet<>();//访问过的节点
            pre = new ArrayList<>();//存放当前走过的路径，数据结构也可以是Stack或Queue
            paths = new HashSet<>(); //所有路径

            dfs(fixMethodInflunceGraph, fixMethod, commonnodes, visited, pre, paths, new HashSet<>());

            coinfluencenode_eachnode.addAll(paths);
            System.out.println("the first node is " + node);
            System.out.println("coinfluencenode is ");
            System.out.println(coinfluencenode_eachnode);
            break;
        }

        HashMap<String, ArrayList<String>> twoNodeGraph = new HashMap<>();

        for(String kNode : callGraph.keySet()){
            if(coinfluencenode_eachnode.contains(kNode)){
                for(String vNode : callGraph.get(kNode)){
                    if(coinfluencenode_eachnode.contains(vNode)){
                        ArrayList<String> temp = new ArrayList<>();
                        if(twoNodeGraph.containsKey(kNode)){
                            temp = twoNodeGraph.get(kNode);
                        }
                        temp.add(vNode);
                        twoNodeGraph.put(kNode, temp);
                    }
                }
            }
        }
        System.out.println("twoNodeGraph is ------");

        drawdot(twoNodeGraph);

        return coinfluencenode_eachnode;
    }

    /**
     *
     * @param graph 在该图中进行dfs
     * @param node 起始节点
     * @param nodesset 目的节点的集合
     * @param visited 记录是否被访问过
     * @param pre 记录当前经过的路径
     * @param paths 结果集合set
     * @param commonnodes
     */
    private void dfs(HashMap<String, ArrayList<String>> graph, String node, HashSet<String> nodesset, HashSet<String> visited, ArrayList<String> pre, HashSet<String> paths, HashSet<String> commonnodes) {
        visited.add(node);
        pre.add(node);

        if (nodesset.contains(node)) {
            commonnodes.add(node);
            paths.addAll(pre);
            pre.remove(pre.size() - 1);
            return;
        }
        //遍历节点node的所有子节点
        if (graph.containsKey(node)) {
            for (String n : graph.get(node)) {
                if (paths.contains(n)) {
                    visited.add(node);
                    paths.addAll(pre);
                }
                if (!visited.contains(n)) {
                    dfs(graph, n, nodesset, visited, pre, paths, commonnodes);
                }
            }
        }
        pre.remove(pre.size() - 1);
    }

    public HashMap<String, ArrayList<String>> bfs(HashMap<String, ArrayList<String>> graph, String start, HashSet<String> Influence_node) {
        HashMap<String, ArrayList<String>> g = new HashMap<>();
        Queue<String> queue = new LinkedList<>(); //存储访问的节点
        Queue<String> visite = new LinkedList<>(); //存储访问过得节点

        queue.add(start); //起始节点添加到队列

        visite.add(start); //标识为访问过
        while (!queue.isEmpty()) {
            String node = queue.poll(); //队列头结点出队
            ArrayList<String> valnode = new ArrayList<>();
            if (g.keySet().contains(node)) {
                valnode = g.get(node);
            }

            if (graph.keySet().contains(node)) {
                List<String> set = graph.get(node); //获取所有的直接关联的节点

                if (set.size() != 0) {
                    for (String next : set) {
                        if (!visite.contains(next)) { //不包含说明没有没有被访问
                            queue.add(next);
                            valnode.add(next);
                            visite.add(next);
                        }

                    }
                }
                if (valnode.size() != 0) {
                    g.put(node, valnode);
                }

            }
        }
        for (String n : visite) {
            Influence_node.add(n);
        }
        return g;
    }
    public static void drawdot_havecenter(Map<String, ArrayList<String>> G, String startNode){
        int index = 0;
        String lines = "digraph G { \n";
        HashSet<String> nodes = new HashSet<>();

        nodes.add(startNode);
        for(String n : G.get(startNode)){
            nodes.add(n);
            if(G.keySet().contains(n)){
                for(String nn : G.get(n)){
                    nodes.add(nn);
                    if(G.keySet().contains(nn)){
                        for(String nnn : G.get(nn)){
                            nodes.add(nnn);
                            if(G.keySet().contains(nnn)){
                                for(String nnnn : G.get(nnn)){
                                    nodes.add(nnnn);
                                }
                            }
                        }
                    }
                }
            }
        }
        List<String> nodeslist = new ArrayList<>(nodes);
        HashSet<String> edgset = new HashSet<>();
        for(String k : G.keySet()){
            if(nodeslist.contains(k)){
                int start = nodeslist.indexOf(k);
                if(G.get(k) != null) {
                    for (String v : G.get(k)) {
                        if(nodeslist.contains(v)){
                            int end = nodeslist.indexOf(v);
                            String edg = " " + start + " -> " + end + ";\n";
                            edgset.add(edg);
                        }
                    }
                }
            }
        }
        for(String e : edgset){
            lines = lines + e;
        }
        for(int x = 0; x < nodeslist.size(); x++){
            String node = " " + x + " [label=\"" + nodeslist.get(x) + "\"];\n";
            lines = lines + node;
        }
        lines = lines + "}\n\n\n\n";
        System.out.println(lines);
//        try {
//            BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\工作文档\\工作\\数据集构建第一部分\\Dataset_Collection\\out\\graph.txt"));
//            writer.write(lines);
//            writer.close();
//        }catch (Exception e){
//            e.printStackTrace();
//        }

    }
    public static void drawdot(Map<String, ArrayList<String>> G){
        int index = 0;
        String lines = "digraph G { \n";
        HashSet<String> nodes = new HashSet<>();
        for(String k : G.keySet()){
            if(G.get(k) != null && index < 50){
                index++;
                for(String v : G.get(k)){
                    nodes.add(k);
                    nodes.add(v);
                    index++;
                }
            }
        }
        List<String> nodeslist = new ArrayList<>(nodes);
        HashSet<String> edgset = new HashSet<>();
        for(String k : G.keySet()){
            if(nodeslist.contains(k)){
                int start = nodeslist.indexOf(k);
                if(G.get(k) != null) {
                    for (String v : G.get(k)) {
                        if(nodeslist.contains(v)){
                            int end = nodeslist.indexOf(v);
                            String edg = " " + start + " -> " + end + ";\n";
                            edgset.add(edg);
                        }
                    }
                }
            }
        }
        for(String e : edgset){
            lines = lines + e;
        }
        for(int x = 0; x < nodeslist.size(); x++){
            String node = " " + x + " [label=\"" + nodeslist.get(x) + "\"];\n";
            lines = lines + node;
        }
        lines = lines + "}\n\n\n\n";
        System.out.println(lines);
//        try {
//            BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\工作文档\\工作\\数据集构建第一部分\\Dataset_Collection\\out\\graph.txt"));
//            writer.write(lines);
//            writer.close();
//        }catch (Exception e){
//            e.printStackTrace();
//        }

    }

    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> graph = new HashMap<>();
        graph.put("1", new ArrayList<>(Arrays.asList("1", "2", "3")));
        graph.put("2", new ArrayList<>(Arrays.asList("5")));
        graph.put("3", new ArrayList<>(Arrays.asList("6")));
        graph.put("4", new ArrayList<>(Arrays.asList("5")));
        graph.put("5", new ArrayList<>());
        graph.put("6", new ArrayList<>());

        HashMap<String, ArrayList<String>> reversedGraph = new searchParentNode().reverseGraph(graph);

        HashSet<String> temp = new HashSet<>();
        temp.add("5");

        HashSet<String> result = new searchAlgorithm().getParentNodes(reversedGraph, "6", temp);
        System.out.println(result);
    }
}
