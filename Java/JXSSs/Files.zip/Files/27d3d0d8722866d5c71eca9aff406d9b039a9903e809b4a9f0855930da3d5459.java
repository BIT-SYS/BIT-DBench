package org.apache.wicket.markup.html;

import org.apache.wicket.Component;

public class WebComponent extends Component {
}
