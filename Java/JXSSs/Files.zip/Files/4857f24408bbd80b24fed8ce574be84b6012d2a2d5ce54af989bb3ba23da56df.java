package org.apache.wicket.markup.html;

import org.apache.wicket.Page;

public class WebPage extends Page {
}
