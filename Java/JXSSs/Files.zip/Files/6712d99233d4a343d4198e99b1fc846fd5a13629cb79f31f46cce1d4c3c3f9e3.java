package org.apache.wicket;

public class Component {
    public final Component setEscapeModelStrings(final boolean escapeMarkup)
    {
        return this;
    }
}
