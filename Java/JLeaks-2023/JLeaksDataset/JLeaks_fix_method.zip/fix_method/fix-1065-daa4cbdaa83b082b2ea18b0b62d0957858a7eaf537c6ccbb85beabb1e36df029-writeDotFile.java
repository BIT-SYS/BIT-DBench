{
    if (g == null) {
        throw new IllegalArgumentException("g is null");
    }
    StringBuffer dotStringBuffer = dotOutput(g, labels, title);
    // retrieve the filename parameter to this component, a String
    if (dotfile == null) {
        throw new WalaException("internal error: null filename parameter");
    }
    try {
        File f = new File(dotfile);
        try (final FileWriter fw = new FileWriter(f)) {
            fw.write(dotStringBuffer.toString());
        }
        return f;
    } catch (Exception e) {
        throw new WalaException("Error writing dot file " + dotfile);
    }
}