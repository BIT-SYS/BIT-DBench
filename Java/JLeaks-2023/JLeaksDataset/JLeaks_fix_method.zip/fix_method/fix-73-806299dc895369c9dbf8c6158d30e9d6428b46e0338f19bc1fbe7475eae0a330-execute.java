{
    boolean success = false;
    Connect conn;
    try {
        conn = LibvirtConnection.getConnectionByVmName(cmd.getVmName());
        success = network_rules_vmSecondaryIp(conn, cmd.getVmName(), cmd.getVmSecIp(), cmd.getAction());
    } catch (LibvirtException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    return new Answer(cmd, success, "");
}