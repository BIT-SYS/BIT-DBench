{
    out.write(encodeToBytes().toString());
}