{
    if (format == null) {
        if (buffer == null)
            return null;
        AudioFormat format = null;
        try (InputStream is = buffer.getInputStream()) {
            format = AudioSystem.getAudioFileFormat(is).getFormat();
        } catch (Exception e) {
            // e.printStackTrace();
        }
        return format;
    }
    return format;
}