{
    ConfigGetter<T> getter = new ConfigGetter<>(source, c);
    return getter.getConfig(configId);
}