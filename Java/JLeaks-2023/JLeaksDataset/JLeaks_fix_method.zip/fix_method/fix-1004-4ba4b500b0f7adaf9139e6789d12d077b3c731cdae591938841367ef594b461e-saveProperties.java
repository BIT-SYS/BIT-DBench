{
    try {
        final String fileName = new FileSave("Where To Save map.properties ?", "map.properties", mapFolderLocation).getPathString();
        if (fileName == null) {
            return;
        }
        final FileOutputStream sink = new FileOutputStream(fileName);
        final String stringToWrite = getOutPutString();
        try (final OutputStreamWriter out = new OutputStreamWriter(sink)) {
            out.write(stringToWrite);
        }
        System.out.println("");
        System.out.println("Data written to :" + new File(fileName).getCanonicalPath());
        System.out.println("");
        System.out.println(stringToWrite);
    } catch (final Exception e) {
        ClientLogger.logQuietly(e);
    }
}