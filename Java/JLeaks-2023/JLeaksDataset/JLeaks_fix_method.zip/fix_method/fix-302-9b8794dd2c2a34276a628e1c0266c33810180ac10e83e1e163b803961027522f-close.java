{
    if (!myClosed) {
        myClosed = true;
        try {
            flush();
        } finally {
            myStorage.close();
        }
    }
}