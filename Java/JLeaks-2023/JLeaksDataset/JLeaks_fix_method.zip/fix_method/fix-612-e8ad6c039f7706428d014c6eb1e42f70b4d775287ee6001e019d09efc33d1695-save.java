{
    try (RIFFWriter writer = new RIFFWriter(out, "DLS ")) {
        writeSoundbank(writer);
    }
}