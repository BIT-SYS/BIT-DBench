{
    try {
        return new ListIterator<>(Query.DEFAULT_CAPACITY, iterator);
    } finally {
        CloseableIterator.closeIterator(iterator);
    }
}