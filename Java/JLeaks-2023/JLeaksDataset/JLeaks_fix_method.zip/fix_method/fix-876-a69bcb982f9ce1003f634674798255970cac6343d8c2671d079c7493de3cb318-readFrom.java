{
    final EmptyCheckInputStream is = new EmptyCheckInputStream(entityStream);
    try (Jsonb jsonb = getJsonb(type)) {
        return jsonb.fromJson(is, genericType);
        // If null is returned, considered to be empty stream
    } catch (Throwable e) {
        if (is.isEmpty()) {
            return null;
        }
        // detail text provided in logger message
        throw new ProcessingException(Messages.MESSAGES.jsonBDeserializationError(e.toString()), e);
    }
}