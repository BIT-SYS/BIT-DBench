{
    TableSplit tSplit = (TableSplit) split;
    if (tSplit.getTableName() == null) {
        throw new IOException("Cannot create a record reader because of a" + " previous error. Please look at the previous logs lines from" + " the task's full log for more details.");
    }
    HTable table = new HTable(context.getConfiguration(), tSplit.getTableName());
    TableRecordReader trr = this.tableRecordReader;
    try {
        // if no table record reader was provided use default
        if (trr == null) {
            trr = new TableRecordReader();
        }
        Scan sc = tSplit.getScan();
        sc.setStartRow(tSplit.getStartRow());
        sc.setStopRow(tSplit.getEndRow());
        trr.setScan(sc);
        trr.setHTable(table);
    } catch (IOException ioe) {
        // If there is an exception make sure that all
        // resources are closed and released.
        table.close();
        trr.close();
        throw ioe;
    }
    return trr;
}