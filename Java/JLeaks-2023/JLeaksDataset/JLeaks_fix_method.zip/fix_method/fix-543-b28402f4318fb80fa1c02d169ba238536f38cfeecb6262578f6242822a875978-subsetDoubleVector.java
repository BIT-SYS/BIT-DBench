{
    return (Double[]) subsetObjectVector(tabfile, column, varcount, casecount, COLUMN_TYPE_DOUBLE);
}