{
    if (value != null && value != defaultValue) {
        String strColor = MessageFormat.format("new Color({0}, {1}, {2})", new Object[] { value.getRed(), value.getGreen(), value.getBlue() });
        write(MessageFormat.format(pattern, new Object[] { strColor }));
    }
}