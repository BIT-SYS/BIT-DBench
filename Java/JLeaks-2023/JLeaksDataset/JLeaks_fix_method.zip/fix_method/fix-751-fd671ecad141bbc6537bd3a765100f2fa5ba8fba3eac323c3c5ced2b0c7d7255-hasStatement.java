{
    // Checks whether the repository contains statements with a specific subject,
    // predicate and/or object, optionally in the specified contexts.
    try (RepositoryResult<Statement> stIter = getStatements(subj, pred, obj, includeInferred, contexts)) {
        return stIter.hasNext();
    }
}