{
    if (toUnix) {
        toUnix(input, amount);
    } else {
        toDos(input, amount);
    }
}