{
    try {
        int size = Iterators.size(iter);
        return size;
    } finally {
        iter.close();
    }
}