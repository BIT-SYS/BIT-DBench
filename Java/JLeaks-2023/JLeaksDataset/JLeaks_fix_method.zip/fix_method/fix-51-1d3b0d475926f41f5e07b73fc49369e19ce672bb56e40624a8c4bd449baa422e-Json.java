public class Json {
  private Json() {}                               // singleton: no public ctor

  static final JsonFactory FACTORY = new JsonFactory();
  static final ObjectMapper MAPPER = new ObjectMapper(FACTORY);

  /** The schema for Json data. */
  public static final Schema SCHEMA;
  static {
    try {
      InputStream in = Json.class.getResourceAsStream("/org/apache/avro/data/Json.avsc");
      try {
        SCHEMA = Schema.parse(in);
      } finally {
        in.close();
      }
    } catch (IOException e) {
      throw new AvroRuntimeException(e);
    }
  }