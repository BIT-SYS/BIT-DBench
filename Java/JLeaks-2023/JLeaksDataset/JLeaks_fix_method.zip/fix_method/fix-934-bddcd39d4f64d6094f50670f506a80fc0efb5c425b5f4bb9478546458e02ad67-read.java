{
    return this.dataBuffer.read(destination, offset, length);
}