{
    psInsert.setInt(1, scanId);
    psInsert.setInt(2, pluginId);
    psInsert.setString(3, alert);
    psInsert.setInt(4, risk);
    psInsert.setInt(5, reliability);
    psInsert.setString(6, description);
    psInsert.setString(7, uri);
    psInsert.setString(8, param);
    psInsert.setString(9, attack);
    psInsert.setString(10, otherInfo);
    psInsert.setString(11, solution);
    psInsert.setString(12, reference);
    psInsert.setString(13, evidence);
    psInsert.setInt(14, cweId);
    psInsert.setInt(15, wascId);
    psInsert.setInt(16, historyId);
    psInsert.setInt(17, sourceHistoryId);
    psInsert.executeUpdate();
    int id;
    try (ResultSet rs = psGetIdLastInsert.executeQuery()) {
        rs.next();
        id = rs.getInt(1);
    }
    return read(id);
}