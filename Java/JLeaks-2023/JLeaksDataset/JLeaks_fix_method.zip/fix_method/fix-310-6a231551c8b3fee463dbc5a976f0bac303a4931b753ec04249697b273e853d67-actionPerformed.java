{
    Column[] columns = _columns;
    if (columns == null) {
        List<Column> cols = new ArrayList<Column>();
        for (InputColumn<?> col : _inputColumns) {
            if (col.isPhysicalColumn()) {
                cols.add(col.getPhysicalColumn());
            }
        }
        columns = cols.toArray(new Column[cols.size()]);
    }
    if (columns.length == 0) {
        throw new IllegalStateException("No columns found - could not determine which columns to query");
    }
    try (final DatastoreConnection con = _datastore.openConnection()) {
        DataContext dc = con.getDataContext();
        Query q = dc.query().from(columns[0].getTable()).select(columns).toQuery();
        DataSetWindow window = new DataSetWindow(q, dc, PAGE_SIZE, _windowContext);
        window.setVisible(true);
    }
}