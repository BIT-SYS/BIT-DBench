{
    // $NON-NLS-1$
    Args.notNull(file, "Truststore file");
    final KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
    try (FileInputStream instream = new FileInputStream(file)) {
        trustStore.load(instream, tsp);
    }
    return builder.loadTrustMaterial(trustStore, trustStrategy);
}