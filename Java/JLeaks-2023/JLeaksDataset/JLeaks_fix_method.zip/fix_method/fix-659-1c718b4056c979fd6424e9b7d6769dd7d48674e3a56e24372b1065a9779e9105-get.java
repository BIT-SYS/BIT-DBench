{
    Long2DoubleMap itemMeans = new Long2DoubleOpenHashMap();
    Cursor<Rating> ratings = dao.getEvents(Rating.class);
    double globalMean;
    try {
        globalMean = computeItemAverages(ratings.fast().iterator(), damping, itemMeans);
    } finally {
        ratings.close();
    }
    return new ItemMeanPredictor(itemMeans, globalMean, damping);
}