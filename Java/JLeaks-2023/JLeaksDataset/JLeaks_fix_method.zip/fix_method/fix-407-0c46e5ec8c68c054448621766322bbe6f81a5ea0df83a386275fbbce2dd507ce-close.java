{
    try {
        super.close();
    } finally {
        out.close();
    }
}