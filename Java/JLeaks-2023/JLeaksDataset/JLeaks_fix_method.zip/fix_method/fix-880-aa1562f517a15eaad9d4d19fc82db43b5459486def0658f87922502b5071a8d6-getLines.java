{
    try (FileReader fr = new FileReader(file)) {
        return IOUtils.readLines(fr);
    }
}