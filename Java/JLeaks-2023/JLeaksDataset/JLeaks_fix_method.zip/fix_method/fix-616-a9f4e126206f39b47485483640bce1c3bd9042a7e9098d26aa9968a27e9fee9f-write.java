{
    s.write(getData());
}