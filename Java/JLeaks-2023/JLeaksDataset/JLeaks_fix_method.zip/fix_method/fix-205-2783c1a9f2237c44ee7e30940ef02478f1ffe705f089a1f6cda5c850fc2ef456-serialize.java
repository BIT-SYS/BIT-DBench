{
    try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutput out = new ObjectOutputStream(bos)) {
        out.writeObject(resultValue);
        out.flush();
        return bos.toByteArray();
    } catch (Exception ex) {
        log.info("Exception during serialization", ex);
    }
    return null;
}