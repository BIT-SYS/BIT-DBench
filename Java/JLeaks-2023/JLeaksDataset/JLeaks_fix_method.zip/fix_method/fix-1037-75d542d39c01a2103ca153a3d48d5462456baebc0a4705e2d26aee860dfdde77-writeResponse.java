{
    response.setContentType(contentType);
    final OutputStream out = response.getOutputStream();
    try (// Set the response type
    PrintWriter outWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(out, "UTF-8")))) {
        outWriter.print(output);
        outWriter.flush();
    }
}