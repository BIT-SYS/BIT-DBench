{
    Trigger trigger = null;
    ExecutableInput input = defaultInput;
    ExecutableCondition condition = defaultCondition;
    List<ActionWrapper> actions = defaultActions;
    ExecutableTransform transform = null;
    TimeValue throttlePeriod = null;
    Map<String, Object> metatdata = null;
    WatchStatus status = null;
    long version = Versions.MATCH_ANY;
    String currentFieldName = null;
    XContentParser.Token token;
    while ((token = parser.nextToken()) != XContentParser.Token.END_OBJECT) {
        if (token == null) {
            throw new ElasticsearchParseException("could not parse watch [{}]. null token", id);
        } else if (token == XContentParser.Token.FIELD_NAME) {
            currentFieldName = parser.currentName();
        } else if (token == null || currentFieldName == null) {
            throw new ElasticsearchParseException("could not parse watch [{}], unexpected token [{}]", id, token);
        } else if (WatchField.TRIGGER.match(currentFieldName, parser.getDeprecationHandler())) {
            trigger = triggerService.parseTrigger(id, parser);
        } else if (WatchField.INPUT.match(currentFieldName, parser.getDeprecationHandler())) {
            input = inputRegistry.parse(id, parser);
        } else if (WatchField.CONDITION.match(currentFieldName, parser.getDeprecationHandler())) {
            condition = actionRegistry.getConditionRegistry().parseExecutable(id, parser);
        } else if (WatchField.TRANSFORM.match(currentFieldName, parser.getDeprecationHandler())) {
            transform = actionRegistry.getTransformRegistry().parse(id, parser);
        } else if (WatchField.THROTTLE_PERIOD.match(currentFieldName, parser.getDeprecationHandler())) {
            throttlePeriod = timeValueMillis(parser.longValue());
        } else if (WatchField.THROTTLE_PERIOD_HUMAN.match(currentFieldName, parser.getDeprecationHandler())) {
            // Parser for human specified and 2.x backwards compatible throttle period
            try {
                throttlePeriod = WatcherDateTimeUtils.parseTimeValue(parser, WatchField.THROTTLE_PERIOD_HUMAN.toString());
            } catch (ElasticsearchParseException pe) {
                throw new ElasticsearchParseException("could not parse watch [{}]. failed to parse time value for field [{}]", pe, id, currentFieldName);
            }
        } else if (WatchField.ACTIONS.match(currentFieldName, parser.getDeprecationHandler())) {
            actions = actionRegistry.parseActions(id, parser);
        } else if (WatchField.METADATA.match(currentFieldName, parser.getDeprecationHandler())) {
            metatdata = parser.map();
        } else if (WatchField.VERSION.match(currentFieldName, parser.getDeprecationHandler())) {
            version = parser.longValue();
        } else if (WatchField.STATUS.match(currentFieldName, parser.getDeprecationHandler())) {
            if (includeStatus) {
                status = WatchStatus.parse(id, parser, clock);
            } else {
                parser.skipChildren();
            }
        } else {
            throw new ElasticsearchParseException("could not parse watch [{}]. unexpected field [{}]", id, currentFieldName);
        }
    }
    if (trigger == null) {
        throw new ElasticsearchParseException("could not parse watch [{}]. missing required field [{}]", id, WatchField.TRIGGER.getPreferredName());
    }
    if (status != null) {
        // verify the status is valid (that every action indeed has a status)
        for (ActionWrapper action : actions) {
            if (status.actionStatus(action.id()) == null) {
                throw new ElasticsearchParseException("could not parse watch [{}]. watch status in invalid state. action [{}] " + "status is missing", id, action.id());
            }
        }
    } else {
        // we need to create the initial statuses for the actions
        Map<String, ActionStatus> actionsStatuses = new HashMap<>();
        DateTime now = new DateTime(WatcherXContentParser.clock(parser).millis(), UTC);
        for (ActionWrapper action : actions) {
            actionsStatuses.put(action.id(), new ActionStatus(now));
        }
        status = new WatchStatus(now, unmodifiableMap(actionsStatuses));
    }
    return new Watch(id, trigger, input, condition, transform, throttlePeriod, actions, metatdata, status, version);
}