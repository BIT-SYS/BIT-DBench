{
    LongList items = new LongArrayList();
    try (FileReader fread = new FileReader(file);
        BufferedReader buf = new BufferedReader(fread)) {
        String line;
        int lno = 0;
        while ((line = buf.readLine()) != null) {
            lno += 1;
            if (line.trim().isEmpty()) {
                // skip blank lines
                continue;
            }
            long item;
            try {
                item = Long.parseLong(line.trim());
            } catch (IllegalArgumentException ex) {
                throw new IOException("invalid ID on " + file + " line " + lno + ": " + line);
            }
            items.add(item);
        }
    }
    return items;
}