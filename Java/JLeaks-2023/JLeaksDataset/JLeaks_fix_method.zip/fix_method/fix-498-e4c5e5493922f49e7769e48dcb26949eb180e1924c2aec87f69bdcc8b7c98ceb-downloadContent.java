{
    if (is == null) {
        return new DownloadedContent.InMemory(new byte[] {});
    }
    final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    final byte[] buffer = new byte[1024];
    int nbRead;
    try {
        while ((nbRead = is.read(buffer)) != -1) {
            bos.write(buffer, 0, nbRead);
            if (bos.size() > maxInMemory) {
                // we have exceeded the max for memory, let's write everything to a temporary file
                final File file = File.createTempFile("htmlunit", ".tmp");
                file.deleteOnExit();
                try (final FileOutputStream fos = new FileOutputStream(file)) {
                    // what we have already read
                    bos.writeTo(fos);
                    // what remains from the server response
                    IOUtils.copyLarge(is, fos);
                }
                return new DownloadedContent.OnFile(file, true);
            }
        }
    } catch (final ConnectionClosedException e) {
        LOG.warn("Connection was closed while reading from stream.", e);
        return new DownloadedContent.InMemory(bos.toByteArray());
    } catch (final IOException e) {
        // this might happen with broken gzip content
        LOG.warn("Exception while reading from stream.", e);
        return new DownloadedContent.InMemory(bos.toByteArray());
    } finally {
        IOUtils.closeQuietly(is);
    }
    return new DownloadedContent.InMemory(bos.toByteArray());
}