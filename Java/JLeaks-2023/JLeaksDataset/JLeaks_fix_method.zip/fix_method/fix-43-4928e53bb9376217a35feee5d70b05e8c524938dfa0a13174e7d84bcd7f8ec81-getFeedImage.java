{
    Cursor cursor = adapter.getImageCursor(id);
    try {
        if ((cursor.getCount() == 0) || !cursor.moveToFirst()) {
            return null;
        }
        FeedImage image = FeedImage.fromCursor(cursor);
        image.setId(id);
        return image;
    } finally {
        cursor.close();
    }
}