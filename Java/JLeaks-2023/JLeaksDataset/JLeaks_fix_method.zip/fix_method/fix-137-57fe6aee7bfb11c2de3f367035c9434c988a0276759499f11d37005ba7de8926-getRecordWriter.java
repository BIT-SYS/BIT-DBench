{
    return new TableRecordWriter(job);
}