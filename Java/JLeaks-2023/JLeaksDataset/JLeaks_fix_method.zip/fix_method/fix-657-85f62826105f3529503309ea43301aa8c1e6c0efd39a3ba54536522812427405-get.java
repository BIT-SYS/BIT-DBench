{
    String name = fileName;
    if (name == null) {
        name = prefix + "-" + UUID.randomUUID().toString() + ".csv";
    }
    logger.info("writing {} to {}", prefix, name);
    File file = new File(workingDir, name);
    try (PrintWriter writer = new PrintWriter(file)) {
        LongSet ids = getIds();
        LongIterator iter = ids.iterator();
        while (iter.hasNext()) {
            writer.println(iter.nextLong());
        }
    } catch (IOException e) {
        throw new RuntimeException("Error creating ratings file", e);
    }
    return name;
}