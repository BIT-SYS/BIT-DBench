  T build(ServiceLocator serviceLocator) throws IllegalStateException {
    try {
      for (ServiceCreationConfiguration<?> serviceConfig : serviceCfgs) {
        Service service = serviceLocator.getOrCreateServiceFor(serviceConfig);
        if (service == null) {
          throw new IllegalArgumentException("Couldn't resolve Service " + serviceConfig.getServiceType().getName());
        }
      }
      serviceLocator.loadDependenciesOf(ServiceDeps.class);
      serviceLocator.startAllServices();
    } catch (Exception e) {
      throw new IllegalStateException("UserManagedCacheBuilder failed to build.", e);
    }
    final Store.Provider storeProvider = serviceLocator.getService(Store.Provider.class);

    Store.Configuration<K, V> storeConfig;
    boolean persistent = resourcePools.getResourceTypeSet().contains(ResourceType.Core.DISK);
    final Store<K, V> store;
    if (persistent) {
      if (id == null) {
        throw new IllegalStateException("Persistent user managed caches must have an id set");
      }
      LocalPersistenceService persistenceService = serviceLocator.getService(LocalPersistenceService.class);
      if (!resourcePools.getPoolForResource(ResourceType.Core.DISK).isPersistent()) {
        try {
          persistenceService.destroyPersistenceSpace(id);
        } catch (CachePersistenceException cpex) {
          throw new RuntimeException("Unable to clean-up persistence space for non-restartable cache " + id, cpex);
        }
      }
      try {
        LocalPersistenceService.PersistenceSpaceIdentifier space = persistenceService.getOrCreatePersistenceSpace(id);
        SerializationProvider serialization = serviceLocator.getService(SerializationProvider.class);
        Serializer<K> keySerializer = serialization.createKeySerializer(keyType, classLoader, space);
        Serializer<V> valueSerializer = serialization.createValueSerializer(valueType, classLoader, space);
        storeConfig = new StoreConfigurationImpl<K, V>(keyType, valueType, evictionVeto, evictionPrioritizer, classLoader,
                expiry, resourcePools, keySerializer, valueSerializer);
        store = storeProvider.createStore(storeConfig, space);
      } catch (CachePersistenceException cpex) {
        throw new RuntimeException("Unable to create persistence space for cache " + id, cpex);
      }
    } else {
      Serializer<K> keySerializer = null;
      Serializer<V> valueSerializer = null;
      SerializationProvider serialization = serviceLocator.getService(SerializationProvider.class);
      if (serialization != null) {
        try {
          keySerializer = serialization.createKeySerializer(keyType, classLoader);
          valueSerializer = serialization.createValueSerializer(valueType, classLoader);
        } catch (Throwable t) {
          //TODO SerializationProvider doesn't require any exception behavior...
          LOGGER.info("Could not create serializers for user managed cache " + id, t);
        }
      }
      storeConfig = new StoreConfigurationImpl<K, V>(keyType, valueType, evictionVeto, evictionPrioritizer, classLoader,
              expiry, resourcePools, keySerializer, valueSerializer);
      store = storeProvider.createStore(storeConfig);
    }

    CacheConfiguration<K, V> cacheConfig = new BaseCacheConfiguration<K, V>(keyType, valueType, evictionVeto,
        evictionPrioritizer, classLoader, expiry, resourcePools);

    RuntimeConfiguration<K, V> runtimeConfiguration = new RuntimeConfiguration<K, V>(cacheConfig, cacheEventNotificationService);

    LifeCycled lifeCycled = new LifeCycled() {
      @Override
      public void init() throws Exception {
        storeProvider.initStore(store);
      }

      @Override
      public void close() throws Exception {
        storeProvider.releaseStore(store);
      }
    };
    if (persistent) {
      LocalPersistenceService persistenceService = serviceLocator
          .getService(LocalPersistenceService.class);
      if (persistenceService == null) {
        throw new IllegalStateException("No LocalPersistenceService could be found - did you configure one?");
      }

      PersistentUserManagedEhcache<K, V> cache = new PersistentUserManagedEhcache<K, V>(runtimeConfiguration, store, storeConfig, persistenceService, cacheLoaderWriter, cacheEventNotificationService, id);
      cache.addHook(lifeCycled);
      return cast(cache);
    } else {
      String loggerName;
      if (id != null) {
        loggerName = Ehcache.class.getName() + "-" + id;
      } else {
        loggerName = Ehcache.class.getName() + "-UserManaged" + instanceId.incrementAndGet();
      }
      final Ehcache<K, V> ehcache;
      ehcache = new Ehcache<K, V>(runtimeConfiguration, store, cacheLoaderWriter, cacheEventNotificationService, LoggerFactory.getLogger(loggerName));
      ehcache.addHook(lifeCycled);
      return cast(ehcache);
    }

  }
