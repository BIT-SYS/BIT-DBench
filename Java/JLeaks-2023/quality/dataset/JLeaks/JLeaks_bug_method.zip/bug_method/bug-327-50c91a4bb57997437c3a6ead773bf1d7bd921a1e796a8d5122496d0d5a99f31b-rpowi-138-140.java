    public NDArray rpowi(Number n) {
        return manager.create(n).toType(array.getDataType(), false).powi(array);
    }
