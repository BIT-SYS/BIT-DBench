		public void beginTransaction() throws ProducerFencedException {
			this.delegate.beginTransaction();
		}
