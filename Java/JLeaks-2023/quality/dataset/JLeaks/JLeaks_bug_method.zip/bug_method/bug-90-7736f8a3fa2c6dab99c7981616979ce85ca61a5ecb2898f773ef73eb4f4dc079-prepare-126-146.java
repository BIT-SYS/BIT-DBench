  public DruidStatement prepare(final PlannerFactory plannerFactory, final String query, final long maxRowCount)
  {
    try (final DruidPlanner planner = plannerFactory.createPlanner(queryContext)) {
      synchronized (lock) {
        ensure(State.NEW);
        this.plannerResult = planner.plan(query);
        this.maxRowCount = maxRowCount;
        this.query = query;
        this.signature = Meta.Signature.create(
            createColumnMetaData(plannerResult.rowType()),
            query,
            new ArrayList<AvaticaParameter>(),
            Meta.CursorFactory.ARRAY,
            Meta.StatementType.SELECT // We only support SELECT
        );
        this.state = State.PREPARED;
      }
    }
    catch (Exception e) {
      throw Throwables.propagate(e);
    }
