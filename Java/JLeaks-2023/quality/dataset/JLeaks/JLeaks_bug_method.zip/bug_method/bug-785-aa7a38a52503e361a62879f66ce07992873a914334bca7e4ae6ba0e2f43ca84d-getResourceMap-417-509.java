        private Map<String, Map<String, ZipUtils.Info>> getResourceMap() throws IOException {
            Map<String, Map<String, ZipUtils.Info>> res = content;
            if (res == null) {
                synchronized (this) {
                    res = content;
                    if (res == null) {
                        res = ZipUtils.readEntries(getChannel());
                        content = res;
                    }
                }
            }
            return res;
        }

        /**
         * Splits a {@code resourceName} into folder and base file name.
         *
         * @param resourceName the name to split
         * @return an array containing parent folder and base file name.
         */
        private static String[] split(String resourceName) {
            int index = resourceName.lastIndexOf('/');
            if (index < 0) {
                return new String[]{"", resourceName};
            } else {
                return new String[]{
                                resourceName.substring(0, index),
                                resourceName.substring(index + 1, resourceName.length())
                };
            }
        }

        /**
         * Utility methods to read zip file.
         */
        static final class ZipUtils {

            private static final int LIMIT = 1 << 16;
            private static final long UINT32_MAX_VALUE = 0xffffffffL;
            private static final int UINT16_MAX_VALUE = 0xffff;

            private ZipUtils() {
                throw new IllegalStateException("No instance allowed.");
            }

            /**
             * Adapts {@link SeekableByteChannel} to {@link InputStream}.
             */
            private static class ChannelInputStream extends InputStream {

                private final SeekableByteChannel channel;
                private final long len;

                ChannelInputStream(SeekableByteChannel channel) throws IOException {
                    this.channel = channel;
                    this.len = channel.size();
                }

                ChannelInputStream(SeekableByteChannel channel, long len) throws IOException {
                    assert channel != null;
                    assert len >= 0;
                    this.channel = channel;
                    this.len = channel.position() + len;
                }

                @Override
                public int read(byte[] data, int offset, int size) throws IOException {
                    int rem = available();
                    if (rem == 0) {
                        return -1;
                    }
                    int rlen = size < rem ? size : rem;
                    ByteBuffer buffer = ByteBuffer.wrap(data, offset, rlen);
                    return this.channel.read(buffer);
                }

                @Override
                public int read() throws java.io.IOException {
                    if (available() == 0) {
                        return -1;
                    } else {
                        ByteBuffer buffer = ByteBuffer.allocate(1);
                        channel.read(buffer);
                        buffer.flip();
                        return buffer.get();
                    }
                }

                @Override
                public int available() throws IOException {
                    return (int) (len - this.channel.position());
                }
            }
