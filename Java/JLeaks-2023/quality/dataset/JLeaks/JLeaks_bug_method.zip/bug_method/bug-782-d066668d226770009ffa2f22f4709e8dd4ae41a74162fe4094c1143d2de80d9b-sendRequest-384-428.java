    private static void sendRequest(RemoteRequest request, HttpURLConnection conn) throws IOException {
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "R-Grid-Remote-Client");
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        byte[] osBuf = request.params;
        if (log.isLoggable(Level.FINER)) {
            log.finer(RemoteDeviceDataExchange.bytesToString("Data to server:", osBuf, osBuf.length));
        }
        try {
            os.write(osBuf);
        } finally {
            os.close();
        }
        int responseCode = conn.getResponseCode();
        if (responseCode == 200) { // Status OK
            InputStream is = conn.getInputStream();
            byte[] isBuf = new byte[is.available() + 1];
            int off = 0;
            int len;
            try {
                while ((len = is.read(isBuf, off, isBuf.length - off)) != -1) {
                    off += len;
                    if (off == isBuf.length) {
                        byte[] newBuf = new byte[isBuf.length + Math.max(isBuf.length, is.available() + 1)];
                        System.arraycopy(isBuf, 0, newBuf, 0, off);
                        isBuf = newBuf;
                    }
                }
            } finally {
                is.close();
            }
            if (log.isLoggable(Level.FINER)) {
                log.finer(RemoteDeviceDataExchange.bytesToString("Response from server:", isBuf, off));
            }
            byte[] result;
            if (off != isBuf.length) {
                result = new byte[off];
                System.arraycopy(isBuf, 0, result, 0, off);
            } else {
                result = isBuf;
            }
            request.finish(result, null);
        }
    }
