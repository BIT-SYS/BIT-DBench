	public final static void copyFile(ResourceFile fromFile, ResourceFile toFile,
			TaskMonitor monitor) throws IOException {

		InputStream fin = null;
		OutputStream out = null;
		try {
			fin = fromFile.getInputStream();
			out = toFile.getOutputStream();

			if (monitor != null) {
				monitor.initialize((int) fromFile.length());
			}
			copyStreamToStream(fin, out, monitor);
		}
		finally {
			if (fin != null) {
				fin.close();
			}

			if (out != null) {
				out.close();
			}
		}
	}
