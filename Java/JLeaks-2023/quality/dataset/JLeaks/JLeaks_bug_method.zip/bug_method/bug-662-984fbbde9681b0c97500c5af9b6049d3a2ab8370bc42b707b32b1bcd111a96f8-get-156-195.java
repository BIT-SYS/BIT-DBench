        public RatingSnapshotDAO get() {
            File file;
            try {
                file = File.createTempFile("ratings", ".pack");
            } catch (IOException e) {
                throw new RuntimeException("cannot create temporary file");
            }
            file.deleteOnExit();
            logger.debug("packing ratings to {}", file);

            EnumSet<BinaryFormatFlag> flags = EnumSet.noneOf(BinaryFormatFlag.class);
            SortOrder order = SortOrder.ANY;
            if (useTimestamps) {
                flags.add(BinaryFormatFlag.TIMESTAMPS);
                order = SortOrder.TIMESTAMP;
            }

            Closer closer = Closer.create();
            try {
                try {
                    BinaryRatingPacker packer = closer.register(BinaryRatingPacker.open(file, flags));
                    Cursor<Rating> ratings = closer.register(dao.streamEvents(Rating.class, order));
                    packer.writeRatings(ratings);
                } catch (Throwable th) { // NOSONAR using a closer
                    throw closer.rethrow(th);
                } finally {
                    closer.close();
                }
                BinaryRatingDAO result = BinaryRatingDAO.open(file);
                // try to delete the file early, helps keep things clean on Unix
                if (file.delete()) {
                    logger.debug("unlinked {}, will be deleted when freed", file);
                }
                return new RatingSnapshotDAO(result);
            } catch (IOException ex) {
                throw new RuntimeException("error packing ratings", ex);
            }
        }
    }
}
