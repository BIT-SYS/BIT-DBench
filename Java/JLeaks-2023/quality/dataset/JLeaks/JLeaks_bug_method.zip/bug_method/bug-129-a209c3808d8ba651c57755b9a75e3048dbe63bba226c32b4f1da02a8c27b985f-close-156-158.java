  public void close() {
    this.scanner.close();
  }
