	protected void closeAllResources() {
	}

