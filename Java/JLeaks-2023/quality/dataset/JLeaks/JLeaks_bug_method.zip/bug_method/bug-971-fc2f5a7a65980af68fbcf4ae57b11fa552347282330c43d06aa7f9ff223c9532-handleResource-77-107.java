	@Override
	public void handleResource(String id, byte[] data)
	{
		ensureParentFolder();
		
		OutputStream os = null;
		
		try
		{
			os = new BufferedOutputStream(new FileOutputStream(new File(parentFolder, id)));
			os.write(data);
		}
		catch (IOException e)
		{
			throw new JRRuntimeException(e);
		}
		finally
		{
			if (os != null)
			{
				try
				{
					os.close();
				}
				catch (IOException e)
				{
					throw new JRRuntimeException(e);
				}
			}
		}
	}
