    private Exception exception = null;

    /**
     * Get the value of exception.
     *
     * @return the value of exception
     */
    public Exception getException() {
        return exception;
    }

    /**
     * returns whether or not an exception occurred during download.
     *
     * @return whether or not an exception occurred during download
     */
    public boolean hasException() {
        return exception != null;
    }

    @Override
    public Future<ProcessTask> call() throws Exception {
        try {
            Settings.setInstance(settings);
            final URL url1 = new URL(nvdCveInfo.getUrl());
            final URL url2 = new URL(nvdCveInfo.getOldSchemaVersionUrl());
            String msg = String.format("Download Started for NVD CVE - %s", nvdCveInfo.getId());
            LOGGER.log(Level.INFO, msg);
            try {
                Downloader.fetchFile(url1, first);
                Downloader.fetchFile(url2, second);
            } catch (DownloadFailedException ex) {
                msg = String.format("Download Failed for NVD CVE - %s%nSome CVEs may not be reported.", nvdCveInfo.getId());
                LOGGER.log(Level.WARNING, msg);
                if (Settings.getString(Settings.KEYS.PROXY_SERVER) == null) {
                    LOGGER.log(Level.INFO,
                            "If you are behind a proxy you may need to configure dependency-check to use the proxy.");
                }
                LOGGER.log(Level.FINE, null, ex);
                return null;
            }
            if (url1.toExternalForm().endsWith(".xml.gz")) {
                extractGzip(first);
            }
            if (url2.toExternalForm().endsWith(".xml.gz")) {
                extractGzip(second);
            }

            msg = String.format("Download Complete for NVD CVE - %s", nvdCveInfo.getId());
            LOGGER.log(Level.INFO, msg);
            if (this.processorService == null) {
                return null;
            }
            final ProcessTask task = new ProcessTask(cveDB, this, settings);
            return this.processorService.submit(task);

        } catch (Throwable ex) {
            final String msg = String.format("An exception occurred downloading NVD CVE - %s%nSome CVEs may not be reported.", nvdCveInfo.getId());
            LOGGER.log(Level.WARNING, msg);
            LOGGER.log(Level.FINE, "Download Task Failed", ex);
        } finally {
            Settings.cleanup(false);
        }
        return null;
    }

    /**
     * Attempts to delete the files that were downloaded.
     */
    public void cleanup() {
        boolean deleted = false;
        try {
            if (first != null && first.exists()) {
                deleted = first.delete();
            }
        } finally {
            if (first != null && (first.exists() || !deleted)) {
                first.deleteOnExit();
            }
        }
        try {
            deleted = false;
            if (second != null && second.exists()) {
                deleted = second.delete();
            }
        } finally {
            if (second != null && (second.exists() || !deleted)) {
                second.deleteOnExit();
            }
        }
    }

    /**
     * Extracts the file contained in a gzip archive. The extracted file is placed in the exact same path as the file
     * specified.
     *
     * @param file the archive file
     * @throws FileNotFoundException thrown if the file does not exist
     * @throws IOException thrown if there is an error extracting the file.
     */
    private void extractGzip(File file) throws FileNotFoundException, IOException {
        String originalPath = file.getPath();
        File gzip = new File(originalPath + ".gz");
        if (gzip.isFile()) {
            gzip.delete();
        }
        file.renameTo(gzip);
        file = new File(originalPath);

        byte[] buffer = new byte[4096];

        GZIPInputStream cin = new GZIPInputStream(new FileInputStream(gzip));

        FileOutputStream out = new FileOutputStream(file);

        int len;
        while ((len = cin.read(buffer)) > 0) {
            out.write(buffer, 0, len);
        }
        cin.close();
        out.close();
        FileUtils.delete(gzip);
    }
