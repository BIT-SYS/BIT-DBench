    public static double computeMeanRating(DataAccessObject dao) {
        double total = 0;
        long count = 0;

        Cursor<Rating> ratings = dao.getEvents(Rating.class);
        for (Rating r : ratings.fast()) {
            Preference p = r.getPreference();
            if (p != null) {
                total += p.getValue();
                count += 1;
            }
        }
        ratings.close();

        double avg = 0;
        if (count > 0) {
            avg = total / count;
        }

        return avg;
    }
}
