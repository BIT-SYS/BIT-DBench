  public CenterPicker(final String mapName) {
    super("Center Picker");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    File file = null;
    if (mapFolderLocation != null && mapFolderLocation.exists()) {
      file = new File(mapFolderLocation, "polygons.txt");
    }
    if (file == null || !file.exists()) {
      file = new File(new File(mapName).getParent() + File.separator + "polygons.txt");
    }
    if (file.exists() && JOptionPane.showConfirmDialog(new JPanel(),
        "A polygons.txt file was found in the map's folder, do you want to use the file to supply the territories "
            + "names?",
        "File Suggestion", 1) == 0) {
      try {
        polygons = PointFileReaderWriter.readOneToManyPolygons(new FileInputStream(file.getPath()));
      } catch (final IOException ex1) {
        System.out.println("Something wrong with your Polygons file: " + ex1);
        ex1.printStackTrace();
      }
    } else {
      try {
        final String polyPath = new FileOpen("Select A Polygon File", mapFolderLocation, ".txt").getPathString();
        if (polyPath != null) {
          polygons = PointFileReaderWriter.readOneToManyPolygons(new FileInputStream(polyPath));
        }
      } catch (final IOException ex1) {
        System.out.println("Something wrong with your Polygons file: " + ex1);
        ex1.printStackTrace();
      }
    }
