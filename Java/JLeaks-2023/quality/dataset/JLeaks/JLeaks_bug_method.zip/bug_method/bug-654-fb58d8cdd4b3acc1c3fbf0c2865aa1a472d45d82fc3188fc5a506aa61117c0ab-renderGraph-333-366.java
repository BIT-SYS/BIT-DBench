    public static void renderGraph(DAGNode<Component,Dependency> graph,
                                   File graphvizFile) throws IOException, RecommenderBuildException {
        logger.debug("graph has {} nodes", graph.getReachableNodes().size());
        logger.debug("simulating instantiation");
        RecommenderInstantiator instantiator = RecommenderInstantiator.create(graph);
        DAGNode<Component, Dependency> unshared = instantiator.simulate();
        logger.debug("unshared graph has {} nodes", unshared.getReachableNodes().size());
        Closer close = Closer.create();
        try {
            Writer writer = close.register(new FileWriter(graphvizFile));
            GraphWriter gw = close.register(new GraphWriter(writer));
            GraphDumper dumper = new GraphDumper(graph, unshared.getReachableNodes(), gw);
            logger.debug("writing root node");
            String rid = dumper.setRoot(graph);
            // process each other node & add an edge
            for (DAGEdge<Component, Dependency> e: graph.getOutgoingEdges()) {
                DAGNode<Component, Dependency> target = e.getTail();
                Component csat = target.getLabel();
                if (!satIsNull(csat.getSatisfaction())) {
                    logger.debug("processing node {}", csat.getSatisfaction());
                    String id = dumper.process(target);
                    gw.putEdge(EdgeBuilder.create(rid, id)
                                          .set("arrowhead", "vee")
                                          .build());
                }
            }
            // and we're done
            dumper.finish();
        } catch (Throwable th) { // NOSONAR using a closer
            throw close.rethrow(th);
        } finally {
            close.close();
        }
    }
