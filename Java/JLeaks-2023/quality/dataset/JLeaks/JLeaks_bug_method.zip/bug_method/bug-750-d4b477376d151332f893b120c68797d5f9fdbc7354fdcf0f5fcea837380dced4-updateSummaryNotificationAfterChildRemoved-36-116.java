   static void updateSummaryNotificationAfterChildRemoved(Context context, SQLiteDatabase writableDb, String group, boolean dismissed) {
      Cursor cursor = writableDb.query(
          NotificationTable.TABLE_NAME,
          new String[] { NotificationTable.COLUMN_NAME_ANDROID_NOTIFICATION_ID, // return columns
                         NotificationTable.COLUMN_NAME_CREATED_TIME },
          NotificationTable.COLUMN_NAME_GROUP_ID + " = ? AND " + // Where String
              NotificationTable.COLUMN_NAME_DISMISSED + " = 0 AND " +
              NotificationTable.COLUMN_NAME_OPENED + " = 0 AND " +
              NotificationTable.COLUMN_NAME_IS_SUMMARY + " = 0" ,
          new String[] { group }, // whereArgs
          null, null,
          NotificationTable._ID + " DESC");   // sort order, new to old);
      
      int notifsInGroup = cursor.getCount();
   
      // If all individual notifications consumed
      //   - Remove summary notification from the shade.
      //   - Mark summary notification as consumed.
      if (notifsInGroup == 0) {
         cursor.close();
         
         // Get the Android Notification ID of the summary notification
         cursor = writableDb.query(
             NotificationTable.TABLE_NAME,
             new String[] { NotificationTable.COLUMN_NAME_ANDROID_NOTIFICATION_ID }, // retColumn
             NotificationTable.COLUMN_NAME_GROUP_ID + " = ? AND " + // Where String
                 NotificationTable.COLUMN_NAME_DISMISSED + " = 0 AND " +
                 NotificationTable.COLUMN_NAME_OPENED + " = 0 AND " +
                 NotificationTable.COLUMN_NAME_IS_SUMMARY + " = 1" ,
             new String[] { group }, // whereArgs
             null, null, null);
         
         boolean hasRecord = cursor.moveToFirst();
         if (!hasRecord)
            return;
         int androidNotifId = cursor.getInt(cursor.getColumnIndex(NotificationTable.COLUMN_NAME_ANDROID_NOTIFICATION_ID));
         cursor.close();
         
         // Remove the summary notification from the shade.
         NotificationManager notificationManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
         notificationManager.cancel(androidNotifId);
         
         // Mark the summary notification as opened or dismissed.
         ContentValues values = new ContentValues();
         values.put(dismissed ? NotificationTable.COLUMN_NAME_DISMISSED : NotificationTable.COLUMN_NAME_OPENED, 1);
         writableDb.update(NotificationTable.TABLE_NAME,
                           values,
                           NotificationTable.COLUMN_NAME_ANDROID_NOTIFICATION_ID + " = " + androidNotifId,
                           null);
         return;
      }
      
      // Only a single notification now in the group
      //   - Need to recreate a summary notification so it looks like a normal notifications since we
      //        only have one notification now.
      if (notifsInGroup == 1) {
         cursor.close();
         restoreSummary(context, group);
         return;
      }
      
      // 2 or more still left in the group
      //  - Just need to update the summary notification.
      //  - Don't need start a broadcast / service as the extender doesn't support overriding
      //      the summary notification.
      try {
         cursor.moveToFirst();
         Long datetime = cursor.getLong(cursor.getColumnIndex(NotificationTable.COLUMN_NAME_CREATED_TIME));
         cursor.close();
         
         NotificationGenerationJob notifJob = new NotificationGenerationJob(context);
         notifJob.restoring = true;
         notifJob.shownTimeStamp = datetime;
         
         JSONObject payload = new JSONObject();
         payload.put("grp", group);
         notifJob.jsonPayload = payload;
         
         GenerateNotification.updateSummaryNotification(notifJob);
      } catch (JSONException e) {}
   }
