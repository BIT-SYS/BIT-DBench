  public PlacementPicker(final String mapName) {
    super("Placement Picker");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    if (!placeDimensionsSet) {
      try {
        File file = null;
        if (mapFolderLocation != null && mapFolderLocation.exists()) {
          file = new File(mapFolderLocation, "map.properties");
        }
        if (file == null || !file.exists()) {
          file = new File(new File(mapName).getParent() + File.separator + "map.properties");
        }
        if (file.exists()) {
          double scale = unitZoomPercent;
          int width = unitWidth;
          int height = unitHeight;
          boolean found = false;
          final String scaleProperty = MapData.PROPERTY_UNITS_SCALE + "=";
          final String widthProperty = MapData.PROPERTY_UNITS_WIDTH + "=";
          final String heightProperty = MapData.PROPERTY_UNITS_HEIGHT + "=";
          final FileReader reader = new FileReader(file);
          final LineNumberReader reader2 = new LineNumberReader(reader);
          int i = 0;
          while (true) {
            reader2.setLineNumber(i);
            final String line = reader2.readLine();
            if (line == null) {
              break;
            }
            if (line.contains(scaleProperty)) {
              try {
                scale = Double.parseDouble(line.substring(line.indexOf(scaleProperty) + scaleProperty.length()).trim());
                found = true;
              } catch (final NumberFormatException ex) {
                // ignore malformed input
              }
            }
            if (line.contains(widthProperty)) {
              try {
                width = Integer.parseInt(line.substring(line.indexOf(widthProperty) + widthProperty.length()).trim());
                found = true;
              } catch (final NumberFormatException ex) {
                // ignore malformed input
              }
            }
            if (line.contains(heightProperty)) {
              try {
                height =
                    Integer.parseInt(line.substring(line.indexOf(heightProperty) + heightProperty.length()).trim());
                found = true;
              } catch (final NumberFormatException ex) {
                // ignore malformed input
              }
            }
          }
          reader2.close();
          i++;
          if (found) {
            final int result = JOptionPane.showConfirmDialog(new JPanel(),
                "A map.properties file was found in the map's folder, "
                    + "\r\n do you want to use the file to supply the info for the placement box size? "
                    + "\r\n Zoom = " + scale + ",  Width = " + width + ",  Height = " + height + ",    Result = ("
                    + ((int) (scale * width)) + "x" + ((int) (scale * height)) + ")",
                "File Suggestion", 1);

            if (result == 0) {
              unitZoomPercent = scale;
              placeWidth = (int) (unitZoomPercent * width);
              placeHeight = (int) (unitZoomPercent * height);
              placeDimensionsSet = true;
            }
          }
        }
      } catch (final Exception ex) {
        ClientLogger.logQuietly(ex);
      }
    }
    if (!placeDimensionsSet || JOptionPane.showConfirmDialog(new JPanel(),
        "Placement Box Size already set (" + placeWidth + "x" + placeHeight + "), "
            + "do you wish to continue with this?\r\n"
            + "Select Yes to continue, Select No to override and change the size.",
        "Placement Box Size", JOptionPane.YES_NO_OPTION) == 1) {
      try {
        final String result = getUnitsScale();
        try {
          unitZoomPercent = Double.parseDouble(result.toLowerCase());
        } catch (final NumberFormatException ex) {
          // ignore malformed input
        }
        final String width = JOptionPane.showInputDialog(null,
            "Enter the unit's image width in pixels (unscaled / without zoom).\r\n(e.g. 48)");
        if (width != null) {
          try {
            placeWidth = (int) (unitZoomPercent * Integer.parseInt(width));
          } catch (final NumberFormatException ex) {
            // ignore malformed input
          }
        }
        final String height = JOptionPane.showInputDialog(null,
            "Enter the unit's image height in pixels (unscaled / without zoom).\r\n(e.g. 48)");
        if (height != null) {
          try {
            placeHeight = (int) (unitZoomPercent * Integer.parseInt(height));
          } catch (final NumberFormatException ex) {
            // ignore malformed input
          }
        }
        placeDimensionsSet = true;
      } catch (final Exception ex) {
        ClientLogger.logQuietly(ex);
      }
    }
    File file = null;
    if (mapFolderLocation != null && mapFolderLocation.exists()) {
      file = new File(mapFolderLocation, "polygons.txt");
    }
    if (file == null || !file.exists()) {
      file = new File(new File(mapName).getParent() + File.separator + "polygons.txt");
    }
    if (file.exists() && JOptionPane.showConfirmDialog(new JPanel(),
        "A polygons.txt file was found in the map's folder, do you want to use the file to supply the territories?",
        "File Suggestion", 1) == 0) {
      try {
        System.out.println("Polygons : " + file.getPath());
        polygons = PointFileReaderWriter.readOneToManyPolygons(new FileInputStream(file.getPath()));
      } catch (final IOException ex1) {
        ex1.printStackTrace();
      }
    } else {
      try {
        System.out.println("Select the Polygons file");
        final String polyPath = new FileOpen("Select A Polygon File", mapFolderLocation, ".txt").getPathString();
        if (polyPath != null) {
          System.out.println("Polygons : " + polyPath);
          polygons = PointFileReaderWriter.readOneToManyPolygons(new FileInputStream(polyPath));
        } else {
          System.out.println("Polygons file not given. Will run regardless");
        }
      } catch (final IOException ex1) {
        ex1.printStackTrace();
      }
    }
    createImage(mapName);
    final JPanel imagePanel = createMainPanel();
    /*
     * Add a mouse listener to show
     * X : Y coordinates on the lower
     * left corner of the screen.
     */
    imagePanel.addMouseMotionListener(new MouseMotionAdapter() {
      @Override
      public void mouseMoved(final MouseEvent e) {
        locationLabel.setText("x:" + e.getX() + " y:" + e.getY());
        currentSquare = new Point(e.getPoint());
        repaint();
      }
    });
    /*
     * Add a mouse listener to monitor
     * for right mouse button being
     * clicked.
     */
    imagePanel.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(final MouseEvent e) {
        mouseEvent(e.getPoint(), e.isControlDown() || e.isShiftDown(), SwingUtilities.isRightMouseButton(e));
      }
    });
    // set up the image panel size dimensions ...etc
    imagePanel.setMinimumSize(new Dimension(image.getWidth(this), image.getHeight(this)));
    imagePanel.setPreferredSize(new Dimension(image.getWidth(this), image.getHeight(this)));
    imagePanel.setMaximumSize(new Dimension(image.getWidth(this), image.getHeight(this)));
    // set up the layout manager
    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(new JScrollPane(imagePanel), BorderLayout.CENTER);
    this.getContentPane().add(locationLabel, BorderLayout.SOUTH);
    // set up the actions
    final Action openAction = SwingAction.of("Load Placements", e -> loadPlacements());
    openAction.putValue(Action.SHORT_DESCRIPTION, "Load An Existing Placement File");
    final Action saveAction = SwingAction.of("Save Placements", e -> savePlacements());
    saveAction.putValue(Action.SHORT_DESCRIPTION, "Save The Placements To File");
    final Action exitAction = SwingAction.of("Exit", e -> System.exit(0));
    exitAction.putValue(Action.SHORT_DESCRIPTION, "Exit The Program");
    // set up the menu items
    final JMenuItem openItem = new JMenuItem(openAction);
    openItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
    final JMenuItem saveItem = new JMenuItem(saveAction);
    saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
    final JMenuItem exitItem = new JMenuItem(exitAction);
    // set up the menu bar
    final JMenuBar menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    final JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('F');
    fileMenu.add(openItem);
    fileMenu.add(saveItem);
    fileMenu.addSeparator();
    fileMenu.add(exitItem);
    showAllMode = false;
    showOverflowMode = false;
    showIncompleteMode = false;
    incompleteNum = 1;
    showAllModeItem = new JCheckBoxMenuItem("Show All Placements Mode", false);
    showAllModeItem.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent event) {
        showAllMode = showAllModeItem.getState();
        repaint();
      }
    });
    showOverflowModeItem = new JCheckBoxMenuItem("Show Overflow Mode", false);
    showOverflowModeItem.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent event) {
        showOverflowMode = showOverflowModeItem.getState();
        repaint();
      }
    });
    showIncompleteModeItem = new JCheckBoxMenuItem("Show Incomplete Placements Mode", false);
    showIncompleteModeItem.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent event) {
        if (showIncompleteModeItem.getState()) {
          final String num = JOptionPane.showInputDialog(null,
              "Enter the minimum number of placements each territory must have.\r\n(examples: 1, 4, etc.)");
          try {
            incompleteNum = Math.max(1, Math.min(50, Integer.parseInt(num)));
          } catch (final Exception ex) {
            incompleteNum = 1;
          }
        }
        showIncompleteMode = showIncompleteModeItem.getState();
        repaint();
      }
    });
    final JMenu editMenu = new JMenu("Edit");
    editMenu.setMnemonic('E');
    editMenu.add(showAllModeItem);
    editMenu.add(showOverflowModeItem);
    editMenu.add(showIncompleteModeItem);
    menuBar.add(fileMenu);
    menuBar.add(editMenu);
  } // end constructor
