    private static boolean stop(
            Server server, CommandExecutor executor, DefaultMirroringService mirroringService,
            ProjectManager pm, ExecutorService repositoryWorker) {

        boolean success = true;
        try {
            if (server != null) {
                logger.info("Stopping the RPC server ..");
                server.stop().join();
                logger.info("Stopped the RPC server");
            }
        } catch (Exception e) {
            success = false;
            logger.warn("Failed to stop the RPC server:", e);
        } finally {
            try {
                if (executor != null) {
                    logger.info("Stopping the command executor ..");
                    executor.stop();
                    logger.info("Stopped the command executor");
                }
            } catch (Exception e) {
                success = false;
                logger.warn("Failed to stop the command executor:", e);
            } finally {
                try {
                    // Stop the mirroring service if the command executor did not stop it.
                    if (mirroringService != null && mirroringService.isStarted()) {
                        logger.info("Stopping the mirroring service not terminated by the command executor ..");
                        mirroringService.stop();
                        logger.info("Stopped the mirroring service");
                    }
                } catch (Exception e) {
                    success = false;
                    logger.warn("Failed to stop the mirroring service:", e);
                } finally {
                    try {
                        if (pm != null) {
                            logger.info("Stopping the project manager ..");
                            pm.close();
                            logger.info("Stopped the project manager");
                        }
                    } catch (Exception e) {
                        success = false;
                        logger.warn("Failed to stop the project manager:", e);
                    } finally {
                        if (repositoryWorker != null && !repositoryWorker.isTerminated()) {
                            logger.info("Stopping the repository worker ..");
                            boolean interruptLater = false;
                            while (!repositoryWorker.isTerminated()) {
                                repositoryWorker.shutdownNow();
                                try {
                                    repositoryWorker.awaitTermination(1, TimeUnit.SECONDS);
                                } catch (InterruptedException e) {
                                    // Interrupt later.
                                    interruptLater = true;
                                }
                            }
                            logger.info("Stopped the repository worker");

                            if (interruptLater) {
                                Thread.currentThread().interrupt();
                            }
                        }
                    }
                }
            }
        }
        return success;
    }
}
