    /**
     * Write this to a file.
     *
     * @param file the file to write to
     */
    private void write(final File file) {
      try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
        writer.write("digraph " + graphName + "{");
        writer.newLine();
        for (final String line : lines) {
          writer.write(line + ";");
          writer.newLine();
        }
        writer.write("}");
        writer.flush();
      } catch (IOException exc) {
        throw new BugInCF(exc, "Exception visualizing type:%nfile=%s%ntype=%s", file, type);
      }
    }

    /**
     * Connection drawer is used to add the connections between all the nodes created by the
     * NodeDrawer. It is not a scanner and is called on every node in the nodes map.
     */
    private class ConnectionDrawer implements AnnotatedTypeVisitor<Void, Void> {
