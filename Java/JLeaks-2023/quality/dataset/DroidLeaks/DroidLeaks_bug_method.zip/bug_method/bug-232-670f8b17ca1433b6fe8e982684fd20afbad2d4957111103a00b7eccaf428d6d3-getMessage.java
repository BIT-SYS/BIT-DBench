{
    synchronized (CACHE) {
        String body = cursor.getString(INDEX_BODY);
        int id = cursor.getInt(INDEX_ID);
        if (body == null) {
            // MMS
            id *= -1;
        }
        Message ret = CACHE.get(id);
        if (ret == null) {
            ret = new Message(context, cursor);
            CACHE.put(id, ret);
            Log.d(TAG, "cachesize: " + CACHE.size());
            while (CACHE.size() > CAHCESIZE) {
                Integer i = CACHE.keySet().iterator().next();
                Log.d(TAG, "rm msg. from cache: " + i);
                Message cc = CACHE.remove(i);
                if (cc == null) {
                    Log.w(TAG, "CACHE might be inconsistent!");
                    break;
                }
            }
        } else {
            ret.update(cursor);
        }
        return ret;
    }
}