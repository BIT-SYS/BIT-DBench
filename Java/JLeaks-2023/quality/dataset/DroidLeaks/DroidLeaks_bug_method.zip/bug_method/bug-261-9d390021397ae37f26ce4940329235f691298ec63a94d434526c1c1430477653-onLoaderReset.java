{
    if (mAdapter != null)
        mAdapter.swapCursor(null);
    configureEmptyLabel();
    if (isTablet()) {
        reloadLinearLayout();
    }
}