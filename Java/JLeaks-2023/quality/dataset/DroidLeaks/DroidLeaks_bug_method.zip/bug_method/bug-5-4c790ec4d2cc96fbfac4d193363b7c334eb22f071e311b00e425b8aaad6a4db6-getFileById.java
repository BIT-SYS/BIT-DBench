{
    Cursor c = getCursorForValue(ProviderTableMeta._ID, String.valueOf(id));
    OCFile file = null;
    if (c.moveToFirst()) {
        file = createFileInstance(c);
        c.close();
    }
    return file;
}