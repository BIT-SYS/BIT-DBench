{
    try {
        Multipart multipartEncryptedMultipart = (Multipart) currentlyDecrypringOrVerifyingPart.getBody();
        BodyPart encryptionPayloadPart = multipartEncryptedMultipart.getBodyPart(1);
        Body encryptionPayloadBody = encryptionPayloadPart.getBody();
        encryptionPayloadBody.writeTo(out);
    } catch (Exception e) {
        Log.e(K9.LOG_TAG, "Exception while writing message to crypto provider", e);
    }
}