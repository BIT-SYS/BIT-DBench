{
    Cursor cursor = DATABASE.query(TABLE_NAME, null, EMAIL_COLUMN + "= ?", new String[] { email }, null, null, null);
    if (cursor != null && cursor.getCount() > 0) {
        return true;
    } else {
        return false;
    }
}