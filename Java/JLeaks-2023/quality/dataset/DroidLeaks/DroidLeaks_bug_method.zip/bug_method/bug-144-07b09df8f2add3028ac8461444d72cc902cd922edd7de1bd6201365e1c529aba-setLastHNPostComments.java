{
    try {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(getLastHNPostCommentsPath(postID)));
        os.writeObject(comments);
    } catch (Exception e) {
        Log.e(TAG, "Could not save last HNPostComments to file :(", e);
    }
}