{
    if (getBookById(book.getId()) == null) {
        return false;
    }
    final ZLImage image = BookUtil.getCover(book);
    if (image == null) {
        return false;
    }
    if (image instanceof ZLLoadableImage) {
        final ZLLoadableImage loadableImage = (ZLLoadableImage) image;
        if (!loadableImage.isSynchronized()) {
            loadableImage.synchronize();
        }
    }
    final ZLAndroidImageData data = ((ZLAndroidImageManager) ZLAndroidImageManager.Instance()).getImageData(image);
    if (data == null) {
        return false;
    }
    final Bitmap coverBitmap = data.getFullSizeBitmap();
    if (coverBitmap == null) {
        return false;
    }
    OutputStream outStream = null;
    File file = new File(url);
    File parent = file.getParentFile();
    parent.mkdirs();
    try {
        outStream = new FileOutputStream(file);
        coverBitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
        outStream.flush();
        outStream.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
        return false;
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
    return true;
}