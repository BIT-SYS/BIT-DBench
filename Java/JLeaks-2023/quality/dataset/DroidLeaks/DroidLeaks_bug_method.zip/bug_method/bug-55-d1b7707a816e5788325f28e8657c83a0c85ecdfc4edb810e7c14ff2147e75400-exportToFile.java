{
    OperationLog log = new OperationLog();
    if (masterKeyIds != null) {
        log.add(LogType.MSG_EXPORT, 0, masterKeyIds.length);
    } else {
        log.add(LogType.MSG_EXPORT_ALL, 0);
    }
    // do we have a file name?
    if (outputFile == null) {
        log.add(LogType.MSG_EXPORT_ERROR_NO_FILE, 1);
        return new ExportResult(ExportResult.RESULT_ERROR, log);
    }
    // check if storage is ready
    if (!FileHelper.isStorageMounted(outputFile)) {
        log.add(LogType.MSG_EXPORT_ERROR_STORAGE, 1);
        return new ExportResult(ExportResult.RESULT_ERROR, log);
    }
    try {
        OutputStream outStream = new FileOutputStream(outputFile);
        ExportResult result = exportKeyRings(log, masterKeyIds, exportSecret, outStream);
        if (result.cancelled()) {
            // noinspection ResultOfMethodCallIgnored
            new File(outputFile).delete();
        }
        return result;
    } catch (FileNotFoundException e) {
        log.add(LogType.MSG_EXPORT_ERROR_FOPEN, 1);
        return new ExportResult(ExportResult.RESULT_ERROR, log);
    }
}