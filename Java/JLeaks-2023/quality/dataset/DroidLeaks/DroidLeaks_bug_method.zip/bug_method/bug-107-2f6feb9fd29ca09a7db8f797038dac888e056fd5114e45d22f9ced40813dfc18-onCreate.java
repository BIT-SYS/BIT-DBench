{
    super.onCreate(icicle);
    // getWindow().requestFeature(Window.FEATURE_LEFT_ICON);
    setContentView(R.layout.account_activity);
    Intent i = getIntent();
    mIsNewAccount = getIntent().getBooleanExtra("register", false);
    mSignInHelper = new SignInHelper(this);
    SignInHelper.SignInListener signInListener = new SignInHelper.SignInListener() {

        public void connectedToService() {
        }

        public void stateChanged(int state, long accountId) {
            if (state == ImConnection.LOGGING_IN || state == ImConnection.LOGGED_IN) {
                mSignInHelper.goToAccount(accountId);
                finish();
            }
        }
    };
    mSignInHelper.setSignInListener(signInListener);
    mEditUserAccount = (EditText) findViewById(R.id.edtName);
    mEditUserAccount.setOnFocusChangeListener(new View.OnFocusChangeListener() {

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            checkUserChanged();
        }
    });
    mEditPass = (EditText) findViewById(R.id.edtPass);
    mEditPassConfirm = (EditText) findViewById(R.id.edtPassConfirm);
    mSpinnerDomains = (Spinner) findViewById(R.id.spinnerDomains);
    if (mIsNewAccount) {
        mEditPassConfirm.setVisibility(View.VISIBLE);
        mSpinnerDomains.setVisibility(View.VISIBLE);
        mEditUserAccount.setHint(R.string.account_setup_new_username);
    }
    mRememberPass = (CheckBox) findViewById(R.id.rememberPassword);
    mUseTor = (CheckBox) findViewById(R.id.useTor);
    mBtnSignIn = (Button) findViewById(R.id.btnSignIn);
    if (mIsNewAccount)
        mBtnSignIn.setText("Create Account");
    mBtnAdvanced = (Button) findViewById(R.id.btnAdvanced);
    mBtnDelete = (Button) findViewById(R.id.btnDelete);
    mRememberPass.setOnCheckedChangeListener(new OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            updateWidgetState();
        }
    });
    mApp = (ImApp) getApplication();
    String action = i.getAction();
    if (i.hasExtra("isSignedIn"))
        isSignedIn = i.getBooleanExtra("isSignedIn", false);
    final ProviderDef provider;
    ContentResolver cr = getContentResolver();
    Uri uri = i.getData();
    // check if there is account information and direct accordingly
    if (Intent.ACTION_INSERT_OR_EDIT.equals(action)) {
        if ((uri == null) || !Imps.Account.CONTENT_ITEM_TYPE.equals(cr.getType(uri))) {
            action = Intent.ACTION_INSERT;
        } else {
            action = Intent.ACTION_EDIT;
        }
    }
    if (Intent.ACTION_INSERT.equals(action) && uri.getScheme().equals("ima")) {
        ImPluginHelper helper = ImPluginHelper.getInstance(this);
        String authority = uri.getAuthority();
        String[] userpass_host = authority.split("@");
        String[] user_pass = userpass_host[0].split(":");
        mUserName = user_pass[0];
        String pass = user_pass[1];
        mDomain = userpass_host[1];
        mPort = 0;
        Cursor cursor = openAccountByUsernameAndDomain(cr);
        boolean exists = cursor.moveToFirst();
        long accountId;
        if (exists) {
            accountId = cursor.getLong(0);
            mAccountUri = ContentUris.withAppendedId(Imps.Account.CONTENT_URI, accountId);
            pass = cursor.getString(ACCOUNT_PASSWORD_COLUMN);
        } else {
            // xmpp FIXME
            mProviderId = helper.createAdditionalProvider(helper.getProviderNames().get(0));
            accountId = ImApp.insertOrUpdateAccount(cr, mProviderId, mUserName, pass);
            mAccountUri = ContentUris.withAppendedId(Imps.Account.CONTENT_URI, accountId);
            createNewAccount(mUserName, pass);
        }
        cursor.close();
        setAccountKeepSignedIn(true);
        mSignInHelper.activateAccount(mProviderId, accountId);
        mSignInHelper.signIn(pass, mProviderId, accountId, true);
        setResult(RESULT_OK);
        finish();
    } else if (Intent.ACTION_INSERT.equals(action)) {
        mOriginalUserAccount = "";
        // TODO once we implement multiple IM protocols
        mProviderId = ContentUris.parseId(uri);
        provider = mApp.getProvider(mProviderId);
        if (provider != null) {
            setTitle(getResources().getString(R.string.add_account, provider.mFullName));
        } else {
            finish();
        }
    } else if (Intent.ACTION_EDIT.equals(action)) {
        if ((uri == null) || !Imps.Account.CONTENT_ITEM_TYPE.equals(cr.getType(uri))) {
            LogCleaner.warn(ImApp.LOG_TAG, "<AccountActivity>Bad data");
            return;
        }
        isEdit = true;
        Cursor cursor = cr.query(uri, ACCOUNT_PROJECTION, null, null, null);
        if (cursor == null) {
            finish();
            return;
        }
        if (!cursor.moveToFirst()) {
            cursor.close();
            finish();
            return;
        }
        setTitle(R.string.sign_in);
        mAccountId = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
        mProviderId = cursor.getLong(ACCOUNT_PROVIDER_COLUMN);
        provider = mApp.getProvider(mProviderId);
        Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(cr, mProviderId, false, /* don't keep updated */
        null);
        mOriginalUserAccount = cursor.getString(ACCOUNT_USERNAME_COLUMN) + "@" + settings.getDomain();
        mEditUserAccount.setText(mOriginalUserAccount);
        mEditPass.setText(cursor.getString(ACCOUNT_PASSWORD_COLUMN));
        mRememberPass.setChecked(!cursor.isNull(ACCOUNT_PASSWORD_COLUMN));
        mUseTor.setChecked(settings.getUseTor());
        mBtnDelete.setVisibility(View.VISIBLE);
        cursor.close();
        settings.close();
    } else {
        LogCleaner.warn(ImApp.LOG_TAG, "<AccountActivity> unknown intent action " + action);
        finish();
        return;
    }
    if (isSignedIn) {
        mBtnSignIn.setText(getString(R.string.menu_sign_out));
        mBtnSignIn.setBackgroundResource(R.drawable.btn_red);
    }
    final BrandingResources brandingRes = mApp.getBrandingResource(mProviderId);
    mEditUserAccount.addTextChangedListener(mTextWatcher);
    mEditPass.addTextChangedListener(mTextWatcher);
    mBtnAdvanced.setOnClickListener(new OnClickListener() {

        @Override
        public void onClick(View v) {
            showAdvanced();
        }
    });
    mBtnDelete.setOnClickListener(new OnClickListener() {

        @Override
        public void onClick(View v) {
            deleteAccount();
            finish();
        }
    });
    mBtnSignIn.setOnClickListener(new OnClickListener() {

        @Override
        public void onClick(View v) {
            checkUserChanged();
            if (mUseTor.isChecked()) {
                OrbotHelper oh = new OrbotHelper(AccountActivity.this);
                if (!oh.isOrbotRunning()) {
                    oh.requestOrbotStart(AccountActivity.this);
                    return;
                }
            }
            final String pass = mEditPass.getText().toString();
            final String passConf = mEditPassConfirm.getText().toString();
            final boolean rememberPass = mRememberPass.isChecked();
            // TODO(miron) does this ever need to be true?
            final boolean isActive = false;
            ContentResolver cr = getContentResolver();
            if (mIsNewAccount) {
                mDomain = (String) mSpinnerDomains.getSelectedItem();
                String fullUser = mEditUserAccount.getText().toString();
                if (fullUser.indexOf("@") == -1)
                    fullUser += '@' + mDomain;
                if (!parseAccount(fullUser)) {
                    mEditUserAccount.selectAll();
                    mEditUserAccount.requestFocus();
                    return;
                }
            } else {
                if (!parseAccount(mEditUserAccount.getText().toString())) {
                    mEditUserAccount.selectAll();
                    mEditUserAccount.requestFocus();
                    return;
                }
            }
            final long accountId = ImApp.insertOrUpdateAccount(cr, mProviderId, mUserName, rememberPass ? pass : null);
            mAccountUri = ContentUris.withAppendedId(Imps.Account.CONTENT_URI, accountId);
            // if remember pass is true, set the "keep signed in" property to true
            if (mIsNewAccount) {
                if (pass.equals(passConf)) {
                    createNewAccount(mUserName, pass);
                    setAccountKeepSignedIn(rememberPass);
                    mSignInHelper.activateAccount(mProviderId, accountId);
                    setResult(RESULT_OK);
                    // mSignInHelper.signIn(pass, mProviderId, accountId, isActive);
                    // isSignedIn = true;
                    // updateWidgetState();
                    finish();
                } else {
                    Toast.makeText(AccountActivity.this, "Your passwords do not match", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (isSignedIn) {
                    signOut();
                    isSignedIn = false;
                } else {
                    setAccountKeepSignedIn(rememberPass);
                    if (!mOriginalUserAccount.equals(mUserName + '@' + mDomain) && shouldShowTermOfUse(brandingRes)) {
                        confirmTermsOfUse(brandingRes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mSignInHelper.signIn(pass, mProviderId, accountId, isActive);
                            }
                        });
                    } else {
                        mSignInHelper.signIn(pass, mProviderId, accountId, isActive);
                    }
                    isSignedIn = true;
                }
                updateWidgetState();
                setResult(RESULT_OK);
                finish();
            }
        }
    });
    mUseTor.setOnCheckedChangeListener(new OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            updateUseTor(isChecked);
        }
    });
    updateWidgetState();
    if (i.hasExtra("title")) {
        String title = i.getExtras().getString("title");
        setTitle(title);
    }
    if (i.hasExtra("newuser")) {
        String newuser = i.getExtras().getString("newuser");
        mEditUserAccount.setText(newuser);
        parseAccount(newuser);
        settingsForDomain(mDomain, mPort);
    }
    if (i.hasExtra("newpass")) {
        mEditPass.setText(i.getExtras().getString("newpass"));
        mEditPass.setVisibility(View.GONE);
        mRememberPass.setChecked(true);
        mRememberPass.setVisibility(View.GONE);
    }
}