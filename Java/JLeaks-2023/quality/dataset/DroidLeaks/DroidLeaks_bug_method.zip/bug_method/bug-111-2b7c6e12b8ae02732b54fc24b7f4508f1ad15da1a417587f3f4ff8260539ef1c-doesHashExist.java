{
    StringBuilder buf = new StringBuilder(Imps.Avatars.CONTACT);
    buf.append("=?");
    buf.append(" AND ");
    buf.append(Imps.Avatars.HASH);
    buf.append("=?");
    String[] selectionArgs = new String[] { jid, hash };
    // return resolver.update(updateUri, values, buf.toString(), selectionArgs) > 0;
    return resolver.query(queryUri, null, buf.toString(), selectionArgs, null).getCount() > 0;
}