{
    LogManager.i(this, "rotateImageIfNeeded: " + srcUri);
    final String srcPath = FileUtils.getPath(Application.getInstance(), srcUri);
    if (srcPath == null) {
        return srcUri;
    }
    ExifInterface exif;
    try {
        exif = new ExifInterface(srcPath);
    } catch (IOException e) {
        e.printStackTrace();
        return srcUri;
    }
    int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
    Matrix matrix = new Matrix();
    switch(orientation) {
        case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
            LogManager.i(this, "ORIENTATION_FLIP_HORIZONTAL");
            matrix.setScale(-1, 1);
            break;
        case ExifInterface.ORIENTATION_ROTATE_180:
            LogManager.i(this, "ORIENTATION_ROTATE_180");
            matrix.setRotate(180);
            break;
        case ExifInterface.ORIENTATION_FLIP_VERTICAL:
            LogManager.i(this, "ORIENTATION_FLIP_VERTICAL");
            matrix.setRotate(180);
            matrix.postScale(-1, 1);
            break;
        case ExifInterface.ORIENTATION_TRANSPOSE:
            LogManager.i(this, "ORIENTATION_TRANSPOSE");
            matrix.setRotate(90);
            matrix.postScale(-1, 1);
            break;
        case ExifInterface.ORIENTATION_ROTATE_90:
            LogManager.i(this, "ORIENTATION_ROTATE_90");
            matrix.setRotate(90);
            break;
        case ExifInterface.ORIENTATION_TRANSVERSE:
            LogManager.i(this, "ORIENTATION_TRANSVERSE");
            matrix.setRotate(-90);
            matrix.postScale(-1, 1);
            break;
        case ExifInterface.ORIENTATION_ROTATE_270:
            LogManager.i(this, "ORIENTATION_ROTATE_270");
            matrix.setRotate(-90);
            break;
        case ExifInterface.ORIENTATION_NORMAL:
        case ExifInterface.ORIENTATION_UNDEFINED:
        default:
            LogManager.i(this, "default orientation");
            return srcUri;
    }
    Bitmap srcBitmap = BitmapFactory.decodeFile(srcPath);
    try {
        Bitmap oriented = Bitmap.createBitmap(srcBitmap, 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(), matrix, true);
        srcBitmap.recycle();
        final File rotateImageFile = createImageFile(ROTATE_FILE_NAME);
        FileOutputStream out = new FileOutputStream(rotateImageFile);
        oriented.compress(Bitmap.CompressFormat.JPEG, 100, out);
        return Uri.fromFile(rotateImageFile);
    } catch (IOException | OutOfMemoryError e) {
        e.printStackTrace();
        return srcUri;
    }
}