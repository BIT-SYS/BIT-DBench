{
    if (newCursor == null) {
        mCursorDataCount = 0;
        return super.swapCursor(newCursor);
    }
    mCursorDataCount = newCursor.getCount();
    // to mimic the infinite the notification's infinite scroll ui
    // (with a progress spinner on the bottom of the list), we'll need to add
    // extra cells in the gridview:
    // - spacer cells as fillers to place the progress spinner on the first cell (_id < 0)
    // - progress spinner cell (_id = Integer.MIN_VALUE)
    // use a matrix cursor to create the extra rows
    MatrixCursor matrixCursor = new MatrixCursor(new String[] { "_id" });
    // add spacer cells
    int columnCount = getColumnCount(mContext);
    int remainder = newCursor.getCount() % columnCount;
    if (remainder > 0) {
        int spaceCount = columnCount - remainder;
        for (int i = 0; i < spaceCount; i++) {
            int id = i - spaceCount;
            matrixCursor.addRow(new Object[] { id + "" });
        }
    }
    // add progress spinner cell
    matrixCursor.addRow(new Object[] { Integer.MIN_VALUE });
    // use a merge cursor to place merge the extra rows at the bottom of the newly swapped cursor
    MergeCursor mergeCursor = new MergeCursor(new Cursor[] { newCursor, matrixCursor });
    return super.swapCursor(mergeCursor);
}