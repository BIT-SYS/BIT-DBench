{
    try {
        long start = System.currentTimeMillis();
        ModelAdapter<Server> modelAdapter = FlowManager.getModelAdapter(Server.class);
        Cursor c = new Select().all().from(Server.class).query();
        if (c != null && c.moveToFirst()) {
            servers = new SparseArray<>(c.getCount());
            do {
                Server s = modelAdapter.loadFromCursor(c);
                servers.put(s.getCid(), s);
                s.updateIgnores(s.raw_ignores);
            } while (c.moveToNext());
            c.close();
            long time = System.currentTimeMillis() - start;
            android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " servers in " + time + "ms");
        }
    } catch (SQLiteException e) {
        servers.clear();
    }
}