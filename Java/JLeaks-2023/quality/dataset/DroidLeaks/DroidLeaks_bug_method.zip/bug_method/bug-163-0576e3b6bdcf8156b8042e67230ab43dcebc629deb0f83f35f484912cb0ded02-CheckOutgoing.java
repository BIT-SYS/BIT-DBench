        private void checkOutgoing() throws MessagingException {
            if (!(account.getRemoteStore() instanceof WebDavStore)) {
                publishProgress(R.string.account_setup_check_settings_check_outgoing_msg);
            }
            Transport transport = Transport.getInstance(K9.app, account);
            transport.close();
            transport.open();
            transport.close();
        }