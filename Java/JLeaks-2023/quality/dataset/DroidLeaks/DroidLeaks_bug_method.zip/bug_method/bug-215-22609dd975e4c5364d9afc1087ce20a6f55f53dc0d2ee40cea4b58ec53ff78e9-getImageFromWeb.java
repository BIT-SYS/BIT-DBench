{
    QuranScreenInfo instance = QuranScreenInfo.getInstance();
    if (instance == null) {
        return null;
    }
    String urlString = IMG_HOST + "width" + instance.getWidthParam() + "/" + filename;
    Log.d(TAG, "want to download: " + urlString);
    InputStream is;
    try {
        URL url = new URL(urlString);
        is = (InputStream) url.getContent();
    } catch (Exception e) {
        return null;
    }
    String path = getQuranDirectory(context);
    if (path != null) {
        path += File.separator + filename;
        // can't write to the sdcard, try to decode in memory
        if (!QuranFileUtils.makeQuranDirectory(context)) {
            return decodeBitmapStream(is);
        }
        try {
            saveStream(is, path);
        } catch (Exception e) {
            // failed to save the image, try to decode
            Log.d("quran_utils", e.toString());
            return decodeBitmapStream(is);
        }
        // we were able to save the bitmap, load from the sdcard...
        return QuranFileUtils.getImageFromSD(context, filename);
    } else {
        return decodeBitmapStream(is);
    }
}