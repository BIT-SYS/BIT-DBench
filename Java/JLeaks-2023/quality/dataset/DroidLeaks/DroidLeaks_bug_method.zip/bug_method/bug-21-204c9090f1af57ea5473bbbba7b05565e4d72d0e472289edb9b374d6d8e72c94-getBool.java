{
    Cursor cur = getDB().getDatabase().rawQuery("SELECT value FROM deckVars WHERE key = '" + key + "'", null);
    if (cur.moveToFirst()) {
        return (cur.getInt(0) != 0);
    }
    return false;
}