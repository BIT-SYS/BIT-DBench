{
    Cursor c = getCursorForValue(ProviderTableMeta.FILE_PATH, path);
    OCFile file = null;
    if (c.moveToFirst()) {
        file = createFileInstance(c);
        c.close();
    }
    return file;
}