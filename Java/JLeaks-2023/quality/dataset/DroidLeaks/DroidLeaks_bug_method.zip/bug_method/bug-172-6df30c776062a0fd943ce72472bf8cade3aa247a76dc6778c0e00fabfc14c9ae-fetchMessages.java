{
    WebDavHttpClient httpclient;
    httpclient = getHttpClient();
    /**
     * We can't hand off to processRequest() since we need the stream to parse.
     */
    for (int i = 0, count = messages.length; i < count; i++) {
        WebDavMessage wdMessage;
        int statusCode = 0;
        if (!(messages[i] instanceof WebDavMessage)) {
            throw new MessagingException("WebDavStore fetch called with non-WebDavMessage");
        }
        wdMessage = (WebDavMessage) messages[i];
        if (listener != null) {
            listener.messageStarted(wdMessage.getUid(), i, count);
        }
        /**
         * If fetch is called outside of the initial list (ie, a locally stored message), it may not have a URL
         * associated. Verify and fix that
         */
        if (wdMessage.getUrl().equals("")) {
            wdMessage.setUrl(getMessageUrls(new String[] { wdMessage.getUid() }).get(wdMessage.getUid()));
            Log.i(K9.LOG_TAG, "Fetching messages with UID = '" + wdMessage.getUid() + "', URL = '" + wdMessage.getUrl() + "'");
            if (wdMessage.getUrl().equals("")) {
                throw new MessagingException("Unable to get URL for message");
            }
        }
        try {
            Log.i(K9.LOG_TAG, "Fetching message with UID = '" + wdMessage.getUid() + "', URL = '" + wdMessage.getUrl() + "'");
            HttpGet httpget = new HttpGet(new URI(wdMessage.getUrl()));
            HttpResponse response;
            HttpEntity entity;
            httpget.setHeader("translate", "f");
            if (mAuthentication == AUTH_TYPE_BASIC) {
                httpget.setHeader("Authorization", mAuthString);
            }
            response = httpclient.executeOverride(httpget, mContext);
            statusCode = response.getStatusLine().getStatusCode();
            entity = response.getEntity();
            if (statusCode < 200 || statusCode > 300) {
                throw new IOException("Error during with code " + statusCode + " during fetch: " + response.getStatusLine().toString());
            }
            if (entity != null) {
                InputStream istream = null;
                StringBuilder buffer = new StringBuilder();
                String tempText = "";
                String resultText = "";
                BufferedReader reader;
                int currentLines = 0;
                istream = WebDavHttpClient.getUngzippedContent(entity);
                if (lines != -1) {
                    reader = new BufferedReader(new InputStreamReader(istream), 8192);
                    while ((tempText = reader.readLine()) != null && (currentLines < lines)) {
                        buffer.append(tempText).append("\r\n");
                        currentLines++;
                    }
                    istream.close();
                    resultText = buffer.toString();
                    istream = new ByteArrayInputStream(resultText.getBytes("UTF-8"));
                }
                wdMessage.parse(istream);
            }
        } catch (IllegalArgumentException iae) {
            Log.e(K9.LOG_TAG, "IllegalArgumentException caught " + iae + "\nTrace: " + processException(iae));
            throw new MessagingException("IllegalArgumentException caught", iae);
        } catch (URISyntaxException use) {
            Log.e(K9.LOG_TAG, "URISyntaxException caught " + use + "\nTrace: " + processException(use));
            throw new MessagingException("URISyntaxException caught", use);
        } catch (IOException ioe) {
            Log.e(K9.LOG_TAG, "Non-success response code loading message, response code was " + statusCode + "\nURL: " + wdMessage.getUrl() + "\nError: " + ioe.getMessage() + "\nTrace: " + processException(ioe));
            throw new MessagingException("Failure code " + statusCode, ioe);
        }
        if (listener != null) {
            listener.messageFinished(wdMessage, i, count);
        }
    }
}