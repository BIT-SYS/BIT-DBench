{
    try {
        ObjectInputStream obj = new ObjectInputStream(new FileInputStream(getLastHNFeedFilePath()));
        Object rawHNFeed = obj.readObject();
        if (rawHNFeed instanceof HNFeed)
            return (HNFeed) rawHNFeed;
    } catch (Exception e) {
        Log.e(TAG, "Could not get last HNFeed from file :(", e);
    }
    return null;
}