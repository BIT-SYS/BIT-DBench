{
    final Bundle bundle = msg.getData();
    final String text = bundle.getString("text");
    final int duration = bundle.getInt("duration");
    Toast.makeText(VLCApplication.getAppContext(), text, duration).show();
}