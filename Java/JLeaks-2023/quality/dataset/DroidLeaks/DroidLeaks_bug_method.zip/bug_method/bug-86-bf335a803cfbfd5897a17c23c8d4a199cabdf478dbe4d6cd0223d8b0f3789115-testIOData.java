{
    byte[] source = new byte[] { 1, 1, 1, 1 };
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeData(source);
    byte[] converted = out.toByteArray();
    ByteArrayInputStream bin = new ByteArrayInputStream(converted);
    OtrInputStream ois = new OtrInputStream(bin);
    byte[] result = ois.readData();
    assertTrue(java.util.Arrays.equals(source, result));
}