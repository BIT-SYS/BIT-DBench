{
    if (service == null) {
        // Nothing to do at this point
        return;
    }
    Cursor c = service.getContentResolver().query(SipProfile.ACCOUNT_URI, ACC_PROJECTION, SipProfile.FIELD_ACTIVE + "=?", new String[] { "1" }, null);
    ArrayList<SipProfile> accToAdd = new ArrayList<SipProfile>();
    ArrayList<SipProfile> accToRemove = new ArrayList<SipProfile>();
    ArrayList<Long> alreadyAddedAcc = new ArrayList<Long>();
    for (SipProfile addedAcc : addedAccounts) {
        alreadyAddedAcc.add(addedAcc.id);
    }
    // Decide which accounts should be removed, added, left unchanged
    if (c != null && c.getCount() > 0) {
        try {
            if (c.moveToFirst()) {
                do {
                    final SipProfile acc = new SipProfile(c);
                    AccountStatusDisplay accountStatusDisplay = AccountListUtils.getAccountDisplay(service, acc.id);
                    if (accountStatusDisplay.availableForCalls) {
                        if (!alreadyAddedAcc.contains(acc.id)) {
                            accToAdd.add(acc);
                        }
                    } else {
                        if (alreadyAddedAcc.contains(acc.id)) {
                            accToRemove.add(acc);
                        }
                    }
                } while (c.moveToNext());
            }
        } catch (Exception e) {
            Log.e(THIS_FILE, "Error on looping over sip profiles", e);
        } finally {
            c.close();
        }
    }
    for (SipProfile acc : accToRemove) {
        deleteBuddiesForAccount(acc);
    }
    for (SipProfile acc : accToAdd) {
        addBuddiesForAccount(acc);
    }
}