{
    Cursor contactMasterKey = context.getContentResolver().query(contactUri, new String[] { ContactsContract.Data.DATA2 }, null, null, null);
    if (contactMasterKey != null) {
        if (contactMasterKey.moveToNext()) {
            return KeychainContract.KeyRings.buildGenericKeyRingUri(contactMasterKey.getLong(0));
        }
        contactMasterKey.close();
    }
    return null;
}