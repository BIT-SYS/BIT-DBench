{
    if (intent == null) {
        Log.w(TAG, "onHandleIntent(null)");
        return;
    }
    final String a = intent.getAction();
    Log.d(TAG, "onHandleIntent(" + a + ")");
    final PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
    final PowerManager.WakeLock wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, TAG);
    wakelock.acquire();
    Log.i(TAG, "got wakelock");
    if (a != null && (// .
    // .
    a.equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED) || a.equals(ACTION_SMS))) {
        Log.i(TAG, "sleep for " + WAIT_FOR_LOGS + "ms");
        try {
            Thread.sleep(WAIT_FOR_LOGS);
        } catch (InterruptedException e) {
            Log.e(TAG, "interrupted while waiting for logs", e);
        }
    }
    final Handler h = Plans.getHandler();
    if (h != null) {
        h.sendEmptyMessage(Plans.MSG_BACKGROUND_START_MATCHER);
    }
    // update roaming info
    roaming = ((TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE)).isNetworkRoaming();
    Log.d(TAG, "roaming: " + roaming);
    final SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(this);
    if (// .
    System.currentTimeMillis() - p.getLong(PREFS_LASTBACKUP, 0L) > BACKUP_PERIOD) {
        if (DataProvider.doBackup(this)) {
            p.edit().putLong(PREFS_LASTBACKUP, System.currentTimeMillis()).commit();
        }
    }
    dateStart = p.getLong(Preferences.PREFS_DATE_BEGIN, DatePreference.DEFAULT_VALUE);
    deleteBefore = Preferences.getDeleteLogsBefore(p);
    splitAt160 = p.getBoolean(Preferences.PREFS_SPLIT_SMS_AT_160, false);
    final boolean showCallInfo = p.getBoolean(Preferences.PREFS_SHOWCALLINFO, false);
    final boolean askForPlan = p.getBoolean(Preferences.PREFS_ASK_FOR_PLAN, false);
    final boolean runMatcher = a == ACTION_RUN_MATCHER;
    boolean shortRun = runMatcher || a != null && (a.equals(Intent.ACTION_BOOT_COMPLETED) || // .
    a.equals(Intent.ACTION_SHUTDOWN) || // .
    a.equals(Intent.ACTION_REBOOT) || a.equals(Intent.ACTION_DATE_CHANGED));
    if (!shortRun && a != null && a.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
        if (intent.getBooleanExtra(ConnectivityManager.EXTRA_IS_FAILOVER, false)) {
            return;
        }
        shortRun = true;
    }
    final ContentResolver cr = this.getContentResolver();
    boolean showDialog = false;
    if (!shortRun && h != null) {
        final Cursor c = cr.query(DataProvider.Logs.CONTENT_URI, new String[] { DataProvider.Logs.PLAN_ID }, DataProvider.Logs.RULE_ID + " != " + DataProvider.NO_ID + " AND " + DataProvider.Logs.TYPE + " != " + DataProvider.TYPE_DATA, null, null);
        if (c.getCount() < UNMATHCEDLOGS_TO_SHOW_DIALOG) {
            showDialog = true;
            // skip if no plan is set up
            Cursor c1 = cr.query(DataProvider.Plans.CONTENT_URI, new String[] { DataProvider.Plans.ID }, null, null, null);
            if (c1.getCount() <= 0) {
                shortRun = true;
                showDialog = false;
            }
            c1.close();
            // skip if no rule is set up
            c1 = cr.query(DataProvider.Rules.CONTENT_URI, new String[] { DataProvider.Rules.ID }, null, null, null);
            if (c1.getCount() <= 0) {
                shortRun = true;
                showDialog = false;
            }
            c1.close();
            if (showDialog) {
                h.sendEmptyMessage(Plans.MSG_BACKGROUND_START_RUNNER);
            }
        }
        c.close();
    }
    updateData(this, shortRun && !runMatcher);
    if (!shortRun || runMatcher) {
        if (deleteBefore > 0L) {
            deleteOldLogs(cr);
        }
        updateCalls(cr);
        updateSMS(cr, DataProvider.DIRECTION_IN);
        updateSMS(cr, DataProvider.DIRECTION_OUT);
        updateMMS(this);
        if (RuleMatcher.match(this, showDialog)) {
            StatsAppWidgetProvider.updateWidgets(this);
        }
    } else if (roaming) {
        updateCalls(cr);
        updateSMS(cr, DataProvider.DIRECTION_IN);
        updateSMS(cr, DataProvider.DIRECTION_OUT);
        updateMMS(this);
    }
    if (showDialog) {
        h.sendEmptyMessage(Plans.MSG_BACKGROUND_STOP_RUNNER);
    }
    if ((showCallInfo || askForPlan) && a != null && // .
    a.// .
    equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
        final Cursor c = cr.query(DataProvider.Logs.CONTENT_URI, DataProvider.Logs.PROJECTION, DataProvider.Logs.TYPE + " = " + DataProvider.TYPE_CALL, null, DataProvider.Logs.DATE + " DESC");
        if (c != null && c.moveToFirst()) {
            final long id = c.getLong(DataProvider.Logs.INDEX_ID);
            final long date = c.getLong(DataProvider.Logs.INDEX_DATE);
            final long amount = c.getLong(DataProvider.Logs.INDEX_AMOUNT);
            final long now = System.currentTimeMillis();
            if (amount > 0L && // .
            date + amount * CallMeter.MILLIS + GAP_FOR_LOGS >= now) {
                // only show real calls
                // only show calls made just now
                final float cost = c.getFloat(DataProvider.Logs.INDEX_COST);
                final String planname = DataProvider.Plans.getName(cr, c.getLong(DataProvider.Logs.INDEX_PLAN_ID));
                StringBuffer sb = new StringBuffer();
                sb.append(Common.prettySeconds(amount, false));
                if (cost > 0) {
                    String currencyFormat = Preferences.getCurrencyFormat(this);
                    sb.append(// FIXME
                    " | " + String.format(currencyFormat, cost));
                }
                if (planname != null) {
                    sb.insert(0, planname + ": ");
                } else if (askForPlan) {
                    this.handler.post(new Runnable() {

                        @Override
                        public void run() {
                            Log.i(TAG, "launching ask for plan dialog");
                            final Intent i = new Intent(// .
                            LogRunnerService.this, AskForPlan.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.putExtra(AskForPlan.EXTRA_ID, id);
                            i.putExtra(AskForPlan.EXTRA_DATE, date);
                            i.putExtra(AskForPlan.EXTRA_AMOUNT, amount);
                            LogRunnerService.this.startActivity(i);
                        }
                    });
                }
                if (showCallInfo) {
                    final String s = sb.toString();
                    Log.i(TAG, "Toast: " + s);
                    this.handler.post(new Runnable() {

                        @Override
                        public void run() {
                            final Toast toast = Toast.makeText(LogRunnerService.this, s, Toast.LENGTH_LONG);
                            toast.show();
                        }
                    });
                }
            } else {
                Log.i(TAG, "skip Toast: amount=" + amount);
                Log.i(TAG, "skip Toast: date+amount+gap=" + (// .
                date + amount * CallMeter.MILLIS + GAP_FOR_LOGS));
                Log.i(TAG, "skip Toast: now            =" + now);
            }
        }
        if (c != null && !c.isClosed()) {
            c.close();
        }
    }
    // schedule next update
    LogRunnerReceiver.schedNext(this);
    if (h != null) {
        h.sendEmptyMessage(Plans.MSG_BACKGROUND_STOP_MATCHER);
    }
    wakelock.release();
    Log.i(TAG, "wakelock released");
}