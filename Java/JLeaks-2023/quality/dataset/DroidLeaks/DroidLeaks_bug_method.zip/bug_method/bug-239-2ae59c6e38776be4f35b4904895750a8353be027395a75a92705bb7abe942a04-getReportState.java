{
    Cursor c = mDb.query(TABLE, array(STATE), WHERE, array(reportId), null, null, null);
    if (c.getCount() < 1) {
        return STATE_NOT_OPENGEOSMS;
    }
    c.moveToFirst();
    return c.getInt(0);
}