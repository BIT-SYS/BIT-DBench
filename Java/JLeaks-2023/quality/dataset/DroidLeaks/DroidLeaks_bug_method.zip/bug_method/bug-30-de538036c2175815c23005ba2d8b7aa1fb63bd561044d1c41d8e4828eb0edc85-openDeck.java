{
    Deck deck = new Deck();
    Log.i(TAG, "openDeck - Opening database " + path);
    AnkiDb.openDatabase(path);
    // Read in deck table columns
    Cursor cursor = AnkiDb.database.rawQuery("SELECT *" + " FROM decks" + " LIMIT 1", null);
    if (cursor.isClosed())
        throw new SQLException();
    cursor.moveToFirst();
    deck.id = cursor.getLong(0);
    deck.created = cursor.getDouble(1);
    deck.modified = cursor.getDouble(2);
    deck.description = cursor.getString(3);
    deck.version = cursor.getInt(4);
    deck.currentModelId = cursor.getLong(5);
    deck.syncName = cursor.getString(6);
    deck.lastSync = cursor.getDouble(7);
    deck.hardIntervalMin = cursor.getDouble(8);
    deck.hardIntervalMax = cursor.getDouble(9);
    deck.midIntervalMin = cursor.getDouble(10);
    deck.midIntervalMax = cursor.getDouble(11);
    deck.easyIntervalMin = cursor.getDouble(12);
    deck.easyIntervalMax = cursor.getDouble(13);
    deck.delay0 = cursor.getDouble(14);
    deck.delay1 = cursor.getDouble(15);
    deck.delay2 = cursor.getDouble(16);
    deck.collapseTime = cursor.getDouble(17);
    deck.highPriority = cursor.getString(18);
    deck.medPriority = cursor.getString(19);
    deck.lowPriority = cursor.getString(20);
    deck.suspended = cursor.getString(21);
    deck.newCardOrder = cursor.getInt(22);
    deck.newCardSpacing = cursor.getInt(23);
    deck.failedCardMax = cursor.getInt(24);
    deck.newCardsPerDay = cursor.getInt(25);
    deck.sessionRepLimit = cursor.getInt(26);
    deck.sessionTimeLimit = cursor.getInt(27);
    deck.utcOffset = cursor.getDouble(28);
    deck.cardCount = cursor.getInt(29);
    deck.factCount = cursor.getInt(30);
    deck.failedNowCount = cursor.getInt(31);
    deck.failedSoonCount = cursor.getInt(32);
    deck.revCount = cursor.getInt(33);
    deck.newCount = cursor.getInt(34);
    deck.revCardOrder = cursor.getInt(35);
    Log.i(TAG, "openDeck - Read " + cursor.getColumnCount() + " columns from decks table.");
    cursor.close();
    Log.i(TAG, String.format("openDeck - modified: %f currentTime: %f", deck.modified, System.currentTimeMillis() / 1000.0));
    deck.initVars();
    // Ensure necessary indices are available
    deck.updateDynamicIndices();
    // Save counts to determine if we should save deck after check
    int oldCount = deck.failedSoonCount + deck.revCount + deck.newCount;
    // Update counts
    deck.rebuildQueue();
    // Unsuspend reviewed early & buried
    cursor = AnkiDb.database.rawQuery("SELECT id " + "FROM cards " + "WHERE type in (0,1,2) and " + "isDue = 0 and " + "priority in (-1,-2)", null);
    if (cursor.isClosed())
        throw new SQLException();
    if (cursor.moveToFirst()) {
        int count = cursor.getCount();
        long[] ids = new long[count];
        for (int i = 0; i < count; i++) {
            ids[i] = cursor.getLong(0);
            cursor.moveToNext();
        }
        deck.updatePriorities(ids);
        deck.checkDue();
    }
    cursor.close();
    // Save deck to database if it has been modified
    if ((oldCount != (deck.failedSoonCount + deck.revCount + deck.newCount)) || deck.modifiedSinceSave())
        deck.commitToDB();
    Card.updateStmt = null;
    return deck;
}