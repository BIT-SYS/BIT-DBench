{
    try {
        ObjectInputStream obj = new ObjectInputStream(new FileInputStream(getLastHNPostCommentsPath(postID)));
        Object rawHNComments = obj.readObject();
        if (rawHNComments instanceof HNPostComments)
            return (HNPostComments) rawHNComments;
    } catch (Exception e) {
        Log.e(TAG, "Could not get last HNPostComments from file :(", e);
    }
    return null;
}