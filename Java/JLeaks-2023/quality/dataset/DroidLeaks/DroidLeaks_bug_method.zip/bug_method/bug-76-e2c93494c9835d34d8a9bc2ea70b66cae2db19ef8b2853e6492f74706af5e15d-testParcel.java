{
    final Image image1 = new Image.Builder().setUrl(FILE1).setTitle("Title1").setDescription("Description1").build();
    final Parcel parcel = Parcel.obtain();
    image1.writeToParcel(parcel, 0);
    parcel.setDataPosition(0);
    final Image image2 = Image.CREATOR.createFromParcel(parcel);
    assertThat(image1).isEqualTo(image2);
}