{
    if (myLibrary != null) {
        myLibrary.deactivate();
        myLibrary = null;
    }
    super.onDestroy();
}