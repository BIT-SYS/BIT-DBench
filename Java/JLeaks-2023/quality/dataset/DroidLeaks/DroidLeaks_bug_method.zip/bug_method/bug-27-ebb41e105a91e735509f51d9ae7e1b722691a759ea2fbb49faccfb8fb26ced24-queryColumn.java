{
    ArrayList<T> results = new ArrayList<T>();
    try {
        Cursor cursor = AnkiDb.database.rawQuery(query, null);
        cursor.moveToFirst();
        String methodName = getCursorMethodName(type.getSimpleName());
        do {
            // The magical line. Almost as illegible as python code ;)
            results.add(type.cast(Cursor.class.getMethod(methodName, int.class).invoke(cursor, column)));
        } while (cursor.moveToNext());
        cursor.close();
    } catch (Exception e) {
        Log.e(TAG, "queryColumn: Got Exception: " + e.getMessage());
        return null;
    }
    return results;
}