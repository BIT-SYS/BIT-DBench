{
    try {
        JSONObject o = new JSONObject();
        o.put("_reqid", ++last_reqid);
        o.put("_method", "disconnect");
        o.put("cid", cid);
        o.put("msg", message);
        client.send(o.toString());
        Log.d("IRCCloud", "Reqid: " + last_reqid + " Method: disconnect");
        return last_reqid;
    } catch (JSONException e) {
        e.printStackTrace();
        return -1;
    }
}