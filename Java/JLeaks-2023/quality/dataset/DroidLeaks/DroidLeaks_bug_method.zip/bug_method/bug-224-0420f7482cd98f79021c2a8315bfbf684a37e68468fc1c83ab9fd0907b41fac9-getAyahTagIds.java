{
    Cursor cursor = mDb.query(AyahTagMapTable.TABLE_NAME, new String[] { AyahTagMapTable.TAG_ID }, AyahTagMapTable.AYAH_ID + "=" + ayahId, null, null, null, AyahTagMapTable.TAG_ID);
    List<Integer> tagIds = new ArrayList<Integer>();
    while (cursor.moveToNext()) {
        tagIds.add(cursor.getInt(0));
    }
    return tagIds;
}