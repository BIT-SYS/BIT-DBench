{
    final HashMap entityMap = new HashMap();
    entityMap.put("amp", new char[] { '&' });
    entityMap.put("apos", new char[] { '\'' });
    entityMap.put("gt", new char[] { '>' });
    entityMap.put("lt", new char[] { '<' });
    entityMap.put("quot", new char[] { '\"' });
    final InputStreamReader streamReader = myStreamReader;
    final ZLXMLReader xmlReader = myXMLReader;
    char[] buffer = myBuffer;
    final ZLMutableString tagName = new ZLMutableString();
    final ZLMutableString attributeName = new ZLMutableString();
    final ZLMutableString attributeValue = new ZLMutableString();
    final boolean dontCacheAttributeValues = xmlReader.dontCacheAttributeValues();
    final ZLMutableString entityName = new ZLMutableString();
    final HashMap strings = new HashMap();
    final ZLStringMap attributes = new ZLStringMap();
    String[] tagStack = new String[10];
    int tagStackSize = 0;
    byte state = START_DOCUMENT;
    byte savedState = START_DOCUMENT;
    while (true) {
        int count = streamReader.read(buffer);
        if (count <= 0) {
            return;
        }
        if (count < buffer.length) {
            buffer = ZLArrayUtils.createCopy(buffer, count, count);
        }
        int startPosition = 0;
        try {
            for (int i = -1; ; ) {
                mainSwitchLabel: switch(state) {
                    case START_DOCUMENT:
                        while (true) {
                            switch(buffer[++i]) {
                                case '<':
                                    state = LANGLE;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case LANGLE:
                        switch(buffer[++i]) {
                            case '/':
                                state = END_TAG;
                                startPosition = i + 1;
                                break;
                            case '!':
                            case '?':
                                state = COMMENT;
                                break;
                            default:
                                state = START_TAG;
                                startPosition = i;
                                break;
                        }
                        break;
                    case COMMENT:
                        while (true) {
                            switch(buffer[++i]) {
                                case '>':
                                    state = TEXT;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case START_TAG:
                        while (true) {
                            switch(buffer[++i]) {
                                case 0x0008:
                                case 0x0009:
                                case 0x000A:
                                case 0x000B:
                                case 0x000C:
                                case 0x000D:
                                case ' ':
                                    state = WS_AFTER_START_TAG_NAME;
                                    tagName.append(buffer, startPosition, i - startPosition);
                                    break mainSwitchLabel;
                                case '>':
                                    state = TEXT;
                                    tagName.append(buffer, startPosition, i - startPosition);
                                    {
                                        String stringTagName = convertToString(strings, tagName);
                                        if (tagStackSize == tagStack.length) {
                                            tagStack = ZLArrayUtils.createCopy(tagStack, tagStackSize, tagStackSize << 1);
                                        }
                                        tagStack[tagStackSize++] = stringTagName;
                                        processStartTag(xmlReader, stringTagName, attributes);
                                    }
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                                case '/':
                                    state = SLASH;
                                    tagName.append(buffer, startPosition, i - startPosition);
                                    processFullTag(xmlReader, convertToString(strings, tagName), attributes);
                                    break mainSwitchLabel;
                                case '&':
                                    savedState = START_TAG;
                                    tagName.append(buffer, startPosition, i - startPosition);
                                    state = ENTITY_REF;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case WS_AFTER_START_TAG_NAME:
                        switch(buffer[++i]) {
                            case '>':
                                {
                                    String stringTagName = convertToString(strings, tagName);
                                    if (tagStackSize == tagStack.length) {
                                        tagStack = ZLArrayUtils.createCopy(tagStack, tagStackSize, tagStackSize << 1);
                                    }
                                    tagStack[tagStackSize++] = stringTagName;
                                    processStartTag(xmlReader, stringTagName, attributes);
                                }
                                state = TEXT;
                                startPosition = i + 1;
                                break;
                            case '/':
                                state = SLASH;
                                processFullTag(xmlReader, convertToString(strings, tagName), attributes);
                                break;
                            case 0x0008:
                            case 0x0009:
                            case 0x000A:
                            case 0x000B:
                            case 0x000C:
                            case 0x000D:
                            case ' ':
                                break;
                            default:
                                state = ATTRIBUTE_NAME;
                                startPosition = i;
                                break;
                        }
                        break;
                    case ATTRIBUTE_NAME:
                        while (true) {
                            switch(buffer[++i]) {
                                case '=':
                                    attributeName.append(buffer, startPosition, i - startPosition);
                                    state = WAIT_ATTRIBUTE_VALUE;
                                    break mainSwitchLabel;
                                case '&':
                                    attributeName.append(buffer, startPosition, i - startPosition);
                                    savedState = ATTRIBUTE_NAME;
                                    state = ENTITY_REF;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                                case 0x0008:
                                case 0x0009:
                                case 0x000A:
                                case 0x000B:
                                case 0x000C:
                                case 0x000D:
                                case ' ':
                                    attributeName.append(buffer, startPosition, i - startPosition);
                                    state = WAIT_EQUALS;
                                    break mainSwitchLabel;
                            }
                        }
                    case WAIT_EQUALS:
                        while (true) {
                            switch(buffer[++i]) {
                                case '=':
                                    state = WAIT_ATTRIBUTE_VALUE;
                                    break mainSwitchLabel;
                            }
                        }
                    case WAIT_ATTRIBUTE_VALUE:
                        while (true) {
                            switch(buffer[++i]) {
                                case '"':
                                    state = ATTRIBUTE_VALUE;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case ATTRIBUTE_VALUE:
                        while (true) {
                            switch(buffer[++i]) {
                                case '"':
                                    attributeValue.append(buffer, startPosition, i - startPosition);
                                    state = WS_AFTER_START_TAG_NAME;
                                    if (dontCacheAttributeValues) {
                                        attributes.put(convertToString(strings, attributeName), attributeValue.toString());
                                        attributeValue.clear();
                                    } else {
                                        attributes.put(convertToString(strings, attributeName), convertToString(strings, attributeValue));
                                    }
                                    break mainSwitchLabel;
                                case '&':
                                    attributeValue.append(buffer, startPosition, i - startPosition);
                                    savedState = ATTRIBUTE_VALUE;
                                    state = ENTITY_REF;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case ENTITY_REF:
                        while (true) {
                            switch(buffer[++i]) {
                                case ';':
                                    entityName.append(buffer, startPosition, i - startPosition);
                                    state = savedState;
                                    startPosition = i + 1;
                                    final char[] value = getEntityValue(entityMap, convertToString(strings, entityName));
                                    if (value != null) {
                                        switch(state) {
                                            case ATTRIBUTE_VALUE:
                                                attributeValue.append(value, 0, value.length);
                                                break;
                                            case ATTRIBUTE_NAME:
                                                attributeName.append(value, 0, value.length);
                                                break;
                                            case START_TAG:
                                                // case END_TAG:
                                                tagName.append(value, 0, value.length);
                                                break;
                                            case TEXT:
                                                xmlReader.characterDataHandler(value, 0, value.length);
                                                break;
                                        }
                                    }
                                    break mainSwitchLabel;
                            }
                        }
                    case SLASH:
                        while (true) {
                            switch(buffer[++i]) {
                                case '>':
                                    state = TEXT;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    case END_TAG:
                        while (true) {
                            switch(buffer[++i]) {
                                case '>':
                                    // tagName.append(buffer, startPosition, i - startPosition);
                                    if (tagStackSize > 0) {
                                        processEndTag(xmlReader, tagStack[--tagStackSize]);
                                    }
                                    // processEndTag(xmlReader, convertToString(strings, tagName));
                                    state = TEXT;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                    /*
						case WS_AFTER_END_TAG_NAME:
							while (true) {
								switch (buffer[++i]) {
									case '>':
										state = TEXT;
										if (tagStackSize > 0) {
											processEndTag(xmlReader, tagStack[--tagStackSize]);
										}
										//processEndTag(xmlReader, convertToString(strings, tagName));
										startPosition = i + 1;
										break mainSwitchLabel;
								}
							}
						*/
                    case TEXT:
                        while (true) {
                            switch(buffer[++i]) {
                                case '<':
                                    if (i > startPosition) {
                                        xmlReader.characterDataHandlerFinal(buffer, startPosition, i - startPosition);
                                    }
                                    state = LANGLE;
                                    break mainSwitchLabel;
                                case '&':
                                    if (i > startPosition) {
                                        xmlReader.characterDataHandler(buffer, startPosition, i - startPosition);
                                    }
                                    savedState = TEXT;
                                    state = ENTITY_REF;
                                    startPosition = i + 1;
                                    break mainSwitchLabel;
                            }
                        }
                }
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            switch(state) {
                case START_TAG:
                    // case END_TAG:
                    tagName.append(buffer, startPosition, count - startPosition);
                    break;
                case ATTRIBUTE_NAME:
                    attributeName.append(buffer, startPosition, count - startPosition);
                    break;
                case ATTRIBUTE_VALUE:
                    attributeValue.append(buffer, startPosition, count - startPosition);
                    break;
                case ENTITY_REF:
                    entityName.append(buffer, startPosition, count - startPosition);
                    break;
                case TEXT:
                    xmlReader.characterDataHandler(buffer, startPosition, count - startPosition);
                    break;
            }
        }
    }
}