{
    Cursor cursor = getQueue();
    if ((cursor.getCount() == 0 || mContext == null) && !mUploadInProgress) {
        MediaUploadService.this.stopSelf();
        return;
    } else {
        if (!mUploadInProgress) {
            uploadMediaFile(cursor);
        } else {
            mHandler.postDelayed(this, UPLOAD_WAIT_TIME);
        }
    }
}