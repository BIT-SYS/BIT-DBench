{
    super.onPause();
    Log.d(TAG, "onPause called");
    if (forcedOrientation && bound != null)
        bound.setResizeAllowed(false);
}