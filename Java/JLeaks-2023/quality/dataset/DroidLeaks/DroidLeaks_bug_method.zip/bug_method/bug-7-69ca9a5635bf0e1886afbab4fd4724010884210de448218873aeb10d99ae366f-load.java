{
    try {
        long start = System.currentTimeMillis();
        ModelAdapter<Buffer> modelAdapter = FlowManager.getModelAdapter(Buffer.class);
        Cursor c = new Select().all().from(Buffer.class).query();
        if (c != null && c.moveToFirst()) {
            buffers = new ArrayList<>(c.getCount());
            buffers_indexed = new SparseArray<>(c.getCount());
            do {
                Buffer b = modelAdapter.loadFromCursor(c);
                buffers.add(b);
                buffers_indexed.put(b.getBid(), b);
            } while (c.moveToNext());
            c.close();
            long time = System.currentTimeMillis() - start;
            android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " buffers in " + time + "ms");
        }
    } catch (SQLiteException e) {
        buffers.clear();
        buffers_indexed.clear();
    }
}