{
    mIsRunning = false;
    mTranscriptScreen.finish();
    if (mFinishCallback != null) {
        mFinishCallback.onSessionFinish(this);
    }
}