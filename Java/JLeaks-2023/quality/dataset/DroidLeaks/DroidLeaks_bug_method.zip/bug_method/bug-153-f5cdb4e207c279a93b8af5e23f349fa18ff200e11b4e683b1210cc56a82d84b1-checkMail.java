{
    if (useManualWakeLock) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        WakeLock wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Email");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(Email.MANUAL_WAKE_LOCK_TIMEOUT);
    }
    for (MessagingListener l : getListeners()) {
        l.checkMailStarted(context, account);
    }
    put("checkMail", listener, new Runnable() {

        public void run() {
            final NotificationManager notifMgr = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            try {
                Log.i(Email.LOG_TAG, "Starting mail check");
                Preferences prefs = Preferences.getPreferences(context);
                Account[] accounts;
                if (account != null) {
                    accounts = new Account[] { account };
                } else {
                    accounts = prefs.getAccounts();
                }
                for (final Account account : accounts) {
                    final long accountInterval = account.getAutomaticCheckIntervalMinutes() * 60 * 1000;
                    if (ignoreLastCheckedTime == false && accountInterval <= 0) {
                        if (Config.LOGV || true) {
                            Log.v(Email.LOG_TAG, "Skipping synchronizing account " + account.getDescription());
                        }
                        continue;
                    }
                    if (Config.LOGV || true) {
                        Log.v(Email.LOG_TAG, "Synchronizing account " + account.getDescription());
                    }
                    putBackground("sendPending " + account.getDescription(), null, new Runnable() {

                        public void run() {
                            if (account.isShowOngoing()) {
                                Notification notif = new Notification(R.drawable.ic_menu_refresh, context.getString(R.string.notification_bg_send_ticker, account.getDescription()), System.currentTimeMillis());
                                // JRV XXX TODO - do we want to notify MessageList too?
                                Intent intent = FolderList.actionHandleAccountIntent(context, account, Email.INBOX);
                                PendingIntent pi = PendingIntent.getActivity(context, 0, intent, 0);
                                notif.setLatestEventInfo(context, context.getString(R.string.notification_bg_send_title), account.getDescription(), pi);
                                notif.flags = Notification.FLAG_ONGOING_EVENT;
                                if (Email.NOTIFICATION_LED_WHILE_SYNCING) {
                                    notif.flags |= Notification.FLAG_SHOW_LIGHTS;
                                    notif.ledARGB = Email.NOTIFICATION_LED_DIM_COLOR;
                                    notif.ledOnMS = Email.NOTIFICATION_LED_FAST_ON_TIME;
                                    notif.ledOffMS = Email.NOTIFICATION_LED_FAST_OFF_TIME;
                                }
                                notifMgr.notify(Email.FETCHING_EMAIL_NOTIFICATION_ID, notif);
                            }
                            try {
                                sendPendingMessagesSynchronous(account);
                            } finally {
                                if (account.isShowOngoing()) {
                                    notifMgr.cancel(Email.FETCHING_EMAIL_NOTIFICATION_ID);
                                }
                            }
                        }
                    });
                    try {
                        Account.FolderMode aDisplayMode = account.getFolderDisplayMode();
                        Account.FolderMode aSyncMode = account.getFolderSyncMode();
                        Store localStore = Store.getInstance(account.getLocalStoreUri(), mApplication);
                        for (final Folder folder : localStore.getPersonalNamespaces()) {
                            folder.open(Folder.OpenMode.READ_WRITE);
                            folder.refresh(prefs);
                            Folder.FolderClass fDisplayMode = folder.getDisplayClass();
                            Folder.FolderClass fSyncMode = folder.getSyncClass();
                            if ((aDisplayMode == Account.FolderMode.FIRST_CLASS && fDisplayMode != Folder.FolderClass.FIRST_CLASS) || (aDisplayMode == Account.FolderMode.FIRST_AND_SECOND_CLASS && fDisplayMode != Folder.FolderClass.FIRST_CLASS && fDisplayMode != Folder.FolderClass.SECOND_CLASS) || (aDisplayMode == Account.FolderMode.NOT_SECOND_CLASS && fDisplayMode == Folder.FolderClass.SECOND_CLASS)) {
                                // Never sync a folder that isn't displayed
                                if (Config.LOGV) {
                                    Log.v(Email.LOG_TAG, "Not syncing folder " + folder.getName() + " which is in display mode " + fDisplayMode + " while account is in display mode " + aDisplayMode);
                                }
                                continue;
                            }
                            if ((aSyncMode == Account.FolderMode.FIRST_CLASS && fSyncMode != Folder.FolderClass.FIRST_CLASS) || (aSyncMode == Account.FolderMode.FIRST_AND_SECOND_CLASS && fSyncMode != Folder.FolderClass.FIRST_CLASS && fSyncMode != Folder.FolderClass.SECOND_CLASS) || (aSyncMode == Account.FolderMode.NOT_SECOND_CLASS && fSyncMode == Folder.FolderClass.SECOND_CLASS)) {
                                // Do not sync folders in the wrong class
                                if (Config.LOGV) {
                                    Log.v(Email.LOG_TAG, "Not syncing folder " + folder.getName() + " which is in sync mode " + fSyncMode + " while account is in sync mode " + aSyncMode);
                                }
                                continue;
                            }
                            if (Config.LOGV) {
                                Log.v(Email.LOG_TAG, "Folder " + folder.getName() + " was last synced @ " + new Date(folder.getLastChecked()));
                            }
                            if (ignoreLastCheckedTime == false && folder.getLastChecked() > (System.currentTimeMillis() - accountInterval)) {
                                if (Config.LOGV) {
                                    Log.v(Email.LOG_TAG, "Not syncing folder " + folder.getName() + ", previously synced @ " + new Date(folder.getLastChecked()) + " which would be too recent for the account period");
                                }
                                continue;
                            }
                            putBackground("sync" + folder.getName(), null, new Runnable() {

                                public void run() {
                                    try {
                                        // In case multiple Commands get enqueued, don't run more than
                                        // once
                                        final LocalStore localStore = (LocalStore) Store.getInstance(account.getLocalStoreUri(), mApplication);
                                        LocalFolder tLocalFolder = (LocalFolder) localStore.getFolder(folder.getName());
                                        tLocalFolder.open(Folder.OpenMode.READ_WRITE);
                                        if (ignoreLastCheckedTime == false && tLocalFolder.getLastChecked() > (System.currentTimeMillis() - accountInterval)) {
                                            if (Config.LOGV) {
                                                Log.v(Email.LOG_TAG, "Not running Command for folder " + folder.getName() + ", previously synced @ " + new Date(folder.getLastChecked()) + " which would be too recent for the account period");
                                            }
                                            return;
                                        }
                                        if (account.isShowOngoing()) {
                                            Notification notif = new Notification(R.drawable.ic_menu_refresh, context.getString(R.string.notification_bg_sync_ticker, account.getDescription(), folder.getName()), System.currentTimeMillis());
                                            // JRV XXX TODO - do we want to notify MessageList too?
                                            Intent intent = FolderList.actionHandleAccountIntent(context, account, Email.INBOX);
                                            PendingIntent pi = PendingIntent.getActivity(context, 0, intent, 0);
                                            notif.setLatestEventInfo(context, context.getString(R.string.notification_bg_sync_title), account.getDescription() + context.getString(R.string.notification_bg_title_separator) + folder.getName(), pi);
                                            notif.flags = Notification.FLAG_ONGOING_EVENT;
                                            if (Email.NOTIFICATION_LED_WHILE_SYNCING) {
                                                notif.flags |= Notification.FLAG_SHOW_LIGHTS;
                                                notif.ledARGB = Email.NOTIFICATION_LED_DIM_COLOR;
                                                notif.ledOnMS = Email.NOTIFICATION_LED_FAST_ON_TIME;
                                                notif.ledOffMS = Email.NOTIFICATION_LED_FAST_OFF_TIME;
                                            }
                                            notifMgr.notify(Email.FETCHING_EMAIL_NOTIFICATION_ID, notif);
                                        }
                                        try {
                                            synchronizeMailboxSynchronous(account, folder.getName());
                                        } finally {
                                            if (account.isShowOngoing()) {
                                                notifMgr.cancel(Email.FETCHING_EMAIL_NOTIFICATION_ID);
                                            }
                                        }
                                    } catch (Exception e) {
                                        Log.e(Email.LOG_TAG, "Exception while processing folder " + account.getDescription() + ":" + folder.getName(), e);
                                        addErrorMessage(account, e);
                                    }
                                }
                            });
                        }
                    } catch (MessagingException e) {
                        Log.e(Email.LOG_TAG, "Unable to synchronize account " + account.getName(), e);
                        addErrorMessage(account, e);
                    }
                }
            } catch (Exception e) {
                Log.e(Email.LOG_TAG, "Unable to synchronize mail", e);
                addErrorMessage(account, e);
            }
            putBackground("finalize sync", null, new Runnable() {

                public void run() {
                    Log.i(Email.LOG_TAG, "Finished mail sync");
                    for (MessagingListener l : getListeners()) {
                        l.checkMailFinished(context, account);
                    }
                }
            });
        }
    });
}