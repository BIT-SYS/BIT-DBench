{
    try {
        AyahInfoDatabaseHandler handler = new AyahInfoDatabaseHandler("ayahinfo.db");
        Cursor cursor = handler.getVerseBounds(sura, ayah);
        Map<Integer, AyahBounds> lineCoords = new HashMap<Integer, AyahBounds>();
        AyahBounds first = null, last = null, current = null;
        if ((cursor == null) || (!cursor.moveToFirst()))
            return;
        do {
            current = new AyahBounds(cursor.getInt(1), cursor.getInt(4), cursor.getInt(5), cursor.getInt(6), cursor.getInt(7), cursor.getInt(8));
            if (first == null)
                first = current;
            if (!lineCoords.containsKey(current.getLine()))
                lineCoords.put(current.getLine(), current);
            else
                lineCoords.get(current.getLine()).engulf(current);
        } while (cursor.moveToNext());
        if ((first != null) && (current != null) && (first.getPosition() != current.getPosition()))
            last = current;
        handler.closeDatabase();
        doHighlightAyah(first, last, lineCoords);
    } catch (SQLException se) {
    }
}