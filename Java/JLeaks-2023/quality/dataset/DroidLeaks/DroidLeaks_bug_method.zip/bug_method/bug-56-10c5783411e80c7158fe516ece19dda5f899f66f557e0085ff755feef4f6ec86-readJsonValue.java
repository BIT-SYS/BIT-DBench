{
    try {
        return readJsonValue(urlopen.openStream(url, postData, false), valueType);
    } catch (Exception e) {
        e.printStackTrace();
        throw new BankException(e.getMessage(), e);
    }
}