{
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeData(b);
    byte[] otrb = out.toByteArray();
    out.close();
    return otrb;
}