{
    swapCursor(mQuery.execute());
}