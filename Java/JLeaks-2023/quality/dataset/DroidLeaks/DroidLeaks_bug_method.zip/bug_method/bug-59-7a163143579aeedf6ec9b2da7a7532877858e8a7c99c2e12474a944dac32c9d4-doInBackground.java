{
    String accountId = WidgetConfigureActivity.getAccountId(context, appWidgetId);
    if (accountId == null) {
        Log.d("WidgetService", "Widget not found in db: " + appWidgetId);
        return null;
    }
    String bankId = accountId.split("_")[0];
    Bank bank = BankFactory.bankFromDb(new Long(bankId), context, false);
    if (bank == null) {
        return null;
    }
    try {
        if (!bank.isDisabled()) {
            bank.update();
            bank.save();
        } else {
            Log.d("BankdroidWidgetProvider", "Bank is disabled, skipping refresh on " + bank.getDbId());
        }
    } catch (BankException e) {
        Log.d(TAG, "Error while updating bank '" + bank.getDbId() + "'; " + e.getMessage());
    } catch (LoginException e) {
        Log.d("", "Disabling bank: " + bank.getDbId());
        bank.disable();
    }
    BankdroidWidgetProvider.updateAppWidget(context, appWidgetManager, appWidgetId);
    return null;
}