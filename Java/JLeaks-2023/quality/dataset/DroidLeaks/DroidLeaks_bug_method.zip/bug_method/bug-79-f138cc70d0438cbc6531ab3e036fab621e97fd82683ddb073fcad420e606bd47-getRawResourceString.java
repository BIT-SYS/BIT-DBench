{
    String result;
    Scanner scanner = null;
    try {
        final InputStream ins = res.openRawResource(resourceId);
        scanner = new Scanner(ins, CharEncoding.UTF_8);
        result = scanner.useDelimiter("\\A").next();
        IOUtils.closeQuietly(ins);
    } finally {
        if (scanner != null) {
            scanner.close();
        }
    }
    return result;
}