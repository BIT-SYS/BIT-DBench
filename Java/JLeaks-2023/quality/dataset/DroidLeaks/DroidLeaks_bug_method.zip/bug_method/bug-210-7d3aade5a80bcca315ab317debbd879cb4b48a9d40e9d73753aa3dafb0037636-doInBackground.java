{
    Bitmap result = null;
    if (params.length != 1)
        return result;
    String storagePath = params[0];
    try {
        if (isCancelled())
            return result;
        File picture = new File(storagePath);
        if (picture != null) {
            // Decode file into a bitmap in real size for being able to make zoom on
            // the image
            result = BitmapFactory.decodeStream(new FlushedInputStream(new BufferedInputStream(new FileInputStream(picture))));
        }
        if (isCancelled())
            return result;
        if (result == null) {
            mErrorMessageId = R.string.preview_image_error_unknown_format;
            Log_OC.e(TAG, "File could not be loaded as a bitmap: " + storagePath);
        } else {
            // Rotate image, obeying exif tag.
            result = BitmapUtils.rotateImage(result, storagePath);
        }
    } catch (OutOfMemoryError e) {
        Log_OC.w(TAG, "Out of memory rendering file " + storagePath + " in full size; scaling down");
        if (isCancelled())
            return result;
        // If out of memory error when loading or rotating image, try to load it scaled
        result = loadScaledImage(storagePath);
        if (result == null) {
            mErrorMessageId = R.string.preview_image_error_unknown_format;
            Log_OC.e(TAG, "File could not be loaded as a bitmap: " + storagePath);
        } else {
            // Rotate scaled image, obeying exif tag
            result = BitmapUtils.rotateImage(result, storagePath);
        }
    } catch (NoSuchFieldError e) {
        mErrorMessageId = R.string.common_error_unknown;
        Log_OC.e(TAG, "Error from access to unexisting field despite protection; file " + storagePath, e);
    } catch (Throwable t) {
        mErrorMessageId = R.string.common_error_unknown;
        Log_OC.e(TAG, "Unexpected error loading " + getFile().getStoragePath(), t);
    }
    return result;
}