{
    Cursor c = db.query(CATEGORIES_TABLE, new String[] { "parent_id" }, "category_name=\"" + category + "\" AND blog_id=" + id, null, null, null, null);
    if (c.getCount() == 0)
        return -1;
    c.moveToFirst();
    int categoryParentID = c.getInt(0);
    return categoryParentID;
}