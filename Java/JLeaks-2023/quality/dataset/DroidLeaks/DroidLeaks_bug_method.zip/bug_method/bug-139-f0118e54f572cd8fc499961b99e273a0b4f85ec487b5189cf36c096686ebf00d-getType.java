{
    Cursor cursor = DATABASE.query(TABLE_NAME, null, EMAIL_COLUMN + "= ?", new String[] { email }, null, null, null);
    if (cursor != null && cursor.getCount() > 0) {
        cursor.moveToFirst();
        Integer value = cursor.getInt(cursor.getColumnIndex(TYPE_COLUMN));
        return OtpType.getEnum(value);
    }
    return null;
}