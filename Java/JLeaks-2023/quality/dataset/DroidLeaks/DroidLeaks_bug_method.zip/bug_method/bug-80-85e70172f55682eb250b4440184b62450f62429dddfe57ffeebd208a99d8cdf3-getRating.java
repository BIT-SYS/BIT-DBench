{
    if (guids == null && geocodes == null) {
        return Collections.emptyMap();
    }
    final Parameters params = new Parameters("version", "cgeo");
    final ImmutablePair<String, String> login = Settings.getGCvoteLogin();
    if (login != null) {
        params.put("userName", login.left, "password", login.right);
    }
    // use guid or gccode for lookup
    final boolean requestByGuids = CollectionUtils.isNotEmpty(guids);
    if (requestByGuids) {
        params.put("cacheIds", StringUtils.join(guids, ','));
    } else {
        params.put("waypoints", StringUtils.join(geocodes, ','));
    }
    final InputStream response = Network.getResponseStream(Network.getRequest("http://gcvote.com/getVotes.php", params));
    if (response == null) {
        return Collections.emptyMap();
    }
    return getRatingsFromXMLResponse(response, requestByGuids);
}