{
    int source = 10;
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeShort(source);
    byte[] converted = out.toByteArray();
    ByteArrayInputStream bin = new ByteArrayInputStream(converted);
    OtrInputStream ois = new OtrInputStream(bin);
    int result = ois.readShort();
    assertEquals(source, result);
}