{
    super.onDestroy();
    Log.i(THIS_FILE, "Destroying SIP Service");
    unregisterBroadcasts();
    notificationManager.onServiceDestroy();
    getExecutor().execute(new FinalizeDestroyRunnable());
}