{
    try {
        ContentResolver resolver = mContext.getContentResolver();
        InputStream is = resolver.openInputStream(mUri);
        mImportContents = StorageImporter.getImportStreamContents(mContext, is, mEncryptionKey);
        // Open another InputStream in the background. This is used later by ImportAsyncTask
        mInputStream = resolver.openInputStream(mUri);
    } catch (StorageImportExportException e) {
        Log.w(K9.LOG_TAG, "Exception during export", e);
        return false;
    } catch (FileNotFoundException e) {
        Log.w(K9.LOG_TAG, "Couldn't read content from URI " + mUri);
        return false;
    }
    return true;
}