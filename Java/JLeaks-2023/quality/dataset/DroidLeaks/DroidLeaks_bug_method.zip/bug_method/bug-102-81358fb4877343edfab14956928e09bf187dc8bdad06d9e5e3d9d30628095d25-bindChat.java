{
    log("bind " + this + " " + chatId);
    mLastChatId = chatId;
    Uri contactUri = ContentUris.withAppendedId(Imps.Contacts.CONTENT_URI, chatId);
    mCursor = mActivity.getContentResolver().query(contactUri, CHAT_PROJECTION, null, null, null);
    if (mCursor == null)
        return;
    if (!mCursor.moveToFirst()) {
        if (Log.isLoggable(ImApp.LOG_TAG, Log.DEBUG)) {
            log("Failed to query chat: " + chatId);
        }
        mLastChatId = -1;
    } else {
        updateContactInfo();
        mCurrentChatSession = getChatSession();
        if (mCurrentChatSession == null)
            mCurrentChatSession = createChatSession();
        if (mCurrentChatSession != null) {
            isServiceUp = true;
        }
        updateChat();
    }
}