{
    CharSequence timestamp = DateFormat.format("yyyyMMdd_kkmmss", System.currentTimeMillis());
    String filename = name + "_" + timestamp + ".log";
    try {
        FileOutputStream stream = new FileOutputStream(filename);
        OutputStreamWriter output = new OutputStreamWriter(stream);
        BufferedWriter bw = new BufferedWriter(output);
        bw.write(log);
        bw.newLine();
        bw.close();
        output.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}