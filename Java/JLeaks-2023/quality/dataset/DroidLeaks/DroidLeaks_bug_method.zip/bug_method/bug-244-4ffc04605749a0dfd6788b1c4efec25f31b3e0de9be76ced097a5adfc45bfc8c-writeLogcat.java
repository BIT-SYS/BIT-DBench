{
    String[] args = { "logcat", "-v", "time", "-d" };
    Process process = Runtime.getRuntime().exec(args);
    InputStreamReader input = new InputStreamReader(process.getInputStream());
    OutputStreamWriter output = new OutputStreamWriter(new FileOutputStream(filename));
    BufferedReader br = new BufferedReader(input);
    BufferedWriter bw = new BufferedWriter(output);
    String line;
    while ((line = br.readLine()) != null) {
        bw.write(line);
        bw.newLine();
    }
    bw.close();
    output.close();
    br.close();
    input.close();
}