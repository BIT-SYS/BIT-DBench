{
    try {
        Cursor langsCursor = getContentResolver().query(UserDictionary.Words.CONTENT_URI, new String[] { UserDictionary.Words.LOCALE }, null, null, null);
        if (langsCursor == null)
            throw new NullPointerException("No device-wide user dictionary");
        langsCursor.moveToFirst();
        ArrayList<String> langs = new ArrayList<String>();
        while (!langsCursor.isAfterLast()) {
            String locale = langsCursor.getString(0);
            langsCursor.moveToNext();
            if (TextUtils.isEmpty(locale))
                continue;
            if (langs.contains(locale))
                continue;
            langs.add(locale);
        }
        return langs.toArray(new String[langs.size()]);
    } catch (Exception e) {
        // TODO: Use ASK fallback
        e.printStackTrace();
    }
    return new String[] { "en" };
}