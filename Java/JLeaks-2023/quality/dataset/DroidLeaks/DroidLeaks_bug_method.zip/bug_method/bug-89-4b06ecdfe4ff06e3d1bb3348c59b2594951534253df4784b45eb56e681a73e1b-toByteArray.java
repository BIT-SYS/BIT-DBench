{
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeMysteriousT(t);
    byte[] b = out.toByteArray();
    out.close();
    return b;
}