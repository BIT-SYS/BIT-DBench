{
    DBAdapter db = new DBAdapter(context);
    db.open();
    Cursor c = db.getAccount(accountId);
    if (c == null || c.isClosed() || (c.isBeforeFirst() && c.isAfterLast())) {
        db.close();
        return null;
    }
    Account account = new Account(c.getString(c.getColumnIndex("name")), new BigDecimal(c.getString(c.getColumnIndex("balance"))), c.getString(c.getColumnIndex("id")).split("_")[1], c.getLong(c.getColumnIndex("bankid")), c.getInt(c.getColumnIndex("acctype")));
    account.setHidden(c.getInt(c.getColumnIndex("hidden")) == 1 ? true : false);
    account.setNotify(c.getInt(c.getColumnIndex("notify")) == 1 ? true : false);
    account.setCurrency(c.getString(c.getColumnIndex("currency")));
    c.close();
    if (loadTransactions) {
        ArrayList<Transaction> transactions = new ArrayList<Transaction>();
        // "transdate", "btransaction", "amount"}
        c = db.fetchTransactions(accountId);
        if (!(c == null || c.isClosed() || (c.isBeforeFirst() && c.isAfterLast()))) {
            while (!c.isLast() && !c.isAfterLast()) {
                c.moveToNext();
                transactions.add(new Transaction(c.getString(c.getColumnIndex("transdate")), c.getString(c.getColumnIndex("btransaction")), new BigDecimal(c.getString(c.getColumnIndex("amount"))), c.getString(c.getColumnIndex("currency"))));
            }
        }
        account.setTransactions(transactions);
    }
    db.close();
    return account;
}