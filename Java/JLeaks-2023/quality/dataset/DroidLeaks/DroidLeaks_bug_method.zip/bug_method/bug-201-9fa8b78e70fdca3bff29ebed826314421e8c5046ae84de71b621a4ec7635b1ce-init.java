{
    prologSystem.clearTheory();
    voiceDir = null;
    if (voiceProvider != null) {
        File parent = ctx.getAppPath(IndexConstants.VOICE_INDEX_DIR);
        voiceDir = new File(parent, voiceProvider);
        if (!voiceDir.exists()) {
            voiceDir = null;
            throw new CommandPlayerException(ctx.getString(R.string.voice_data_unavailable));
        }
    }
    // see comments below why it is impossible to read from zip (don't know
    // how to play file from zip)
    // voiceZipFile = null;
    if (voiceDir != null) {
        long time = System.currentTimeMillis();
        boolean wrong = false;
        try {
            InputStream config;
            // if (voiceDir.getName().endsWith(".zip")) { //$NON-NLS-1$
            // voiceZipFile = new ZipFile(voiceDir);
            // config = voiceZipFile.getInputStream(voiceZipFile.getEntry("_config.p")); //$NON-NLS-1$
            // } else {
            // $NON-NLS-1$
            config = new FileInputStream(new File(voiceDir, configFile));
            // }
            MetricsConstants mc = settings.METRIC_SYSTEM.get();
            ApplicationMode m = settings.getApplicationMode();
            if (m.getParent() != null) {
                m = m.getParent();
            }
            prologSystem.addTheory(new Theory("appMode('" + m.getStringKey().toLowerCase() + "')."));
            prologSystem.addTheory(new Theory("measure('" + mc.toTTSString() + "')."));
            prologSystem.addTheory(new Theory(config));
        } catch (InvalidTheoryException e) {
            // $NON-NLS-1$
            log.error("Loading voice config exception " + voiceProvider, e);
            wrong = true;
        } catch (IOException e) {
            // $NON-NLS-1$
            log.error("Loading voice config exception " + voiceProvider, e);
            wrong = true;
        }
        if (wrong) {
            throw new CommandPlayerException(ctx.getString(R.string.voice_data_corrupted));
        } else {
            Term val = solveSimplePredicate(P_VERSION);
            if (!(val instanceof Number) || Arrays.binarySearch(sortedVoiceVersions, ((Number) val).intValue()) < 0) {
                throw new CommandPlayerException(ctx.getString(R.string.voice_data_not_supported));
            }
            currentVersion = ((Number) val).intValue();
        }
        if (log.isInfoEnabled()) {
            // $NON-NLS-1$ //$NON-NLS-2$
            log.info("Initializing voice subsystem  " + voiceProvider + " : " + (System.currentTimeMillis() - time));
        }
    }
}