{
    final long maxdate = this.getMaxDate(cr, DataProvider.TYPE_SMS);
    final Uri mmsUri = Uri.parse("content://mms/");
    final String[] mmsProjection = new String[] { Calls.DATE, MMS_TYPE };
    Cursor cursor = cr.query(mmsUri, mmsProjection, Calls.DATE + " > " + maxdate, null, Calls.DATE + " DESC");
    if (cursor == null || !cursor.moveToFirst()) {
        cursor = cr.query(mmsUri, mmsProjection, Calls.DATE + " > " + (maxdate / CallMeter.MILLIS), null, Calls.DATE + " DESC");
    }
    if (cursor != null && cursor.moveToFirst()) {
        final int idDate = cursor.getColumnIndex(Calls.DATE);
        final int idType = cursor.getColumnIndex(MMS_TYPE);
        // FIXME: final int idAddress = cursor.getColumnIndex("address");
        final // .
        ArrayList<ContentValues> // .
        cvalues = new ArrayList<ContentValues>(CallMeter.HUNDRET);
        do {
            final ContentValues cv = new ContentValues();
            final int t = cursor.getInt(idType);
            final long d = cursor.getLong(idDate);
            Log.d(TAG, "mms date: " + d);
            Log.d(TAG, "mms type: " + t);
            if (t == MMS_IN) {
                cv.put(DataProvider.Logs.DIRECTION, DataProvider.DIRECTION_IN);
            } else if (t == MMS_OUT) {
                cv.put(DataProvider.Logs.DIRECTION, DataProvider.DIRECTION_OUT);
            } else {
                continue;
            }
            cv.put(DataProvider.Logs.PLAN_ID, DataProvider.NO_ID);
            cv.put(DataProvider.Logs.RULE_ID, DataProvider.NO_ID);
            cv.put(DataProvider.Logs.TYPE, DataProvider.TYPE_MMS);
            cv.put(DataProvider.Logs.DATE, this.fixDate(d));
            // FIXME: cv.put(DataProvider.Logs.REMOTE,
            // DataProvider.Logs.cleanNumber(
            // cursor.getLong(idAddress), false));
            cv.put(DataProvider.Logs.AMOUNT, 1);
            if (roaming) {
                cv.put(DataProvider.Logs.ROAMED, 1);
            }
            cvalues.add(cv);
            if (cvalues.size() >= CallMeter.HUNDRET) {
                cr.bulkInsert(DataProvider.Logs.CONTENT_URI, cvalues.toArray(TO_ARRAY));
                Log.d(TAG, "new mms: " + cvalues.size());
                cvalues.clear();
            }
        } while (cursor.moveToNext());
        if (cvalues.size() > 0) {
            cr.bulkInsert(DataProvider.Logs.CONTENT_URI, cvalues.toArray(TO_ARRAY));
            Log.d(TAG, "new mms: " + cvalues.size());
        }
    }
    if (cursor != null && !cursor.isClosed()) {
        cursor.close();
    }
}