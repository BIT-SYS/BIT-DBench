{
    Cursor cursor = findAyah(sura, ayah, new String[] { AyahTable.BOOKMARKED });
    return (cursor.moveToFirst() && cursor.getInt(0) == 1);
}