{
    try {
        Log.d(TAG, "Updating " + bank);
        bank.update();
        bank.updateAllTransactions();
        Log.d(TAG, "Saving " + bank);
        bank.save();
        Log.d(TAG, "Disabled: " + bank.isDisabled());
    } catch (BankException e) {
        this.exc = e;
    } catch (LoginException e) {
        this.exc = e;
    }
    return null;
}