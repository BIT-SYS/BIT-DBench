{
    StringBuilder sb = new StringBuilder();
    sb.append(EXPORT_VERSION + "\n");
    sb.append(URLEncoder.encode(descr) + "\n");
    final SQLiteDatabase db = new DatabaseHelper(context).getReadableDatabase();
    backupRuleSetSub(sb, db, Plans.TABLE, Plans.PROJECTION, null);
    backupRuleSetSub(sb, db, Rules.TABLE, Rules.PROJECTION, null);
    backupRuleSetSub(sb, db, Hours.TABLE, Hours.PROJECTION, null);
    backupRuleSetSub(sb, db, HoursGroup.TABLE, HoursGroup.PROJECTION, null);
    backupRuleSetSub(sb, db, Numbers.TABLE, Numbers.PROJECTION, null);
    backupRuleSetSub(sb, db, NumbersGroup.TABLE, NumbersGroup.PROJECTION, null);
    return sb.toString();
}