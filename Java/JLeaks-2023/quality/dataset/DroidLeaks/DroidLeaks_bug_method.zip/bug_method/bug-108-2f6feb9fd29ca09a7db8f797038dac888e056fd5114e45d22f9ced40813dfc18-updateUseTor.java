    
    private void updateUseTor(boolean useTor) {
        checkUserChanged();
    
        OrbotHelper orbotHelper = new OrbotHelper(this);
        Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(
                getContentResolver(), mProviderId, false /* don't keep updated */, null /* no handler */);

        if (useTor && (!orbotHelper.isOrbotInstalled()))
        {
            //Toast.makeText(this, "Orbot app is not installed. Please install from Google Play or from https://guardianproject.info/releases", Toast.LENGTH_LONG).show();
            
            orbotHelper.promptToInstall(this);
            
            mUseTor.setChecked(false);
            settings.setUseTor(false);
        }
        else
        {
            settings.setUseTor(useTor);
        }
                
        settingsForDomain(settings.getDomain(),settings.getPort());
             
        settings.close();
      
    }
/*