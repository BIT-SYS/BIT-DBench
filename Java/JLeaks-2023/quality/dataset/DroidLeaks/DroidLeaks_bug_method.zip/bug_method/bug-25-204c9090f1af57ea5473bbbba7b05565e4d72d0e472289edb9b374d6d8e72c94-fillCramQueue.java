    @SuppressWarnings("unused")
    private void _fillCramQueue() {
        if ((mRevCount != 0) && mRevQueue.isEmpty()) {
            Log.i(AnkiDroidApp.TAG, "fill cram queue: " + mActiveCramTags + " " + mCramOrder + " " + mQueueLimit);
            String sql = "SELECT id, factId FROM cards c WHERE type BETWEEN 0 AND 2 ORDER BY " + mCramOrder + " LIMIT "
                    + mQueueLimit;
            sql = cardLimit(mActiveCramTags, null, sql);
            Log.i(AnkiDroidApp.TAG, "SQL: " + sql);
            Cursor cur = getDB().getDatabase().rawQuery(sql, null);
            while (cur.moveToNext()) {
                QueueItem qi = new QueueItem(cur.getLong(0), cur.getLong(1));
                mRevQueue.add(0, qi); // Add to front, so list is reversed as it is built
            }
        }
    }
