{
    Cursor c = db.query(POSTS_TABLE, null, "isLocalChange=1", null, null, null, null);
    int numRows = c.getCount();
    if (numRows > 0) {
        return true;
    }
    c.close();
    return false;
}