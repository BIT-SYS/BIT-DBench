{
    try {
        return new BinaryTempFileBodyInputStream(new FileInputStream(mFile));
    } catch (IOException ioe) {
        throw new MessagingException("Unable to open body", ioe);
    }
}