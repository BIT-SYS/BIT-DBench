{
    final Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(getContentResolver(), mProviderId, false, /* don't keep updated */
    null);
    String key = preference.getKey();
    if (preference instanceof CheckBoxPreference) {
        boolean value = ((CheckBoxPreference) preference).isChecked();
        if (key.equals(getString(R.string.pref_security_allow_plain_auth))) {
            settings.setAllowPlainAuth(value);
        } else if (key.equals(getString(R.string.pref_security_require_tls))) {
            settings.setRequireTls(value);
        } else if (key.equals(getString(R.string.pref_security_tls_cert_verify))) {
            settings.setTlsCertVerify(value);
        } else if (key.equals(getString(R.string.pref_security_do_dns_srv))) {
            settings.setDoDnsSrv(value);
        } else if (key.equals(getString(R.string.pref_hide_offline_contacts))) {
            settings.setHideOfflineContacts(value);
        } else if (key.equals(getString(R.string.pref_enable_notifications))) {
            settings.setEnableNotification(value);
        } else if (key.equals(getString(R.string.pref_notification_vibrate))) {
            settings.setVibrate(value);
        } else if (key.equals(getString(R.string.pref_notification_sound))) {
            if (!value) {
                settings.setRingtoneURI(null);
            }
        }
        settings.close();
        return true;
    } else if (preference instanceof EditTextPreference) {
        String value = ((EditTextPreference) preference).getText();
        if (key.equals(getString(R.string.pref_account_user))) {
            ContentResolver cr = getContentResolver();
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            String password = prefs.getString(getString(R.string.pref_account_pass), null);
            mAccountId = ImApp.insertOrUpdateAccount(cr, mProviderId, value, password);
        } else if (key.equals(getString(R.string.pref_account_pass))) {
            ContentResolver cr = getContentResolver();
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            String userName = prefs.getString(getString(R.string.pref_account_user), null);
            mAccountId = ImApp.insertOrUpdateAccount(cr, mProviderId, userName, value);
        } else if (key.equals(getString(R.string.pref_account_domain))) {
            settings.setDomain(value);
        } else if (key.equals(getString(R.string.pref_account_xmpp_resource))) {
            settings.setXmppResource(value);
        } else if (key.equals(getString(R.string.pref_account_port))) {
            try {
                settings.setPort(Integer.parseInt(value));
            } catch (NumberFormatException nfe) {
                // TODO port numbers with non-int content should be handled better
                Toast.makeText(getBaseContext(), "Port number must be a number", Toast.LENGTH_SHORT).show();
            }
        } else if (key.equals(getString(R.string.pref_account_server))) {
            settings.setServer(value);
        } else if (key.equals(getString(R.string.pref_security_otr_mode))) {
            settings.setOtrMode(value);
        }
        settings.close();
        return true;
    }
    return false;
}