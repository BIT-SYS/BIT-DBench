{
    Cursor c = db.query(MEDIA_TABLE, null, "postID=" + post.getId() + " AND filePath='" + src + "'", null, null, null, null);
    int numRows = c.getCount();
    c.moveToFirst();
    MediaFile mf = new MediaFile();
    if (numRows == 1) {
        mf.setPostID(c.getInt(1));
        mf.setFilePath(c.getString(2));
        mf.setFileName(c.getString(3));
        mf.setTitle(c.getString(4));
        mf.setDescription(c.getString(5));
        mf.setCaption(c.getString(6));
        mf.setHorizontalAlignment(c.getInt(7));
        mf.setWidth(c.getInt(8));
        mf.setHeight(c.getInt(9));
        mf.setMIMEType(c.getString(10));
        mf.setFeatured(c.getInt(11) > 0);
        mf.setVideo(c.getInt(12) > 0);
    } else {
        return null;
    }
    c.close();
    return mf;
}