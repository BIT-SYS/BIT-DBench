{
    Cursor cursor = getMediaFilesForBlog(blogId);
    return cursor.getCount();
}