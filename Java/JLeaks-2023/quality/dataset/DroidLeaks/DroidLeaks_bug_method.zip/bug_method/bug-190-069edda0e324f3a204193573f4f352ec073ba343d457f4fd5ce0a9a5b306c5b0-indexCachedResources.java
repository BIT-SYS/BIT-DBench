{
    Cursor cursor = sqliteDb.rawQuery("SELECT filename, date_modified, left, right, top, bottom FROM TILE_SOURCES", new String[0]);
    if (cursor.moveToFirst()) {
        do {
            String filename = cursor.getString(0);
            long lastModified = cursor.getLong(1);
            Long read = fileModified.get(filename);
            if (rs.containsKey(filename) && read != null && lastModified == read) {
                int left = cursor.getInt(2);
                int right = cursor.getInt(3);
                int top = cursor.getInt(4);
                float bottom = cursor.getInt(5);
                indexedResources.insert(filename, new QuadRect(left, top, right, bottom));
                fileModified.remove(filename);
            }
        } while (cursor.moveToNext());
        cursor.close();
    }
}