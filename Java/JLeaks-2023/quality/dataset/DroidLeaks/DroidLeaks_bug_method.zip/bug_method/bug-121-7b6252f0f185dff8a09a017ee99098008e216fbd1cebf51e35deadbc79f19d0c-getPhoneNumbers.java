{
    ArrayList<Phone> phones = new ArrayList<Phone>();
    Cursor pCur = ctxt.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[] { id }, null);
    while (pCur.moveToNext()) {
        phones.add(new Phone(pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)), pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE))));
    }
    pCur.close();
    // Add any custom IM named 'sip' and set its type to 'sip'
    pCur = ctxt.getContentResolver().query(ContactsContract.Data.CONTENT_URI, null, ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?", new String[] { id, ContactsContract.CommonDataKinds.Im.CONTENT_ITEM_TYPE }, null);
    while (pCur.moveToNext()) {
        // Could also use some other IM type but may be confusing. Are there phones with no 'custom' IM type?
        if (pCur.getInt(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Im.PROTOCOL)) == ContactsContract.CommonDataKinds.Im.PROTOCOL_CUSTOM) {
            if (pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Im.CUSTOM_PROTOCOL)).equalsIgnoreCase("sip")) {
                phones.add(new Phone(pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Im.DATA)), "sip"));
            }
        }
    }
    pCur.close();
    // Add any SIP uri if android 9
    if (Compatibility.isCompatible(9)) {
        pCur = ctxt.getContentResolver().query(ContactsContract.Data.CONTENT_URI, null, ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?", new String[] { id, GINGER_SIP_TYPE }, null);
        while (pCur.moveToNext()) {
            // Could also use some other IM type but may be confusing. Are there phones with no 'custom' IM type?
            phones.add(new Phone(pCur.getString(pCur.getColumnIndex(ContactsContract.Data.DATA1)), "sip"));
        }
    }
    return (phones);
}