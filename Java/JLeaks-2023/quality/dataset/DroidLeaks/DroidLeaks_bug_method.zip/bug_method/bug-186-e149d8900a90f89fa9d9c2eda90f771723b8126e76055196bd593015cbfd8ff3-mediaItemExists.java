{
    Cursor cursor = mDb.query(MEDIA_TABLE_NAME, new String[] { MEDIA_LOCATION }, MEDIA_LOCATION + "=?", new String[] { location }, null, null, null);
    boolean exists = cursor.moveToFirst();
    cursor.close();
    return exists;
}