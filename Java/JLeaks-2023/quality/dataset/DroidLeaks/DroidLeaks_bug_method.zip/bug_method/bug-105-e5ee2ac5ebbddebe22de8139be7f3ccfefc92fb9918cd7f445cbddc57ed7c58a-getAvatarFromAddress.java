{
    String[] projection = { Imps.Contacts.AVATAR_DATA };
    String[] args = { address };
    String query = "username LIKE ?";
    Cursor cursor = cr.query(Imps.Contacts.CONTENT_URI, projection, query, args, Imps.Contacts.DEFAULT_SORT_ORDER);
    if (cursor.moveToFirst()) {
        String hexData = cursor.getString(0);
        if (hexData.equals("NULL")) {
            return null;
        }
        cursor.close();
        byte[] data = Hex.decode(hexData.substring(2, hexData.length() - 1));
        return decodeAvatar(data, width, height);
    } else {
        cursor.close();
        return null;
    }
}