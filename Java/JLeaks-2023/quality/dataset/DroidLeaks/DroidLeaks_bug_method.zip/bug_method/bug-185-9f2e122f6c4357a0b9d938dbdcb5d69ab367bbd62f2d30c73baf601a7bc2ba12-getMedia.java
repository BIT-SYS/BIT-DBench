    public synchronized Media getMedia(String path) {

        Cursor cursor;
        Media media = null;
        Bitmap picture = null;
        byte[] blob;

        cursor = mDb.query(
                MEDIA_TABLE_NAME,
                new String[] {
                        MEDIA_TIME, //0 long
                        MEDIA_LENGTH, //1 long
                        MEDIA_TYPE, //2 int
                        MEDIA_PICTURE, //3 Bitmap
                        MEDIA_TITLE, //4 string
                        MEDIA_ARTIST, //5 string
                        MEDIA_GENRE, //6 string
                        MEDIA_ALBUM //7 string
                },
                MEDIA_PATH + "=?",
                new String[] { path },
                null, null, null);
        if (cursor.moveToFirst()) {

            blob = cursor.getBlob(3);
            if (blob != null) {
                picture = BitmapFactory.decodeByteArray(blob, 0, blob.length);
            }

            media = new Media(mContext, new File(path), cursor.getLong(0),
                    cursor.getLong(1), cursor.getInt(2),
                    picture, cursor.getString(4),
                    cursor.getString(5), cursor.getString(6),
                    cursor.getString(7));
        }

        return media;
    }
