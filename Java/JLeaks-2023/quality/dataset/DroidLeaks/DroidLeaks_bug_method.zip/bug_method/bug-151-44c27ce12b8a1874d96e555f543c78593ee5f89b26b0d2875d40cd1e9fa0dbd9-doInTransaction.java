{
    ConcurrentHashMap<String, String> newStorage = new ConcurrentHashMap<String, String>();
    newStorage.putAll(storage);
    workingStorage.set(newStorage);
    SQLiteDatabase mDb = openDB();
    workingDB.set(mDb);
    ArrayList<String> changedKeys = new ArrayList<String>();
    workingChangedKeys.set(changedKeys);
    mDb.beginTransaction();
    try {
        dbWork.run();
        mDb.setTransactionSuccessful();
        storage = newStorage;
        for (String changedKey : changedKeys) {
            for (OnSharedPreferenceChangeListener listener : listeners) {
                listener.onSharedPreferenceChanged(this, changedKey);
            }
        }
    } finally {
        workingDB.remove();
        workingStorage.remove();
        workingChangedKeys.remove();
        mDb.endTransaction();
    }
}