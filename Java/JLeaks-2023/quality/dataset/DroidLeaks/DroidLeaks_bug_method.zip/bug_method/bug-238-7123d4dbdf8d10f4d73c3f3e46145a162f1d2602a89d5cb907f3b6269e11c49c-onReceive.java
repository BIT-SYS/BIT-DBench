{
    if (getResultCode() != Activity.RESULT_OK) {
        mRecvRetVal = false;
        context.unregisterReceiver(this);
        mSem.release();
        return;
    }
    mPendingIntents.remove(mPendingIntents.size() - 1);
    if (mPendingIntents.isEmpty()) {
        mRecvRetVal = true;
        context.unregisterReceiver(this);
        mSem.release();
    }
}