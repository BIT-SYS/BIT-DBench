{
    Cursor cursor = mDb.query(TagsTable.TABLE_NAME, new String[] { TagsTable.ID, TagsTable.NAME, TagsTable.DESCRIPTION, TagsTable.COLOR }, null, null, null, null, TagsTable.ID);
    List<AyahTag> tagList = new ArrayList<AyahTag>();
    while (cursor.moveToNext()) {
        AyahTag tag = new AyahTag(cursor.getInt(0), cursor.getString(1));
        if (!cursor.isNull(2))
            tag.description = cursor.getString(2);
        if (!cursor.isNull(3))
            tag.color = cursor.getInt(3);
        tagList.add(tag);
    }
    return tagList;
}