{
    Cursor cursor = findPage(page);
    if (!cursor.moveToFirst()) {
        ContentValues values = new ContentValues();
        values.put(PageTable.ID, page);
        values.put(PageTable.BOOKMARKED, 1);
        mDb.insert(PageTable.TABLE_NAME, null, values);
        return true;
    } else {
        boolean isBookmarked = (cursor.getInt(0) != 0);
        ContentValues values = new ContentValues();
        values.put(PageTable.BOOKMARKED, !isBookmarked);
        mDb.update(PageTable.TABLE_NAME, values, PageTable.ID + "=" + page, null);
        return !isBookmarked;
    }
}