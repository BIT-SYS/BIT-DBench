{
    Cursor cursor = getContentResolver().query(TrackContentProvider.CONTENT_URI_TRACK, null, null, null, Schema.COL_START_DATE + " asc");
    // Stop any currently active tracks
    if (currentTrackId != -1) {
        stopActiveTrack();
    }
    if (cursor.moveToFirst()) {
        int id_col = cursor.getColumnIndex("_id");
        do {
            deleteTrack(cursor.getLong(id_col));
        } while (cursor.moveToNext());
    }
}