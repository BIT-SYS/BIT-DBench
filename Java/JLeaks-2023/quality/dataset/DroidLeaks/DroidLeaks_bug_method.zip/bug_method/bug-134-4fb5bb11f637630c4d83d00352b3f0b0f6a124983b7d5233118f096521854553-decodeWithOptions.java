{
    final InputStream stream = myImage.inputStream();
    return stream != null ? BitmapFactory.decodeStream(stream, new Rect(), options) : null;
}