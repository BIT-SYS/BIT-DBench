{
    Cursor cursor = DATABASE.query(TABLE_NAME, null, EMAIL_COLUMN + "= ?", new String[] { email }, null, null, null);
    if (cursor != null && cursor.getCount() > 0) {
        cursor.moveToFirst();
        return cursor.getInt(cursor.getColumnIndex(COUNTER_COLUMN));
    }
    return null;
}