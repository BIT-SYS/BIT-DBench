{
    this.open();
    boolean result = false;
    Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
    result = cursor.moveToNext();
    this.close();
    return !result;
}