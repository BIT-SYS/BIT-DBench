{
    File d = new File(Environment.getExternalStorageDirectory(), DataProvider.PACKAGE);
    File f = new File(d, "logs-" + DateFormat.format("yyyyMMddkkmmss", System.currentTimeMillis()) + ".csv");
    f.mkdirs();
    if (f.exists()) {
        f.delete();
    }
    try {
        // build csv file and save it to sd card
        FileWriter w = new FileWriter(f);
        Cursor c = context.getContentResolver().query(DataProvider.Logs.CONTENT_URI_JOIN, DataProvider.Logs.PROJECTION_JOIN, null, null, null);
        w.append("date;type;direction;roamed;remote_number;" + "amount;billed_amount;cost;plan;rule\n");
        String[] types = context.getResources().getStringArray(R.array.plans_type);
        String[] directions = context.getResources().getStringArray(R.array.direction_calls);
        String cformat = getCurrencyFormat(context);
        if (c.moveToFirst()) {
            do {
                w.append(DateFormat.format("yyyyMMddkkmmss;", c.getLong(DataProvider.Logs.INDEX_DATE)));
                int t = c.getInt(DataProvider.Logs.INDEX_TYPE);
                w.append(types[t] + ";");
                int dir = c.getInt(DataProvider.Logs.INDEX_DIRECTION);
                w.append(directions[dir] + ";");
                w.append(c.getInt(DataProvider.Logs.INDEX_ROAMED) + ";");
                w.append(c.getString(DataProvider.Logs.INDEX_REMOTE) + ";");
                long a = c.getLong(DataProvider.Logs.INDEX_AMOUNT);
                float ba = c.getFloat(DataProvider.Logs.INDEX_BILL_AMOUNT);
                float cost = c.getFloat(DataProvider.Logs.INDEX_COST);
                w.append(Common.formatAmount(t, a, true) + ";");
                w.append(Common.formatAmount(t, ba, true) + ";");
                w.append(String.format(cformat, cost) + ";");
                w.append(c.getString(DataProvider.Logs.INDEX_PLAN_NAME) + ";");
                w.append(c.getString(DataProvider.Logs.INDEX_RULE_NAME) + "\n");
            } while (c.moveToNext());
        }
        c.close();
        w.close();
        // return file name
        return f.getAbsolutePath();
    } catch (IOException e) {
        Log.e(TAG, "error writing csv file", e);
    }
    return null;
}