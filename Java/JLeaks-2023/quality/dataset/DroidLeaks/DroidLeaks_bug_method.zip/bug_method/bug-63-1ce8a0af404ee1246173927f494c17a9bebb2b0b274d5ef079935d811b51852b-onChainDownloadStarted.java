{
    startDownload(blocksLeft);
    originalBlocksLeft = blocksLeft;
}