{
    if (!extraInformationRead) {
        Cursor startCursor = cr.query(TrackContentProvider.trackStartUri(trackId), null, null, null, null);
        if (startCursor.moveToFirst()) {
            startDate = startCursor.getLong(startCursor.getColumnIndex(Schema.COL_TIMESTAMP));
            startLat = startCursor.getFloat(startCursor.getColumnIndex(Schema.COL_LATITUDE));
            startLong = startCursor.getFloat(startCursor.getColumnIndex(Schema.COL_LONGITUDE));
        }
        Cursor endCursor = cr.query(TrackContentProvider.trackEndUri(trackId), null, null, null, null);
        if (endCursor.moveToFirst()) {
            endDate = endCursor.getLong(endCursor.getColumnIndex(Schema.COL_TIMESTAMP));
            endLat = endCursor.getFloat(endCursor.getColumnIndex(Schema.COL_LATITUDE));
            endLong = endCursor.getFloat(endCursor.getColumnIndex(Schema.COL_LONGITUDE));
        }
        extraInformationRead = true;
    }
}