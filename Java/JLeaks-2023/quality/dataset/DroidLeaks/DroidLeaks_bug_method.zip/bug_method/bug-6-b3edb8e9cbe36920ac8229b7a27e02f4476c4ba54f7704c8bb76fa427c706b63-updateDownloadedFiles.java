{
    boolean upgradedResult = true;
    boolean upgraded = false;
    boolean renamed = false;
    String whereClause = ProviderTableMeta.FILE_ACCOUNT_OWNER + "=? AND " + ProviderTableMeta.FILE_STORAGE_PATH + " IS NOT NULL";
    Cursor c = db.query(ProviderTableMeta.FILE_TABLE_NAME, null, whereClause, new String[] { newAccountName }, null, null, null);
    if (c.moveToFirst()) {
        // create storage path
        String oldAccountPath = FileStorageUtils.getSavePath(oldAccountName);
        String newAccountPath = FileStorageUtils.getSavePath(newAccountName);
        if (oldAccountPath != newAccountPath) {
            // move files
            File oldAccountFolder = new File(oldAccountPath);
            File newAccountFolder = new File(newAccountPath);
            renamed = oldAccountFolder.renameTo(newAccountFolder);
            // update database
            do {
                // Update database
                String oldPath = c.getString(c.getColumnIndex(ProviderTableMeta.FILE_STORAGE_PATH));
                OCFile file = new OCFile(c.getString(c.getColumnIndex(ProviderTableMeta.FILE_PATH)));
                String newPath = FileStorageUtils.getDefaultSavePathFor(newAccountName, file);
                db.beginTransaction();
                try {
                    ContentValues cv = new ContentValues();
                    cv.put(ProviderTableMeta.FILE_STORAGE_PATH, newPath);
                    db.update(ProviderTableMeta.FILE_TABLE_NAME, cv, ProviderTableMeta.FILE_STORAGE_PATH + "=?", new String[] { oldPath });
                    upgraded = true;
                    Log_OC.d("SQL", "Updated downloaded files: old file name == " + oldPath + ", new file name == " + newPath);
                } catch (SQLException e) {
                    upgraded = false;
                } finally {
                    db.endTransaction();
                }
                upgradedResult = upgraded && upgradedResult;
            } while (c.moveToNext());
        }
    }
    c.close();
    return (renamed && upgradedResult);
}