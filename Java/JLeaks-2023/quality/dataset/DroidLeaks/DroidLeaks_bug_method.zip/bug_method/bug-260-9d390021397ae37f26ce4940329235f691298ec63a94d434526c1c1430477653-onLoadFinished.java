{
    mCallback.onCursorLoaded(getUri(), data);
    if (mAdapter != null)
        mAdapter.swapCursor(data);
    configureEmptyLabel();
    if (isTablet()) {
        reloadLinearLayout();
    }
}