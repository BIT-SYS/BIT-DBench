    private void _rebuildRevEarlyCount() {
        String extraLim = ""; // In the future it would be nice to skip the first x days of due cards

        String sql = "SELECT count() FROM cards WHERE type = 1 AND combinedDue > " + mDueCutoff + extraLim;
        mRevCount = (int) getDB().queryScalar(sql);
    }
