    public void onDestroy() {
        super.onDestroy();
        ((LocationManager)getSystemService(Context.LOCATION_SERVICE))
                .removeUpdates(new DeviceLocationListener());
    }