{
    Cursor cursor = findAyah(sura, ayah, new String[] { AyahTable.NOTES });
    if (!cursor.moveToFirst() || cursor.isNull(0))
        return "";
    return cursor.getString(0);
}