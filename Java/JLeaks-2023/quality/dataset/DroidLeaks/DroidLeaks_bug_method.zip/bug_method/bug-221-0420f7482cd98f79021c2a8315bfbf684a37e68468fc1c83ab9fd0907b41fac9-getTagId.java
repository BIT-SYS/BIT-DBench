{
    Cursor cursor = mDb.query(TagsTable.TABLE_NAME, new String[] { TagsTable.ID }, TagsTable.NAME + "='" + tagName + "'", null, null, null, TagsTable.ID);
    if (cursor.moveToFirst())
        return cursor.getInt(0);
    else
        return null;
}