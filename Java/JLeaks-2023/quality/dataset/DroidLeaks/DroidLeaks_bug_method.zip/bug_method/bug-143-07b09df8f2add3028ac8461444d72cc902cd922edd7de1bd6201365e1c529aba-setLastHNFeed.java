{
    try {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(getLastHNFeedFilePath()));
        os.writeObject(hnFeed);
    } catch (Exception e) {
        Log.e(TAG, "Could not save last HNFeed to file :(", e);
    }
}