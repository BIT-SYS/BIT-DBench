	public SQLiteBlockStore(final Context context, final NetworkParameters networkParameters, final String databaseName) throws BlockStoreException
	{
		this.networkParameters = networkParameters;

		helper = new Helper(context, databaseName);

		final SQLiteDatabase db = helper.getReadableDatabase();
		final Cursor query = db.query(TABLE_SETTINGS, new String[] { COLUMN_SETTINGS_VALUE }, COLUMN_SETTINGS_NAME + "=?",
				new String[] { SETTING_CHAINHEAD }, null, null, null);
		if (query.moveToFirst())
		{
			final Sha256Hash hash = new Sha256Hash(query.getBlob(query.getColumnIndexOrThrow(COLUMN_SETTINGS_VALUE)));
			chainHeadBlock = get(hash);
			if (chainHeadBlock == null)
				throw new BlockStoreException("could not find block for chain head");
		}
		else
		{
			try
			{
				// set up the genesis block
				final Block genesis = networkParameters.genesisBlock.cloneAsHeader();
				final StoredBlock storedGenesis = new StoredBlock(genesis, genesis.getWork(), 0);

				put(storedGenesis);
				setChainHead(storedGenesis);
			}
			catch (final VerificationException x)
			{
				throw new BlockStoreException(x);
			}
		}
	}
