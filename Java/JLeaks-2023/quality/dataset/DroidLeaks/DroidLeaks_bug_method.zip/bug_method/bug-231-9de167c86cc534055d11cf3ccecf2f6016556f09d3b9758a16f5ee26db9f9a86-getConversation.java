{
    synchronized (CACHE) {
        Conversation ret = CACHE.get(threadId);
        if (ret == null || ret.getAddress() == null || forceUpdate) {
            Cursor cursor = context.getContentResolver().query(ConversationProvider.CONTENT_URI, ConversationProvider.PROJECTION, // .
            ConversationProvider.PROJECTION[ConversationProvider.INDEX_THREADID] + " = " + threadId, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                return getConversation(context, cursor, true);
            } else {
                Log.e(TAG, "did not found conversation: " + threadId);
            }
        }
        return ret;
    }
}