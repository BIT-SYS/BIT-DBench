{
    super.onStop();
    this.unbindService(connection);
    if (this.hosts != null) {
        this.hosts.close();
        this.hosts = null;
    }
}