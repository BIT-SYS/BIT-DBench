{
    try {
        return BitmapFactory.decodeStream(mContext.getContentResolver().openInputStream(AttachmentProvider.getAttachmentThumbnailUri(mAccount, part.getAttachmentId(), 62, 62)));
    } catch (Exception e) {
        /*
             * We don't care what happened, we just return null for the preview icon.
             */
        return null;
    }
}