{
    new Thread(new Runnable() {

        public void run() {
            doFilter(query);
        }
    }).start();
}