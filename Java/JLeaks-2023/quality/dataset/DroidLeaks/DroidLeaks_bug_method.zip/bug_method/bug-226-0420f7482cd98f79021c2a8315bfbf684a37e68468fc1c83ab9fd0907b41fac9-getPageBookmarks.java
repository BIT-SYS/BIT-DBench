{
    Cursor cursor = mDb.query(PageTable.TABLE_NAME, new String[] { PageTable.ID }, PageTable.BOOKMARKED + "=1", null, null, null, PageTable.ID);
    List<Integer> pageBookmarks = new ArrayList<Integer>();
    while (cursor.moveToNext()) {
        pageBookmarks.add(cursor.getInt(0));
    }
    return pageBookmarks;
}