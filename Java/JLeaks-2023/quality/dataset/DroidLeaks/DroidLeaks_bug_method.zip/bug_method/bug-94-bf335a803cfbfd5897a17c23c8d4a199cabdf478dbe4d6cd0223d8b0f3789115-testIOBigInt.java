{
    KeyPair pair = new OtrCryptoEngineImpl().generateDHKeyPair();
    BigInteger source = ((DHPublicKey) pair.getPublic()).getY();
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeBigInt(source);
    byte[] converted = out.toByteArray();
    ByteArrayInputStream bin = new ByteArrayInputStream(converted);
    OtrInputStream ois = new OtrInputStream(bin);
    BigInteger result = ois.readBigInt();
    assertTrue(source.compareTo(result) == 0);
}