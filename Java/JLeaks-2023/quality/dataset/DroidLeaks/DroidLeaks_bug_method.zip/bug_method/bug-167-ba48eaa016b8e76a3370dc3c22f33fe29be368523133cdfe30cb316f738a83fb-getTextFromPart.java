{
    try {
        if ((part != null) && (part.getBody() != null)) {
            final Body body = part.getBody();
            if (body instanceof TextBody) {
                return ((TextBody) body).getText();
            }
            final String mimeType = part.getMimeType();
            if ((mimeType != null) && MimeUtility.mimeTypeMatches(mimeType, "text/*")) {
                /*
                     * We've got a text part, so let's see if it needs to be processed further.
                     */
                String charset = getHeaderParameter(part.getContentType(), "charset");
                /*
                     * determine the charset from HTML message.
                     */
                if (mimeType.equalsIgnoreCase("text/html") && charset == null) {
                    InputStreamReader in = new InputStreamReader(part.getBody().getInputStream(), "US-ASCII");
                    char[] buf = new char[256];
                    in.read(buf, 0, buf.length);
                    String str = new String(buf);
                    if (str.length() == 0) {
                        return "";
                    }
                    Pattern p = Pattern.compile("<meta http-equiv=\"?Content-Type\"? content=\"text/html; charset=(.+?)\">", Pattern.CASE_INSENSITIVE);
                    Matcher m = p.matcher(str);
                    if (m.find()) {
                        charset = m.group(1);
                    }
                }
                charset = fixupCharset(charset, getMessageFromPart(part));
                /*
                     * Now we read the part into a buffer for further processing. Because
                     * the stream is now wrapped we'll remove any transfer encoding at this point.
                     */
                InputStream in = part.getBody().getInputStream();
                return readToString(in, charset);
            }
        }
    } catch (OutOfMemoryError oom) {
        /*
             * If we are not able to process the body there's nothing we can do about it. Return
             * null and let the upper layers handle the missing content.
             */
        Log.e(K9.LOG_TAG, "Unable to getTextFromPart " + oom.toString());
    } catch (Exception e) {
        /*
             * If we are not able to process the body there's nothing we can do about it. Return
             * null and let the upper layers handle the missing content.
             */
        Log.e(K9.LOG_TAG, "Unable to getTextFromPart", e);
    }
    return null;
}