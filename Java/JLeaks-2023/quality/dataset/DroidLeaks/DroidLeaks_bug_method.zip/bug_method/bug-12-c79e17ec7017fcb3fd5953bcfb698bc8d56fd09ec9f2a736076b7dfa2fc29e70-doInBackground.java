{
    InputStream fileIn;
    try {
        while (activity == null) Thread.sleep(100);
        if (type != null && type.startsWith("image/") && !type.equals("image/gif") && !type.equals("image/png") && Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(activity).getString("photo_size", "1024")) > 0) {
            mFileUri = activity.resize(mFileUri);
        }
        fileIn = activity.getContentResolver().openInputStream(mFileUri);
        Cursor c = activity.getContentResolver().query(mFileUri, new String[] { OpenableColumns.SIZE }, null, null, null);
        if (c != null && c.moveToFirst()) {
            total = c.getInt(0);
            c.close();
        } else {
            total = fileIn.available();
        }
    } catch (Exception e) {
        Crashlytics.log(Log.ERROR, "IRCCloud", "could not open InputStream: " + e);
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    show_alert("Upload Failed", "Unable to open input file stream");
                }
            });
        } else {
            NotificationManagerCompat.from(IRCCloudApplication.getInstance().getApplicationContext()).cancel(mBuffer.bid);
            Notifications.getInstance().alert(mBuffer.bid, "Upload Failed", "Unable to upload file to IRCCloud.");
        }
        return null;
    }
    if (total > 15000000) {
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    show_alert("Upload Failed", "Sorry, you can’t upload files larger than 15 MB");
                }
            });
        } else {
            NotificationManagerCompat.from(IRCCloudApplication.getInstance().getApplicationContext()).cancel(mBuffer.bid);
            Notifications.getInstance().alert(mBuffer.bid, "Upload Failed", "Unable to upload file to IRCCloud.");
        }
        return null;
    }
    activity.runOnUiThread(new Runnable() {

        @Override
        public void run() {
            String filesize;
            if (total < 1024) {
                filesize = total + " B";
            } else {
                int exp = (int) (Math.log(total) / Math.log(1024));
                filesize = String.format("%.1f ", total / Math.pow(1024, exp)) + ("KMGTPE".charAt(exp - 1)) + "B";
            }
            fileSize.setText(filesize + " • " + type);
            notification.setContentText(filesize + " • " + type);
            NotificationManagerCompat.from(IRCCloudApplication.getInstance().getApplicationContext()).notify(mBuffer.bid, notification.build());
        }
    });
    InputStream responseIn = null;
    try {
        String boundary = UUID.randomUUID().toString();
        http = (HttpURLConnection) new URL("https://" + NetworkConnection.IRCCLOUD_HOST + "/chat/upload").openConnection();
        http.setReadTimeout(60000);
        http.setConnectTimeout(60000);
        http.setDoOutput(true);
        http.setFixedLengthStreamingMode(total + (boundary.length() * 2) + original_filename.length() + type.length() + 88);
        http.setRequestProperty("User-Agent", NetworkConnection.getInstance().useragent);
        http.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        http.setRequestProperty("Cookie", "session=" + NetworkConnection.getInstance().session);
        http.setRequestProperty("x-irccloud-session", NetworkConnection.getInstance().session);
        OutputStream out = http.getOutputStream();
        out.write(("--" + boundary + "\r\n").getBytes());
        out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + original_filename + "\"\r\n").getBytes());
        out.write(("Content-Type: " + type + "\r\n\r\n").getBytes());
        copy(fileIn, out);
        if (!isCancelled()) {
            out.write(("\r\n--" + boundary + "--\r\n").getBytes());
            out.flush();
            out.close();
            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                responseIn = http.getInputStream();
                return onInput(responseIn);
            } else {
                Crashlytics.log(Log.INFO, "IRCCloud", "responseCode=" + http.getResponseCode());
                responseIn = http.getErrorStream();
                StringBuilder sb = new StringBuilder();
                Scanner scanner = new Scanner(responseIn).useDelimiter("\\A");
                while (scanner.hasNext()) {
                    sb.append(scanner.next());
                }
                Crashlytics.log(Log.ERROR, "IRCCloud", "error response: " + sb.toString());
            }
        } else {
            Log.e("IRCCloud", "Upload cancelled");
        }
    } catch (IOException ex) {
        ex.printStackTrace();
    } catch (Exception ex) {
        ex.printStackTrace();
        Crashlytics.logException(ex);
        error = "An unexpected error occurred. Please try again later.";
    } finally {
        try {
            if (responseIn != null)
                responseIn.close();
        } catch (Exception ignore) {
        }
        try {
            if (http != null)
                http.disconnect();
        } catch (Exception ignore) {
        }
        try {
            fileIn.close();
        } catch (Exception ignore) {
        }
    }
    return null;
}