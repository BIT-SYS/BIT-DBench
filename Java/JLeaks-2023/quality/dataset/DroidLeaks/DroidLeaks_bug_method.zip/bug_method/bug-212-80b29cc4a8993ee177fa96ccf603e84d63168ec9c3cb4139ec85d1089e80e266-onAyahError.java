	public void onAyahError(AyahItem ayah) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("An error occured");
		builder.setNegativeButton("ok", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				
			}
		});
		builder.show();
	}