{
    // get plans
    final Cursor currentCursor = (Cursor) Plans.this.adapter.getItem(position);
    Cursor otherCursor = null;
    try {
        otherCursor = (Cursor) Plans.this.adapter.getItem(position + direction);
    } catch (Exception e) {
        Log.w(TAG, "error swap " + direction, e);
    }
    if (otherCursor == null) {
        return;
    }
    // set new order
    final int orderCurrent = currentCursor.getInt(DataProvider.Plans.INDE_ORDER);
    final int orderOther = currentCursor.getInt(DataProvider.Plans.INDE_ORDER);
    final ContentValues cvCurrent = new ContentValues();
    ContentValues cvOther = null;
    if (orderCurrent == orderOther) {
        cvCurrent.put(DataProvider.Plans.ORDER, orderCurrent + direction);
    } else {
        cvOther = new ContentValues();
        cvCurrent.put(DataProvider.Plans.ORDER, orderOther);
        cvOther.put(DataProvider.Plans.ORDER, orderCurrent);
    }
    // push changes
    final ContentResolver cr = this.getContentResolver();
    cr.update(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(currentCursor.getString(DataProvider.Plans.INDEX_ID)).build(), cvCurrent, null, null);
    if (cvOther != null) {
        cr.update(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(otherCursor.getString(DataProvider.Plans.INDEX_ID)).build(), cvOther, null, null);
    }
}