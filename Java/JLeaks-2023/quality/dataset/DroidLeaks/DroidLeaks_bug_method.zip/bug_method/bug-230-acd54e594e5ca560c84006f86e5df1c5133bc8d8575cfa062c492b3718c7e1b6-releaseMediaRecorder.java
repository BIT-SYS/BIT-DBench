{
    Log.v(TAG, "Releasing media recorder.");
    if (mMediaRecorder != null) {
        mMediaRecorder.reset();
        mMediaRecorder.release();
        mMediaRecorder = null;
    }
}