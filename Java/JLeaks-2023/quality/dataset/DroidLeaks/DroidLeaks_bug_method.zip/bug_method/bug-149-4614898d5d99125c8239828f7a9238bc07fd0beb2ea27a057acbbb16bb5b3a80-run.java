{
    while (isRunning) {
        try {
            Socket client = socket.accept();
            if (client == null) {
                continue;
            }
            HttpRequest request = readRequest(client);
            if (isRunning)
                processRequest(request, client);
        } catch (SocketTimeoutException e) {
            // Do nothing
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error connecting to client", e);
        }
    }
}