{
    int ayahId = QuranInfo.getAyahId(sura, ayah);
    Cursor cursor = findAyah(ayahId, new String[] { AyahTable.BOOKMARKED });
    if (cursor.moveToFirst()) {
        boolean isBookmarked = (cursor.getInt(0) != 0);
        ContentValues values = new ContentValues();
        values.put(AyahTable.BOOKMARKED, !isBookmarked);
        mDb.update(AyahTable.TABLE_NAME, values, AyahTable.ID + "=" + ayahId, null);
        return !isBookmarked;
    } else {
        ContentValues values = createAyahValues(ayahId, page, sura, ayah, 1);
        mDb.insert(AyahTable.TABLE_NAME, null, values);
        return true;
    }
}