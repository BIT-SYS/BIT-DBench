{
    final InputStream ins = getResourceStream(resourceId);
    final String result = new Scanner(ins).useDelimiter("\\A").next();
    try {
        ins.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
    return result;
}