{
    /* Used for the lazy loading */
    Cursor cursor;
    Bitmap picture = null;
    byte[] blob;
    cursor = mDb.query(MEDIA_TABLE_NAME, new String[] { MEDIA_PICTURE }, MEDIA_LOCATION + "=?", new String[] { location }, null, null, null);
    if (cursor.moveToFirst()) {
        blob = cursor.getBlob(0);
        if (blob != null && blob.length > 1 && blob.length < 500000) {
            picture = BitmapFactory.decodeByteArray(blob, 0, blob.length);
            blob = null;
        }
    }
    return picture;
}