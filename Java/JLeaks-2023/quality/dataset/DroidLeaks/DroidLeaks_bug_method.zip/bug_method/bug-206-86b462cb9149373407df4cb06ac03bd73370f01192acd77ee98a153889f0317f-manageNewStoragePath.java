{
    Log.d(TAG, "manageNewStoragePath");
    // we'll need this FilenameFitler to clean up our track directory
    FilenameFilter gpxFilenameFilter = new FilenameFilter() {

        @Override
        public boolean accept(File dir, String filename) {
            if (filename.toLowerCase().endsWith(".gpx"))
                return true;
            return false;
        }
    };
    // query all tracks
    String[] columns = new String[] { Schema.COL_ID, Schema.COL_DIR };
    Cursor cursor = db.query(Schema.TBL_TRACK, columns, null, null, null, null, null);
    // if we have a valid cursor and can write to the sdcard, we'll go on and try to copy the files
    if (cursor != null && cursor.moveToFirst()) {
        Log.d(TAG, "manageNewStoragePath (found " + cursor.getCount() + " tracks to be processed)");
        do {
            long trackId = cursor.getLong(cursor.getColumnIndex(Schema.COL_ID));
            Log.d(TAG, "manageNewStoragePath (" + trackId + ")");
            String oldDirName = cursor.getString(cursor.getColumnIndex(Schema.COL_DIR));
            File newDir = DataHelper.getTrackDirectory(trackId);
            File oldDir = new File(oldDirName);
            if (oldDir.exists() && oldDir.canRead()) {
                // if our new directory doesn't exist, we'll create it
                if (!newDir.exists())
                    newDir.mkdirs();
                if (newDir.exists() && newDir.canWrite()) {
                    Log.d(TAG, "manageNewStoragePath (" + trackId + "): copy directory");
                    // we'll first copy all files to our new storage area... we'll clean up later
                    FileSystemUtils.copyDirectoryContents(newDir, oldDir);
                    // cleaning up new storage area
                    // find gpx files we accidentally copied to our new storage area and delete them
                    for (File gpxFile : newDir.listFiles(gpxFilenameFilter)) {
                        Log.d(TAG, "manageNewStoragePath (" + trackId + "): deleting gpx file [" + gpxFile + "]");
                        gpxFile.delete();
                    }
                } else {
                    Log.e(TAG, "manageNewStoragePath (" + trackId + "): directory [" + newDir + "] is not writable or could not be created");
                }
            }
        } while (cursor.moveToNext());
    }
    ContentValues vals = new ContentValues();
    vals.putNull(Schema.COL_DIR);
    db.update(Schema.TBL_TRACK, vals, null, null);
}