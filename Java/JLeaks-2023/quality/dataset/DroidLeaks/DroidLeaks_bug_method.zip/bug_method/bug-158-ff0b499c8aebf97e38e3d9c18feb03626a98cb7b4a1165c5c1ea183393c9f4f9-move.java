{
    if (to.exists()) {
        to.delete();
    }
    to.getParentFile().mkdirs();
    try {
        FileInputStream in = new FileInputStream(from);
        FileOutputStream out = new FileOutputStream(to);
        byte[] buffer = new byte[1024];
        int count = -1;
        while ((count = in.read(buffer)) > 0) {
            out.write(buffer, 0, count);
        }
        out.close();
        in.close();
        from.delete();
        return true;
    } catch (Exception e) {
        Log.w(K9.LOG_TAG, "cannot move " + from.getAbsolutePath() + " to " + to.getAbsolutePath(), e);
        return false;
    }
}