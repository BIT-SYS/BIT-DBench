{
    SQLiteDatabase db = this.getWritableDatabase();
    db.delete(TABLE_HOSTS, "_id = ?", new String[] { Long.toString(id) });
}