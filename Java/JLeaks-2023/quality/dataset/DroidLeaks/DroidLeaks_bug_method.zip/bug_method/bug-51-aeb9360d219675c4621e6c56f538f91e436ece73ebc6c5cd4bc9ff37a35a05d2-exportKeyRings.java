{
    /* TODO isn't this checked above, with the isStorageMounted call?
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            log.add(LogType.MSG_EXPORT_ERROR_STORAGE, 1);
            return new ExportResult(ExportResult.RESULT_ERROR, log);
        }
        */
    if (!BufferedOutputStream.class.isInstance(outStream)) {
        outStream = new BufferedOutputStream(outStream);
    }
    int okSecret = 0, okPublic = 0, progress = 0;
    try {
        String selection = null, ids[] = null;
        if (masterKeyIds != null) {
            // generate placeholders and string selection args
            ids = new String[masterKeyIds.length];
            StringBuilder placeholders = new StringBuilder("?");
            for (int i = 0; i < masterKeyIds.length; i++) {
                ids[i] = Long.toString(masterKeyIds[i]);
                if (i != 0) {
                    placeholders.append(",?");
                }
            }
            // put together selection string
            selection = Tables.KEY_RINGS_PUBLIC + "." + KeyRings.MASTER_KEY_ID + " IN (" + placeholders + ")";
        }
        Cursor cursor = mProviderHelper.getContentResolver().query(KeyRings.buildUnifiedKeyRingsUri(), new String[] { KeyRings.MASTER_KEY_ID, KeyRings.PUBKEY_DATA, KeyRings.PRIVKEY_DATA, KeyRings.HAS_ANY_SECRET }, selection, ids, Tables.KEYS + "." + KeyRings.MASTER_KEY_ID);
        if (cursor == null || !cursor.moveToFirst()) {
            log.add(LogType.MSG_EXPORT_ERROR_DB, 1);
            return new ExportResult(ExportResult.RESULT_ERROR, log, okPublic, okSecret);
        }
        int numKeys = cursor.getCount();
        updateProgress(mContext.getResources().getQuantityString(R.plurals.progress_exporting_key, numKeys), 0, numKeys);
        // For each public masterKey id
        while (!cursor.isAfterLast()) {
            // Create an output stream
            ArmoredOutputStream arOutStream = new ArmoredOutputStream(outStream);
            String version = PgpHelper.getVersionForHeader(mContext);
            if (version != null) {
                arOutStream.setHeader("Version", version);
            }
            long keyId = cursor.getLong(0);
            log.add(LogType.MSG_EXPORT_PUBLIC, 1, KeyFormattingUtils.beautifyKeyId(keyId));
            {
                // export public key part
                byte[] data = cursor.getBlob(1);
                arOutStream.write(data);
                arOutStream.close();
                okPublic += 1;
            }
            // export secret key part
            if (exportSecret && cursor.getInt(3) > 0) {
                log.add(LogType.MSG_EXPORT_SECRET, 2, KeyFormattingUtils.beautifyKeyId(keyId));
                byte[] data = cursor.getBlob(2);
                arOutStream.write(data);
                okSecret += 1;
            }
            updateProgress(progress++, numKeys);
            cursor.moveToNext();
        }
        updateProgress(R.string.progress_done, numKeys, numKeys);
    } catch (IOException e) {
        log.add(LogType.MSG_EXPORT_ERROR_IO, 1);
        return new ExportResult(ExportResult.RESULT_ERROR, log, okPublic, okSecret);
    }
    log.add(LogType.MSG_EXPORT_SUCCESS, 1);
    return new ExportResult(ExportResult.RESULT_OK, log, okPublic, okSecret);
}