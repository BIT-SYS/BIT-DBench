{
    ContentResolver cr = getContentResolver();
    long providerId = -1;
    long accountId = -1;
    Collection<IImConnection> listConns = ((ImApp) getApplication()).getActiveConnections();
    // look for active connections that match the host we need
    for (IImConnection conn : listConns) {
        try {
            long connProviderId = conn.getProviderId();
            Cursor cursor = cr.query(Imps.ProviderSettings.CONTENT_URI, new String[] { Imps.ProviderSettings.NAME, Imps.ProviderSettings.VALUE }, Imps.ProviderSettings.PROVIDER + "=?", new String[] { Long.toString(connProviderId) }, null);
            Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(cursor, cr, connProviderId, false, /* don't keep updated */
            null);
            try {
                String domainToCheck = settings.getDomain();
                if (domainToCheck != null && domainToCheck.length() > 0 && mHost.contains(domainToCheck)) {
                    mConn = conn;
                    providerId = connProviderId;
                    accountId = conn.getAccountId();
                    break;
                }
            } finally {
                settings.close();
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    // nothing active, let's see if non-active connections match
    if (mConn == null) {
        Cursor cursorProvider = initProviderCursor();
        if (cursorProvider == null || cursorProvider.getCount() == 0) {
            createNewAccount();
            return;
        } else {
            while (cursorProvider.moveToNext()) {
                // make sure there is a stored password
                if (!cursorProvider.isNull(ACTIVE_ACCOUNT_PW_COLUMN)) {
                    long cProviderId = cursorProvider.getLong(PROVIDER_ID_COLUMN);
                    Cursor cursor = cr.query(Imps.ProviderSettings.CONTENT_URI, new String[] { Imps.ProviderSettings.NAME, Imps.ProviderSettings.VALUE }, Imps.ProviderSettings.PROVIDER + "=?", new String[] { Long.toString(cProviderId) }, null);
                    Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(cursor, cr, cProviderId, false, /* don't keep updated */
                    null);
                    // does the conference host we need, match the settings domain for a logged in account
                    String domainToCheck = settings.getDomain();
                    if (domainToCheck != null && domainToCheck.length() > 0 && mHost.contains(domainToCheck)) {
                        providerId = cProviderId;
                        accountId = cursorProvider.getLong(ACTIVE_ACCOUNT_ID_COLUMN);
                        mConn = ((ImApp) getApplication()).getConnection(providerId);
                        // now sign in
                        signInAccount(accountId, providerId, cursorProvider.getString(ACTIVE_ACCOUNT_PW_COLUMN));
                        // do sign in, the rest of the process will happen later
                        break;
                    }
                    settings.close();
                    cursorProvider.close();
                }
            }
        }
    }
    if (mConn != null) {
        try {
            int state = mConn.getState();
            accountId = mConn.getAccountId();
            providerId = mConn.getProviderId();
            if (state < ImConnection.LOGGED_IN) {
                Cursor cursorProvider = initProviderCursor();
                while (cursorProvider.moveToNext()) {
                    if (cursorProvider.getLong(ACTIVE_ACCOUNT_ID_COLUMN) == accountId) {
                        signInAccount(accountId, providerId, cursorProvider.getString(ACTIVE_ACCOUNT_PW_COLUMN));
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e1) {
                            e1.printStackTrace();
                        }
                        // wait here for three seconds
                        mConn = ((ImApp) getApplication()).getConnection(providerId);
                        break;
                    }
                }
                cursorProvider.close();
            }
            if (state == ImConnection.LOGGED_IN || state == ImConnection.SUSPENDED) {
                Uri data = getIntent().getData();
                if (data.getScheme().equals("immu")) {
                    this.openMultiUserChat(data);
                } else if (!isValidToAddress()) {
                    showContactList(accountId);
                } else {
                    openChat(providerId, accountId);
                }
            }
        } catch (RemoteException e) {
            // Ouch!  Service died!  We'll just disappear.
            Log.w("ImUrlActivity", "Connection disappeared!");
            finish();
        }
    } else {
        createNewAccount();
        return;
    }
}