{
    Cursor cursor = AnkiDb.database.rawQuery(query, null);
    if (!cursor.moveToFirst())
        throw new SQLException("No result for query: " + query);
    long scalar = cursor.getLong(0);
    cursor.close();
    return scalar;
}