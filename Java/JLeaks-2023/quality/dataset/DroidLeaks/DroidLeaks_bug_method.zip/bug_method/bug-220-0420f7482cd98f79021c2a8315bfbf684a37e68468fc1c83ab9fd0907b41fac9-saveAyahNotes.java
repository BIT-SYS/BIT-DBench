{
    int ayahId = QuranInfo.getAyahId(sura, ayah);
    Cursor cursor = findAyah(ayahId, new String[] { AyahTable.BOOKMARKED });
    if (cursor.moveToFirst()) {
        ContentValues values = new ContentValues();
        values.put(AyahTable.NOTES, notes);
        mDb.update(AyahTable.TABLE_NAME, values, AyahTable.ID + "=" + ayahId, null);
    } else {
        ContentValues values = createAyahValues(ayahId, page, sura, ayah, 0);
        values.put(AyahTable.NOTES, notes);
        mDb.insert(AyahTable.TABLE_NAME, null, values);
    }
}