{
    super.onDestroy();
    Log.i(AnkiDroidApp.TAG, "StudyOptions - onDestroy()");
    if (mUnmountReceiver != null) {
        unregisterReceiver(mUnmountReceiver);
    }
}