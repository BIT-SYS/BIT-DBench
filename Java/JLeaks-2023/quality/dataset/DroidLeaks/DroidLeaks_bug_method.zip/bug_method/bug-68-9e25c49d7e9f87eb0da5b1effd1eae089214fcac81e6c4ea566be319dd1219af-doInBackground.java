{
    String ret = null;
    Cursor c = this.ctx.getContentResolver().query(Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, this.num), new String[] { PhoneLookup.DISPLAY_NAME }, null, null, null);
    if (c.moveToFirst()) {
        ret = c.getString(0);
    }
    c.close();
    return ret;
}