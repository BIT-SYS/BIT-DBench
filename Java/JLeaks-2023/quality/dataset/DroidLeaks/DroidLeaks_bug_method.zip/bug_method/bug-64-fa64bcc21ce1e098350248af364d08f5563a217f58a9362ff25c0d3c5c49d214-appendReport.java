{
    final Formatter formatter = new Formatter(report);
    for (int i = 0; i < indent; i++) report.append("  - ");
    formatter.format("%tF %tT  %s  [%d]\n", file.lastModified(), file.lastModified(), file.getName(), file.length());
    if (file.isDirectory())
        for (final File f : file.listFiles()) appendReport(report, f, indent + 1);
}