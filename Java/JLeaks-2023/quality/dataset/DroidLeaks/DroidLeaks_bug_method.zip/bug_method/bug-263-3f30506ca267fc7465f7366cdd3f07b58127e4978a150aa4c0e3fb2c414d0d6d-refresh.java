{
    Cursor cursor = fetchThemes(getThemeSortType());
    if (mAdapter == null) {
        mAdapter = new ThemeTabAdapter(getActivity(), cursor, false);
    }
    if (mNoResultText.isShown())
        mNoResultText.setVisibility(View.GONE);
    mAdapter.swapCursor(cursor);
}