{
    ArrayList<ContentValues> ret = new ArrayList<ContentValues>();
    String[] proj = cols;
    if (strip != null) {
        proj = new String[cols.length - 1];
        int i = 0;
        for (String c : cols) {
            if (strip.equals(c)) {
                continue;
            }
            proj[i] = c;
            ++i;
        }
    }
    final int l = proj.length;
    Cursor cursor = null;
    try {
        cursor = db.query(table, proj, null, null, null, null, null);
    } catch (SQLException e) {
        if (l == 1) {
            return null;
        }
        final String err = e.getMessage();
        if (!err.startsWith("no such column:")) {
            return null;
        }
        final String str = err.split(":", 3)[1].trim();
        return backup(db, table, proj, str);
    }
    if (cursor != null && cursor.moveToFirst()) {
        do {
            final ContentValues cv = new ContentValues();
            for (int i = 0; i < l; i++) {
                final String s = cursor.getString(i);
                if (s != null) {
                    cv.put(proj[i], s);
                }
            }
            ret.add(cv);
        } while (cursor.moveToNext());
    }
    if (cursor != null && !cursor.isClosed()) {
        cursor.close();
    }
    return ret.toArray(new ContentValues[0]);
}