{
    mCheckedItems.clear();
    mGridView.setSelection(0);
    mGridView.requestFocusFromTouch();
    mGridView.setSelection(0);
    mGridAdapter.swapCursor(null);
    resetSpinnerAdapter();
    mHasRetrievedAllMedia = false;
}