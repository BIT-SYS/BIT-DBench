{
    db = ctx.openOrCreateDatabase(DATABASE_NAME, 0, null);
    Cursor c = db.query("eula", new String[] { "interval" }, "id=0", null, null, null, null);
    int numRows = c.getCount();
    c.moveToFirst();
    String returnValue = "";
    if (numRows == 1) {
        if (c.getString(0) != null) {
            returnValue = c.getString(0);
        }
    }
    db.close();
    return returnValue;
}