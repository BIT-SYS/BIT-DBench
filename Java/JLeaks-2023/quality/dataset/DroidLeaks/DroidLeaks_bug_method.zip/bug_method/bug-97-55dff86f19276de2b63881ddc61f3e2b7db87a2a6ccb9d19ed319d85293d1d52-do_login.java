{
    /*
        if (mConnection != null) {
            setState(getState(), new ImErrorInfo(ImErrorInfo.CANT_CONNECT_TO_SERVER,
                    "still trying..."));
            return;
        }*/
    ContentResolver contentResolver = mContext.getContentResolver();
    Cursor cursor = contentResolver.query(Imps.ProviderSettings.CONTENT_URI, new String[] { Imps.ProviderSettings.NAME, Imps.ProviderSettings.VALUE }, Imps.ProviderSettings.PROVIDER + "=?", new String[] { Long.toString(mProviderId) }, null);
    if (cursor == null)
        // not going to work
        return;
    Imps.ProviderSettings.QueryMap providerSettings = new Imps.ProviderSettings.QueryMap(cursor, contentResolver, mProviderId, false, null);
    // providerSettings is closed in initConnection();
    String userName = Imps.Account.getUserName(contentResolver, mAccountId);
    String defaultStatus = null;
    mNeedReconnect = true;
    setState(LOGGING_IN, null);
    mUserPresence = new Presence(Presence.AVAILABLE, defaultStatus, Presence.CLIENT_TYPE_MOBILE);
    try {
        if (userName == null || userName.length() == 0)
            throw new XMPPException("empty username not allowed");
        initConnectionAndLogin(providerSettings, userName);
        setState(LOGGED_IN, null);
        debug(TAG, "logged in");
        mNeedReconnect = false;
    } catch (XMPPException e) {
        debug(TAG, "exception thrown on connection", e);
        ImErrorInfo info = new ImErrorInfo(ImErrorInfo.CANT_CONNECT_TO_SERVER, e.getMessage());
        // our default behavior is to retry
        mRetryLogin = true;
        if (mConnection != null && mConnection.isConnected() && (!mConnection.isAuthenticated())) {
            if (mIsGoogleAuth) {
                debug(TAG, "google failed; may need to refresh");
                String newPassword = refreshGoogleToken(userName, mPassword, providerSettings.getDomain());
                if (newPassword != null)
                    mPassword = newPassword;
                mRetryLogin = true;
            } else {
                debug(TAG, "not authorized - will not retry");
                info = new ImErrorInfo(ImErrorInfo.INVALID_USERNAME, "invalid user/password");
                mRetryLogin = false;
                mNeedReconnect = false;
            }
        }
        if (mRetryLogin && getState() != SUSPENDED) {
            debug(TAG, "will retry");
            setState(LOGGING_IN, info);
            maybe_reconnect();
        } else {
            debug(TAG, "will not retry");
            disconnect();
            disconnected(info);
        }
    } catch (Exception e) {
        debug(TAG, "login failed", e);
        mRetryLogin = true;
        mNeedReconnect = true;
        debug(TAG, "will retry");
        ImErrorInfo info = new ImErrorInfo(ImErrorInfo.UNKNOWN_ERROR, "keymanagement exception");
        setState(LOGGING_IN, info);
    } finally {
        providerSettings.close();
    }
}