{
    TranslationItem[] results = null;
    open();
    Cursor cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, COLUMN_DISPLAY_NAME);
    results = loadTranslations(cursor);
    close();
    return results;
}