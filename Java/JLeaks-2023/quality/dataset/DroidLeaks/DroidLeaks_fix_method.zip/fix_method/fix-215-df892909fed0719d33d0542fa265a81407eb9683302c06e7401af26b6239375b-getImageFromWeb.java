{
    QuranScreenInfo instance = QuranScreenInfo.getInstance();
    if (instance == null) {
        return null;
    }
    String urlString = IMG_HOST + "width" + instance.getWidthParam() + "/" + filename;
    Log.d(TAG, "want to download: " + urlString);
    InputStream is;
    try {
        URL url = new URL(urlString);
        is = (InputStream) url.getContent();
    } catch (Exception e) {
        return null;
    }
    String path = getQuranDirectory(context);
    if (path != null) {
        path += File.separator + filename;
        // can't write to the sdcard, try to decode in memory
        if (!QuranFileUtils.makeQuranDirectory(context)) {
            return decodeBitmapStream(is);
        }
        try {
            saveStream(is, path);
            return decodeBitmapStream(is);
        } catch (Exception e) {
            // failed to save the image, try to decode
            Crashlytics.logException(e);
            return decodeBitmapStream(is);
        } finally {
            try {
                is.close();
            } catch (Exception e) {
                // ignore
            }
        }
    } else {
        return decodeBitmapStream(is);
    }
}