{
    mIsRunning = false;
    mTranscriptScreen.finish();
    // Stop the reader and writer threads, and close the I/O streams
    mWriterHandler.sendEmptyMessage(FINISH);
    try {
        mTermIn.close();
        mTermOut.close();
    } catch (IOException e) {
        // We don't care if this fails
    }
    if (mFinishCallback != null) {
        mFinishCallback.onSessionFinish(this);
    }
}