{
    super.onDestroy();
    mAdapter.getCursor().close();
}