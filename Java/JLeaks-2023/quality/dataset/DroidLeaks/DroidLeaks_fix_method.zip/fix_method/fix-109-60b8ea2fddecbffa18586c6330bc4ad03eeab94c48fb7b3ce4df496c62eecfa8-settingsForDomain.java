{
    if (domain.equals("gmail.com")) {
        // Google only supports a certain configuration for XMPP:
        // http://code.google.com/apis/talk/open_communications.html
        settings.setDoDnsSrv(false);
        settings.setServer(DEFAULT_SERVER_GOOGLE);
        settings.setDomain(domain);
        settings.setPort(DEFAULT_PORT);
        settings.setRequireTls(true);
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    } else if (mEditPass.getText().toString().startsWith(GTalkOAuth2.NAME)) {
        // this is not @gmail but IS a google account
        settings.setDoDnsSrv(false);
        // set the google connect server
        settings.setServer(DEFAULT_SERVER_GOOGLE);
        settings.setDomain(domain);
        settings.setPort(DEFAULT_PORT);
        settings.setRequireTls(true);
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    } else if (domain.equals("jabber.org")) {
        settings.setDoDnsSrv(false);
        settings.setServer(DEFAULT_SERVER_JABBERORG);
        settings.setDomain(domain);
        settings.setPort(DEFAULT_PORT);
        settings.setRequireTls(true);
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    } else if (domain.equals("facebook.com")) {
        settings.setDoDnsSrv(false);
        settings.setDomain(DEFAULT_SERVER_FACEBOOK);
        settings.setPort(DEFAULT_PORT);
        settings.setServer(DEFAULT_SERVER_FACEBOOK);
        // facebook TLS now seems to be on
        settings.setRequireTls(true);
        // but cert verify can still be funky - off by default
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    } else if (domain.equals("jabber.ccc.de")) {
        if (settings.getUseTor()) {
            settings.setDoDnsSrv(false);
            settings.setServer(ONION_JABBERCCC);
        } else {
            settings.setDoDnsSrv(true);
            settings.setServer("");
        }
        settings.setDomain(domain);
        settings.setPort(DEFAULT_PORT);
        settings.setRequireTls(true);
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    } else {
        settings.setDomain(domain);
        settings.setPort(port);
        // if use Tor, turn off DNS resolution, and set Server manually from Domain
        if (settings.getUseTor()) {
            settings.setDoDnsSrv(false);
            // if Tor is off, and the user has not provided any values here, set to the @domain
            if (settings.getServer() == null || settings.getServer().length() == 0)
                settings.setServer(domain);
        } else if (settings.getServer() == null || settings.getServer().length() == 0) {
            // if Tor is off, and the user has not provided any values here, then reset to nothing
            settings.setDoDnsSrv(true);
            settings.setServer("");
        }
        settings.setRequireTls(true);
        settings.setTlsCertVerify(true);
        settings.setAllowPlainAuth(false);
    }
}