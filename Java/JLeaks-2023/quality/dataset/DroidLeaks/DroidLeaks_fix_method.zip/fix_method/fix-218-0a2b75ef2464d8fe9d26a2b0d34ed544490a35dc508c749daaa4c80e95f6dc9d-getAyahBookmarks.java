{
    String query = AyahTable.BOOKMARKED + "=1";
    if (page != null)
        query += " and " + AyahTable.PAGE + "=" + page;
    Cursor cursor = db.query(AyahTable.TABLE_NAME, new String[] { AyahTable.ID, AyahTable.PAGE, AyahTable.SURA, AyahTable.AYAH }, query, null, null, null, AyahTable.SURA + ", " + AyahTable.AYAH);
    List<AyahBookmark> ayahBookmarks = new ArrayList<AyahBookmark>();
    while (cursor.moveToNext()) {
        ayahBookmarks.add(new AyahBookmark(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2), cursor.getInt(3), true));
    }
    cursor.close();
    return ayahBookmarks;
}