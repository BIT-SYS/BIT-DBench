{
    Cursor c = mDb.query(TABLE, array(STATE), WHERE, array(reportId), null, null, null);
    if (c.getCount() < 1) {
        // free resources
        c.close();
        return STATE_NOT_OPENGEOSMS;
    }
    c.moveToFirst();
    final int reportState = c.getInt(0);
    // free resources
    c.close();
    return reportState;
}