{
    if (!AndroidDevices.hasExternalStorage())
        return;
    String line;
    FileInputStream input = null;
    BufferedReader br = null;
    int rowCount = 0;
    int position = 0;
    String currentMedia;
    List<String> mediaPathList = new ArrayList<String>();
    try {
        // read CurrentMedia
        input = new FileInputStream(AudioUtil.CACHE_DIR + "/" + "CurrentMedia.txt");
        br = new BufferedReader(new InputStreamReader(input));
        currentMedia = br.readLine();
        mShuffling = "1".equals(br.readLine());
        br.close();
        br = null;
        input.close();
        // read MediaList
        input = new FileInputStream(AudioUtil.CACHE_DIR + "/" + "MediaList.txt");
        br = new BufferedReader(new InputStreamReader(input));
        while ((line = br.readLine()) != null) {
            mediaPathList.add(line);
            if (line.equals(currentMedia))
                position = rowCount;
            rowCount++;
        }
        // load playlist
        mInterface.load(mediaPathList, position, false);
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try {
            if (br != null)
                br.close();
            if (input != null)
                input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}