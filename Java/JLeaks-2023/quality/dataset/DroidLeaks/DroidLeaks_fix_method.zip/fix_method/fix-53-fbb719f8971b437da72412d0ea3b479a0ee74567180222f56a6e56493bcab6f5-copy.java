{
    FileInputStream is = new FileInputStream(in);
    FileOutputStream os = new FileOutputStream(out);
    try {
        byte[] buf = new byte[512];
        while (is.available() > 0) {
            int count = is.read(buf, 0, 512);
            os.write(buf, 0, count);
        }
    } finally {
        is.close();
        os.close();
    }
}