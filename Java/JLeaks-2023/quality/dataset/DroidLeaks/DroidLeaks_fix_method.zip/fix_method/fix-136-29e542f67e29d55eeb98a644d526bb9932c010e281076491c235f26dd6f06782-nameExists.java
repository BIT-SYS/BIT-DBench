{
    Cursor cursor = getAccount(email);
    try {
        return !cursorIsEmpty(cursor);
    } finally {
        tryCloseCursor(cursor);
    }
}