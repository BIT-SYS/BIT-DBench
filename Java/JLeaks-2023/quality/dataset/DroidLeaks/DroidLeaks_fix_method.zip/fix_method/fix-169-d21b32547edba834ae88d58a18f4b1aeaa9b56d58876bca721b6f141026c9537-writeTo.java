{
    InputStream in = getInputStream();
    try {
        boolean closeStream = false;
        if (MimeUtil.isBase64Encoding(mEncoding)) {
            out = new Base64OutputStream(out);
            closeStream = true;
        } else if (MimeUtil.isQuotedPrintableEncoded(mEncoding)) {
            out = new QuotedPrintableOutputStream(out, false);
            closeStream = true;
        }
        try {
            IOUtils.copy(in, out);
        } finally {
            if (closeStream) {
                out.close();
            }
        }
    } finally {
        in.close();
    }
}