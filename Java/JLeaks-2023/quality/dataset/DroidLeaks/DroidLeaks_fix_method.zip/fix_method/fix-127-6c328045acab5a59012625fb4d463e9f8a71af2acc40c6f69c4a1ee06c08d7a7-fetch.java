{
    if (!isAvailable())
        return null;
    final File file = dataFileName(name);
    if (!file.exists())
        return null;
    if (expired(file, maxAgeInDays))
        return null;
    final ByteArrayOutputStream output = new ByteArrayOutputStream();
    try {
        final FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        int n = 0;
        while ((n = fis.read(buffer)) != -1) output.write(buffer, 0, n);
        fis.close();
    }// try
     catch (IOException e) {
        return null;
    }
    // catch
    return output.toByteArray();
}