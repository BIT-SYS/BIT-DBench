{
    File file = new File(destination);
    OutputStream output = null;
    try {
        file.createNewFile();
        output = new BufferedOutputStream(new FileOutputStream(file));
        byte[] buf = new byte[Utils.CHUNK_SIZE];
        int len;
        while ((len = source.read(buf)) > 0) {
            output.write(buf, 0, len);
            bytesReceived += len;
            publishProgress();
        }
        output.close();
        return true;
    } catch (IOException e) {
        try {
            output.close();
        } catch (IOException e1) {
            // do nothing
        }
        // no write access or sd card full
        file.delete();
        return false;
    }
}