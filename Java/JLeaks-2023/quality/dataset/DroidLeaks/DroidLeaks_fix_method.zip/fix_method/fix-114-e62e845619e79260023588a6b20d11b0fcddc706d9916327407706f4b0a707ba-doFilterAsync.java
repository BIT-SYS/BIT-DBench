{
    if (mCursor != null)
        mCursor.close();
    new Thread(new Runnable() {

        public void run() {
            doFilter(query);
        }
    }).start();
}