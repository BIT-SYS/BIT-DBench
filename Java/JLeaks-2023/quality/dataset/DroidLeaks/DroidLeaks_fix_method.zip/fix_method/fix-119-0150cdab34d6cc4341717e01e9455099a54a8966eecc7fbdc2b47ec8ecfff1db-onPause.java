{
    super.onPause();
    Log.d(TAG, "onPause called");
    // Allow the screen to dim and fall asleep.
    if (wakelock != null && wakelock.isHeld())
        wakelock.release();
    if (forcedOrientation && bound != null)
        bound.setResizeAllowed(false);
}