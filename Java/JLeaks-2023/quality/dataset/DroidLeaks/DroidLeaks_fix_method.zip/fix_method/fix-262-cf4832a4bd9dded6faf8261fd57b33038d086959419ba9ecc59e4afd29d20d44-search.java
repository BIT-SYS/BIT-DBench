{
    mLastSearch = searchTerm;
    String blogId = getBlogId();
    Cursor cursor = WordPress.wpDB.getThemes(blogId, searchTerm);
    if (mAdapter == null) {
        return;
    } else {
        mAdapter.changeCursor(cursor);
        mGridView.invalidateViews();
        if (cursor == null || cursor.getCount() == 0) {
            mNoResultText.setVisibility(View.VISIBLE);
        } else {
            mNoResultText.setVisibility(View.GONE);
        }
    }
}