{
    ObjectInputStream obj = null;
    try {
        obj = new ObjectInputStream(new FileInputStream(getLastHNFeedFilePath()));
        Object rawHNFeed = obj.readObject();
        if (rawHNFeed instanceof HNFeed)
            return (HNFeed) rawHNFeed;
    } catch (Exception e) {
        Log.e(TAG, "Could not get last HNFeed from file :(", e);
    } finally {
        if (obj != null) {
            try {
                obj.close();
            } catch (IOException e) {
                Log.e(TAG, "Couldn't close last NH feed file :(", e);
            }
        }
    }
    return null;
}