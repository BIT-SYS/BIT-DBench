{
    Cursor contactMasterKey = context.getContentResolver().query(contactUri, new String[] { ContactsContract.Data.DATA2 }, null, null, null);
    if (contactMasterKey != null) {
        try {
            if (contactMasterKey.moveToNext()) {
                return KeychainContract.KeyRings.buildGenericKeyRingUri(contactMasterKey.getLong(0));
            }
        } finally {
            contactMasterKey.close();
        }
    }
    return null;
}