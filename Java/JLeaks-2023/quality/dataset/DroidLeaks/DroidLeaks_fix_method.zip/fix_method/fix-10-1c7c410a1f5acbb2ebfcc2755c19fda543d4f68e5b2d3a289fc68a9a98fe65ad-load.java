{
    Cursor c = new Select().all().from(Server.class).query();
    try {
        long start = System.currentTimeMillis();
        ModelAdapter<Server> modelAdapter = FlowManager.getModelAdapter(Server.class);
        if (c != null && c.moveToFirst()) {
            servers = new SparseArray<>(c.getCount());
            do {
                Server s = modelAdapter.loadFromCursor(c);
                servers.put(s.getCid(), s);
                s.updateIgnores(s.raw_ignores);
            } while (c.moveToNext());
            long time = System.currentTimeMillis() - start;
            android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " servers in " + time + "ms");
        }
    } catch (SQLiteException e) {
        servers.clear();
    } finally {
        if (c != null)
            c.close();
    }
}