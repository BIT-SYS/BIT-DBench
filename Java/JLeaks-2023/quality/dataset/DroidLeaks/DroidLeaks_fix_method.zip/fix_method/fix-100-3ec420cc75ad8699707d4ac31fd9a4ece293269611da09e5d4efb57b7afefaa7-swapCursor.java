{
    if (mBindTask != null) {
        mBindTask.cancel(false);
        mBindTask = null;
    }
    if (mStashCursor != null && (!mStashCursor.isClosed()))
        mStashCursor.close();
    mStashCursor = newCursor;
    if (mStashCursor != null) {
        // Delay swapping in the cursor until we get the extra info
        List<AccountInfo> accountInfoList = getAccountInfoList(mStashCursor);
        runBindTask((Activity) mContext, accountInfoList);
    }
    return super.swapCursor(mStashCursor);
}