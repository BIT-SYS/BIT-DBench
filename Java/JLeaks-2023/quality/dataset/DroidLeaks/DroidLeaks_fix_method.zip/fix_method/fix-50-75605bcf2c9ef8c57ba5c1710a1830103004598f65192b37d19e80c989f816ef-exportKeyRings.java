{
    /* TODO isn't this checked above, with the isStorageMounted call?
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            log.add(LogType.MSG_EXPORT_ERROR_STORAGE, 1);
            return new ExportResult(ExportResult.RESULT_ERROR, log);
        }
        */
    if (!BufferedOutputStream.class.isInstance(outStream)) {
        outStream = new BufferedOutputStream(outStream);
    }
    int okSecret = 0, okPublic = 0, progress = 0;
    Cursor cursor = null;
    try {
        String selection = null, ids[] = null;
        if (masterKeyIds != null) {
            // generate placeholders and string selection args
            ids = new String[masterKeyIds.length];
            StringBuilder placeholders = new StringBuilder("?");
            for (int i = 0; i < masterKeyIds.length; i++) {
                ids[i] = Long.toString(masterKeyIds[i]);
                if (i != 0) {
                    placeholders.append(",?");
                }
            }
            // put together selection string
            selection = Tables.KEY_RINGS_PUBLIC + "." + KeyRings.MASTER_KEY_ID + " IN (" + placeholders + ")";
        }
        cursor = mProviderHelper.getContentResolver().query(KeyRings.buildUnifiedKeyRingsUri(), new String[] { KeyRings.MASTER_KEY_ID, KeyRings.PUBKEY_DATA, KeyRings.PRIVKEY_DATA, KeyRings.HAS_ANY_SECRET }, selection, ids, Tables.KEYS + "." + KeyRings.MASTER_KEY_ID);
        if (cursor == null || !cursor.moveToFirst()) {
            log.add(LogType.MSG_EXPORT_ERROR_DB, 1);
            return new ExportResult(ExportResult.RESULT_ERROR, log, okPublic, okSecret);
        }
        int numKeys = cursor.getCount();
        updateProgress(mContext.getResources().getQuantityString(R.plurals.progress_exporting_key, numKeys), 0, numKeys);
        // For each public masterKey id
        while (!cursor.isAfterLast()) {
            long keyId = cursor.getLong(0);
            ArmoredOutputStream arOutStream = null;
            // Create an output stream
            try {
                arOutStream = new ArmoredOutputStream(outStream);
                log.add(LogType.MSG_EXPORT_PUBLIC, 1, KeyFormattingUtils.beautifyKeyId(keyId));
                byte[] data = cursor.getBlob(1);
                CanonicalizedKeyRing ring = UncachedKeyRing.decodeFromData(data).canonicalize(log, 2, true);
                ring.encode(arOutStream);
                okPublic += 1;
            } catch (PgpGeneralException e) {
                log.add(LogType.MSG_EXPORT_ERROR_KEY, 2);
                updateProgress(progress++, numKeys);
                continue;
            } finally {
                // make sure this is closed
                if (arOutStream != null) {
                    arOutStream.close();
                }
                arOutStream = null;
            }
            if (exportSecret && cursor.getInt(3) > 0) {
                try {
                    arOutStream = new ArmoredOutputStream(outStream);
                    // export secret key part
                    log.add(LogType.MSG_EXPORT_SECRET, 2, KeyFormattingUtils.beautifyKeyId(keyId));
                    byte[] data = cursor.getBlob(2);
                    CanonicalizedKeyRing ring = UncachedKeyRing.decodeFromData(data).canonicalize(log, 2, true);
                    ring.encode(arOutStream);
                    okSecret += 1;
                } catch (PgpGeneralException e) {
                    log.add(LogType.MSG_EXPORT_ERROR_KEY, 2);
                    updateProgress(progress++, numKeys);
                    continue;
                } finally {
                    // make sure this is closed
                    if (arOutStream != null) {
                        arOutStream.close();
                    }
                }
            }
            updateProgress(progress++, numKeys);
            cursor.moveToNext();
        }
        updateProgress(R.string.progress_done, numKeys, numKeys);
    } catch (IOException e) {
        log.add(LogType.MSG_EXPORT_ERROR_IO, 1);
        return new ExportResult(ExportResult.RESULT_ERROR, log, okPublic, okSecret);
    } finally {
        // Make sure the stream is closed
        if (outStream != null)
            try {
                outStream.close();
            } catch (Exception e) {
                Log.e(Constants.TAG, "error closing stream", e);
            }
        if (cursor != null) {
            cursor.close();
        }
    }
    log.add(LogType.MSG_EXPORT_SUCCESS, 1);
    return new ExportResult(ExportResult.RESULT_OK, log, okPublic, okSecret);
}