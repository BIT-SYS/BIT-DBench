{
    Cursor c = new Select().all().from(Channel.class).query();
    try {
        long start = System.currentTimeMillis();
        ModelAdapter<Channel> modelAdapter = FlowManager.getModelAdapter(Channel.class);
        if (c != null && c.moveToFirst()) {
            channels = new SparseArray<>(c.getCount());
            do {
                Channel s = modelAdapter.loadFromCursor(c);
                channels.put(s.bid, s);
                updateMode(s.bid, s.mode, s.ops, true);
            } while (c.moveToNext());
            long time = System.currentTimeMillis() - start;
            android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " channels in " + time + "ms");
        }
    } catch (SQLiteException e) {
        channels.clear();
    } finally {
        if (c != null)
            c.close();
    }
}