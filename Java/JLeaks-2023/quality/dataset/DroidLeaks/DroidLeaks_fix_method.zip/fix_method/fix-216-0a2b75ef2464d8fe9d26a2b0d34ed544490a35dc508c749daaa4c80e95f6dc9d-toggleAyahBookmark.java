{
    int ayahId = QuranInfo.getAyahId(sura, ayah);
    Cursor cursor = findAyah(ayahId, new String[] { AyahTable.BOOKMARKED });
    boolean result = true;
    if (cursor.moveToFirst()) {
        boolean isBookmarked = (cursor.getInt(0) != 0);
        ContentValues values = new ContentValues();
        values.put(AyahTable.BOOKMARKED, !isBookmarked);
        db.update(AyahTable.TABLE_NAME, values, AyahTable.ID + "=" + ayahId, null);
        result = !isBookmarked;
    } else {
        ContentValues values = createAyahValues(ayahId, page, sura, ayah, 1);
        db.insert(AyahTable.TABLE_NAME, null, values);
    }
    cursor.close();
    return result;
}