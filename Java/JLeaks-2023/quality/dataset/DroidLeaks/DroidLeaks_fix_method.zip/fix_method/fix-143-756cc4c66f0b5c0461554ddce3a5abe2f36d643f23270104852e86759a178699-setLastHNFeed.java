{
    ObjectOutputStream os = null;
    try {
        os = new ObjectOutputStream(new FileOutputStream(getLastHNFeedFilePath()));
        os.writeObject(hnFeed);
    } catch (Exception e) {
        Log.e(TAG, "Could not save last HNFeed to file :(", e);
    } finally {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                Log.e(TAG, "Couldn't close last NH feed file :(", e);
            }
        }
    }
}