{
    try {
        mCursor = getContentResolver().query(UserDictionary.Words.CONTENT_URI, QUERY_PROJECTION, QUERY_SELECTION, new String[] { mSelectedLocale }, "UPPER(" + UserDictionary.Words.WORD + ")");
    } catch (Exception e) {
        // TODO: Use ASK fallback
        e.printStackTrace();
    }
    return null;
}