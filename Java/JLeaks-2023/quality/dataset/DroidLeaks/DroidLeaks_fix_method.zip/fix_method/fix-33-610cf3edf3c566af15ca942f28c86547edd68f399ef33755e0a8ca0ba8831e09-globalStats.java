{
    Log.i(TAG, "Getting global stats...");
    int type = STATS_LIFE;
    Date today = genToday(deck);
    Cursor cursor = null;
    Stats stats = null;
    try {
        cursor = AnkiDb.database.rawQuery("SELECT id " + "FROM stats " + "WHERE type = " + String.valueOf(type), null);
        if (cursor.moveToFirst()) {
            stats = new Stats();
            stats.fromDB(cursor.getLong(0));
            return stats;
        }
    } finally {
        if (cursor != null)
            cursor.close();
    }
    stats = new Stats();
    stats.create(type, today);
    stats.type = type;
    return stats;
}