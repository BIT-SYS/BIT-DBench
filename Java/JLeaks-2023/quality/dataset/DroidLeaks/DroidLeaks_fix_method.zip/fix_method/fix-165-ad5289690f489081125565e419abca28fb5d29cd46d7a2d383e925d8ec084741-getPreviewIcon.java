{
    Bitmap icon = null;
    try {
        InputStream input = mContext.getContentResolver().openInputStream(AttachmentProvider.getAttachmentThumbnailUri(mAccount, part.getAttachmentId(), 62, 62));
        icon = BitmapFactory.decodeStream(input);
        input.close();
    } catch (Exception e) {
        /*
             * We don't care what happened, we just return null for the preview icon.
             */
    }
    return icon;
}