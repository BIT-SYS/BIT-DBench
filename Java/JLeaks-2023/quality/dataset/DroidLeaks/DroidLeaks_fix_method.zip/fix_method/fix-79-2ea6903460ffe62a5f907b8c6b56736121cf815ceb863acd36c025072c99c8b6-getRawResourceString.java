{
    InputStream ins = null;
    Scanner scanner = null;
    try {
        ins = res.openRawResource(resourceId);
        scanner = new Scanner(ins, CharEncoding.UTF_8);
        return scanner.useDelimiter("\\A").next();
    } finally {
        IOUtils.closeQuietly(scanner);
        IOUtils.closeQuietly(ins);
    }
}