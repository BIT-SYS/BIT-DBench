{
    FileInfo info = new FileInfo();
    if (uri.getScheme() != null && uri.getScheme().equals("file")) {
        info.path = uri.getPath();
        return info;
    }
    if (uri.toString().startsWith("content://org.openintents.filemanager/")) {
        // Work around URI escaping brokenness
        info.path = uri.toString().replaceFirst("content://org.openintents.filemanager", "");
        return info;
    }
    Cursor cursor = aContext.getContentResolver().query(uri, null, null, null, null);
    if (cursor != null && cursor.getCount() > 0) {
        cursor.moveToFirst();
        // need to check columns for different types
        int dataIdx = cursor.getColumnIndex(MediaStore.Images.Media.DATA);
        if (dataIdx != -1) {
            info.path = cursor.getString(dataIdx);
            info.type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
        } else {
            dataIdx = cursor.getColumnIndex(MediaStore.Video.Media.DATA);
            if (dataIdx != -1) {
                info.path = cursor.getString(dataIdx);
                info.type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE));
            } else {
                dataIdx = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                if (dataIdx != -1) {
                    info.path = cursor.getString(dataIdx);
                    info.type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE));
                } else {
                    dataIdx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA);
                    if (dataIdx != -1) {
                        info.path = cursor.getString(dataIdx);
                        info.type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE));
                    }
                }
            }
        }
    }
    if (cursor != null)
        cursor.close();
    return info;
}