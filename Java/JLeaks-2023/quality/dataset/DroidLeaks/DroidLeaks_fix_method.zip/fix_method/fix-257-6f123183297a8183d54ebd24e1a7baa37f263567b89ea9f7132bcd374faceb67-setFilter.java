{
    mFilter = filter;
    Cursor cursor = filterItems(mFilter);
    if (cursor != null) {
        mGridAdapter.changeCursor(cursor);
        mResultView.setVisibility(View.GONE);
    } else {
        if (filter != Filter.CUSTOM_DATE) {
            mResultView.setVisibility(View.VISIBLE);
            mResultView.setText(getResources().getString(R.string.empty_fields));
        }
    }
}