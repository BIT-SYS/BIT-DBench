{
    try {
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        OtrInputStream ois = new OtrInputStream(in);
        int len = ois.readInt();
        if (len > 100) {
            ois.close();
            throw new SMException("Too many ints");
        }
        BigInteger[] ints = new BigInteger[len];
        for (int i = 0; i < len; i++) {
            ints[i] = ois.readBigInt();
        }
        ois.close();
        return ints;
    } catch (IOException ex) {
        throw new SMException("cannot unserialize bigints");
    }
}