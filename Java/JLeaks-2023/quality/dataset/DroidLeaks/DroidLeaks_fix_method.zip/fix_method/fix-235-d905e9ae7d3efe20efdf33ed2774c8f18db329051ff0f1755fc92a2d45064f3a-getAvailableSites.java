{
    // Try to access the TorrentSitesProvider of the Torrent Search app
    Uri uri = Uri.parse("content://org.transdroid.search.torrentsitesprovider/sites");
    ContentProviderClient test = context.getContentResolver().acquireContentProviderClient(uri);
    if (test == null) {
        // Torrent Search package is not yet installed
        return null;
    }
    // Query the available in-app torrent search sites
    Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
    if (cursor == null) {
        // The installed Torrent Search version is corrupt or incompatible
        return null;
    }
    List<SearchSite> sites = new ArrayList<>();
    if (cursor.moveToFirst()) {
        do {
            // Read the cursor fields into the SearchSite object
            sites.add(new SearchSite(cursor.getInt(CURSOR_SITE_ID), cursor.getString(CURSOR_SITE_CODE), cursor.getString(CURSOR_SITE_NAME), cursor.getString(CURSOR_SITE_RSSURL), cursor.getColumnNames().length > 4 && cursor.getInt(CURSOR_SITE_ISPRIVATE) == 1));
        } while (cursor.moveToNext());
    }
    cursor.close();
    return sites;
}