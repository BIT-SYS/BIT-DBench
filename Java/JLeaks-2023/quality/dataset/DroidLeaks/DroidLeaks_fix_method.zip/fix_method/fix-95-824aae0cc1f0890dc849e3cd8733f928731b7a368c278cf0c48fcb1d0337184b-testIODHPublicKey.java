{
    KeyPair pair = new OtrCryptoEngineImpl().generateDHKeyPair();
    DHPublicKey source = (DHPublicKey) pair.getPublic();
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeDHPublicKey(source);
    oos.close();
    byte[] converted = out.toByteArray();
    ByteArrayInputStream bin = new ByteArrayInputStream(converted);
    OtrInputStream ois = new OtrInputStream(bin);
    DHPublicKey result = ois.readDHPublicKey();
    ois.close();
    assertTrue(source.getY().compareTo(result.getY()) == 0);
}