{
    if (!mStoreFile.exists())
        return;
    if (mStoreFile.length() == 0)
        return;
    FileInputStream fis = null;
    OpenSSLPBEInputStream encIS = null;
    try {
        fis = new FileInputStream(mStoreFile);
        // Decrypt the bytes
        encIS = new OpenSSLPBEInputStream(fis, STORE_ALGORITHM, 1, password.toCharArray());
        mProperties.load(encIS);
    } catch (FileNotFoundException fnfe) {
        OtrDebugLogger.log("Properties store file not found: First time?");
        mStoreFile.getParentFile().mkdirs();
    } finally {
        encIS.close();
        fis.close();
    }
}