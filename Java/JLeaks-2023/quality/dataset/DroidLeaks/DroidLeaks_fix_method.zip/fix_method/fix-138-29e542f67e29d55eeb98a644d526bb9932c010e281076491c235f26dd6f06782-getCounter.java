{
    Cursor cursor = getAccount(email);
    try {
        if (!cursorIsEmpty(cursor)) {
            cursor.moveToFirst();
            return cursor.getInt(cursor.getColumnIndex(COUNTER_COLUMN));
        }
    } finally {
        tryCloseCursor(cursor);
    }
    return null;
}