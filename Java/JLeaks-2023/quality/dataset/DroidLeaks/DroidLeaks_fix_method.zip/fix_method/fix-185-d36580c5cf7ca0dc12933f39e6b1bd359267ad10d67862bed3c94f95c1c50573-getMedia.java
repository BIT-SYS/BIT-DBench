{
    Cursor cursor;
    Media media = null;
    Bitmap picture = null;
    byte[] blob;
    cursor = mDb.query(MEDIA_TABLE_NAME, new String[] { // 0 long
    MEDIA_TIME, // 1 long
    MEDIA_LENGTH, // 2 int
    MEDIA_TYPE, // 3 Bitmap
    MEDIA_PICTURE, // 4 string
    MEDIA_TITLE, // 5 string
    MEDIA_ARTIST, // 6 string
    MEDIA_GENRE, // 7 string
    MEDIA_ALBUM }, MEDIA_PATH + "=?", new String[] { path }, null, null, null);
    if (cursor.moveToFirst()) {
        blob = cursor.getBlob(3);
        if (blob != null) {
            picture = BitmapFactory.decodeByteArray(blob, 0, blob.length);
        }
        media = new Media(mContext, new File(path), cursor.getLong(0), cursor.getLong(1), cursor.getInt(2), picture, cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7));
    }
    cursor.close();
    return media;
}