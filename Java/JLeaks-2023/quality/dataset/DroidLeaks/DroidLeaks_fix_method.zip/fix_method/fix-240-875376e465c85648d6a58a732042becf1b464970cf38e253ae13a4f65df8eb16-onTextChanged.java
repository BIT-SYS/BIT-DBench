{
    Cursor cursor = showResults(mTextView.getText().toString());
    // Specify the columns we want to display in the result
    String[] from = new String[] { UshahidiDatabase.DEPLOYMENT_ID, UshahidiDatabase.DEPLOYMENT_NAME, UshahidiDatabase.DEPLOYMENT_DESC, UshahidiDatabase.DEPLOYMENT_URL };
    // Specify the corresponding layout elements where we want the
    // columns to go
    int[] to = new int[] { R.id.deploy_id, R.id.deploy_name, R.id.deploy_desc, R.id.deploy_url };
    // Create a simple cursor adapter for the details of the
    // deployment and apply
    // them to the ListView
    if (cursor != null) {
        SimpleCursorAdapter deployments = new SimpleCursorAdapter(DeploymentSearch.this, R.layout.deployment_search_result, cursor, from, to);
        mListView.setAdapter(deployments);
    } else {
        showResults();
    }
    cursor.close();
}