{
    final StoredBlock storedBlock = writeAheadCache.get(hash);
    if (storedBlock != null)
        return storedBlock;
    // ugly workaround for binding a blob value
    final CursorFactory cursorFactory = new CursorFactory() {

        public Cursor newCursor(final SQLiteDatabase db, final SQLiteCursorDriver masterQuery, final String editTable, final SQLiteQuery query) {
            query.bindBlob(1, hash.getBytes());
            return new SQLiteCursor(db, masterQuery, editTable, query);
        }
    };
    final SQLiteDatabase db = helper.getReadableDatabase();
    final Cursor query = db.queryWithFactory(cursorFactory, false, TABLE_BLOCKS, new String[] { COLUMN_BLOCKS_CHAINWORK, COLUMN_BLOCKS_HEIGHT, COLUMN_BLOCKS_HEADER }, COLUMN_BLOCKS_HASH + "=?", null, null, null, null, null);
    try {
        if (query.moveToFirst()) {
            try {
                final BigInteger chainWork = new BigInteger(query.getBlob(query.getColumnIndexOrThrow(COLUMN_BLOCKS_CHAINWORK)));
                final int height = query.getInt(query.getColumnIndexOrThrow(COLUMN_BLOCKS_HEIGHT));
                final Block block = new Block(networkParameters, query.getBlob(query.getColumnIndexOrThrow(COLUMN_BLOCKS_HEADER)));
                block.verifyHeader();
                return new StoredBlock(block, chainWork, height);
            } catch (final ProtocolException x) {
                // corrupted database
                throw new BlockStoreException(x);
            } catch (final VerificationException x) {
                // should not be able to happen unless the database contains bad blocks
                throw new BlockStoreException(x);
            }
        } else {
            return null;
        }
    } finally {
        query.close();
    }
}