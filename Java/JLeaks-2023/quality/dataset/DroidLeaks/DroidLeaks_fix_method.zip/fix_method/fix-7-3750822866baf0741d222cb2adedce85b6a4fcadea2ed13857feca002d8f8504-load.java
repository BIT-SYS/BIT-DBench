{
    Cursor c = new Select().all().from(Buffer.class).query();
    try {
        long start = System.currentTimeMillis();
        ModelAdapter<Buffer> modelAdapter = FlowManager.getModelAdapter(Buffer.class);
        if (c != null && c.moveToFirst()) {
            buffers = new ArrayList<>(c.getCount());
            buffers_indexed = new SparseArray<>(c.getCount());
            do {
                Buffer b = modelAdapter.loadFromCursor(c);
                buffers.add(b);
                buffers_indexed.put(b.getBid(), b);
            } while (c.moveToNext());
            long time = System.currentTimeMillis() - start;
            android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " buffers in " + time + "ms");
        }
    } catch (SQLiteException e) {
        buffers.clear();
        buffers_indexed.clear();
    } finally {
        if (c != null)
            c.close();
    }
}