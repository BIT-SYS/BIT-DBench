{
    synchronized (createLock) {
        if (mTask != this) {
            Log.w(THIS_FILE, "  unexpected task: " + mNetworkType + (mConnected ? " CONNECTED" : "DISCONNECTED"));
            sipWakeLock.release(this);
            return;
        }
        mTask = null;
        Log.d(THIS_FILE, " deliver change for " + mNetworkType + (mConnected ? " CONNECTED" : "DISCONNECTED"));
        // onConnectivityChanged(mNetworkType, mConnected);
        dataConnectionChanged(mNetworkType, true);
        sipWakeLock.release(this);
    }
}