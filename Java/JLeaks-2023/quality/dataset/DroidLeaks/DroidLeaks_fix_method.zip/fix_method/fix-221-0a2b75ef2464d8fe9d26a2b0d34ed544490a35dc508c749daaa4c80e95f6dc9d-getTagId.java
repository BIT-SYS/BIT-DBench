{
    Cursor cursor = db.query(TagsTable.TABLE_NAME, new String[] { TagsTable.ID }, TagsTable.NAME + "='" + tagName + "'", null, null, null, TagsTable.ID);
    Integer result = null;
    if (cursor.moveToFirst())
        result = cursor.getInt(0);
    cursor.close();
    return result;
}