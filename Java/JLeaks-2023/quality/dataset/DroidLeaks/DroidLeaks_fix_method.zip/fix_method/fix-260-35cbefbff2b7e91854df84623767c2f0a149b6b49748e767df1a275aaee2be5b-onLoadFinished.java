{
    mCallback.onCursorLoaded(getUri(), data);
    if (mAdapter != null)
        mAdapter.changeCursor(data);
    configureEmptyLabel();
    if (isTablet()) {
        reloadLinearLayout();
    }
}