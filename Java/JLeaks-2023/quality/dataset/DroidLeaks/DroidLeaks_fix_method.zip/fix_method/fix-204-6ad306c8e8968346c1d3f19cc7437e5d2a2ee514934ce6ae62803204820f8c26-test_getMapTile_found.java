{
    final MapTile tile = new MapTile(2, 3, 4);
    // create a bitmap, draw something on it, write it to a file and put it in the cache
    final String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "osmdroid" + File.separator + "OpenStreetMapTileProviderTest.png";
    File f = new File(path);
    if (f.exists())
        f.delete();
    final Bitmap bitmap1 = Bitmap.createBitmap(60, 30, Config.ARGB_8888);
    bitmap1.eraseColor(Color.YELLOW);
    final Canvas canvas = new Canvas(bitmap1);
    canvas.drawText("test", 10, 20, new Paint());
    final FileOutputStream fos = new FileOutputStream(path);
    bitmap1.compress(CompressFormat.JPEG, 100, fos);
    fos.close();
    final MapTileRequestState state = new MapTileRequestState(tile, new MapTileModuleProviderBase[] {}, mProvider);
    mProvider.mapTileRequestCompleted(state, TileSourceFactory.MAPNIK.getDrawable(path));
    // do the test
    final Drawable drawable = mProvider.getMapTile(tile);
    if (f.exists())
        f.delete();
    assertNotNull("Expect tile to be not null from path " + path, drawable);
    assertTrue("Expect instance of BitmapDrawable", drawable instanceof BitmapDrawable);
    final Bitmap bitmap2 = ((BitmapDrawable) drawable).getBitmap();
    assertNotNull("Expect tile to be not null", bitmap2);
    // compare a few things to see if it's the same bitmap
    assertEquals("Compare config", bitmap1.getConfig(), bitmap2.getConfig());
    assertEquals("Compare width", bitmap1.getWidth(), bitmap2.getWidth());
    assertEquals("Compare height", bitmap1.getHeight(), bitmap2.getHeight());
    // compare the total thing
    final ByteBuffer bb1 = ByteBuffer.allocate(bitmap1.getWidth() * bitmap1.getHeight() * 4);
    bitmap1.copyPixelsToBuffer(bb1);
    final ByteBuffer bb2 = ByteBuffer.allocate(bitmap2.getWidth() * bitmap2.getHeight() * 4);
    bitmap2.copyPixelsToBuffer(bb2);
    assertEquals("Compare pixels", bb1, bb2);
}