{
    super.onDestroy();
    Log.i(AnkiDroidApp.TAG, "StudyOptions - onDestroy()");
    closeOpenedDeck();
    if (mUnmountReceiver != null) {
        unregisterReceiver(mUnmountReceiver);
    }
}