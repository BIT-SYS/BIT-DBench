{
    Cursor cursor = getAccount(email);
    try {
        if (!cursorIsEmpty(cursor)) {
            cursor.moveToFirst();
            return cursor.getString(cursor.getColumnIndex(SECRET_COLUMN));
        }
    } finally {
        tryCloseCursor(cursor);
    }
    return null;
}