{
    if (mAdapter != null)
        mAdapter.changeCursor(null);
    configureEmptyLabel();
    if (isTablet()) {
        reloadLinearLayout();
    }
}