{
    changeCursor(mQuery.execute());
}