{
    final Cursor cursor = myDatabase.rawQuery("SELECT Tags.tag_id FROM BookTag INNER JOIN Tags ON Tags.tag_id = BookTag.tag_id WHERE BookTag.book_id = ?", new String[] { "" + bookId });
    if (!cursor.moveToNext()) {
        cursor.close();
        return null;
    }
    ArrayList<Tag> list = new ArrayList<Tag>();
    do {
        list.add(getTagById(cursor.getLong(0)));
    } while (cursor.moveToNext());
    cursor.close();
    return list;
}