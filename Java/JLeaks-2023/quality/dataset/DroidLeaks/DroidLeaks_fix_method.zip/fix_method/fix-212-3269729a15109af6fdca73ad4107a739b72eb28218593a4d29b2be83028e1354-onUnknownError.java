public void onUnknownError(AyahItem ayah) {
		lastAyah = ayah;
		quranAudioPlayer.stop();
		onActionStop();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("An error occured");
		builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}