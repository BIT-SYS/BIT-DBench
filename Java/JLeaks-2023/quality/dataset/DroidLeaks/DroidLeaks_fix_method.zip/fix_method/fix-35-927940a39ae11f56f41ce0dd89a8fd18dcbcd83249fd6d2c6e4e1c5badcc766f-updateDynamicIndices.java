{
    Log.i(AnkiDroidApp.TAG, "updateDynamicIndices - Updating indices...");
    HashMap<String, String> indices = new HashMap<String, String>();
    indices.put("intervalDesc", "(type, priority desc, interval desc, factId, combinedDue)");
    indices.put("intervalAsc", "(type, priority desc, interval, factId, combinedDue)");
    indices.put("randomOrder", "(type, priority desc, factId, ordinal, combinedDue)");
    indices.put("dueAsc", "(type, priority desc, due, factId, combinedDue)");
    indices.put("dueDesc", "(type, priority desc, due desc, factId, combinedDue)");
    ArrayList<String> required = new ArrayList<String>();
    if (mRevCardOrder == REV_CARDS_OLD_FIRST) {
        required.add("intervalDesc");
    }
    if (mRevCardOrder == REV_CARDS_NEW_FIRST) {
        required.add("intervalAsc");
    }
    if (mRevCardOrder == REV_CARDS_RANDOM) {
        required.add("randomOrder");
    }
    if (mRevCardOrder == REV_CARDS_DUE_FIRST || mNewCardOrder == NEW_CARDS_OLD_FIRST || mNewCardOrder == NEW_CARDS_RANDOM) {
        required.add("dueAsc");
    }
    if (mNewCardOrder == NEW_CARDS_NEW_FIRST) {
        required.add("dueDesc");
    }
    // Add/delete
    boolean analyze = false;
    Set<Entry<String, String>> entries = indices.entrySet();
    Iterator<Entry<String, String>> iter = entries.iterator();
    String indexName = null;
    while (iter.hasNext()) {
        Entry<String, String> entry = iter.next();
        indexName = "ix_cards_" + entry.getKey() + "2";
        if (required.contains(entry.getKey())) {
            Cursor cursor = null;
            try {
                cursor = getDB().getDatabase().rawQuery("SELECT 1 FROM sqlite_master WHERE name = '" + indexName + "'", null);
                if ((!cursor.moveToNext()) || (cursor.getInt(0) != 1)) {
                    getDB().getDatabase().execSQL("CREATE INDEX " + indexName + " ON cards " + entry.getValue());
                    analyze = true;
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        } else {
            // Leave old indices for older clients
            getDB().getDatabase().execSQL("DROP INDEX IF EXISTS " + indexName);
        }
    }
    if (analyze) {
        getDB().getDatabase().execSQL("ANALYZE");
    }
}