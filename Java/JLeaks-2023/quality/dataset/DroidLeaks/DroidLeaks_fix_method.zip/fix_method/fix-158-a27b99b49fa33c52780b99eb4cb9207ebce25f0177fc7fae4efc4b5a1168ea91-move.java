{
    if (to.exists()) {
        to.delete();
    }
    to.getParentFile().mkdirs();
    try {
        FileInputStream in = new FileInputStream(from);
        try {
            FileOutputStream out = new FileOutputStream(to);
            try {
                byte[] buffer = new byte[1024];
                int count = -1;
                while ((count = in.read(buffer)) > 0) {
                    out.write(buffer, 0, count);
                }
            } finally {
                out.close();
            }
        } finally {
            try {
                in.close();
            } catch (Throwable ignore) {
            }
        }
        from.delete();
        return true;
    } catch (Exception e) {
        Log.w(K9.LOG_TAG, "cannot move " + from.getAbsolutePath() + " to " + to.getAbsolutePath(), e);
        return false;
    }
}