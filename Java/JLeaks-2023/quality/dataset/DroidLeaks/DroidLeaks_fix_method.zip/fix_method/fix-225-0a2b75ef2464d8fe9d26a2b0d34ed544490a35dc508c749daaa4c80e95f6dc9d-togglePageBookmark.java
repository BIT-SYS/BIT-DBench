{
    Cursor cursor = findPage(page);
    boolean result = true;
    if (!cursor.moveToFirst()) {
        ContentValues values = new ContentValues();
        values.put(PageTable.ID, page);
        values.put(PageTable.BOOKMARKED, 1);
        db.insert(PageTable.TABLE_NAME, null, values);
    } else {
        boolean isBookmarked = (cursor.getInt(0) != 0);
        ContentValues values = new ContentValues();
        values.put(PageTable.BOOKMARKED, !isBookmarked);
        db.update(PageTable.TABLE_NAME, values, PageTable.ID + "=" + page, null);
        result = !isBookmarked;
    }
    cursor.close();
    return result;
}