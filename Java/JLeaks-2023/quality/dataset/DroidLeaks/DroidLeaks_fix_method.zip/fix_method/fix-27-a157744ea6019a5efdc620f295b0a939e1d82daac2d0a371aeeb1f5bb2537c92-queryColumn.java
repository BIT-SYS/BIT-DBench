{
    ArrayList<T> results = new ArrayList<T>();
    Cursor cursor = null;
    try {
        cursor = AnkiDb.database.rawQuery(query, null);
        cursor.moveToFirst();
        String methodName = getCursorMethodName(type.getSimpleName());
        do {
            // The magical line. Almost as illegible as python code ;)
            results.add(type.cast(Cursor.class.getMethod(methodName, int.class).invoke(cursor, column)));
        } while (cursor.moveToNext());
    } catch (Exception e) {
        Log.e(TAG, "queryColumn: Got Exception: " + e.getMessage());
        return null;
    } finally {
        if (cursor != null)
            cursor.close();
    }
    return results;
}