{
    // However, if we're being restored from a previous state,
    // then we don't need to do anything and should return or else
    // we could end up with overlapping fragments.
    if (savedInstanceState != null) {
        return;
    }
    // show accounts only if available (deprecated API)
    Cursor cursor = getContentResolver().query(accountsUri, null, null, null, null);
    if (cursor != null && cursor.moveToFirst())
        try {
            mAccountsLabel.setVisibility(View.VISIBLE);
            mAccountsListFragment = AccountsListFragment.newInstance(accountsUri);
            // Create an instance of the fragments
            getSupportFragmentManager().beginTransaction().replace(R.id.api_accounts_list_fragment, mAccountsListFragment).commitAllowingStateLoss();
        } finally {
            cursor.close();
        }
    // Create an instance of the fragments
    mAllowedKeysFragment = AppSettingsAllowedKeysListFragment.newInstance(allowedKeysUri);
    // Add the fragment to the 'fragment_container' FrameLayout
    // NOTE: We use commitAllowingStateLoss() to prevent weird crashes!
    getSupportFragmentManager().beginTransaction().replace(R.id.api_allowed_keys_list_fragment, mAllowedKeysFragment).commitAllowingStateLoss();
    // do it immediately!
    getSupportFragmentManager().executePendingTransactions();
}