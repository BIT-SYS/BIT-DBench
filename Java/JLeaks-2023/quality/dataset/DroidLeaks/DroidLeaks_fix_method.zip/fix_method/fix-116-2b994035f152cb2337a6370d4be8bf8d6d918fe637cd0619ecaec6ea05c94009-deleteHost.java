{
    if (host.getId() < 0)
        return;
    SQLiteDatabase db = this.getWritableDatabase();
    db.delete(TABLE_HOSTS, "_id = ?", new String[] { String.valueOf(host.getId()) });
    db.close();
}