{
    ObjectInputStream obj = null;
    try {
        obj = new ObjectInputStream(new FileInputStream(getLastHNPostCommentsPath(postID)));
        Object rawHNComments = obj.readObject();
        if (rawHNComments instanceof HNPostComments)
            return (HNPostComments) rawHNComments;
    } catch (Exception e) {
        Log.e(TAG, "Could not get last HNPostComments from file :(", e);
    } finally {
        if (obj != null) {
            try {
                obj.close();
            } catch (IOException e) {
                Log.e(TAG, "Couldn't close last NH comments file :(", e);
            }
        }
    }
    return null;
}