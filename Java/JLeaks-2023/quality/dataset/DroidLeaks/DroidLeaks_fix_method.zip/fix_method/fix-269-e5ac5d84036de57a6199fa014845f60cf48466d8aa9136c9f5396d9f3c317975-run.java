{
    Cursor cursor = getQueue();
    if ((cursor == null || cursor.getCount() == 0 || mContext == null) && !mUploadInProgress) {
        if (cursor != null)
            cursor.close();
        MediaUploadService.this.stopSelf();
        return;
    } else {
        if (!mUploadInProgress) {
            uploadMediaFile(cursor);
        } else {
            if (cursor != null)
                cursor.close();
            mHandler.postDelayed(this, UPLOAD_WAIT_TIME);
        }
    }
}