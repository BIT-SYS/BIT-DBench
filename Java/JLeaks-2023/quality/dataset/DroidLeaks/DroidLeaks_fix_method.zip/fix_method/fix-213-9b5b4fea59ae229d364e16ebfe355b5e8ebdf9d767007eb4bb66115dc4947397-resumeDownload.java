{
    BufferedInputStream in = null;
    FileOutputStream fos = null;
    BufferedOutputStream bout = null;
    try {
        for (; downloadIndex < fileNames.length; downloadIndex++) {
            int downloaded = 0;
            File f = new File(saveToDirectories[downloadIndex]);
            f.mkdirs();
            File file = new File(saveToDirectories[downloadIndex], fileNames[downloadIndex] + DOWNLOAD_EXT);
            URL url = new URL(downloadUrls[downloadIndex]);
            URLConnection conn = url.openConnection();
            int total = conn.getContentLength();
            Log.d("quran_srv", "File to download: " + file.getName() + " - total length: " + total);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            if (file.exists()) {
                downloaded = (int) file.length();
                connection.setRequestProperty("Range", "bytes=" + (file.length()) + "-");
                Log.d("quran_srv", "Resuming from " + downloaded);
                if (downloaded == total)
                    continue;
            }
            connection.setRequestProperty("Range", "bytes=" + downloaded + "-");
            connection.setDoInput(true);
            in = new BufferedInputStream(connection.getInputStream(), DOWNLOAD_BUFFER_SIZE);
            fos = (downloaded == 0) ? new FileOutputStream(file.getAbsolutePath()) : new FileOutputStream(file.getAbsolutePath(), true);
            bout = new BufferedOutputStream(fos, DOWNLOAD_BUFFER_SIZE);
            byte[] data = new byte[DOWNLOAD_BUFFER_SIZE];
            int x = 0;
            while (isRunning && (x = in.read(data, 0, DOWNLOAD_BUFFER_SIZE)) >= 0) {
                bout.write(data, 0, x);
                downloaded += x;
                double percent = 100.0 * ((1.0 * downloaded) / (1.0 * total));
                updateProgress((int) percent, fileNames.length, downloadIndex);
            }
            bout.flush();
            bout.close();
            fos.close();
            if (isRunning) {
                file.renameTo(new File(saveToDirectories[downloadIndex], fileNames[downloadIndex]));
                if (zipped || fileNames[downloadIndex].endsWith(".zip"))
                    unzipFile(saveToDirectories[downloadIndex], fileNames[downloadIndex]);
                Log.d("quran_srv", "Download Completed [" + downloadUrls[downloadIndex] + "]");
            } else
                return false;
        }
    } catch (FileNotFoundException e) {
        Log.e("quran_srv", "File not found: IO Exception", e);
    } catch (IOException e) {
        Log.e("quran_srv", "Download paused: IO Exception", e);
        return false;
    } catch (Exception e) {
        Log.e("quran_srv", "Download paused: Exception", e);
        return false;
    }
    return true;
}