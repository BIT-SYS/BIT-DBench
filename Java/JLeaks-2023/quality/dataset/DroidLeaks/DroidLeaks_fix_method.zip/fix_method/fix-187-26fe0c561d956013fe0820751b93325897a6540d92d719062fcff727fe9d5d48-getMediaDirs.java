{
    List<File> paths = new ArrayList<File>();
    Cursor cursor;
    cursor = db.query(DIR_TABLE_NAME, new String[] { DIR_ROW_PATH }, null, null, null, null, null);
    cursor.moveToFirst();
    if (!cursor.isAfterLast()) {
        do {
            File dir = new File(cursor.getString(0));
            paths.add(dir);
        } while (cursor.moveToNext());
    }
    cursor.close();
    return paths;
}