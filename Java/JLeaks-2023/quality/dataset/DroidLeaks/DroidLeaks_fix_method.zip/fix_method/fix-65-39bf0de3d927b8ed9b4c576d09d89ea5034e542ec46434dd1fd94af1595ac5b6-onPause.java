{
    super.onPause();
    Cursor c = this.getContentResolver().query(ContentUris.withAppendedId(DataProvider.Hours.GROUP_URI, this.gid), DataProvider.Hours.PROJECTION, null, null, null);
    if (c.getCount() == 0) {
        Toast.makeText(this, R.string.empty_group, Toast.LENGTH_LONG).show();
    }
    c.close();
}