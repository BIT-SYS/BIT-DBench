{
    Log.v(TAG, "Releasing media recorder.");
    if (mMediaRecorder != null) {
        mMediaRecorder.reset();
        if (mCamera != null) {
            if (Integer.parseInt(Build.VERSION.SDK) >= 8)
                VideoCameraNew2.reconnect(mCamera);
            mCamera.release();
            mCamera = null;
        }
        mMediaRecorder.release();
        mMediaRecorder = null;
    }
}