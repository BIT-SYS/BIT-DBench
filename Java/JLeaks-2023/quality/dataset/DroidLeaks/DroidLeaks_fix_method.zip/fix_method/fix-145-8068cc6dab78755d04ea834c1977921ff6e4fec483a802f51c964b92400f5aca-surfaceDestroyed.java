{
    if (player != null) {
        player.stop();
        player.release();
        player = null;
    }
}