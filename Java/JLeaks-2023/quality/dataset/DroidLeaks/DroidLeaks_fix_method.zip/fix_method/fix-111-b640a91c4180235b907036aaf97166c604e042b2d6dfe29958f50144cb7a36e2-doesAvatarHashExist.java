    
    public static boolean doesAvatarHashExist(ContentResolver resolver, Uri queryUri, 
            String jid, String hash) {

        StringBuilder buf = new StringBuilder(Imps.Avatars.CONTACT);
        buf.append("=?");
        buf.append(" AND ");
        buf.append(Imps.Avatars.HASH);
        buf.append("=?");

        String[] selectionArgs = new String[] { jid, hash };

        //return resolver.update(updateUri, values, buf.toString(), selectionArgs) > 0;
        
        Cursor cursor = resolver.query(queryUri, null, buf.toString(), selectionArgs, null);
        if (cursor == null)
            return false;
        try {
            return cursor.getCount() > 0;
        } finally {
            cursor.close();
        }
    }
    