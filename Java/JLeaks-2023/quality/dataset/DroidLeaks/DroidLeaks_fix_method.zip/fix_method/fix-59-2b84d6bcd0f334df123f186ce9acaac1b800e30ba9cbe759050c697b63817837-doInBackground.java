{
    Log.d("doinback", "round");
    errors = new ArrayList<String>();
    Boolean refreshWidgets = false;
    ArrayList<Bank> banks = BankFactory.banksFromDb(AutoRefreshService.this, false);
    if (banks.isEmpty()) {
        return null;
    }
    DBAdapter db = new DBAdapter(AutoRefreshService.this);
    db.open();
    Double currentBalance;
    Double diff;
    for (Bank bank : banks) {
        if (bank.isDisabled()) {
            Log.d("AA", bank.getName() + " (" + bank.getUsername() + ") is disabled. Skipping refresh.");
            continue;
        }
        Log.d("AA", "Refreshing " + bank.getName() + " (" + bank.getUsername() + ").");
        try {
            currentBalance = bank.getBalance().doubleValue();
            bank.update();
            diff = bank.getBalance().doubleValue() - currentBalance;
            if (diff != 0) {
                showNotification(bank.getName() + ": " + ((diff > 0) ? "+" : "") + Helpers.formatBalance(diff) + " (" + Helpers.formatBalance(bank.getBalance()) + ")");
                refreshWidgets = true;
                bank.updateAllTransactions();
            }
            bank.closeConnection();
            db.updateBank(bank);
        } catch (BankException e) {
            // Refresh widgets if an update fails
            Log.d(TAG, "Error while updating bank '" + bank.getDbId() + "'; " + e.getMessage());
        } catch (LoginException e) {
            refreshWidgets = true;
            db.disableBank(bank.getDbId());
        }
    }
    if (refreshWidgets) {
        sendWidgetRefresh(AutoRefreshService.this);
    }
    db.close();
    return null;
}