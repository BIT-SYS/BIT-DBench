{
    Scanner scanner = null;
    try {
        final InputStream ins = getResourceStream(resourceId);
        scanner = new Scanner(ins);
        return scanner.useDelimiter("\\A").next();
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (scanner != null) {
            scanner.close();
        }
    }
    return null;
}