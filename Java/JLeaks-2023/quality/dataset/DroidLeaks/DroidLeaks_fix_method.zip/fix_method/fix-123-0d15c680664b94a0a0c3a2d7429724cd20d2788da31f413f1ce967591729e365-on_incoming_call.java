{
    lockCpu();
    // Check if we have not already an ongoing call
    if (pjService != null && pjService.service != null && !pjService.service.supportMultipleCalls) {
        SipCallSession[] calls = getCalls();
        if (calls != null && calls.length > 0) {
            for (SipCallSession existingCall : calls) {
                if (!existingCall.isAfterEnded()) {
                    Log.e(THIS_FILE, "Settings to not support two call at the same time !!!");
                    // If there is an ongoing call and we do not support multiple calls
                    // Send busy here
                    pjsua.call_hangup(callId, 486, null, null);
                    unlockCpu();
                    return;
                }
            }
        }
    }
    pjService.service.getExecutor().execute(pjService.service.new SipRunnable() {

        @Override
        public void doRun() throws SameThreadException {
            SipCallSession callInfo = updateCallInfoFromStack(callId);
            Log.d(THIS_FILE, "Incoming call <<");
            IncomingCallInfos iCInfo = new IncomingCallInfos();
            iCInfo.accId = acc_id;
            iCInfo.callInfo = callInfo;
            msgHandler.sendMessage(msgHandler.obtainMessage(ON_INCOMING_CALL, iCInfo));
            Log.d(THIS_FILE, "Incoming call >>");
        }
    });
    unlockCpu();
}