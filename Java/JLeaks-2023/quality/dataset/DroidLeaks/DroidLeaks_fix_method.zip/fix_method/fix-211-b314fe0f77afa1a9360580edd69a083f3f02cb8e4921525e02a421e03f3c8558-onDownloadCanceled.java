	

	@Override
	protected void onDownloadCanceled() {
		super.onDownloadCanceled();
		if (quranAudioPlayer != null) {
			quranAudioPlayer.stop();
		}
		onActionStop();
	}
