{
    try {
        ContentResolver resolver = mContext.getContentResolver();
        InputStream is = resolver.openInputStream(mUri);
        try {
            mImportContents = StorageImporter.getImportStreamContents(mContext, is, mEncryptionKey);
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                /* Ignore */
            }
        }
    } catch (StorageImportExportException e) {
        Log.w(K9.LOG_TAG, "Exception during export", e);
        return false;
    } catch (FileNotFoundException e) {
        Log.w(K9.LOG_TAG, "Couldn't read content from URI " + mUri);
        return false;
    }
    return true;
}