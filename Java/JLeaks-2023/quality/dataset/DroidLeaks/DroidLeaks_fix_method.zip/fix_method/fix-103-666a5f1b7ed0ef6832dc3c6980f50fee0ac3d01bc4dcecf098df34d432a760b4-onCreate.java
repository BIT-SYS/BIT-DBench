{
    super.onCreate();
    this.mPendingIntent = PendingIntent.getService(this, 0, new Intent(HEARTBEAT_ACTION, null, this, HeartbeatService.class), 0);
    this.mRelayIntent = new Intent(HEARTBEAT_ACTION, null, this, RemoteImService.class);
    Imps.ProviderSettings.QueryMap settings = getGlobalSettings();
    long heartBeatInterval = HEARTBEAT_INTERVAL;
    if (settings != null)
        heartBeatInterval = settings.getHeartbeatInterval();
    startHeartbeat(heartBeatInterval);
    mServiceHandler = new ServiceHandler();
    mNetworkConnectivityListener = new NetworkConnectivityListener();
    NetworkConnectivityListener.registerHandler(mServiceHandler, EVENT_NETWORK_STATE_CHANGED);
    mNetworkConnectivityListener.startListening(this);
    settings.close();
}