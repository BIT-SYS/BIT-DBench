{
    Cursor cursor = getMediaFilesForBlog(blogId);
    int count = cursor.getCount();
    cursor.close();
    return count;
}