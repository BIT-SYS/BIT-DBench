{
    Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(getContentResolver(), mProviderId, false, /* don't keep updated */
    null);
    try {
        settingsForDomain(mDomain, mPort);
        XmppConnection xmppConn = new XmppConnection(AccountActivity.this);
        xmppConn.registerAccount(settings, params[0], params[1]);
        // settings closed in registerAccount
    } catch (Exception e) {
        LogCleaner.error(ImApp.LOG_TAG, "error registering new account", e);
        return e.getLocalizedMessage();
    } finally {
        settings.close();
    }
    return null;
}