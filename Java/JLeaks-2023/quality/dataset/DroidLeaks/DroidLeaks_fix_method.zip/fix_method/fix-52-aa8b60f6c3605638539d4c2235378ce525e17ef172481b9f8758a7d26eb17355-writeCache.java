{
    File cacheDir = mContext.getCacheDir();
    if (cacheDir == null) {
        // https://groups.google.com/forum/#!topic/android-developers/-694j87eXVU
        throw new IOException("cache dir is null!");
    }
    File tempFile = new File(mContext.getCacheDir(), mFilename);
    DataOutputStream oos = new DataOutputStream(new FileOutputStream(tempFile));
    try {
        oos.writeInt(numEntries);
        while (it.hasNext()) {
            // creating empty parcel object
            Parcel p = Parcel.obtain();
            // saving bundle as parcel
            p.writeParcelable(it.next(), 0);
            byte[] buf = p.marshall();
            oos.writeInt(buf.length);
            oos.write(buf);
            p.recycle();
        }
    } finally {
        oos.close();
    }
}