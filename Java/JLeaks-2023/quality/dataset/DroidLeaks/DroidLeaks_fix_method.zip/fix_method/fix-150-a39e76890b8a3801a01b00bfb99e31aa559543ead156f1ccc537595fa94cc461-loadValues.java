{
    long startTime = System.currentTimeMillis();
    Log.i(Email.LOG_TAG, "Loading preferences from DB into Storage");
    Cursor cursor = null;
    SQLiteDatabase mDb = null;
    try {
        mDb = openDB();
        cursor = mDb.rawQuery("SELECT primkey, value FROM preferences_storage", null);
        while (cursor.moveToNext()) {
            String key = cursor.getString(0);
            String value = cursor.getString(1);
            if (Email.DEBUG) {
                Log.d(Email.LOG_TAG, "Loading key '" + key + "', value = '" + value + "'");
            }
            storage.put(key, value);
        }
    } finally {
        if (cursor != null) {
            cursor.close();
        }
        if (mDb != null) {
            mDb.close();
        }
        long endTime = System.currentTimeMillis();
        Log.i(Email.LOG_TAG, "Preferences load took " + (endTime - startTime) + "ms");
    }
}