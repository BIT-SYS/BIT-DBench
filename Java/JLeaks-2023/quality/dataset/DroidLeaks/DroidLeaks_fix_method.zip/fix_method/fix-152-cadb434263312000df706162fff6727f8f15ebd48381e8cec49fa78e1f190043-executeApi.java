{
    ParcelFileDescriptor input = null;
    try {
        data.putExtra(EXTRA_API_VERSION, OpenPgpApi.API_VERSION);
        Intent result = null;
        if (ACTION_GET_KEY_IDS.equals(data.getAction())) {
            result = mService.execute(data, null, null);
            return result;
        } else {
            // pipe the input and output
            input = ParcelFileDescriptorUtil.pipeFrom(is, new ParcelFileDescriptorUtil.IThreadListener() {

                @Override
                public void onThreadFinished(Thread thread) {
                    // Log.d(OpenPgpApi.TAG, "Copy to service finished");
                }
            });
            ParcelFileDescriptor output = ParcelFileDescriptorUtil.pipeTo(os, new ParcelFileDescriptorUtil.IThreadListener() {

                @Override
                public void onThreadFinished(Thread thread) {
                    // Log.d(OpenPgpApi.TAG, "Service finished writing!");
                }
            });
            // blocks until result is ready
            result = mService.execute(data, input, output);
            // close() is required to halt the TransferThread
            output.close();
            // set class loader to current context to allow unparcelling
            // of OpenPgpError and OpenPgpSignatureResult
            // http://stackoverflow.com/a/3806769
            result.setExtrasClassLoader(mContext.getClassLoader());
            return result;
        }
    } catch (Exception e) {
        Log.e(OpenPgpApi.TAG, "Exception", e);
        Intent result = new Intent();
        result.putExtra(RESULT_CODE, RESULT_CODE_ERROR);
        result.putExtra(RESULT_ERROR, new OpenPgpError(OpenPgpError.CLIENT_SIDE_ERROR, e.getMessage()));
        return result;
    } finally {
        if (input != null) {
            try {
                input.close();
            } catch (IOException e) {
                Log.e(OpenPgpApi.TAG, "Failed to close input file descriptor", e);
            }
        }
    }
}