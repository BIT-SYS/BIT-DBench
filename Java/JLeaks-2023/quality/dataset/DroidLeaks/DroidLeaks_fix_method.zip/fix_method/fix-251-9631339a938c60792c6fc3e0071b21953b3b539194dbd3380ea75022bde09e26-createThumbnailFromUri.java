{
    if (context == null || imageUri == null || maxWidth <= 0)
        return null;
    String filePath = null;
    if (imageUri.toString().contains("content:")) {
        String[] projection = new String[] { MediaStore.Images.Media.DATA };
        Cursor cur = null;
        try {
            cur = context.getContentResolver().query(imageUri, projection, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                int dataColumn = cur.getColumnIndex(MediaStore.Images.Media.DATA);
                filePath = cur.getString(dataColumn);
            }
        } catch (IllegalStateException stateException) {
            Log.d(ImageUtils.class.getName(), "IllegalStateException querying content:" + imageUri);
        } finally {
            SqlUtils.closeCursor(cur);
        }
    }
    if (TextUtils.isEmpty(filePath)) {
        // access the file directly
        filePath = imageUri.toString().replace("content://media", "");
        filePath = filePath.replace("file://", "");
    }
    // get just the image bounds
    BitmapFactory.Options optBounds = new BitmapFactory.Options();
    optBounds.inJustDecodeBounds = true;
    try {
        BitmapFactory.decodeFile(filePath, optBounds);
    } catch (OutOfMemoryError e) {
        AppLog.e(AppLog.T.UTILS, "OutOfMemoryError Error in setting image: " + e);
        return null;
    }
    // determine correct scale value (should be power of 2)
    // http://stackoverflow.com/questions/477572/android-strange-out-of-memory-issue/3549021#3549021
    int scale = 1;
    if (maxWidth > 0 && optBounds.outWidth > maxWidth) {
        double d = Math.pow(2, (int) Math.round(Math.log(maxWidth / (double) optBounds.outWidth) / Math.log(0.5)));
        scale = (int) d;
    }
    BitmapFactory.Options optActual = new BitmapFactory.Options();
    optActual.inSampleSize = scale;
    // Get the roughly resized bitmap
    final Bitmap bmpResized;
    try {
        bmpResized = BitmapFactory.decodeFile(filePath, optActual);
    } catch (OutOfMemoryError e) {
        AppLog.e(AppLog.T.UTILS, "OutOfMemoryError Error in setting image: " + e);
        return null;
    }
    if (bmpResized == null) {
        return null;
    }
    ByteArrayOutputStream stream = new ByteArrayOutputStream();
    // Now calculate exact scale in order to resize accurately
    float percentage = (float) maxWidth / bmpResized.getWidth();
    float proportionateHeight = bmpResized.getHeight() * percentage;
    int finalHeight = (int) Math.rint(proportionateHeight);
    float scaleWidth = ((float) maxWidth) / bmpResized.getWidth();
    float scaleHeight = ((float) finalHeight) / bmpResized.getHeight();
    float scaleBy = Math.min(scaleWidth, scaleHeight);
    // Resize the bitmap to exact size
    Matrix matrix = new Matrix();
    matrix.postScale(scaleBy, scaleBy);
    // apply rotation
    if (rotation != 0) {
        matrix.setRotate(rotation);
    }
    Bitmap.CompressFormat fmt;
    if (fileExtension != null && fileExtension.equalsIgnoreCase("png")) {
        fmt = Bitmap.CompressFormat.PNG;
    } else {
        fmt = Bitmap.CompressFormat.JPEG;
    }
    final Bitmap bmpRotated;
    try {
        bmpRotated = Bitmap.createBitmap(bmpResized, 0, 0, bmpResized.getWidth(), bmpResized.getHeight(), matrix, true);
    } catch (OutOfMemoryError e) {
        AppLog.e(AppLog.T.UTILS, "OutOfMemoryError Error in setting image: " + e);
        return null;
    } catch (NullPointerException e) {
        // See: https://github.com/wordpress-mobile/WordPress-Android/issues/1844
        AppLog.e(AppLog.T.UTILS, "Bitmap.createBitmap has thrown a NPE internally. This should never happen: " + e);
        return null;
    }
    if (bmpRotated == null) {
        // Fix an issue where bmpRotated is null even if the documentation doesn't say Bitmap.createBitmap can return null.
        // See: https://github.com/wordpress-mobile/WordPress-Android/issues/1848
        return null;
    }
    bmpRotated.compress(fmt, 100, stream);
    bmpResized.recycle();
    bmpRotated.recycle();
    return stream.toByteArray();
}