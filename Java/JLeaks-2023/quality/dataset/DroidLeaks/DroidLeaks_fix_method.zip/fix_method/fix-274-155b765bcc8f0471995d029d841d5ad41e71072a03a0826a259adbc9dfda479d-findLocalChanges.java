{
    Cursor c = db.query(POSTS_TABLE, null, "isLocalChange=? AND blogID=?", new String[] { "1", String.valueOf(blogId) }, null, null, null);
    int numRows = c.getCount();
    c.close();
    if (numRows > 0) {
        return true;
    }
    return false;
}