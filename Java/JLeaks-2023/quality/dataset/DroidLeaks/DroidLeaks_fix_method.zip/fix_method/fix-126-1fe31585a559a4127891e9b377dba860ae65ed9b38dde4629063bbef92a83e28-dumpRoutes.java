{
    String routes = "";
    FileReader fr = null;
    try {
        fr = new FileReader(PROC_NET_ROUTE);
        if (fr != null) {
            StringBuffer contentBuf = new StringBuffer();
            BufferedReader buf = new BufferedReader(fr);
            String line;
            while ((line = buf.readLine()) != null) {
                contentBuf.append(line);
            }
            routes = contentBuf.toString();
            buf.close();
        }
    } catch (FileNotFoundException e) {
        Log.e(THIS_FILE, "No route file found routes", e);
    } catch (IOException e) {
        Log.e(THIS_FILE, "Unable to read route file", e);
    } finally {
        try {
            fr.close();
        } catch (IOException e) {
            Log.e(THIS_FILE, "Unable to close route file", e);
        }
    }
    return routes;
}