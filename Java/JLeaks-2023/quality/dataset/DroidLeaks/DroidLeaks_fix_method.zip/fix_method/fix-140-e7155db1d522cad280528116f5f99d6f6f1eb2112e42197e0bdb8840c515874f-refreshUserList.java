{
    // If the users have changed, let the (potentially running) widget know it needs to be
    // updated
    Intent intent = new Intent(AuthenticatorWidget.WidgetReceiver.APPWIDGET_UPDATE);
    intent.setClass(this, AuthenticatorWidget.WidgetReceiver.class);
    sendBroadcast(intent);
    Cursor cursor = AccountDb.getNames();
    try {
        if (!AccountDb.cursorIsEmpty(cursor)) {
            int index = cursor.getColumnIndex(AccountDb.EMAIL_COLUMN);
            if (isAccountModified || mUsers.length != cursor.getCount()) {
                mUsers = new PinInfo[cursor.getCount()];
            }
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToPosition(i);
                String user = cursor.getString(index);
                Log.i(TAG, "onResume user: " + user);
                computeAndDisplayPin(user, i, false);
            }
            if (mAccessibilityAvailable) {
                mUserAdapter = new PinListAdapter(this, R.layout.user_row, mUsers);
            } else {
                mUserAdapter = new PinListAdapter(this, R.layout.user_row_legacy, mUsers);
            }
            // force refresh of display
            mUserList.setAdapter(mUserAdapter);
            if (mUserList.getVisibility() != View.VISIBLE) {
                mEnterPinTextView.setText(R.string.enter_pin);
                mEnterPinTextView.setVisibility(View.VISIBLE);
                mUserList.setVisibility(View.VISIBLE);
                registerForContextMenu(mUserList);
            }
        } else {
            // If the user started up this app but there is no secret key yet,
            // then tell the user to visit a web page to get the secret key.
            // clear any existing user PIN state
            mUsers = new PinInfo[0];
            tellUserToGetSecretKey();
        }
    } finally {
        AccountDb.tryCloseCursor(cursor);
    }
}