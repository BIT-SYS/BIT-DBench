
        void setLinkifyForMessageView(MessageView messageView) {
            try {
                ContentResolver cr = getContext().getContentResolver();
                Cursor pCursor = cr.query(Imps.ProviderSettings.CONTENT_URI,
                        new String[] { Imps.ProviderSettings.NAME, Imps.ProviderSettings.VALUE },
                        Imps.ProviderSettings.PROVIDER + "=?", new String[] { Long
                                .toString(Imps.ProviderSettings.PROVIDER_ID_FOR_GLOBAL_SETTINGS) },
                        null);
                Imps.ProviderSettings.QueryMap settings = new Imps.ProviderSettings.QueryMap(
                        pCursor, cr, Imps.ProviderSettings.PROVIDER_ID_FOR_GLOBAL_SETTINGS,
                        false /* keep updated */, null /* no handler */);
                messageView.setLinkify(!mConn.isUsingTor() || settings.getLinkifyOnTor());
                pCursor.close();
            } catch (RemoteException e) {
                e.printStackTrace();
                messageView.setLinkify(false);
            }
        }
