{
    String ret = null;
    try {
        Cursor c = this.ctx.getContentResolver().query(Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, this.num), new String[] { PhoneLookup.DISPLAY_NAME }, null, null, null);
        if (c.moveToFirst()) {
            ret = c.getString(0);
        }
        c.close();
    } catch (Exception e) {
        Log.e(TAG, "error loading name", e);
    }
    return ret;
}