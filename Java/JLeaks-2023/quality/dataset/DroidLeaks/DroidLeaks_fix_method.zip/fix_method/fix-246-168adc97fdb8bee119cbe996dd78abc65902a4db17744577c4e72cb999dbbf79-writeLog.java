{
    CharSequence timestamp = DateFormat.format("yyyyMMdd_kkmmss", System.currentTimeMillis());
    String filename = name + "_" + timestamp + ".log";
    FileOutputStream stream;
    try {
        stream = new FileOutputStream(filename);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
        return;
    }
    OutputStreamWriter output = new OutputStreamWriter(stream);
    BufferedWriter bw = new BufferedWriter(output);
    try {
        bw.write(log);
        bw.newLine();
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        try {
            bw.close();
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}