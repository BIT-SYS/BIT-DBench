{
    StatsSummary stat = null;
    try {
        FileInputStream fis = WordPress.getContext().openFileInput(STAT_SUMMARY + blogId);
        StringBuilder fileContent = new StringBuilder();
        byte[] buffer = new byte[1024];
        int bytesRead = fis.read(buffer);
        while (bytesRead != -1) {
            fileContent.append(new String(buffer, 0, bytesRead, "ISO-8859-1"));
            bytesRead = fis.read(buffer);
        }
        fis.close();
        Gson gson = new Gson();
        stat = gson.fromJson(fileContent.toString(), StatsSummary.class);
    } catch (FileNotFoundException e) {
        // stats haven't been downloaded yet
    } catch (IOException e) {
        AppLog.e(T.STATS, e);
    }
    return stat;
}