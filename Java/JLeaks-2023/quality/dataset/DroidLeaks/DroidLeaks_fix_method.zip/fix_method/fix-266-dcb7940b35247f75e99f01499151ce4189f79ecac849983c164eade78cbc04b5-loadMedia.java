{
    String id = mediaId;
    Blog blog = WordPress.getCurrentBlog();
    if (blog != null) {
        String blogId = String.valueOf(blog.getBlogId());
        Cursor cursor;
        // if the id is null, get the first media item in the database
        if (id == null) {
            cursor = WordPress.wpDB.getFirstMediaFileForBlog(blogId);
        } else {
            cursor = WordPress.wpDB.getMediaFile(blogId, id);
        }
        refreshViews(cursor);
        cursor.close();
    }
}