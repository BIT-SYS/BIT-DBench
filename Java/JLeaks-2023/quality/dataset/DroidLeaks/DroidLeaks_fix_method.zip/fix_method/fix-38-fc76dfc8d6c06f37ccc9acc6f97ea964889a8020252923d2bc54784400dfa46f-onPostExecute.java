{
    if (result.getBoolean()) {
        loadCounts();
        openStudyOptions(AnkiDroidApp.getCol().getDecks().selected());
    } else {
        Themes.showThemedToast(DeckPicker.this, getResources().getString(R.string.tutorial_loading_error), false);
    }
    if (mProgressDialog.isShowing()) {
        try {
            mProgressDialog.dismiss();
        } catch (Exception e) {
            Log.e(AnkiDroidApp.TAG, "onPostExecute - Dialog dismiss Exception = " + e.getMessage());
        }
    }
}