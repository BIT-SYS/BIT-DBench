{
    Blog blog = WordPress.getCurrentBlog();
    if (blog == null)
        return;
    String blogId = String.valueOf(blog.getBlogId());
    GregorianCalendar startDate = new GregorianCalendar(mStartYear, mStartMonth, mStartDay);
    GregorianCalendar endDate = new GregorianCalendar(mEndYear, mEndMonth, mEndDay);
    long one_day = 24 * 60 * 60 * 1000;
    Cursor cursor = WordPress.wpDB.getMediaFilesForBlog(blogId, startDate.getTimeInMillis(), endDate.getTimeInMillis() + one_day);
    mGridAdapter.changeCursor(cursor);
    if (cursor != null && cursor.moveToFirst()) {
        mResultView.setVisibility(View.VISIBLE);
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
        fmt.setCalendar(startDate);
        String formattedStart = fmt.format(startDate.getTime());
        String formattedEnd = fmt.format(endDate.getTime());
        mResultView.setText("Displaying media from " + formattedStart + " to " + formattedEnd);
    } else {
        mResultView.setVisibility(View.VISIBLE);
        mResultView.setText(getResources().getString(R.string.empty_fields));
    }
}