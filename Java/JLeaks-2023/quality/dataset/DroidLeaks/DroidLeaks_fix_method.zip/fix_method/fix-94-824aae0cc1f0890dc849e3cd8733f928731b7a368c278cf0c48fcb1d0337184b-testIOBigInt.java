{
    KeyPair pair = new OtrCryptoEngineImpl().generateDHKeyPair();
    BigInteger source = ((DHPublicKey) pair.getPublic()).getY();
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    OtrOutputStream oos = new OtrOutputStream(out);
    oos.writeBigInt(source);
    oos.close();
    byte[] converted = out.toByteArray();
    ByteArrayInputStream bin = new ByteArrayInputStream(converted);
    OtrInputStream ois = new OtrInputStream(bin);
    BigInteger result = ois.readBigInt();
    ois.close();
    assertTrue(source.compareTo(result) == 0);
}