{
    mLocation = null;
    String title = getResources().getString(R.string.title);
    boolean dontParse = false;
    boolean fromStart = false;
    String itemTitle = null;
    // Index in the media list as passed by AudioServer (used only for vout transition internally)
    int itemPosition = -1;
    // position passed in by intent (ms)
    long intentPosition = -1;
    if (getIntent().getAction() != null && getIntent().getAction().equals(Intent.ACTION_VIEW)) {
        /* Started from external application 'content' */
        if (getIntent().getData() != null && getIntent().getData().getScheme() != null && getIntent().getData().getScheme().equals("content")) {
            // Media or MMS URI
            if (getIntent().getData().getHost().equals("media") || getIntent().getData().getHost().equals("mms")) {
                try {
                    Cursor cursor = getContentResolver().query(getIntent().getData(), new String[] { MediaStore.Video.Media.DATA }, null, null, null);
                    if (cursor != null) {
                        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
                        if (cursor.moveToFirst())
                            mLocation = LibVLC.PathToURI(cursor.getString(column_index));
                        cursor.close();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Couldn't read the file from media or MMS");
                    encounteredError();
                }
            } else // Mail-based apps - download the stream to a temporary file and play it
            if (getIntent().getData().getHost().equals("com.fsck.k9.attachmentprovider") || getIntent().getData().getHost().equals("gmail-ls")) {
                try {
                    Cursor cursor = getContentResolver().query(getIntent().getData(), new String[] { MediaStore.MediaColumns.DISPLAY_NAME }, null, null, null);
                    if (cursor != null) {
                        cursor.moveToFirst();
                        String filename = cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME));
                        cursor.close();
                        Log.i(TAG, "Getting file " + filename + " from content:// URI");
                        InputStream is = getContentResolver().openInputStream(getIntent().getData());
                        OutputStream os = new FileOutputStream(Environment.getExternalStorageDirectory().getPath() + "/Download/" + filename);
                        byte[] buffer = new byte[1024];
                        int bytesRead = 0;
                        while ((bytesRead = is.read(buffer)) >= 0) {
                            os.write(buffer, 0, bytesRead);
                        }
                        os.close();
                        is.close();
                        mLocation = LibVLC.PathToURI(Environment.getExternalStorageDirectory().getPath() + "/Download/" + filename);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Couldn't download file from mail URI");
                    encounteredError();
                }
            } else // other content-based URI (probably file pickers)
            {
                mLocation = getIntent().getData().getPath();
            }
        } else /* External application */
        if (getIntent().getDataString() != null) {
            // Plain URI
            mLocation = getIntent().getDataString();
            // Remove VLC prefix if needed
            if (mLocation.startsWith("vlc://")) {
                mLocation = mLocation.substring(6);
            }
            // Decode URI
            if (!mLocation.contains("/")) {
                try {
                    mLocation = URLDecoder.decode(mLocation, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Log.e(TAG, "Couldn't understand the intent");
            encounteredError();
        }
        // Try to get the position
        if (getIntent().getExtras() != null)
            intentPosition = getIntent().getExtras().getLong("position", -1);
    } else /* ACTION_VIEW */
    /* Started from VideoListActivity */
    if (getIntent().getAction() != null && getIntent().getAction().equals(PLAY_FROM_VIDEOGRID) && getIntent().getExtras() != null) {
        mLocation = getIntent().getExtras().getString("itemLocation");
        itemTitle = getIntent().getExtras().getString("itemTitle");
        dontParse = getIntent().getExtras().getBoolean("dontParse");
        fromStart = getIntent().getExtras().getBoolean("fromStart");
        itemPosition = getIntent().getExtras().getInt("itemPosition", -1);
    }
    mSurface.setKeepScreenOn(true);
    /* Start / resume playback */
    if (dontParse && itemPosition >= 0) {
        // Provided externally from AudioService
        Log.d(TAG, "Continuing playback from AudioService at index " + itemPosition);
        savedIndexPosition = itemPosition;
        if (!mLibVLC.isPlaying()) {
            // AudioService-transitioned playback for item after sleep and resume
            mLibVLC.playIndex(savedIndexPosition);
            dontParse = false;
        } else {
            stopLoadingAnimation();
            showOverlay();
        }
    } else if (savedIndexPosition > -1) {
        // Stop the previous playback.
        AudioServiceController.getInstance().stop();
        mLibVLC.setMediaList();
        mLibVLC.playIndex(savedIndexPosition);
    } else if (mLocation != null && mLocation.length() > 0 && !dontParse) {
        // Stop the previous playback.
        AudioServiceController.getInstance().stop();
        mLibVLC.setMediaList();
        mLibVLC.getMediaList().add(new Media(mLibVLC, mLocation));
        savedIndexPosition = mLibVLC.getMediaList().size() - 1;
        mLibVLC.playIndex(savedIndexPosition);
    }
    mCanSeek = false;
    if (mLocation != null && mLocation.length() > 0 && !dontParse) {
        // restore last position
        SharedPreferences preferences = getSharedPreferences(PreferencesActivity.NAME, MODE_PRIVATE);
        Media media = MediaDatabase.getInstance(this).getMedia(mLocation);
        if (media != null) {
            // in media library
            if (media.getTime() > 0 && !fromStart)
                mLibVLC.setTime(media.getTime());
            mLastAudioTrack = media.getAudioTrack();
            mLastSpuTrack = media.getSpuTrack();
        } else {
            // not in media library
            long rTime = preferences.getLong(PreferencesActivity.VIDEO_RESUME_TIME, -1);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong(PreferencesActivity.VIDEO_RESUME_TIME, -1);
            editor.commit();
            if (rTime > 0)
                mLibVLC.setTime(rTime);
            if (intentPosition > 0)
                mLibVLC.setTime(intentPosition);
        }
        // Get possible subtitles
        String subtitleList_serialized = preferences.getString(PreferencesActivity.VIDEO_SUBTITLE_FILES, null);
        ArrayList<String> prefsList = new ArrayList<String>();
        if (subtitleList_serialized != null) {
            ByteArrayInputStream bis = new ByteArrayInputStream(subtitleList_serialized.getBytes());
            try {
                ObjectInputStream ois = new ObjectInputStream(bis);
                prefsList = (ArrayList<String>) ois.readObject();
            } catch (ClassNotFoundException e) {
            } catch (StreamCorruptedException e) {
            } catch (IOException e) {
            }
        }
        for (String x : prefsList) {
            if (!mSubtitleSelectedFiles.contains(x))
                mSubtitleSelectedFiles.add(x);
        }
        // Get the title
        try {
            title = URLDecoder.decode(mLocation, "UTF-8");
        } catch (UnsupportedEncodingException e) {
        } catch (IllegalArgumentException e) {
        }
        if (title.startsWith("file:")) {
            title = new File(title).getName();
            int dotIndex = title.lastIndexOf('.');
            if (dotIndex != -1)
                title = title.substring(0, dotIndex);
        }
    } else if (itemTitle != null) {
        title = itemTitle;
    }
    mTitle.setText(title);
}