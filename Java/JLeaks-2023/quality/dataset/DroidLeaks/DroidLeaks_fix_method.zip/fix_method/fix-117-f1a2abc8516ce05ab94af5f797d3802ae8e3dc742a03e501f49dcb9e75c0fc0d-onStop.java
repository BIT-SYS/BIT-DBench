{
    super.onStop();
    if (this.pubkeydb != null)
        this.pubkeydb.close();
}