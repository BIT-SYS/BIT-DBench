{
    getLocationManager().removeUpdates(mLocationListener);
    if (this.mDoGPSRecordingAndContributing) {
        OSMUploader.uploadAsync(this.mRouteRecorder.getRecordedGeoPoints());
    }
    super.onResume();
}