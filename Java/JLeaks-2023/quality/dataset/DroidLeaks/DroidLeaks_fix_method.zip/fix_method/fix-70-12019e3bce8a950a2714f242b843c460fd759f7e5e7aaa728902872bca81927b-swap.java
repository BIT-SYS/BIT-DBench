{
    final ContentResolver cr = this.getContentResolver();
    Cursor cursor = null;
    // get plans
    final String idCurrent = String.valueOf(this.adapter.getItemId(position));
    final String idOther = String.valueOf(this.adapter.getItemId(position + direction));
    cursor = cr.query(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(idCurrent).build(), DataProvider.Plans.PROJECTION, null, null, null);
    if (cursor == null || !cursor.moveToFirst()) {
        return;
    }
    final int orderCurrent = cursor.getInt(DataProvider.Plans.INDEX_ORDER);
    cursor.close();
    cursor = cr.query(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(idOther).build(), DataProvider.Plans.PROJECTION, null, null, null);
    if (cursor == null || !cursor.moveToFirst()) {
        return;
    }
    final int orderOther = cursor.getInt(DataProvider.Plans.INDEX_ORDER);
    cursor.close();
    // set new order
    final ContentValues cvCurrent = new ContentValues();
    ContentValues cvOther = null;
    if (orderCurrent == orderOther) {
        cvCurrent.put(DataProvider.Plans.ORDER, orderCurrent + direction);
    } else {
        cvOther = new ContentValues();
        cvCurrent.put(DataProvider.Plans.ORDER, orderOther);
        cvOther.put(DataProvider.Plans.ORDER, orderCurrent);
    }
    // push changes
    cr.update(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(String.valueOf(idCurrent)).build(), cvCurrent, null, null);
    if (cvOther != null) {
        cr.update(DataProvider.Plans.CONTENT_URI.buildUpon().appendPath(String.valueOf(idOther)).build(), cvOther, null, null);
    }
}