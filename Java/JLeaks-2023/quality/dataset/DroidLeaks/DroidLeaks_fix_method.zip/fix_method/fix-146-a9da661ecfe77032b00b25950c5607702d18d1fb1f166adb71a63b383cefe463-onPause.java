{
    super.onPause();
    if (player != null) {
        try {
            player.stop();
        } catch (IllegalStateException e) {
        }
        player.release();
        player = null;
    }
}