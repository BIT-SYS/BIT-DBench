{
    InputStream in = getInputStream();
    Base64OutputStream base64Out = new Base64OutputStream(out);
    try {
        IOUtils.copy(in, base64Out);
    } finally {
        base64Out.close();
    }
}