{
    errors = new ArrayList<String>();
    ArrayList<Bank> banks;
    if (bankId != -1) {
        banks = new ArrayList<Bank>();
        banks.add(BankFactory.bankFromDb(bankId, parent, true));
    } else {
        banks = BankFactory.banksFromDb(parent, true);
    }
    bankcount = banks.size();
    this.dialog.setMax(bankcount);
    int i = 0;
    for (Bank bank : banks) {
        publishProgress(new String[] { new Integer(i).toString(), bank.getName() + " (" + bank.getUsername() + ")" });
        if (bank.isDisabled()) {
            Log.d("AA", bank.getName() + " (" + bank.getUsername() + ") is disabled. Skipping refresh.");
            continue;
        }
        Log.d("AA", "Refreshing " + bank.getName() + " (" + bank.getUsername() + ").");
        try {
            bank.update();
            bank.updateAllTransactions();
            bank.closeConnection();
            bank.save();
            i++;
        } catch (BankException e) {
            this.errors.add(bank.getName() + " (" + bank.getUsername() + ")");
        } catch (LoginException e) {
            this.errors.add(bank.getName() + " (" + bank.getUsername() + ")");
            bank.disable();
        }
    }
    publishProgress(new String[] { new Integer(i).toString(), "" });
    return null;
}