{
    try {
        if (connection.authenticateWithNone(username)) {
            finishConnection();
            return;
        }
    } catch (Exception e) {
        Log.d(TAG, "Host does not support 'none' authentication.");
    }
    outputLine("Trying to authenticate");
    try {
        if (!pubkeysExhausted && connection.isAuthMethodAvailable(username, AUTH_PUBLICKEY)) {
            Cursor cursor = pubkeydb.allPubkeys();
            String keyNickname;
            PrivateKey privKey;
            PublicKey pubKey;
            while (cursor.moveToNext()) {
                if (cursor.getInt(COL_ENCRYPTED) == 0) {
                    keyNickname = cursor.getString(COL_NICKNAME);
                    privKey = PubkeyUtils.decodePrivate(cursor.getBlob(COL_PRIVATE), cursor.getString(COL_TYPE));
                    pubKey = PubkeyUtils.decodePublic(cursor.getBlob(COL_PUBLIC), cursor.getString(COL_TYPE));
                    Log.d("TerminalBridge", "Trying key " + PubkeyUtils.formatKey(pubKey));
                    if (connection.authenticateWithPublicKey(username, PubkeyUtils.convertToTrilead(privKey, pubKey))) {
                        finishConnection();
                    } else {
                        outputLine("Authentication method 'publickey' with key " + keyNickname + " failed");
                    }
                }
            }
            cursor.close();
            pubkeysExhausted = true;
        } else if (connection.isAuthMethodAvailable(username, AUTH_PASSWORD)) {
            outputLine("Attempting 'password' authentication");
            String password = promptHelper.requestStringPrompt("Password");
            if (connection.authenticateWithPassword(username, password)) {
                finishConnection();
            } else {
                outputLine("Authentication method 'password' failed");
            }
        } else if (connection.isAuthMethodAvailable(username, AUTH_KEYBOARDINTERACTIVE)) {
            // this auth method will talk with us using InteractiveCallback interface
            // it blocks until authentication finishes
            outputLine("Attempting 'keyboard-interactive' authentication");
            if (connection.authenticateWithKeyboardInteractive(username, TerminalBridge.this)) {
                finishConnection();
            } else {
                outputLine("Authentication method 'keyboard-interactive' failed");
            }
        } else {
            outputLine("[Your host doesn't support 'password' or 'keyboard-interactive' authentication.]");
        }
    } catch (Exception e) {
        Log.e(TAG, "Problem during handleAuthentication()", e);
    }
}