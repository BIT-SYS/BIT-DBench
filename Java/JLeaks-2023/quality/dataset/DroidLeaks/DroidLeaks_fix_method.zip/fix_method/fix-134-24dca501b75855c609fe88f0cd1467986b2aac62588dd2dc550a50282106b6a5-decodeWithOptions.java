{
    final InputStream stream = myImage.inputStream();
    if (stream == null) {
        return null;
    }
    final Bitmap bmp = BitmapFactory.decodeStream(stream, new Rect(), options);
    try {
        System.err.println(stream);
        stream.close();
    } catch (IOException e) {
    }
    return bmp;
}