{
    Activity activity = getActivity();
    if (activity == null) {
        return;
    }
    ProviderHelper providerHelper = new ProviderHelper(activity);
    Cursor cursor = providerHelper.getContentResolver().query(KeyRings.buildUnifiedKeyRingsUri(), new String[] { KeyRings.FINGERPRINT }, null, null, null);
    if (cursor == null) {
        Notify.create(activity, R.string.error_loading_keys, Style.ERROR);
        return;
    }
    ArrayList<ParcelableKeyRing> keyList = new ArrayList<>();
    try {
        while (cursor.moveToNext()) {
            // fingerprint column is 0
            byte[] blob = cursor.getBlob(0);
            String fingerprint = KeyFormattingUtils.convertFingerprintToHex(blob);
            ParcelableKeyRing keyEntry = new ParcelableKeyRing(fingerprint, null, null);
            keyList.add(keyEntry);
        }
    } finally {
        cursor.close();
    }
    ServiceProgressHandler serviceHandler = new ServiceProgressHandler(getActivity()) {

        @Override
        public void handleMessage(Message message) {
            // handle messages by standard KeychainIntentServiceHandler first
            super.handleMessage(message);
            if (message.arg1 == MessageStatus.OKAY.ordinal()) {
                // get returned data bundle
                Bundle returnData = message.getData();
                if (returnData == null) {
                    return;
                }
                final ImportKeyResult result = returnData.getParcelable(OperationResult.EXTRA_RESULT);
                if (result == null) {
                    Log.e(Constants.TAG, "result == null");
                    return;
                }
                result.createNotify(getActivity()).show();
            }
        }
    };
    // Send all information needed to service to query keys in other thread
    Intent intent = new Intent(getActivity(), KeychainService.class);
    intent.setAction(KeychainService.ACTION_IMPORT_KEYRING);
    // fill values for this action
    Bundle data = new Bundle();
    // search config
    {
        Preferences prefs = Preferences.getPreferences(getActivity());
        Preferences.CloudSearchPrefs cloudPrefs = new Preferences.CloudSearchPrefs(true, true, prefs.getPreferredKeyserver());
        data.putString(KeychainService.IMPORT_KEY_SERVER, cloudPrefs.keyserver);
    }
    data.putParcelableArrayList(KeychainService.IMPORT_KEY_LIST, keyList);
    intent.putExtra(KeychainService.EXTRA_DATA, data);
    // Create a new Messenger for the communication back
    Messenger messenger = new Messenger(serviceHandler);
    intent.putExtra(KeychainService.EXTRA_MESSENGER, messenger);
    // show progress dialog
    serviceHandler.showProgressDialog(getString(R.string.progress_updating), ProgressDialog.STYLE_HORIZONTAL, true);
    // start service with intent
    getActivity().startService(intent);
}