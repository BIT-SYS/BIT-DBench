{
    try {
        javax.net.ssl.TrustManagerFactory tmf = javax.net.ssl.TrustManagerFactory.getInstance("X509");
        for (X509Certificate element : chain) {
            keyStore.setCertificateEntry(element.getSubjectDN().toString(), element);
        }
        tmf.init(keyStore);
        TrustManager[] tms = tmf.getTrustManagers();
        if (tms != null) {
            for (TrustManager tm : tms) {
                if (tm instanceof X509TrustManager) {
                    localTrustManager = (X509TrustManager) tm;
                    break;
                }
            }
        }
        java.io.OutputStream keyStoreStream = null;
        try {
            keyStoreStream = new java.io.FileOutputStream(keyStoreFile);
            keyStore.store(keyStoreStream, "".toCharArray());
        } catch (FileNotFoundException e) {
            throw new CertificateException("Unable to write KeyStore: " + e.getMessage());
        } catch (CertificateException e) {
            throw new CertificateException("Unable to write KeyStore: " + e.getMessage());
        } catch (IOException e) {
            throw new CertificateException("Unable to write KeyStore: " + e.getMessage());
        } finally {
            IOUtils.closeQuietly(keyStoreStream);
        }
    } catch (NoSuchAlgorithmException e) {
        Log.e(LOG_TAG, "Unable to get X509 Trust Manager ", e);
    } catch (KeyStoreException e) {
        Log.e(LOG_TAG, "Key Store exception while initializing TrustManagerFactory ", e);
    }
}