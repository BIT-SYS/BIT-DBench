{
    if (myLibrary != null) {
        final LibraryImplementation l = myLibrary;
        myLibrary = null;
        l.deactivate();
        l.close();
    }
    super.onDestroy();
}