{
    // Try to query the TorrentSearchProvider to search for torrents on the web
    Uri uri = Uri.parse("content://org.transdroid.search.torrentsearchprovider/search/" + query);
    Cursor cursor;
    if (site == null) {
        // If no explicit site was supplied, rely on the Torrent Search package's default
        cursor = context.getContentResolver().query(uri, null, null, null, sortBy.name());
    } else {
        cursor = context.getContentResolver().query(uri, null, "SITE = ?", new String[] { site.getKey() }, sortBy.name());
    }
    if (cursor == null) {
        // The content provider could not load any content (for example when there is no connection)
        return null;
    }
    if (cursor.moveToFirst()) {
        ArrayList<SearchResult> results = new ArrayList<>();
        do {
            // Read the cursor fields into the SearchResult object
            results.add(new SearchResult(cursor.getInt(CURSOR_SEARCH_ID), cursor.getString(CURSOR_SEARCH_NAME), cursor.getString(CURSOR_SEARCH_TORRENTURL), cursor.getString(CURSOR_SEARCH_DETAILSURL), cursor.getString(CURSOR_SEARCH_SIZE), cursor.getLong(CURSOR_SEARCH_ADDED), cursor.getString(CURSOR_SEARCH_SEEDERS), cursor.getString(CURSOR_SEARCH_LEECHERS)));
        } while (cursor.moveToNext());
        cursor.close();
        return results;
    }
    // Torrent Search package is not yet installed
    cursor.close();
    return null;
}