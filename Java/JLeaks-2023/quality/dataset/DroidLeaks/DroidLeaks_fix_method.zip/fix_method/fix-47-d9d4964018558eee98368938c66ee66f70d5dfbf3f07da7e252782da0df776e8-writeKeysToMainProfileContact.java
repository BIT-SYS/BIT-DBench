{
    // deletes contacts hidden by the user so they can be reinserted if necessary
    deleteFlaggedMainProfileRawContacts(resolver);
    Set<Long> keysToDelete = getMainProfileMasterKeyIds(resolver);
    // get all keys which have associated secret keys
    // TODO: figure out why using selectionArgs does not work in this case
    Cursor cursor = resolver.query(KeychainContract.KeyRings.buildUnifiedKeyRingsUri(), KEYS_TO_CONTACT_PROJECTION, KeychainContract.KeyRings.HAS_ANY_SECRET + "!=0", null, null);
    if (cursor != null)
        try {
            while (cursor.moveToNext()) {
                long masterKeyId = cursor.getLong(INDEX_MASTER_KEY_ID);
                boolean isExpired = cursor.getInt(INDEX_IS_EXPIRED) != 0;
                boolean isRevoked = cursor.getInt(INDEX_IS_REVOKED) > 0;
                KeyRing.UserId userIdSplit = KeyRing.splitUserId(cursor.getString(INDEX_USER_ID));
                if (!isExpired && !isRevoked && userIdSplit.name != null) {
                    // if expired or revoked will not be removed from keysToDelete or inserted
                    // into main profile ("me" contact)
                    boolean existsInMainProfile = keysToDelete.remove(masterKeyId);
                    if (!existsInMainProfile) {
                        // new raw contact
                        long rawContactId = -1;
                        Log.d(Constants.TAG, "masterKeyId with secret " + masterKeyId);
                        ArrayList<ContentProviderOperation> ops = new ArrayList<>();
                        insertMainProfileRawContact(ops, masterKeyId);
                        writeContactKey(ops, context, rawContactId, masterKeyId, userIdSplit.name);
                        try {
                            resolver.applyBatch(ContactsContract.AUTHORITY, ops);
                        } catch (Exception e) {
                            Log.w(Constants.TAG, e);
                        }
                    }
                }
            }
        } finally {
            cursor.close();
        }
    for (long masterKeyId : keysToDelete) {
        deleteMainProfileRawContactByMasterKeyId(resolver, masterKeyId);
        Log.d(Constants.TAG, "Delete main profile raw contact with masterKeyId " + masterKeyId);
    }
}