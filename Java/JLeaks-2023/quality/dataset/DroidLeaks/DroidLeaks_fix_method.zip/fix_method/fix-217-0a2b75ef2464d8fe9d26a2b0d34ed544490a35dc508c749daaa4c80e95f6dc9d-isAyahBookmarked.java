{
    Cursor cursor = findAyah(sura, ayah, new String[] { AyahTable.BOOKMARKED });
    boolean result = (cursor.moveToFirst() && cursor.getInt(0) == 1);
    cursor.close();
    return result;
}