{
    super.onDestroy();
    locListener.stop();
}