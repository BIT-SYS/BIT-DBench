{
    startDownload(blocksLeft);
    originalBlocksLeft = blocksLeft;
    if (blocksLeft == 0) {
        doneDownload();
        done.release();
    }
}