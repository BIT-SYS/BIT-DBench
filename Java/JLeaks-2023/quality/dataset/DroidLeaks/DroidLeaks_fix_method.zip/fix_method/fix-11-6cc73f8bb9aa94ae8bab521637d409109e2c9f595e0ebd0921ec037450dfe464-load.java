{
    synchronized (users) {
        Cursor c = new Select().from(User.class).where(Condition.column(User$Table.BID).is(bid)).query();
        try {
            if (loaded_bids.contains(bid))
                return;
            long start = System.currentTimeMillis();
            ModelAdapter<User> modelAdapter = FlowManager.getModelAdapter(User.class);
            if (c != null && c.moveToFirst()) {
                android.util.Log.d("IRCCloud", "Loading users for bid" + bid);
                do {
                    User e = modelAdapter.loadFromCursor(c);
                    if (!users.containsKey(e.bid) || users.get(e.bid) == null)
                        users.put(e.bid, new TreeMap<String, User>(comparator));
                    users.get(e.bid).put(e.nick.toLowerCase(), e);
                } while (c.moveToNext());
                long time = System.currentTimeMillis() - start;
                android.util.Log.i("IRCCloud", "Loaded " + c.getCount() + " users in " + time + "ms");
                loaded_bids.add(bid);
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (c != null)
                c.close();
        }
    }
}