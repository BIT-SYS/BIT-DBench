{
    Cursor cursor = findAyah(sura, ayah, new String[] { AyahTable.NOTES });
    String result = null;
    if (cursor.moveToFirst() && !cursor.isNull(0))
        result = cursor.getString(0);
    cursor.close();
    return result;
}