{
    for (int i = 0; i < indent; i++) report.append("  - ");
    final Formatter formatter = new Formatter(report);
    formatter.format("%tF %tT  %s  [%d]\n", file.lastModified(), file.lastModified(), file.getName(), file.length());
    formatter.close();
    if (file.isDirectory())
        for (final File f : file.listFiles()) appendReport(report, f, indent + 1);
}