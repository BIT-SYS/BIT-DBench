{
    if (mOpenHelper != null)
        mOpenHelper.close();
}