{
    InputStream is = null;
    FileInputStream fis = null;
    try {
        fis = new FileInputStream(mFile);
        is = new BinaryTempFileBodyInputStream(fis);
        return is;
    } catch (IOException ioe) {
        try {
            if (fis != null) {
                fis.close();
            }
        } catch (IOException e) {
        }
        try {
            if (is != null) {
                is.close();
            }
        } catch (IOException e) {
        }
        throw new MessagingException("Unable to open body", ioe);
    }
}