{
    if (!cursor.moveToFirst())
        return;
    mUploadInProgress = true;
    int blogId = Integer.valueOf(cursor.getString((cursor.getColumnIndex("blogId"))));
    final String blogIdStr = String.valueOf(blogId);
    final String mediaId = cursor.getString(cursor.getColumnIndex("mediaId"));
    String fileName = cursor.getString(cursor.getColumnIndex("fileName"));
    String filePath = cursor.getString(cursor.getColumnIndex("filePath"));
    String mimeType = cursor.getString(cursor.getColumnIndex("mimeType"));
    cursor.close();
    MediaFile mediaFile = new MediaFile();
    mediaFile.setBlogId(blogIdStr);
    mediaFile.setFileName(fileName);
    mediaFile.setFilePath(filePath);
    mediaFile.setMIMEType(mimeType);
    ApiHelper.UploadMediaTask task = new ApiHelper.UploadMediaTask(mContext, mediaFile, new Callback() {

        @Override
        public void onSuccess(String id) {
            // once the file has been uploaded, delete the local database entry and
            // download the new one so that we are up-to-date and so that users can edit it.
            WordPress.wpDB.deleteMediaFile(blogIdStr, mediaId);
            fetchMediaFile(id);
        }

        @Override
        public void onFailure() {
            WordPress.wpDB.updateMediaUploadState(blogIdStr, mediaId, "failed");
            mUploadInProgress = false;
            sendUpdateBroadcast();
            mHandler.post(fetchQueueTask);
        }
    });
    WordPress.wpDB.updateMediaUploadState(blogIdStr, mediaId, "uploading");
    sendUpdateBroadcast();
    List<Object> apiArgs = new ArrayList<Object>();
    apiArgs.add(WordPress.getCurrentBlog());
    task.execute(apiArgs);
    mHandler.post(fetchQueueTask);
}