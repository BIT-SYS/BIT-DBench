{
    ObjectOutputStream os = null;
    try {
        os = new ObjectOutputStream(new FileOutputStream(getLastHNPostCommentsPath(postID)));
        os.writeObject(comments);
    } catch (Exception e) {
        Log.e(TAG, "Could not save last HNPostComments to file :(", e);
    } finally {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                Log.e(TAG, "Couldn't close last NH comments file :(", e);
            }
        }
    }
}