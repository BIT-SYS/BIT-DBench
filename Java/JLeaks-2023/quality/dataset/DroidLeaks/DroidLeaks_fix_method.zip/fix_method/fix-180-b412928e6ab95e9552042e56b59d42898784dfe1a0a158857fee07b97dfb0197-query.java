{
    if (K9.app == null) {
        return null;
    }
    if (K9.DEBUG) {
        Log.v(K9.LOG_TAG, "MessageProvider/query: " + uri);
    }
    final Cursor cursor;
    final int code = mUriMatcher.match(uri);
    if (code == -1) {
        throw new IllegalStateException("Unrecognized URI: " + uri);
    }
    try {
        // since we used the list index as the UriMatcher code, using it
        // back to retrieve the handler from the list
        final QueryHandler handler = mQueryHandlers.get(code);
        cursor = handler.query(uri, projection, selection, selectionArgs, sortOrder);
    } catch (Exception e) {
        Log.e(K9.LOG_TAG, "Unable to execute query for URI: " + uri, e);
        return null;
    }
    return cursor;
}