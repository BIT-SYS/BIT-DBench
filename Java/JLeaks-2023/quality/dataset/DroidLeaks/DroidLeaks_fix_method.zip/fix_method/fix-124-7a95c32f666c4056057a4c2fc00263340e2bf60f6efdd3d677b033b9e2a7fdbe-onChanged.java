{
    synchronized (SipService.this) {
        // When turning on WIFI, it needs some time for network
        // connectivity to get stabile so we defer good news (because
        // we want to skip the interim ones) but deliver bad news
        // immediately
        if (connected) {
            if (mTask != null) {
                Log.d(THIS_FILE, "We already have a current task in stack");
                mTask.cancel();
                sipWakeLock.release(mTask);
            }
            mTask = new MyTimerTask(type, connected);
            if (mTimer == null) {
                mTimer = new Timer();
            }
            mTimer.schedule(mTask, 2 * 1000L);
            // hold wakup lock so that we can finish changes before the
            // device goes to sleep
            sipWakeLock.acquire(mTask);
        } else {
            if ((mTask != null) && mTask.mNetworkType.equals(type)) {
                mTask.cancel();
                sipWakeLock.release(mTask);
            }
            // onConnectivityChanged(type, false);
            dataConnectionChanged();
        }
    }
}