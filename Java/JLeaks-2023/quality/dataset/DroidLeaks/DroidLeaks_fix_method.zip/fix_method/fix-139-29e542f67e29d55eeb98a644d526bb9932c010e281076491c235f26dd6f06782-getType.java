{
    Cursor cursor = getAccount(email);
    try {
        if (!cursorIsEmpty(cursor)) {
            cursor.moveToFirst();
            Integer value = cursor.getInt(cursor.getColumnIndex(TYPE_COLUMN));
            return OtpType.getEnum(value);
        }
    } finally {
        tryCloseCursor(cursor);
    }
    return null;
}