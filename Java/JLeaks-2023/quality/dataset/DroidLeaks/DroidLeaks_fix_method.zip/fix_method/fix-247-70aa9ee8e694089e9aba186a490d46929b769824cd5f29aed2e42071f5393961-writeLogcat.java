{
    String[] args = { "logcat", "-v", "time", "-d" };
    Process process = Runtime.getRuntime().exec(args);
    InputStreamReader input = new InputStreamReader(process.getInputStream());
    OutputStreamWriter output = new OutputStreamWriter(new FileOutputStream(filename));
    BufferedReader br = new BufferedReader(input);
    BufferedWriter bw = new BufferedWriter(output);
    String line;
    try {
        while ((line = br.readLine()) != null) {
            bw.write(line);
            bw.newLine();
        }
    } catch (Exception e) {
    } finally {
        bw.close();
        output.close();
        br.close();
        input.close();
    }
}