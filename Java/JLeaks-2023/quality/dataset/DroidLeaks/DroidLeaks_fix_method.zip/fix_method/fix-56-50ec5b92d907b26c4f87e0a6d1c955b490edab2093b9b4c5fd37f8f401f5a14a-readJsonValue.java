{
    return readJsonValue(urlopen.openStream(url, postData, false), valueType);
}