{
    try {
        updateFolderCountsOnFlag(Flag.X_DESTROYED, true);
        ((LocalFolder) mFolder).deleteAttachments(mId);
        db.execSQL("DELETE FROM messages WHERE id = ?", new Object[] { mId });
    } catch (MessagingException e) {
        throw new WrappedException(e);
    }
    return null;
}