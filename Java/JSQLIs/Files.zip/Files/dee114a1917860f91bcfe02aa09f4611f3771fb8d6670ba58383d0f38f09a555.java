- API reference:
- http://slick.lightbend.com/doc/3.0.0/sql.html
- http://slick.lightbend.com/doc/3.1.1/api/index.html#slick.jdbc.SQLActionBuilder

slick/jdbc/SQLActionBuilder.<init>(Lscala/collection/Seq;Lslick/jdbc/SetParameter;)V:1