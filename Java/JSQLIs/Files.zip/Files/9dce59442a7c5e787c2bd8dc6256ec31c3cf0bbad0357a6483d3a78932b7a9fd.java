
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio 15
VisualStudioVersion = 15.0.26124.0
MinimumVisualStudioVersion = 15.0.26124.0
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "Website", "Website\Website.msbuildproj", "{A271793F-72BF-429D-9EC8-83C03559CBD6}"
EndProject
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "Server", "Server\Server.csproj", "{AF5D53C1-32B5-473F-9229-817608068701}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Any CPU = Debug|Any CPU
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|Any CPU = Release|Any CPU
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|x64.ActiveCfg = Debug|x64
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|x64.Build.0 = Debug|x64
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|x86.ActiveCfg = Debug|x86
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Debug|x86.Build.0 = Debug|x86
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|Any CPU.Build.0 = Release|Any CPU
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|x64.ActiveCfg = Release|x64
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|x64.Build.0 = Release|x64
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|x86.ActiveCfg = Release|x86
		{A271793F-72BF-429D-9EC8-83C03559CBD6}.Release|x86.Build.0 = Release|x86
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|x64.ActiveCfg = Debug|x64
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|x64.Build.0 = Debug|x64
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|x86.ActiveCfg = Debug|x86
		{AF5D53C1-32B5-473F-9229-817608068701}.Debug|x86.Build.0 = Debug|x86
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|Any CPU.Build.0 = Release|Any CPU
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|x64.ActiveCfg = Release|x64
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|x64.Build.0 = Release|x64
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|x86.ActiveCfg = Release|x86
		{AF5D53C1-32B5-473F-9229-817608068701}.Release|x86.Build.0 = Release|x86
	EndGlobalSection
EndGlobal
