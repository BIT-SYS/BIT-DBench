package testcode.sqli;

public class JpaSql {
}
