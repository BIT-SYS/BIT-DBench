"importId";"code";"name";"nextNum";"padding";"prefixe";"suffixe";"toBeAdded";"yearlyResetOk";"company.importId"
100;"accountClearance";"Overpayment clearance";1;10;"ACCCLR_%Y_";;1;1;1
101;"chequeReject";"Cheque reject";1;10;"CHQREJ_%Y_";;1;1;1
102;"invoice";"Customer Invoice";1;7;"INV_%Y";;1;1;1
103;"invoice";"Customer Refund";1;7;"REF_%Y";;1;1;1
104;"invoice";"Supplier Invoice";1;7;"SINV_%Y";;1;1;1
105;"invoice";"Supplier Refund";1;7;"SREF_%Y";;1;1;1
106;"debit";"Direct debit (invoice and installments)";1;7;"DDINV_%Y_";;1;1;1
107;"debitReject";"Direct debit reject";1;7;"REJDD_%Y_";;1;1;1
108;"doubtfulCustomer";"Transfer in doubtful receivables";1;7;"DBTREC_%Y_";;1;1;1
109;"irrecoverable";"Transfer in irrecoverables";1;7;"IRRECOV_%Y_";;1;1;1
110;"move";"Sales move line";1;7;"MVSAL_%Y_";;1;1;1
111;"move";"Refund move line";1;10;"MVREF_%Y_";;1;1;1
112;"move";"Purchase move line";1;7;"MVPUR_%Y_";;1;1;1
113;"move";"Purchase refund move line";1;10;"MVSREF_%Y_";;1;1;1
114;"move";"Virtual move line";1;7;"MVVIRT_%Y_";;1;1;1
115;"move";"Move line for payments received in Cash";1;7;"MVCSH_%Y_";;1;1;1
116;"move";"Move line for payments received in Cheque";1;10;"MVCHQ_%Y_";;1;1;1
117;"move";"Move line for payments received in Credit Card";1;10;"MVCC_%Y_";;1;1;1
118;"move";"Move line for payments received in Internet";1;10;"MVWEB_%Y_";;1;1;1
119;"move";"Move line for payments received in IPO";1;10;"MVIPO_%Y_";;1;1;1
120;"move";"Move line for payments received in IPOC";1;10;"MVIPOC_%Y_";;1;1;1
121;"move";"Move line for payments received in Wire Transfer";1;10;"MVWT_%Y_";;1;1;1
122;"move";"Move line for payments received in Direct Debit (invoice and installments)";1;10;"MVDD_%Y_";;1;1;1
123;"move";"Move line for payments received in Other means";1;10;"MVOTH_%Y_";;1;1;1
124;"move";"Move line for payments received but rejected by the bank";1;10;"MVREJ_%Y_";;1;1;1
125;"move";"Move line for automatic reimbursement";1;10;"MVCLTRBT_%Y_";;1;1;1
126;"move";"Move line for payments executed by Cash";1;7;"MVCSH_%Y_";;1;1;1
127;"move";"Move line for payments executed by Cheque";1;10;"MVCHQ_%Y_";;1;1;1
128;"move";"Move line for payments executed by Credit Card";1;10;"MVCC_%Y_";;1;1;1
129;"move";"Move line for payments executed by IPO";1;10;"MVIPO_%Y_";;1;1;1
130;"move";"Move line for payments executed by Wire Transfer";1;10;"MVWT_%Y_";;1;1;1
131;"move";"Move line for payments executed by Direct Debit (invoice and installments)";1;10;"MVDD_%Y_";;1;1;1
132;"move";"Move line for payments executed by Other means";1;10;"MVOTH_%Y_";;1;1;1
133;"move";"Miscellaneous Operation Automatic";1;10;"MVMISCAUTO_%Y_";;1;1;1
134;"move";"Miscellaneous Operation Manual";1;10;"MVMISCMANU_%Y_";;1;1;1
135;"move";"Clearance Move Live";1;10;"MVCLR_%Y_";;1;1;1
136;"move";"Irrecovrable Move Line";1;10;"MVIRREC_%Y_";;1;1;1
137;"moveLineExport";"Accounting Export";1;10;"ACCEXP_%Y_";;1;1;1
138;"moveLineReport";"Accounting Report";1;10;"ACCREPORT_%Y_";;1;1;1
139;"paymentSchedule";"Installment N°";1;10;"INSTAL_%Y_";;1;1;1
140;"paymentVoucher";"N° for payments received in Cash";1;10;"CSH_IN_ESP_%Y_";;1;1;1
141;"paymentVoucher";"N° for payments received in Cheque";1;10;"CSH_IN_CHQ_%Y_";;1;1;1
142;"paymentVoucher";"N° for payments received in Credit Card";1;10;"CSH_IN_CC_%Y_";;1;1;1
143;"paymentVoucher";"N° for payments received through Internet";1;10;"CSH_IN_WEB_%Y_";;1;1;1
144;"paymentVoucher";"N° for payments received in IPO";1;10;"CSH_IN_TIP_%Y_";;1;1;1
145;"paymentVoucher";"N° for payments received in IPOC";1;10;"CSH_IN_TEC_%Y_";;1;1;1
146;"paymentVoucher";"N° for payments received in Wire Transfer";1;10;"CSH_IN_VIR_%Y_";;1;1;1
147;"paymentVoucher";"N° for payments received in Direct Debit (invoice and installments)";1;10;"CSH_IN_PRE_%Y_";;1;1;1
148;"paymentVoucher";"N° for payments received by other means";1;10;"CSH_IN_OTH_%Y_";;1;1;1
149;"paymentVoucher";"N° for payments executed by Cash";1;10;"CSH_OUT_ESP_%Y_";;1;1;1
150;"paymentVoucher";"N° for payments executed by Cheque";1;10;"CSH_OUT_CHQ_%Y_";;1;1;1
151;"paymentVoucher";"N° for payments executed by Credit Card";1;10;"CSH_OUT_CB_%Y_";;1;1;1
152;"paymentVoucher";"N° for payments executed by IPO";1;10;"CSH_OUT_TIP_%Y_";;1;1;1
153;"paymentVoucher";"N° for payments executed by Wire Transfer";1;10;"CSH_OUT_VIR_%Y_";;1;1;1
154;"paymentVoucher";"N° for payments executed by Direct Debit (invoice and installments)";1;10;"CSH_OUT_PRE_%Y_";;1;1;1
155;"paymentVoucher";"N° for payments executed by other means";1;10;"CSH_OUT_OTH_%Y_";;1;1;1
156;"paymentVoucherReceiptNo";"Voucher Receipt N°";1;10;"RECPT_%Y_";;1;1;1
157;"purchaseInterface";"Purchase interface";1;10;"PURINT_%Y_";;1;1;1
158;"refundInterface";"Refund interface";1;10;"REFINT_%Y_";;1;1;1
159;"reimbursement";"Reimbursement proposals";1;10;"REIMB_%Y_";;1;1;1
160;"saleInterface";"Sale interface";1;10;"SALINT_%Y_";;1;1;1
161;"treasuryInterface";"Cash flow interface";1;10;"CSHFLWINT_%Y_";;1;1;1
1;"partner";"Identifier for accounts and contacts";4;10;"P";;1;0;1
2;"saleOrder";"Sale Order / Customer Order";1;5;"SO";;1;0;1
3;"purchaseOrder";"RFQ/Quotes for Suppliers";1;5;"PO";;1;0;1
4;"eventTicket";"Ticket N°";1;4;"TKT";;1;0;1
5;"intStockMove";"Internal stock move N°";1;4;"ISM";;1;0;1
6;"outStockMove";"Delivery order N°";1;4;"DO";;1;0;1
7;"inStockMove";"Goods receipt order N°";1;4;"RO";;1;0;1
8;"inventory";"Inventory N°";1;4;"INV%M%Y";;1;0;1
9;"productTrackingNumber";"Tracking N°";1;5;"TN";;1;0;1
10;"productionOrder";"Production Order N°";1;5;"PDO";;1;0;1
11;"manufOrder";"Manufacturing Order N°";1;5;"MO";;1;0;1
