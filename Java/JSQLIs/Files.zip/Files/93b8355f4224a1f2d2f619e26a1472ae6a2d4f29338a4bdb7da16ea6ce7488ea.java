/**
 * This package contains few utilities to help the creation of unit tests.
 * 
 */
package edu.umd.cs.findbugs.test;