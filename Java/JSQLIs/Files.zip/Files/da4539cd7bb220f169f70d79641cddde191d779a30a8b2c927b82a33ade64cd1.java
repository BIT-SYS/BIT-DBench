<%
    Long falsePositive = (Long) request.getAttribute("input1");
%>

<%= falsePositive %>
<%= (Long) request.getAttribute("input1") %>