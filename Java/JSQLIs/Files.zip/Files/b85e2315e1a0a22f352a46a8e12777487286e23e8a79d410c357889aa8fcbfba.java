<!DOCTYPE html>
<html>
<head>
	<title>Fortunes</title>
</head>
<body>
	<table>
		<tr>
		<th>id</th>
		<th>message</th>
		</tr>
		<% data.each do |fortune| %>
			<tr>
			<td><%= fortune[:id] %></td>
			<td><%= HTML.escape(fortune[:message]) %></td>
			</tr>
		<% end %>
	</table>
</body>
</html>
