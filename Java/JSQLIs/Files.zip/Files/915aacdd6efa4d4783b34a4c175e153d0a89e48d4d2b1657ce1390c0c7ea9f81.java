<?xml version="1.0" ?>
<groups>

    <group id="admin">
        <title>Admin users</title>
        <readAccess>true</readAccess>
        <writeAccess>true</writeAccess>
        <sessionTimeout>1337</sessionTimeout>
    </group>

    <group id="regular">
        <title>Regular users</title>
        <readAccess>true</readAccess>
        <writeAccess>false</writeAccess>
        <sessionTimeout>1337</sessionTimeout>
    </group>

    <group id="guess">
        <title>Guess</title>
        <readAccess>false</readAccess>
        <writeAccess>false</writeAccess>
        <sessionTimeout>0</sessionTimeout>
    </group>

</groups>