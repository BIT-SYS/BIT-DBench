<?xml version="1.0" encoding="UTF-8"?>
<MessageCollection xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xsi:noNamespaceSchemaLocation="http://findsecbugs.h3xstream.com/messagecollection.xsd">

    <Plugin>
        <ShortDescription>Find Security Bugs</ShortDescription>
        <Details>Find Security Bugs is a plugin that aims to help security audit.</Details>
        <BugsUrl>http://h3xstream.github.io/find-sec-bugs/</BugsUrl>
        <AllBugsUrl>http://h3xstream.github.io/find-sec-bugs/</AllBugsUrl>
    </Plugin>

    <!-- Predictable Pseudo Random Generator (PRG) -->
    <Detector class="com.h3xstream.findsecbugs.PredictableRandomDetector">
        <Details>Detect the use of predictable Pseudo Random Generator (PRG).
        </Details>
    </Detector>

    <BugPattern type="PREDICTABLE_RANDOM">
        <ShortDescription>Predictable Pseudo Random Number Generator</ShortDescription>
        <LongDescription>Use of {3} is predictable.</LongDescription>
        <Details>
            <![CDATA[
<p>The use of a predictable random value can lead to vulnerabilities when used in certain security critical contexts. For example, when the value is used as:</p>
<ul>
<li>a CSRF token</li>
<li>a password reset token (sent by email)</li>
<li>any other secret value</li>
</ul>
<p>
A quick fix could be to replace the use of <b>java.util.Random</b> with something stronger, such as <b>java.security.SecureRandom</b>.
</p>
<p>
<b>Vulnerable Code:</b><br/>
<pre>String generateSecretToken() {
    Random r = new Random();
    return Long.toHexString(r.nextLong());
}</pre>
</p>
<p>
<b>Solution:</b>
<pre>import org.apache.commons.codec.binary.Hex;

String generateSecretToken() {
    SecureRandom secRandom = new SecureRandom();

    byte[] result = new byte[32];
    secRandom.nextBytes(result);
    return Hex.encodeHexString(result);
}</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://jazzy.id.au/default/2010/09/20/cracking_random_number_generators_part_1.html">Cracking Random Number Generators - Part 1 (http://jazzy.id.au)</a><br/>
<a href="https://www.securecoding.cert.org/confluence/display/java/MSC02-J.+Generate+strong+random+numbers">CERT: MSC02-J. Generate strong random numbers</a><br/>
<a href="http://cwe.mitre.org/data/definitions/330.html">CWE-330: Use of Insufficiently Random Values</a><br/>
<a href="http://blog.h3xstream.com/2014/12/predicting-struts-csrf-token-cve-2014.html">Predicting Struts CSRF Token (Example of real-life vulnerability and exploitation)</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPR">Predictable Pseudo Random Generator</BugCode>


    <!-- Servlet parameter -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.ServletEndpointDetector">
        <Details>Identify the unfiltered value coming from ServletRequest and HttpServletRequest.
        </Details>
    </Detector>

    <BugPattern type="SERVLET_PARAMETER">
        <ShortDescription>Untrusted Servlet Parameter</ShortDescription>
        <LongDescription>The method {3} returns a String value that is controlled by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The Servlet can read GET and POST parameters from various methods. The value obtained should be considered unsafe.
You may need to validate or sanitize those values before passing them to sensitive APIs such as:</p>
<ul>
<li>SQL query (May lead to SQL injection)</li>
<li>File opening (May lead to path traversal)</li>
<li>Command execution (Potential Command injection)</li>
<li>HTML construction (Potential XSS)</li>
<li>etc...</li>
</ul>

<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/20.html">CWE-20: Improper Input Validation</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSP">Servlet Parameter</BugCode>


    <BugPattern type="SERVLET_CONTENT_TYPE">
        <ShortDescription>Untrusted Content-Type Header</ShortDescription>
        <LongDescription>The HTTP header Content-Type can be controlled by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>
The HTTP header Content-Type can be controlled by the client. As such, its value should not be used in any security critical decisions.
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/807.html">CWE-807: Untrusted Inputs in a Security Decision</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSCT">Content-Type Header</BugCode>


    <BugPattern type="SERVLET_SERVER_NAME">
        <ShortDescription>Untrusted Hostname Header</ShortDescription>
        <LongDescription>The hostname received can often be controlled by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The hostname header can be controlled by the client. As such, its value should not be used in any security critical decisions. 
Both <code>ServletRequest.getServerName()</code> and <code>HttpServletRequest.getHeader("Host")</code> have the same 
behavior which is to extract the <code>Host</code> header.</p>
<pre>
GET /testpage HTTP/1.1
Host: www.example.com
[...]</pre>
<p>
The web container serving your application may redirect requests to your application by default. This would allow
a malicious user to place any value in the Host header. It is recommended that you do not trust this value in any security
decisions you make with respect to a request.
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/807.html">CWE-807: Untrusted Inputs in a Security Decision</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSN">Hostname Header</BugCode>


    <BugPattern type="SERVLET_SESSION_ID">
        <ShortDescription>Untrusted Session Cookie Value</ShortDescription>
        <LongDescription>Direct access to Session ID should be avoided.</LongDescription>
        <Details>
            <![CDATA[
<p>
The method <a href="http://docs.oracle.com/javaee/6/api/javax/servlet/http/HttpServletRequest.html#getRequestedSessionId()"><code>HttpServletRequest.getRequestedSessionId()</code></a>
typically returns the value of the cookie <code>JSESSIONID</code>. This value is normally only accessed by the session management logic and not normal developer code.
</p>
<p>
The value passed to the client is generally an alphanumeric value (e.g., <code>JSESSIONID=jp6q31lq2myn</code>). However, the value can be altered by the client. 
The following HTTP request illustrates the potential modification.
<pre>
GET /somePage HTTP/1.1
Host: yourwebsite.com
User-Agent: Mozilla/5.0
Cookie: JSESSIONID=Any value of the user&#39;s choice!!??'''&quot;&gt;
</pre>
</p>
<p>As such, the JSESSIONID should only be used to see if its value matches an existing session ID. If it does not, the user should be 
considered an unauthenticated user. In addition, the session ID value should never be logged. If it is, then the log file could contain 
valid active session IDs, allowing an insider to hijack any sessions whose IDs have been logged and are still active.
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="https://www.owasp.org/index.php/Session_Management_Cheat_Sheet">OWASP: Session Management Cheat Sheet</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSID">Session Cookie Value</BugCode>


    <BugPattern type="SERVLET_QUERY_STRING">
        <ShortDescription>Untrusted Query String</ShortDescription>
        <LongDescription>The query string can be any value.</LongDescription>
        <Details>
            <![CDATA[
<p>The query string is the concatenation of the GET parameter names and values. Parameters other than those intended can
be passed in.</p>
<p>For the URL request <code>/app/servlet.htm?a=1&b=2</code>, the query string extract will be <code>a=1&b=2</code></p>
<p>Just as is true for individual parameter values retrieved via methods like <code>HttpServletRequest.getParameter()</code>, 
the value obtained from <code>HttpServletRequest.getQueryString()</code> should be considered unsafe.
You may need to validate or sanitize anything pulled from the query string before passing it to sensitive APIs. 
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/20.html">CWE-20: Improper Input Validation</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSQ">Query String</BugCode>


    <BugPattern type="SERVLET_HEADER">
        <ShortDescription>HTTP Headers Untrusted</ShortDescription>
        <LongDescription>Request header can easily be altered by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>Request headers can easily be altered by the requesting user. In general, no assumption should be made that 
the request came from a regular browser without modification by an attacker. As such, it is recommended that you 
not trust this value in any security decisions you make with respect to a request.</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/807.html">CWE-807: Untrusted Inputs in a Security Decision</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSH">HTTP Headers Untrusted</BugCode>


    <BugPattern type="SERVLET_HEADER_REFERER">
        <ShortDescription>Untrusted Referer Header</ShortDescription>
        <LongDescription>The header "Referer" can easily be spoofed by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>
Behavior:
<ul>
<li>Any value can be assigned to this header if the request is coming from a malicious user.</li>
<li>The "Referer" will not be present if the request was initiated from another origin that is secure (https).</li>
</ul>
</p>
<p>
Recommendations:
<ul>
<li>No access control should be based on the value of this header.</li>
<li>No CSRF protection should be based only on this value (<a href="http://www.w3.org/Protocols/HTTP/HTRQ_Headers.html#z14">because it is optional</a>).</li>
</ul>
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/807.html">CWE-807: Untrusted Inputs in a Security Decision</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSHR">Referer Header</BugCode>


    <BugPattern type="SERVLET_HEADER_USER_AGENT">
        <ShortDescription>Untrusted User-Agent Header</ShortDescription>
        <LongDescription>The header "User-Agent" can easily be spoofed by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The header "User-Agent" can easily be spoofed by the client. Adopting different behaviors based on the User-Agent (for
crawler UA) is not recommended.</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/807.html">CWE-807: Untrusted Inputs in a Security Decision</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSHUA">User-Agent Header</BugCode>


    <!-- Cookie usage -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.CookieDetector">
        <Details>Identity direct cookie usage</Details>
    </Detector>

    <BugPattern type="COOKIE_USAGE">
        <ShortDescription>Potentially Sensitive Data in Cookie</ShortDescription>
        <LongDescription>Sensitive data may be stored by the application in a cookie.</LongDescription>
        <Details>
            <![CDATA[
<p>The information stored in a custom cookie should not be sensitive or related to the session. In most cases, sensitive data should only be stored in session
and referenced by the user's session cookie. See HttpSession (HttpServletRequest.getSession())</p>
<p>Custom cookies can be used for information that needs to live longer than and is independent of a specific session.</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/315.html">CWE-315: Cleartext Storage of Sensitive Information in a Cookie</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCU">Potentially Sensitive Data in Cookie</BugCode>


    <!-- Path traversal -->
    <Detector class="com.h3xstream.findsecbugs.PathTraversalDetector">
        <Details>Identify filesystem access requests that take a path as a parameter.</Details>
    </Detector>

    <BugPattern type="PATH_TRAVERSAL_IN">
        <ShortDescription>Potential Path Traversal (File Read)</ShortDescription>
        <LongDescription>Method {3} reads a file whose location is specified by user input.</LongDescription>
        <Details>
            <![CDATA[
<p>A file is opened to read its content. The filename comes from an <b>input</b> parameter. 
If an unfiltered parameter is passed to this file API, files from an arbitrary filesystem location could be read.</p>
<p>This rule identifies <b>potential</b> path traversal vulnerabilities. In many cases, the constructed file path cannot be controlled
by the user. If that is the case, the reported instance is a false positive.</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246952/Path%20Traversal">WASC: Path Traversal</a><br/>
<a href="https://www.owasp.org/index.php/Path_Traversal">OWASP: Path Traversal</a><br/>
<a href="http://capec.mitre.org/data/definitions/126.html">CAPEC-126: Path Traversal</a><br/>
<a href="http://cwe.mitre.org/data/definitions/22.html">CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPTI">Potential Path Traversal (File Read)</BugCode>


    <BugPattern type="PATH_TRAVERSAL_OUT">
        <ShortDescription>Potential Path Traversal (File Write)</ShortDescription>
        <LongDescription>Method {3} writes to a file whose location is specified by user input.</LongDescription>
        <Details>
            <![CDATA[
<p>A file is opened to write to its contents. The filename comes from an <b>input</b> parameter. 
If an unfiltered parameter is passed to this file API, files at an arbitrary filesystem location could be modified.</p>
<p>This rule identifies <b>potential</b> path traversal vulnerabilities. In many cases, the constructed file path cannot be controlled
by the user. If that is the case, the reported instance is a false positive.</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246952/Path%20Traversal">WASC-33: Path Traversal</a><br/>
<a href="https://www.owasp.org/index.php/Path_Traversal">OWASP: Path Traversal</a><br/>
<a href="http://capec.mitre.org/data/definitions/126.html">CAPEC-126: Path Traversal</a><br/>
<a href="http://cwe.mitre.org/data/definitions/22.html">CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPTO">Potential Path Traversal (File Write)</BugCode>


    <!-- Command injection -->
    <Detector class="com.h3xstream.findsecbugs.CommandInjectionDetector">
        <Details>Identify sources of command injection</Details>
    </Detector>

    <BugPattern type="COMMAND_INJECTION">
        <ShortDescription>Potential Command Injection</ShortDescription>
        <LongDescription>{3} is used to executed system commands.</LongDescription>
        <Details>
            <![CDATA[
<p>The highlighted API is used to execute a system command. If unfiltered input is passed to this API, it can lead to arbitrary command execution.</p>
<br/>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/Command_Injection">OWASP: Command Injection</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/78.html">CWE-78: Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCI">Command Injection</BugCode>


    <!-- Weak FilenameUtils method -->
    <Detector class="com.h3xstream.findsecbugs.WeakFilenameUtilsMethodDetector">
        <Details>Identify the usage of some FilenameUtils methods</Details>
    </Detector>

    <BugPattern type="WEAK_FILENAMEUTILS">
        <ShortDescription>FilenameUtils Not Filtering Null Bytes</ShortDescription>
        <LongDescription>FilenameUtils.{3} doesn't filter NULL bytes.</LongDescription>
        <Details>
            <![CDATA[
<p>Some FilenameUtils' methods don't filter NULL bytes (<code>0x00</code>).</p>
<p>If a null byte is injected into a filename, if this filename is passed to the underlying OS, the file retrieved will be the
name of the file that is specified prior to the NULL byte, since at the OS level, all strings are terminated by a null byte even
though Java itself doesn't care about null bytes or treat them special. This OS behavior can be used to bypass filename validation 
that looks at the end of the filename (e.g., endswith ".log") to make sure its a safe file to access.</p>
<p>To fix this, two things are recommended:
<ul>
<li>Upgrade to Java 7 update 40 or later, or Java 8+ since  
<a href="http://bugs.java.com/bugdatabase/view_bug.do?bug_id=8014846">NULL byte injection in filenames is fixed in those versions</a>.</li>
<li>Strongly validate any filenames provided by untrusted users to make sure they are valid (i.e., don't contain null, don't include path characters, etc.)</li>
</ul>
<p>If you know you are using a modern version of Java immune to NULL byte injection, you can probably disable this rule.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246949/Null%20Byte%20Injection">WASC-28: Null Byte Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/158.html">CWE-158: Improper Neutralization of Null Byte or NUL Character</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWF">FilenameUtils Not Filtering Null Bytes</BugCode>


    <!-- Weak TrustManager -->
    <Detector class="com.h3xstream.findsecbugs.crypto.WeakTrustManagerDetector">
        <Details>Identify weak TrustManager implementation</Details>
    </Detector>

    <BugPattern type="WEAK_TRUST_MANAGER">
        <ShortDescription>TrustManager Implementation Empty</ShortDescription>
        <LongDescription>The implementation of TrustManager is vulnerable to a MITM attack.</LongDescription>
        <Details>
            <![CDATA[
<p>Empty TrustManager implementations are often used to connect easily to a host that is not signed by a root
<a href="http://en.wikipedia.org/wiki/Certificate_authority">certificate authority</a>. As a consequence, this is vulnerable to
<a href="http://en.wikipedia.org/wiki/Man-in-the-middle_attack">Man-in-the-middle attacks</a>
since the client will trust any certificate.
</p>
<p>
A TrustManager allowing specific certificates (based on a truststore for example) should be built.
Detailed information for a proper implementation is at:
<a href="http://stackoverflow.com/a/6378872/89769">[1]</a> 
<a href="http://stackoverflow.com/a/5493452/89769">[2]</a>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246945/Insufficient%20Transport%20Layer%20Protection">WASC-04: Insufficient Transport Layer Protection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/295.html">CWE-295: Improper Certificate Validation</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWTM">Weak TrustManager Implementation</BugCode>


    <!-- JAXWS -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.JaxWsEndpointDetector">
        <Details>Identify web services endpoint that implements JAX-WS API</Details>
    </Detector>

    <BugPattern type="JAXWS_ENDPOINT">
        <ShortDescription>Found JAX-WS SOAP Endpoint</ShortDescription>
        <LongDescription>{0}.{1} is a SOAP Web Service endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This method is part of a SOAP Web Service (JSR224).</p>
<p>
<b>The security of this web service should be analyzed. For example:</b>
<ul>
<li>Authentication, if enforced, should be tested.</li>
<li>Access control, if enforced, should be tested.</li>
<li>The inputs should be tracked for potential vulnerabilities.</li>
<li>The communication should ideally be over SSL.</li>
</ul>
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="https://www.owasp.org/index.php/Web_Service_Security_Cheat_Sheet">OWASP: Web Service Security Cheat Sheet</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECJWS">JAX-WS SOAP Endpoint</BugCode>


    <!-- JAXRS -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.JaxRsEndpointDetector">
        <Details>Identify web services endpoint that implements JAX-RS API</Details>
    </Detector>

    <BugPattern type="JAXRS_ENDPOINT">
        <ShortDescription>Found JAX-RS REST Endpoint</ShortDescription>
        <LongDescription>{0}.{1} is a REST Web Service endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This method is part of a REST Web Service (JSR311).</p>
<p>
<b>The security of this web service should be analyzed. For example:</b>
<ul>
<li>Authentication, if enforced, should be tested.</li>
<li>Access control, if enforced, should be tested.</li>
<li>The inputs should be tracked for potential vulnerabilities.</li>
<li>The communication should ideally be over SSL.</li>
<li>If the service supports writes (e.g., via POST), its vulnerability to CSRF should be investigated.<sup>[1]</sup></li>
</ul>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/REST_Assessment_Cheat_Sheet">OWASP: REST Assessment Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/REST_Security_Cheat_Sheet">OWASP: REST Security Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Web_Service_Security_Cheat_Sheet">OWASP: Web Service Security Cheat Sheet</a><br/>
1. <a href="https://www.owasp.org/index.php/Cross-Site_Request_Forgery_(CSRF)">OWASP: Cross-Site Request Forgery</a><br/>
<a href="https://www.owasp.org/index.php/Cross-Site_Request_Forgery_%28CSRF%29_Prevention_Cheat_Sheet">OWASP: CSRF Prevention Cheat Sheet</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECJRS">JAX-RS REST Endpoint</BugCode>


    <!-- Tapestry -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.TapestryEndpointDetector">
        <Details>Identify Tapestry "Pages" that accept user input</Details>
    </Detector>

    <BugPattern type="TAPESTRY_ENDPOINT">
        <ShortDescription>Found Tapestry Page</ShortDescription>
        <LongDescription>{0} is a Tapestry Page</LongDescription>
        <Details>
            <![CDATA[
<p>A Tapestry endpoint was discovered at application startup. Tapestry apps are structured with a backing Java class and a corresponding 
Tapestry Markup Language page (a .tml file) for each page. When a request is received, the GET/POST parameters are mapped to specific 
inputs in the backing Java class. The mapping is either done with fieldName:</p>
<pre><code>
    [...]
    protected String input;
    [...]
</code></pre>
<p>or the definition of an explicit annotation:
</p>
<pre><code>
    [...]
    @org.apache.tapestry5.annotations.Parameter
    protected String parameter1;

    @org.apache.tapestry5.annotations.Component(id = "password")
    private PasswordField passwordField;
    [...]
</code></pre>
<p>The page is mapped to the view <code>[/resources/package/PageName].tml.</code></p>
<p>Each Tapestry page in this application should be researched to make sure all inputs that are automatically 
mapped in this way are properly validated before they are used.</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://tapestry.apache.org/">Apache Tapestry Home Page</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECTE">Tapestry Page</BugCode>


    <!-- Wicket -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.WicketEndpointDetector">
        <Details>Identify Wicket "WebPages" that serve as input</Details>
    </Detector>

    <BugPattern type="WICKET_ENDPOINT">
        <ShortDescription>Found Wicket Page</ShortDescription>
        <LongDescription>{0} is a Wicket WebPage</LongDescription>
        <Details>
            <![CDATA[
<p>This class represents a Wicket WebPage. Input is automatically read from a PageParameters instance passed to the constructor. 
The current page is mapped to the view [/package/WebPageName].html.</p>
<p>Each Wicket page in this application should be researched to make sure all inputs that are automatically 
mapped in this way are properly validated before they are used.</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="https://wicket.apache.org/">Apache Wicket Home Page</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWE">Wicket Page</BugCode>


    <!-- Weak Message Digest -->
    <Detector class="com.h3xstream.findsecbugs.crypto.WeakMessageDigestDetector">
        <Details>Identify the use of weak MessageDigests that could replace recommended standards.</Details>
    </Detector>

    <BugPattern type="WEAK_MESSAGE_DIGEST">
        <ShortDescription>MessageDigest Is Weak</ShortDescription>
        <LongDescription>{3} is not a recommended MessageDigest/Hashing Algorithm</LongDescription>
        <Details>
            <![CDATA[
<p>The algorithm used is not a recommended MessageDigest.</p>
<p><a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST</a> recommends the use of SHA-1, SHA-224*, SHA-256, SHA-384, SHA-512, SHA-512/224, or SHA-512/256.</p>
<p><small>* SHA-224 algorithm is not provided by <a href="http://docs.oracle.com/javase/6/docs/technotes/guides/security/SunProviders.html#SUNProvider"> SUN provider.</a></small></p>
<p>Upgrade your implementation to use one of the approved algorithms. Use an algorithm that is sufficiently strong for your specific security needs.</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST Approved Hashing Algorithms</a><br/>
<a href="http://cwe.mitre.org/data/definitions/327.html">CWE-327: Use of a Broken or Risky Cryptographic Algorithm</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWMD">MessageDigest Is Weak</BugCode>


    <!-- Custom Message Digest -->
    <Detector class="com.h3xstream.findsecbugs.crypto.CustomMessageDigestDetector">
        <Details>Identify the implementation of custom MessageDigest/Hashing Algorithm</Details>
    </Detector>

    <BugPattern type="CUSTOM_MESSAGE_DIGEST">
        <ShortDescription>MessageDigest Is Custom</ShortDescription>
        <LongDescription>{0} is a custom MessageDigest</LongDescription>
        <Details>
            <![CDATA[
<p>Implementing a custom MessageDigest is error-prone.</p>
<p><a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST</a> recommends the use of SHA-1, SHA-224*, SHA-256, SHA-384, SHA-512, SHA-512/224, or SHA-512/256.</p>
<p><small>* SHA-224 algorithm is not provided by <a href="http://docs.oracle.com/javase/6/docs/technotes/guides/security/SunProviders.html#SUNProvider"> SUN provider.</a></small></p>
<p>
    <b>Vulnerable Code:</b><br/>
<pre>MyProprietaryMessageDigest extends MessageDigest {
    @Override
    protected byte[] engineDigest() {
        [...]
        //Creativity is a bad idea
        return [...];
    }
}</pre>
</p>
<p>
<p>Upgrade your implementation to use one of the approved algorithms. Use an algorithm that is sufficiently strong for your specific security needs.</p>
<p>
    <b>Example Solution:</b><br/>
<pre>MessageDigest sha256Digest = MessageDigest.getInstance("SHA256");
sha256Digest.update(password.getBytes());</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST Approved Hashing Algorithms</a><br/>
<a href="http://cwe.mitre.org/data/definitions/327.html">CWE-327: Use of a Broken or Risky Cryptographic Algorithm</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCMD">MessageDigest Is Custom</BugCode>


    <!-- FileUpload Filename -->
    <Detector class="com.h3xstream.findsecbugs.FileUploadFilenameDetector">
        <Details>The filename given by FileUpload API can be tampered with by the client.</Details>
    </Detector>

    <BugPattern type="FILE_UPLOAD_FILENAME">
        <ShortDescription>Tainted Filename Read</ShortDescription>
        <LongDescription>The filename read can be tampered with by the client</LongDescription>
        <Details>
            <![CDATA[
<p>The filename provided by the FileUpload API can be tampered with by the client to reference unauthorized files.</p>
<p>For example:</p>
<ul>
<li><code>"../../../config/overide_file"</code></li>
<li><code>"shell.jsp\u0000expected.gif"</code></li>
</ul>
<p>Therefore, such values should not be passed directly to the filesystem API. If acceptable, the application should generate its 
own file names and use those. Otherwise, the provided filename should be properly validated to ensure it's properly structured, 
contains no unauthorized path characters (e.g., / \), and refers to an authorized file.</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://blogs.securiteam.com/index.php/archives/1268">Securiteam: File upload security recommendations</a><br/>
<a href="http://cwe.mitre.org/data/definitions/22.html">CWE-22: Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECFUN">Tainted Filename Read</BugCode>


    <!-- ReDOS -->
    <Detector class="com.h3xstream.findsecbugs.ReDosDetector">
        <Details>The regular expression can grow exponentially with some input.</Details>
    </Detector>

    <BugPattern type="REDOS">
        <ShortDescription>Regex DOS (ReDOS)</ShortDescription>
        <LongDescription>The regular expression "{0}" is vulnerable to a denial of service attack (ReDOS)</LongDescription>
        <Details>
            <![CDATA[
<p>
    Regular expressions (regexs) are frequently subject to Denial of Service (DOS) attacks (called ReDOS). This is due to the fact that regex engines 
    may take a large amount of time when analyzing certain strings, depending on how the regex is defined.
<p>
    For example, for the regex: <b>^(a+)+$</b>, the input "<code>aaaaaaaaaaaaaaaaX</code>" will cause the regex engine to analyze 65536 
different paths.<sup>[1] Example taken from OWASP references</sup></p>
<p>
Therefore, it is possible that a single request may cause a large amount of computation on the server side. 
The problem with this regex, and others like it, is that there are two different ways the same input character can be accepted by the 
Regex due to the + (or a *) inside the parenthesis, and the + (or a *) outside the parenthesis. The way this is written, either + could 
consume the character 'a'. To fix this, the regex should be rewritten to eliminate the ambiguity. For example, this could simply be 
rewritten as: <b>^a+$</b>, which is presumably what the author meant anyway (any number of a's). Assuming that's what the original 
regex meant, this new regex can be evaluated quickly, and is not subject to ReDOS.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://www.jroller.com/sebastianKuebeck/entry/detecting_and_preventing_redos_vulnerabilities">Sebastian Kubeck's Weblog: Detecting and Preventing ReDoS Vulnerabilities</a><br/>
<sup>[1]</sup> <a href="https://www.owasp.org/index.php/Regular_expression_Denial_of_Service_-_ReDoS">OWASP: Regular expression Denial of Service</a><br/>
<a href="http://cwe.mitre.org/data/definitions/400.html">CWE-400: Uncontrolled Resource Consumption ('Resource Exhaustion')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECRD">Regex DOS</BugCode>


    <!-- SAXParser XXE -->
    <Detector class="com.h3xstream.findsecbugs.xxe.SaxParserXxeDetector">
        <Details>Identify XML parser usage vulnerable to XXE</Details>
    </Detector>

    <BugPattern type="XXE_SAXPARSER">
        <ShortDescription>XML Parsing Vulnerable to XXE (SAXParser)</ShortDescription>
        <LongDescription>The usage of {3} is vulnerable to XML External Entity attacks</LongDescription>
        <Details>
            <![CDATA[
<!--XXE_GENERIC_START-->
<h3>Attack</h3>
<p>XML External Entity (XXE) attacks can occur when an XML parser supports XML entities while processing XML received
from an untrusted source.</p>
<p><b>Risk 1: Expose local file content (XXE: <u>X</u>ML e<u>X</u>ternal <u>E</u>ntity)</b></p>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot; encoding=&quot;ISO-8859-1&quot;?&gt;
&lt;!DOCTYPE foo [
   &lt;!ENTITY xxe SYSTEM &quot;file:///etc/passwd&quot; &gt; ]&gt;
&lt;foo&gt;&amp;xxe;&lt;/foo&gt;</pre>
</p>
<b>Risk 2: Denial of service (XEE: <u>X</u>ml <u>E</u>ntity <u>E</u>xpansion)</b>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot;?&gt;
&lt;!DOCTYPE lolz [
 &lt;!ENTITY lol &quot;lol&quot;&gt;
 &lt;!ELEMENT lolz (#PCDATA)&gt;
 &lt;!ENTITY lol1 &quot;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&quot;&gt;
 &lt;!ENTITY lol2 &quot;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&quot;&gt;
 &lt;!ENTITY lol3 &quot;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&quot;&gt;
[...]
 &lt;!ENTITY lol9 &quot;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&quot;&gt;
]&gt;
&lt;lolz&gt;&lol9;&lt;/lolz&gt;</pre>
</p>

<h3>Solution</h3>
<p>
In order to avoid exposing dangerous feature of the XML parser, you can do the following change to the code.
</p>
<!--XXE_GENERIC_END-->

<p><b>Vulnerable Code:</b></p>
<p>
<pre>
SAXParser parser = SAXParserFactory.newInstance().newSAXParser();

parser.parse(inputStream, customHandler);</pre>
</p>

<p><b>Solution using "Secure processing" mode:</b></p>
<p>
<pre>
SAXParserFactory spf = SAXParserFactory.newInstance();
spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
SAXParser parser = spf.newSAXParser();

parser.parse(inputStream, customHandler);</pre>
</p>

<p><b>Solution disabling DTD:</b></p>
<p>
<pre>
SAXParserFactory spf = SAXParserFactory.newInstance();
spf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
SAXParser parser = spf.newSAXParser();

parser.parse(inputStream, customHandler);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<!--XXE_GENERIC_START-->
<a href="http://cwe.mitre.org/data/definitions/611.html">CWE-611: Improper Restriction of XML External Entity Reference ('XXE')</a><br/>
<a href="https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=61702260">CERT: IDS10-J. Prevent XML external entity attacks</a><br/>
<a href="https://www.owasp.org/index.php/XML_External_Entity_%28XXE%29_Processing">OWASP.org: XML External Entity (XXE) Processing</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Expansion">WS-Attacks.org: XML Entity Expansion</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_External_Entity_DOS">WS-Attacks.org: XML External Entity DOS</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Reference_Attack">WS-Attacks.org: XML Entity Reference Attack</a><br/>
<!--XXE_GENERIC_END-->
<a href="http://xerces.apache.org/xerces-j/features.html">Xerces complete features list</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXXESAX">XXE Vulnerability using SAXParser</BugCode>

    <BugPattern type="XXE_XMLREADER">
        <ShortDescription>XML Parsing Vulnerable to XXE (XMLReader)</ShortDescription>
        <LongDescription>The usage of {3} is vulnerable to XML External Entity attacks</LongDescription>
        <Details>
            <![CDATA[
<!--XXE_GENERIC_START-->
<h3>Attack</h3>
<p>XML External Entity (XXE) attacks can occur when an XML parser supports XML entities while processing XML received
from an untrusted source.</p>
<p><b>Risk 1: Expose local file content (XXE: <u>X</u>ML e<u>X</u>ternal <u>E</u>ntity)</b></p>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot; encoding=&quot;ISO-8859-1&quot;?&gt;
&lt;!DOCTYPE foo [
   &lt;!ENTITY xxe SYSTEM &quot;file:///etc/passwd&quot; &gt; ]&gt;
&lt;foo&gt;&amp;xxe;&lt;/foo&gt;</pre>
</p>
<b>Risk 2: Denial of service (XEE: <u>X</u>ml <u>E</u>ntity <u>E</u>xpansion)</b>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot;?&gt;
&lt;!DOCTYPE lolz [
 &lt;!ENTITY lol &quot;lol&quot;&gt;
 &lt;!ELEMENT lolz (#PCDATA)&gt;
 &lt;!ENTITY lol1 &quot;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&quot;&gt;
 &lt;!ENTITY lol2 &quot;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&quot;&gt;
 &lt;!ENTITY lol3 &quot;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&quot;&gt;
[...]
 &lt;!ENTITY lol9 &quot;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&quot;&gt;
]&gt;
&lt;lolz&gt;&lol9;&lt;/lolz&gt;</pre>
</p>

<h3>Solution</h3>
<p>
In order to avoid exposing dangerous feature of the XML parser, you can do the following change to the code.
</p>
<!--XXE_GENERIC_END-->

<p><b>Vulnerable Code:</b></p>
<p>
<pre>
XMLReader reader = XMLReaderFactory.createXMLReader();
reader.setContentHandler(customHandler);
reader.parse(new InputSource(inputStream));</pre>
</p>

<p><b>Solution using "Secure processing" mode:</b></p>
<p>
<pre>
XMLReader reader = XMLReaderFactory.createXMLReader();
reader.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
reader.setContentHandler(customHandler);

reader.parse(new InputSource(inputStream));</pre>
</p>

<p><b>Solution disabling DTD:</b></p>
<p>
<pre>
XMLReader reader = XMLReaderFactory.createXMLReader();
reader.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
reader.setContentHandler(customHandler);

reader.parse(new InputSource(inputStream));</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<!--XXE_GENERIC_START-->
<a href="http://cwe.mitre.org/data/definitions/611.html">CWE-611: Improper Restriction of XML External Entity Reference ('XXE')</a><br/>
<a href="https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=61702260">CERT: IDS10-J. Prevent XML external entity attacks</a><br/>
<a href="https://www.owasp.org/index.php/XML_External_Entity_%28XXE%29_Processing">OWASP.org: XML External Entity (XXE) Processing</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Expansion">WS-Attacks.org: XML Entity Expansion</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_External_Entity_DOS">WS-Attacks.org: XML External Entity DOS</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Reference_Attack">WS-Attacks.org: XML Entity Reference Attack</a><br/>
<!--XXE_GENERIC_END-->
<a href="http://xerces.apache.org/xerces-j/features.html">Xerces complete features list</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXXEREAD">XXE Vulnerability using XMLReader</BugCode>

    <BugPattern type="XXE_DOCUMENT">
        <ShortDescription>XML Parsing Vulnerable to XXE (DocumentBuilder)</ShortDescription>
        <LongDescription>The usage of {3} is vulnerable to XML External Entity attacks</LongDescription>
        <Details>
            <![CDATA[
<!--XXE_GENERIC_START-->
<h3>Attack</h3>
<p>XML External Entity (XXE) attacks can occur when an XML parser supports XML entities while processing XML received
from an untrusted source.</p>
<p><b>Risk 1: Expose local file content (XXE: <u>X</u>ML e<u>X</u>ternal <u>E</u>ntity)</b></p>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot; encoding=&quot;ISO-8859-1&quot;?&gt;
&lt;!DOCTYPE foo [
   &lt;!ENTITY xxe SYSTEM &quot;file:///etc/passwd&quot; &gt; ]&gt;
&lt;foo&gt;&amp;xxe;&lt;/foo&gt;</pre>
</p>
<b>Risk 2: Denial of service (XEE: <u>X</u>ml <u>E</u>ntity <u>E</u>xpansion)</b>
<p>
<pre>
&lt;?xml version=&quot;1.0&quot;?&gt;
&lt;!DOCTYPE lolz [
 &lt;!ENTITY lol &quot;lol&quot;&gt;
 &lt;!ELEMENT lolz (#PCDATA)&gt;
 &lt;!ENTITY lol1 &quot;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&quot;&gt;
 &lt;!ENTITY lol2 &quot;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&quot;&gt;
 &lt;!ENTITY lol3 &quot;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&quot;&gt;
[...]
 &lt;!ENTITY lol9 &quot;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&lol8;&quot;&gt;
]&gt;
&lt;lolz&gt;&lol9;&lt;/lolz&gt;</pre>
</p>

<h3>Solution</h3>
<p>
In order to avoid exposing dangerous feature of the XML parser, you can do the following change to the code.
</p>
<!--XXE_GENERIC_END-->

<p><b>Vulnerable Code:</b></p>
<p>
<pre>
DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();

Document doc = db.parse(input);</pre>
</p>

<p><b>Solution using "Secure processing" mode:</b></p>
<p>
<pre>
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
DocumentBuilder db = dbf.newDocumentBuilder();

Document doc = db.parse(input);</pre>
</p>

<p><b>Solution disabling DTD:</b></p>
<p>
<pre>
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
DocumentBuilder db = dbf.newDocumentBuilder();

Document doc = db.parse(input);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<!--XXE_GENERIC_START-->
<a href="http://cwe.mitre.org/data/definitions/611.html">CWE-611: Improper Restriction of XML External Entity Reference ('XXE')</a><br/>
<a href="https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=61702260">CERT: IDS10-J. Prevent XML external entity attacks</a><br/>
<a href="https://www.owasp.org/index.php/XML_External_Entity_%28XXE%29_Processing">OWASP.org: XML External Entity (XXE) Processing</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Expansion">WS-Attacks.org: XML Entity Expansion</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_External_Entity_DOS">WS-Attacks.org: XML External Entity DOS</a><br/>
<a href="http://www.ws-attacks.org/index.php/XML_Entity_Reference_Attack">WS-Attacks.org: XML Entity Reference Attack</a><br/>
<!--XXE_GENERIC_END-->
<a href="http://xerces.apache.org/xerces2-j/features.html">Xerces2 complete features list</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXXEDOC">XXE Vulnerability using DocumentBuilder</BugCode>

    <!-- XPath Injection for Javax -->
    <Detector class="com.h3xstream.findsecbugs.xpath.XPathInjectionJavaxDetector">
        <Details>Find XPath query that use tainted input (javax.xml api)</Details>
    </Detector>

    <Detector class="com.h3xstream.findsecbugs.xpath.XPathInjectionApacheXPathApiDetector">
        <Details>Find XPath query that use tainted input (org.apache.xpath api)</Details>
    </Detector>

    <BugPattern type="XPATH_INJECTION">
        <ShortDescription>Potential XPath Injection</ShortDescription>
        <LongDescription>The use of {3} is vulnerable to XPath injection</LongDescription>
        <Details>
            <![CDATA[
<p>
XPath injection risks are similar to SQL injection. If the XPath query contains untrusted user input, the complete datasource
could be exposed. This could allow an attacker to access unauthorized data or maliciously modify the target XML.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246963/SQL%20Injection">WASC-39: XPath Injection</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/643.html">CWE-643: Improper Neutralization of Data within XPath Expressions ('XPath Injection')</a><br/>
<a href="https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=61407250">CERT: IDS09-J. Prevent XPath Injection (archive)</a><br/>
<a href="http://media.blackhat.com/bh-eu-12/Siddharth/bh-eu-12-Siddharth-Xpath-WP.pdf">Black Hat Europe 2012: Hacking XPath 2.0</a><br/>
<a href="http://www.balisage.net/Proceedings/vol7/html/Vlist02/BalisageVol7-Vlist02.html">Balisage: XQuery Injection</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXPI">XPath Injection</BugCode>

    <!-- Struts1 -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.Struts1EndpointDetector">
        <Details>Identify Struts 1 endpoint (also called Action)</Details>
    </Detector>

    <BugPattern type="STRUTS1_ENDPOINT">
        <ShortDescription>Found Struts 1 Action</ShortDescription>
        <LongDescription>{0} is a Struts 1 Endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This class is a Struts 1 Action.</p>
<p>Once a request is routed to this controller, a Form object will automatically be instantiated that contains the HTTP parameters. 
The use of these parameters should be reviewed to make sure they are used safely.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSTR1">Struts 1 Action</BugCode>

    <!-- Struts2 -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.Struts2EndpointDetector">
        <Details>Identify Struts 2 Endpoint</Details>
    </Detector>
    <BugPattern type="STRUTS2_ENDPOINT">
        <ShortDescription>Found Struts 2 Endpoint</ShortDescription>
        <LongDescription>{0} is a Struts 2 Endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>In Struts 2, the endpoints are Plain Old Java Objects (POJOs) which means no Interface/Class needs to be implemented/extended.</p>
<p>When a request is routed to its controller (like the selected class), the supplied HTTP parameters are automatically mapped to setters for
the class. Therefore, all setters of this class should be considered as untrusted input even if the form doesn't include those values. 
An attacker can simply provide additional values in the request, and they will be set in the object anyway, as long as that object has
such a setter. The use of these parameters should be reviewed to make sure they are used safely.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSTR2">Struts 2 Endpoint</BugCode>


    <!-- Spring Controller -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.SpringMvcEndpointDetector">
        <Details>Identify Spring Endpoint (also called Controller)</Details>
    </Detector>
    <BugPattern type="SPRING_ENDPOINT">
        <ShortDescription>Found Spring Endpoint</ShortDescription>
        <LongDescription>{0} is a Spring Controller</LongDescription>
        <Details>
            <![CDATA[
<p>This class is a Spring Controller. All methods annotated with <code>RequestMapping</code> are reachable remotely.
This class should be analyzed to make sure that remotely exposed methods are safe to expose to potential attackers.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSC">Spring Endpoint</BugCode>


    <!-- Custom Injection -->
    <Detector class="com.h3xstream.findsecbugs.injection.custom.CustomInjectionDetector">
        <Details>Detector that find injection for custom methods.</Details>
    </Detector>

    <BugPattern type="CUSTOM_INJECTION">
        <ShortDescription>Potential Injection</ShortDescription>
        <LongDescription>The use of the method {0} is potentially vulnerable injection.</LongDescription>
        <Details>
            <![CDATA[
<p>
The method is susceptible to injection. The input should be validated and properly escaped.
</p>
<p>
    <b>Vulnerable code samples:</b><br/>
    <pre>SqlUtil.execQuery("select * from UserEntity t where id = " + parameterInput);</pre>
</p>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246963/SQL%20Injection">WASC-19: SQL Injection</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="https://www.owasp.org/index.php/SQL_Injection_Prevention_Cheat_Sheet">OWASP: SQL Injection Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Query_Parameterization_Cheat_Sheet">OWASP: Query Parameterization Cheat Sheet</a><br/>
<a href="http://capec.mitre.org/data/definitions/66.html">CAPEC-66: SQL Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/89.html">CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCUSTOMI">Custom Injection</BugCode>


    <!-- SQL Injection -->
    <Detector class="com.h3xstream.findsecbugs.injection.sql.SqlInjectionDetector">
        <Details>Identify various kinds of SQL Injection in SQL APIs that accept strings.</Details>
    </Detector>


    <!-- HQL Injection -->
    <BugPattern type="SQL_INJECTION_HIBERNATE">
        <ShortDescription>Potential SQL/HQL Injection (Hibernate)</ShortDescription>
        <LongDescription>The query is potentially vulnerable SQL/HQL injection</LongDescription>
        <Details>
            <![CDATA[
<p>
The input values included in SQL queries need to be passed in safely.
Bind variables in prepared statements can be use to easily mitigate the risk of SQL injection.
Alternatively to prepare statement, Hibernate Criteria can be used.
</p>
<p>
    <b>Vulnerable Code:</b><br/>
    <pre>
Session session = sessionFactory.openSession();
Query q = session.createQuery("select t from UserEntity t where id = " + input);
q.execute();</pre>
</p>
<p>
    <b>Solution:</b><br/>
    <pre>
Session session = sessionFactory.openSession();
Query q = session.createQuery("select t from UserEntity t where id = :userId");
q.setString("userId",input);
q.execute();</pre>
</p>
<p>
    <b>Solution for dynamic queries (with Hibernate Criteria):</b><br/>
    <pre>
Session session = sessionFactory.openSession();
Query q = session.createCriteria(UserEntity.class)
    .add( Restrictions.like("id", input) )
    .list();
q.execute();</pre>
</p>
<br/>
<p>
<b>References (Hibernate)</b><br/>
<a href="https://docs.jboss.org/hibernate/orm/3.3/reference/en/html/querycriteria.html">Hibernate Documentation: Query Criteria</a><br/>
<a href="https://docs.jboss.org/hibernate/orm/3.2/api/org/hibernate/Query.html">Hibernate Javadoc: Query Object</a><br/>
<a href="http://blog.h3xstream.com/2014/02/hql-for-pentesters.html">HQL for pentesters</a>: Guideline to test if the suspected code is exploitable.<br/>
<b>References (SQL injection)</b><br/>
<a href="http://projects.webappsec.org/w/page/13246963/SQL%20Injection">WASC-19: SQL Injection</a><br/>
<a href="http://capec.mitre.org/data/definitions/66.html">CAPEC-66: SQL Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/89.html">CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')</a>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="https://www.owasp.org/index.php/SQL_Injection_Prevention_Cheat_Sheet">OWASP: SQL Injection Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Query_Parameterization_Cheat_Sheet">OWASP: Query Parameterization Cheat Sheet</a><br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSQLIHIB">HQL Injection</BugCode>

    <!-- JDOQL Injection -->
    <BugPattern type="SQL_INJECTION_JDO">
        <ShortDescription>Potential SQL/JDOQL Injection (JDO)</ShortDescription>
        <LongDescription>The query is potentially vulnerable SQL/JDOQL injection</LongDescription>
        <Details>
            <![CDATA[
<p>
The input values included in SQL queries need to be passed in safely.
Bind variables in prepared statements can be use to easily mitigate the risk of SQL injection.
</p>
<p>
    <b>Vulnerable Code:</b><br/>
    <pre>
PersistenceManager pm = getPM();

Query q = pm.newQuery("select * from Users where name = " + input);
q.execute();</pre>
</p>
<p>
    <b>Solution:</b><br/>
    <pre>
PersistenceManager pm = getPM();

Query q = pm.newQuery("select * from Users where name = nameParam");
q.declareParameters("String nameParam");
q.execute(input);</pre>
</p>
<br/>
<p>
<b>References (JDO)</b><br/>
<a href="https://db.apache.org/jdo/object_retrieval.html">JDO: Object Retrieval</a><br/>
<b>References (SQL injection)</b><br/>
<a href="http://projects.webappsec.org/w/page/13246963/SQL%20Injection">WASC-19: SQL Injection</a><br/>
<a href="http://capec.mitre.org/data/definitions/66.html">CAPEC-66: SQL Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/89.html">CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')</a>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="https://www.owasp.org/index.php/SQL_Injection_Prevention_Cheat_Sheet">OWASP: SQL Injection Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Query_Parameterization_Cheat_Sheet">OWASP: Query Parameterization Cheat Sheet</a><br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSQLIJDO">SQL Injection (JDO)</BugCode>

    <!-- JPQL Injection -->
    <BugPattern type="SQL_INJECTION_JPA">
        <ShortDescription>Potential SQL/JPQL Injection (JPA)</ShortDescription>
        <LongDescription>The query is potentially vulnerable SQL/JPQL injection</LongDescription>
        <Details>
            <![CDATA[
<p>
The input values included in SQL queries need to be passed in safely.
Bind variables in prepared statements can be use to easily mitigate the risk of SQL injection.
</p>
<p>
    <b>Vulnerable Code:</b><br/>
    <pre>
EntityManager pm = getEM();

TypedQuery<UserEntity> q = em.createQuery(
    String.format("select * from Users where name = %s", username),
    UserEntity.class);

UserEntity res = q.getSingleResult();</pre>
</p>
<p>
    <b>Solution:</b><br/>
    <pre>
TypedQuery<UserEntity> q = em.createQuery(
    "select * from Users where name = usernameParam",UserEntity.class)
    .setParameter("usernameParam", username);

UserEntity res = q.getSingleResult();</pre>
</p>
<br/>
<p>
<b>References (JPA)</b><br/>
<a href="http://docs.oracle.com/javaee/6/tutorial/doc/bnbrg.html">The Java EE 6 Tutorial: Creating Queries Using the Java Persistence Query Language</a><br/>
<b>References (SQL injection)</b><br/>
<a href="http://projects.webappsec.org/w/page/13246963/SQL%20Injection">WASC-19: SQL Injection</a><br/>
<a href="http://capec.mitre.org/data/definitions/66.html">CAPEC-66: SQL Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/89.html">CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')</a>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="https://www.owasp.org/index.php/SQL_Injection_Prevention_Cheat_Sheet">OWASP: SQL Injection Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Query_Parameterization_Cheat_Sheet">OWASP: Query Parameterization Cheat Sheet</a><br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSQLIJPA">SQL Injection (JPA)</BugCode>

    <!-- LDAP Injection -->
    <Detector class="com.h3xstream.findsecbugs.injection.ldap.LdapInjectionDetector">
        <Details>Identify various kinds of LDAP Injection in JNDI and UnboundID APIs.</Details>
    </Detector>

    <BugPattern type="LDAP_INJECTION">
        <ShortDescription>Potential LDAP Injection</ShortDescription>
        <LongDescription>The query could be vulnerable to LDAP injection</LongDescription>
        <Details>
            <![CDATA[
<p>
Just like SQL, all inputs passed to an LDAP query need to be passed in safely. Unfortunately, LDAP doesn't have prepared statement interfaces like SQL.
Therefore, the primary defense against LDAP injection is strong input validation of any untrusted data before including it in an LDAP query.
</p>
<p>
    <b>Code at risk:</b><br/>
    <pre>NamingEnumeration<SearchResult> answers = context.search("dc=People,dc=example,dc=com",
        "(uid=" + username + ")", ctrls);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246947/LDAP%20Injection">WASC-29: LDAP Injection</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A1-Injection">OWASP: Top 10 2013-A1-Injection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/90.html">CWE-90: Improper Neutralization of Special Elements used in an LDAP Query ('LDAP Injection')</a><br/>
<a href="http://www.veracode.com/security/ldap-injection">LDAP Injection Guide: Learn How to Detect LDAP Injections and Improve LDAP Security</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECLDAPI">LDAP Injection</BugCode>


    <!-- Script Engine Code injection -->
    <Detector class="com.h3xstream.findsecbugs.injection.script.ScriptInjectionDetector">
        <Details>Identify various kind of code injection.</Details>
    </Detector>

    <BugPattern type="SCRIPT_ENGINE_INJECTION">
        <ShortDescription>Potential code injection when using Script Engine</ShortDescription>
        <LongDescription>This code evaluation could be vulnerable code injection</LongDescription>
        <Details>
            <![CDATA[
<p>
    Dymanic code is being evaluate. A careful analysis of the code construction should be made. Malicious code execution
    could lead to data leakage or operating system compromised.
</p>
<p>
    If the evaluation of user code is intended, a proper sandboxing should be applied (see references).
</p>

<p><b>Code at risk:</b></p>
<p>
<pre>
public void runCustomTrigger(String script) {
    ScriptEngineManager factory = new ScriptEngineManager();
    ScriptEngine engine = factory.getEngineByName("JavaScript");

    engine.eval(script); //Bad things can happen here.
}</pre>
</p>

<p><b>Solution:</b></p>
<p>
Safe evaluation of Javascript code using "Cloudbees Rhino Sandbox" library.<br/>
<pre>
public void runCustomTrigger(String script) {
    SandboxContextFactory contextFactory = new SandboxContextFactory();
    Context context = contextFactory.makeContext();
    contextFactory.enterContext(context);
    try {
        ScriptableObject prototype = context.initStandardObjects();
        prototype.setParentScope(null);
        Scriptable scope = context.newObject(prototype);
        scope.setPrototype(prototype);

        context.evaluateString(scope,script, null, -1, null);
    } finally {
        context.exit();
    }
}</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="https://github.com/cloudbees/rhino-sandbox">Cloudbees Rhino Sandbox</a>: Utility to create sandbox with Rhino (block access to all classes)<br/>
<a href="http://codeutopia.net/blog/2009/01/02/sandboxing-rhino-in-java/">CodeUtopia.net: Sandboxing Rhino in Java</a><br/>
<a href="http://blog.h3xstream.com/2014/11/remote-code-execution-by-design.html">Remote Code Execution .. by design</a>: Example of malicious payload. The samples given could be use to test sandboxing rules.<br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SCRIPTE">Script Engine Injection</BugCode>

    <!-- SPEL Code injection -->
    <Detector class="com.h3xstream.findsecbugs.injection.script.SpelInjectionDetector">
        <Details>Identify usage of Spring Expression Language with potentially malicious input.</Details>
    </Detector>

    <BugPattern type="SPEL_INJECTION">
        <ShortDescription>Potential code injection when using Spring Expression</ShortDescription>
        <LongDescription>This code evaluation could be vulnerable code injection</LongDescription>
        <Details>
            <![CDATA[
<p>
    A Spring expression is built with a dynamic value. The source of the value(s) should be verified to avoid
    that unfiltered values fall into this risky code evaluation.
</p>
<p><b>Code at risk:</b></p>
<p>
<pre>
public void parseExpressionInterface(Person personObj,String property) {

        ExpressionParser parser = new SpelExpressionParser();

        //Unsafe if the input is control by the user..
        Expression exp = parser.parseExpression(property+" == 'Albert'");

        StandardEvaluationContext testContext = new StandardEvaluationContext(personObj);
        boolean result = exp.getValue(testContext, Boolean.class);
[...]</pre>
</p>
<br/>
<p>
    <b>References</b><br/>
    <a href="http://cwe.mitre.org/data/definitions/95.html">CWE-95: Improper Neutralization of Directives in Dynamically Evaluated Code ('Eval Injection')</a><br/>
    <a href="http://cwe.mitre.org/data/definitions/94.html">CWE-94: Improper Control of Generation of Code ('Code Injection')</a><br/>
    <a href="http://docs.spring.io/spring-framework/docs/3.2.x/spring-framework-reference/html/expressions.html">Spring Expression Language (SpEL) - Official Documentation</a><br/>
    <a href="https://www.mindedsecurity.com/fileshare/ExpressionLanguageInjection.pdf">Minded Security: Expression Language Injection</a><br/>
    <a href="http://blog.h3xstream.com/2014/11/remote-code-execution-by-design.html">Remote Code Execution .. by design</a>: Example of malicious payload. The samples given could be use to test sandboxing rules.<br/>
</p>

]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SPELI">Spring Expression Language Injection</BugCode>


    <!-- Bad Hexa -->
    <Detector class="com.h3xstream.findsecbugs.crypto.BadHexadecimalConversionDetector">
        <Details>Identify Bad hexadecimal concatenation</Details>
    </Detector>
    <BugPattern type="BAD_HEXA_CONVERSION">
        <ShortDescription>Bad hexadecimal concatenation</ShortDescription>
        <LongDescription>Leading zero are omit in the concatenation increasing collision potential.</LongDescription>
        <Details>
            <![CDATA[
<p>When converting a byte array containing a hash signature to a human readable string, a conversion mistake can be made if 
the array is read byte by byte. The following sample illustrates the use of Integer.toHexString() which will trim any leading zeroes
from each byte of the computed hash value.
<pre>
MessageDigest md = MessageDigest.getInstance("SHA-1");
byte[] resultBytes = md.digest(password.getBytes("UTF-8"));

StringBuilder stringBuilder = new StringBuilder();
for(byte b :resultBytes) {
    stringBuilder.append( Integer.toHexString( b & 0xFF ) );
}

return stringBuilder.toString();</pre>
</p>
<p>
This mistake weakens the hash value computed since it introduces more collisions. 
For example, the hash values "0x0679" and "0x6709" would both output as "679" for the above function.
</p>

<p>
In this situation, the use of toHexString() should be replaced with String.format() as follows:
<pre>
stringBuilder.append( String.format( "%02X", b ) );</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://cwe.mitre.org/data/definitions/704.html">CWE-704: Incorrect Type Conversion or Cast</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECBHC">Bad hexadecimal concatenation</BugCode>


    <!-- Hazelcast Symmetric encryption -->
    <Detector class="com.h3xstream.findsecbugs.crypto.HazelcastSymmetricEncryptionDetector">
        <Details>Hazelcast Symmetric Encryption Unsafe</Details>
    </Detector>
    <BugPattern type="HAZELCAST_SYMMETRIC_ENCRYPTION">
        <ShortDescription>Hazelcast Symmetric Encryption</ShortDescription>
        <LongDescription>The network communication for Hazelcast are configured to use a symmetric cipher</LongDescription>
        <Details>
            <![CDATA[
<p>The network communications for Hazelcast is configured to use a symmetric cipher (probably DES or blowfish).</p>
<p>Those ciphers alone do not provide integrity or secure authentication. The use of asymmetric encryption is preferred.</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246945/Insufficient%20Transport%20Layer%20Protection">WASC-04: Insufficient Transport Layer Protection</a><br/>
<a href="http://www.hazelcast.com/documentation.jsp#Encryption">Hazelcast Documentation: Encryption (see second part)</a><br/>
<a href="http://cwe.mitre.org/data/definitions/326.html">CWE-326: Inadequate Encryption Strength</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECHAZ">Hazelcast Symmetric Encryption</BugCode>


    <!-- NullCipher's use -->
    <Detector class="com.h3xstream.findsecbugs.crypto.NullCipherDetector">
        <Details>Identify the use of NullCipher</Details>
    </Detector>
    <BugPattern type="NULL_CIPHER">
        <ShortDescription>NullCipher Unsafe</ShortDescription>
        <LongDescription>The use of a NullCipher is typically not desirable</LongDescription>
        <Details>
            <![CDATA[
<p>
The NullCipher is rarely used intentionally in production applications. It implements the Cipher interface by returning ciphertext 
identical to the supplied plaintext. In a few contexts, such as testing, a NullCipher may be appropriate.
</p>
<p>
    <b>Vulnerable Code:</b><br/>
<pre>Cipher doNothingCihper = new NullCipher();
[...]
//The ciphertext produced will be identical to the plaintext.
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
    <b>Solution:</b><br/>
    Avoid using the NullCipher. Its accidental use can introduce a significant confidentiality risk.
</p>
<br/>
<p>
<b>Reference</b><br/>
<a href="http://cwe.mitre.org/data/definitions/327.html">CWE-327: Use of a Broken or Risky Cryptographic Algorithm</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECNC">NullCipher</BugCode>


    <!-- Unencrypted Socket encryption -->
    <Detector class="com.h3xstream.findsecbugs.crypto.UnencryptedSocketDetector">
        <Details>Unencrypted Socket</Details>
    </Detector>
    <BugPattern type="UNENCRYPTED_SOCKET">
        <ShortDescription>Unencrypted Socket</ShortDescription>
        <LongDescription>Unencrypted socket to {0} (instead of SSLSocket)</LongDescription>
        <Details>
            <![CDATA[
<p>
The communication channel used is not encrypted. The traffic could be read by an attacker intercepting the network traffic.
</p>
<p>
<b>Vulnerable Code:</b><br/>
Plain socket (Cleartext communication):
<pre>Socket soc = new Socket("www.google.com",80);</pre>
</p>
<p>
<b>Solution:</b><br/>
SSL Socket (Secure communication):
<pre>Socket soc = SSLSocketFactory.getDefault().createSocket("www.google.com", 443);</pre>
</p>
<p>Beyond using an SSL socket, you need to make sure your use of SSLSocketFactory does all the appropriate certificate validation checks to
make sure you are not subject to man-in-the-middle attacks. Please read the OWASP Transport Layer Protection Cheat Sheet for details on how
to do this correctly.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/Top_10_2010-A9">OWASP: Top 10 2010-A9-Insufficient Transport Layer Protection</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A6-Sensitive_Data_Exposure">OWASP: Top 10 2013-A6-Sensitive Data Exposure</a><br/>
<a href="https://www.owasp.org/index.php/Transport_Layer_Protection_Cheat_Sheet">OWASP: Transport Layer Protection Cheat Sheet</a><br/>
<a href="http://projects.webappsec.org/w/page/13246945/Insufficient%20Transport%20Layer%20Protection">WASC-04: Insufficient Transport Layer Protection</a><br/>
<a href="http://cwe.mitre.org/data/definitions/319.html">CWE-319: Cleartext Transmission of Sensitive Information</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECUS">Unencrypted Socket</BugCode>


    <!-- DES usage -->
    <Detector class="com.h3xstream.findsecbugs.crypto.DesUsageDetector">
        <Details>DES / DESede should be replace by AES</Details>
    </Detector>
    <BugPattern type="DES_USAGE">
        <ShortDescription>DES / DESede Unsafe</ShortDescription>
        <LongDescription>DES / DESede should be replaced with AES</LongDescription>
        <Details>
            <![CDATA[
<p>
DES and DESede (3DES) are not considered strong ciphers for modern applications. Currently, NIST recommends the 
usage of AES block ciphers instead of DES/3DES.
</p>
<p>
    <b>Example weak code:</b>
<pre>Cipher c = Cipher.getInstance("DESede/ECB/PKCS5Padding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
    <b>Example solution:</b>
    <pre>Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://www.nist.gov/itl/fips/060205_des.cfm">NIST Withdraws Outdated Data Encryption Standard</a><br/>
<a href="http://cwe.mitre.org/data/definitions/326.html">CWE-326: Inadequate Encryption Strength</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECDU">DES / DESede</BugCode>


    <!-- RSA NoPadding -->
    <Detector class="com.h3xstream.findsecbugs.crypto.RsaNoPaddingDetector">
        <Details>RSA cipher without proper padding</Details>
    </Detector>
    <BugPattern type="RSA_NO_PADDING">
        <ShortDescription>RSA NoPadding Unsafe</ShortDescription>
        <LongDescription>Use of RSA cipher without proper padding</LongDescription>
        <Details>
            <![CDATA[
<p>
The software uses the RSA algorithm but does not incorporate Optimal Asymmetric Encryption Padding (OAEP), which might weaken the encryption.
</p>
<p>
<b>Vulnerable Code:</b><br/>
<pre>Cipher.getInstance("RSA/NONE/NoPadding")</pre>
</p>
<p>
<b>Solution:</b><br/>
The code should be replaced with:<br/>
<pre>Cipher.getInstance("RSA/ECB/OAEPWithMD5AndMGF1Padding")</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://cwe.mitre.org/data/definitions/780.html">CWE-780: Use of RSA Algorithm without OAEP</a><br/>
<a href="http://rdist.root.org/2009/10/06/why-rsa-encryption-padding-is-critical/">Root Labs: Why RSA encryption padding is critical</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECRNP">RSA NoPadding</BugCode>


    <!-- Hard coded Google API key -->
    <Detector class="com.h3xstream.findsecbugs.password.GoogleApiKeyDetector">
        <Details>Identify hardcoded Google API key</Details>
    </Detector>

    <!-- Hard coded JNDI credentials -->
    <Detector class="com.h3xstream.findsecbugs.password.JndiCredentialsDetector">
        <Details>Identify hardcoded credentials in context initialization</Details>
    </Detector>

    <BugPattern type="HARD_CODE_PASSWORD">
        <ShortDescription>Hard Coded Password</ShortDescription>
        <LongDescription>Hard coded password found</LongDescription>
        <Details>
            <![CDATA[
<p>
Passwords should not be kept in the source code. The source code can be widely shared in an enterprise environment, and is
certainly shared in open source. To be managed safely, passwords and secret keys should be stored in separate configuration files or keystores.
</p>
<p>
<p><b>Vulnerable Code:</b><br/>

<pre>private String SECRET_PASSWORD = "letMeIn!";

Properties props = new Properties();
props.put(Context.SECURITY_CREDENTIALS, "p@ssw0rd");</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://cwe.mitre.org/data/definitions/321.html">CWE-321: Use of Hard-coded Cryptographic Key</a><br/>
<a href="http://cwe.mitre.org/data/definitions/259.html">CWE-259: Use of Hard-coded Password</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECHCP">Hard Coded Password</BugCode>


    <!-- Struts Form Validation -->
    <Detector class="com.h3xstream.findsecbugs.StrutsValidatorFormDetector">
        <Details>Identify Struts Form with no input validation</Details>
    </Detector>
    <BugPattern type="STRUTS_FORM_VALIDATION">
        <ShortDescription>Struts Form Without Input Validation</ShortDescription>
        <LongDescription>Struts Form with no input validation</LongDescription>
        <Details>
            <![CDATA[
<p>
Form inputs should have minimal input validation. Preventive validation helps provide defense in depth against a variety of risks.
</p>
<p>
Validation can be introduce by implementing a <code>validate</code> method.
<pre>
public class RegistrationForm extends ValidatorForm {

    private String name;
    private String email;

    [...]

    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
        //Validation code for name and email parameters passed in via the HttpRequest goes here
    }
}
</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://cwe.mitre.org/data/definitions/20.html">CWE-20: Improper Input Validation</a><br/>
<a href="http://cwe.mitre.org/data/definitions/106.html">CWE-106: Struts: Plug-in Framework not in Use</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSFV">Struts Form Without Input Validation</BugCode>


    <!-- XSS Filter -->
    <Detector class="com.h3xstream.findsecbugs.xss.XSSRequestWrapperDetector">
        <Details>Identify XSSRequestWrapper (weak XSS protection)</Details>
    </Detector>
    <BugPattern type="XSS_REQUEST_WRAPPER">
        <ShortDescription>XSSRequestWrapper is Weak XSS Protection</ShortDescription>
        <LongDescription>XSSRequestWrapper is a weak XSS protection mechanism</LongDescription>
        <Details>
            <![CDATA[
<p>
An implementation of <code>HttpServletRequestWrapper</code> called <code>XSSRequestWrapper</code> was published through
various blog sites. <sup><a href="http://java.dzone.com/articles/stronger-anti-cross-site">[1]</a></sup>
<sup><a href="http://www.javacodegeeks.com/2012/07/anti-cross-site-scripting-xss-filter.html">[2]</a></sup>
</p>
<p>
The filtering is weak for a few reasons:
<ul>
<li>It covers only parameters not headers and side-channel inputs</li>
<li>The replace chain can be bypass easily (see example below)</li>
<li>It's a black list of very specific bad patterns (rather than a white list of good/valid input)</li>
</ul>
</p>
<p>
<b>Example of bypass:</b><br/>
</p>
<pre>&lt;scrivbscript:pt&gt;alert(1)&lt;/scrivbscript:pt&gt;</pre>
<p>
The previous input will be transformed into <b><code>"&lt;script&gt;alert(1)&lt;/script&gt;"</code></b>.
The removal of <code>"vbscript:"</code> is after the replacement of <code>"&lt;script&gt;.*&lt;/script&gt;"</code>.
</p>
<p>
For stronger protection, choose a solution that encodes characters automatically in the <b><u>view</u></b> (template, jsp, ...) following
the XSS protection rules defined in the OWASP XSS Prevention Cheat Sheet.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246920/Cross%20Site%20Scripting">WASC-8: Cross Site Scripting</a><br/>
<a href="https://www.owasp.org/index.php/XSS_%28Cross_Site_Scripting%29_Prevention_Cheat_Sheet">OWASP: XSS Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A3-Cross-Site_Scripting_%28XSS%29">OWASP: Top 10 2013-A3: Cross-Site Scripting (XSS)</a><br/>
<a href="http://cwe.mitre.org/data/definitions/79.html">CWE-79: Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting')</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXRW">XSSRequestWrapper (weak XSS protection)</BugCode>


    <!-- Blowfish key size -->
    <Detector class="com.h3xstream.findsecbugs.crypto.InsufficientKeySizeBlowfishDetector">
        <Details>Identify Blowfish usage with weak key size</Details>
    </Detector>
    <BugPattern type="BLOWFISH_KEY_SIZE">
        <ShortDescription>Blowfish Usage with Weak Key Size</ShortDescription>
        <LongDescription>Blowfish usage with weak key size</LongDescription>
        <Details>
            <![CDATA[
<p>
The Blowfish cipher supports keysizes from 32 bits to 448 bits. A small key size makes the ciphertext vulnerable to brute force attacks.
At least 128 bits of entropy should be used when generating the key if the usage of Blowfish must be retained.
</p>
<p>
If the algorithm can be changed, the AES block cipher should be used instead.
</p>

<p><b>Vulnerable Code:</b><br/>
<pre>KeyGenerator keyGen = KeyGenerator.getInstance("Blowfish");
keyGen.init(64);</pre>
</p>

<p><b>Solution:</b><br/>
<pre>KeyGenerator keyGen = KeyGenerator.getInstance("Blowfish");
keyGen.init(128);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://en.wikipedia.org/wiki/Blowfish_(cipher)">Blowfish (cipher)</a><br/>
<a href="http://cwe.mitre.org/data/definitions/326.html">CWE-326: Inadequate Encryption Strength</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECBKS">Blowfish usage with weak key size</BugCode>


    <!-- RSA key size -->
    <Detector class="com.h3xstream.findsecbugs.crypto.InsufficientKeySizeRsaDetector">
        <Details>Identify RSA usage with weak key size</Details>
    </Detector>
    <BugPattern type="RSA_KEY_SIZE">
        <ShortDescription>RSA Usage with Weak Key Size</ShortDescription>
        <LongDescription>RSA usage with weak key size</LongDescription>
        <Details>
            <![CDATA[
<p>"RSA Laboratories currently recommends key sizes of 1024 bits for corporate use and 2048 bits for extremely valuable keys 
like the root key pair used by a certifying authority". <sup>[1]</sup></p>

<p><b>Vulnerable Code:</b><br/>
<pre>
KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
keyGen.initialize(512);
</pre>
</p>

<p><b>Solution:</b><br/>
The KeyPairGenerator creation should be as follows with at least 2048 bit key size.<br/>
<pre>
KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
keyGen.initialize(2048);
</pre>
</p>
<br/>
<p>
<b>References</b><br/>
[1] <a href="http://www.emc.com/emc-plus/rsa-labs/standards-initiatives/how-large-a-key-should-be-used.htm">RSA Laboratories: 3.1.5 How large a key should be used in the RSA cryptosystem?</a><br/>
<a href="http://en.wikipedia.org/wiki/Key_size#Asymmetric%5Falgorithm%5Fkey%5Flengths">Wikipedia: Asymmetric algorithm key lengths</a><br/>
<a href="http://cwe.mitre.org/data/definitions/326.html">CWE-326: Inadequate Encryption Strength</a><br/>
<a href="http://www.keylength.com/en/compare/">Keylength.com (BlueKrypt): Aggregate key length recommendations.</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECRKS">RSA usage with weak key size</BugCode>

    <!-- Unvalidated redirect -->
    <Detector class="com.h3xstream.findsecbugs.injection.redirect.UnvalidatedRedirectDetector">
        <Details>Identify unvalidated redirects</Details>
    </Detector>
    <BugPattern type="UNVALIDATED_REDIRECT">
        <ShortDescription>Unvalidated Redirect</ShortDescription>
        <LongDescription>Unvalidated Redirect</LongDescription>
        <Details>
            <![CDATA[
<p>
    Unvalidated redirects occur when an application redirects a user to a destination URL specified by a user supplied
    parameter that is not validated. Such vulnerabilities can be used to facilitate phishing attacks.
</p>
<p>
    <b>Scenario</b><br/>
    1. A user is tricked into visiting the malicious URL: http://website.com/login?redirect=http://evil.vvebsite.com/fake/login<br/>
    2. The user is redirected to a fake login page that looks like a site they trust. (http://evil.vvebsite.com/fake/login)<br/>
    3. The user enters his credentials.<br/>
    4. The evil site steals the user's credentials and redirects him to the original website.<br/>
    <br/>
    This attack is plausible because most users don't double check the URL after the redirection. Also, redirection to
    an authentication page is very common.
</p>
<p>
    <b>Vulnerable Code:</b></br/>
    <pre>protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    [...]
    resp.sendRedirect(req.getParameter("redirectUrl"));
    [...]
}</pre>
</p>
<p>
    <b>Solution/Countermeasures:</b><br/>
    <ul>
        <li>Don't accept redirection destinations from users</li>
        <li>Accept a destination key, and use it to look up the target (legal) destination</li>
        <li>Accept only relative paths</li>
        <li>White list URLs (if possible)</li>
        <li>Validate that the beginning of the URL is part of a white list</li>
    </ul>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246981/URL%20Redirector%20Abuse">WASC-38: URL Redirector Abuse</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A10-Unvalidated_Redirects_and_Forwards">OWASP: Top 10 2013-A10: Unvalidated Redirects and Forwards</a><br/>
<a href="https://www.owasp.org/index.php/Unvalidated_Redirects_and_Forwards_Cheat_Sheet">OWASP: Unvalidated Redirects and Forwards Cheat Sheet</a><br/>
<a href="http://cwe.mitre.org/data/definitions/601.html">CWE-601: URL Redirection to Untrusted Site ('Open Redirect')</a>
</p>
            ]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECUR">Unvalidated Redirect</BugCode>


    <!-- XSS in JSP -->
    <Detector class="com.h3xstream.findsecbugs.jsp.JspXssDetector">
        <Details>Identify tainted inputs in JSP views.</Details>
    </Detector>
    <BugPattern type="XSS_JSP_PRINT">
        <ShortDescription>Potential XSS in JSP</ShortDescription>
        <LongDescription>Potential XSS in JSP</LongDescription>
        <Details>
            <![CDATA[
<p>NOTE: If you want this rule to work, you have to precompile your JSPs (which usually isn't done in most build environments)
and then provide FindBugs the path information to the generated class files and the original JSPs themselves. If you are seeing
findings for this rule, you know you have your environment set up properly. Also, this XSS in JSP rule looks for similar issues,
but looks for them in a different way than the existing 'XSS: JSP reflected cross site scripting vulnerability' rule in FindBugs.</p>
<p>A potential XSS was found. It could be used to execute unwanted JavaScript in a client's browser. (See references)
</p>
<p>
    <b>Vulnerable Code:</b>
    <pre><%
String taintedInput = (String) request.getAttribute("input");
%>
[...]
<%= taintedInput %></pre>
</p>
<p>
    <b>Solution:</b>
    <pre>
<%
String taintedInput = (String) request.getAttribute("input");
%>
[...]
<%= Encode.forHtml(taintedInput) %>
    </pre>
</p>
<p>
The best defense against XSS is context sensitive output encoding like the example above. There are typically 4 contexts to consider: 
HTML, JavaScript, CSS (styles), and URLs. Please follow the XSS protection rules defined in the OWASP XSS Prevention Cheat Sheet,
which explains these defenses in significant detail.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246920/Cross%20Site%20Scripting">WASC-8: Cross Site Scripting</a><br/>
<a href="https://www.owasp.org/index.php/XSS_%28Cross_Site_Scripting%29_Prevention_Cheat_Sheet">OWASP: XSS Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A3-Cross-Site_Scripting_%28XSS%29">OWASP: Top 10 2013-A3: Cross-Site Scripting (XSS)</a><br/>
<a href="http://cwe.mitre.org/data/definitions/79.html">CWE-79: Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting')</a><br/>
<a href="https://code.google.com/p/owasp-java-encoder/">OWASP Java Encoder</a><br/>
</p>
            ]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXSS1">Potential XSS in JSP</BugCode>


    <!-- XSS in Servlet -->
    <BugPattern type="XSS_SERVLET">
        <ShortDescription>Potential XSS in Servlet</ShortDescription>
        <LongDescription>Potential XSS in Servlet</LongDescription>
        <Details>
            <![CDATA[
<p>
A potential XSS was found. It could be used to execute unwanted JavaScript in a client's browser. (See references)
</p>
<p>
    <b>Vulnerable Code:</b>
<pre>protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String input1 = req.getParameter("input1");
    [...]
    resp.getWriter().write(input1);
}</pre>
</p>
<p>
    <b>Solution:</b>
<pre>protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String input1 = req.getParameter("input1");
    [...]
    resp.getWriter().write(Encode.forHtml(input1));
}</pre>
</p>
<p>
The best defense against XSS is context sensitive output encoding like the example above. There are typically 4 contexts to consider: 
HTML, JavaScript, CSS (styles), and URLs. Please follow the XSS protection rules defined in the OWASP XSS Prevention Cheat Sheet,
which explains these defenses in significant detail.
</p>
<p>Note that this XSS in Servlet rule looks for similar issues, but looks for them in a different way than the existing 
'XSS: Servlet reflected cross site scripting vulnerability' and 'XSS: Servlet reflected cross site scripting vulnerability in error page' rules in FindBugs.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://projects.webappsec.org/w/page/13246920/Cross%20Site%20Scripting">WASC-8: Cross Site Scripting</a><br/>
<a href="https://www.owasp.org/index.php/XSS_%28Cross_Site_Scripting%29_Prevention_Cheat_Sheet">OWASP: XSS Prevention Cheat Sheet</a><br/>
<a href="https://www.owasp.org/index.php/Top_10_2013-A3-Cross-Site_Scripting_%28XSS%29">OWASP: Top 10 2013-A3: Cross-Site Scripting (XSS)</a><br/>
<a href="http://cwe.mitre.org/data/definitions/79.html">CWE-79: Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting')</a><br/>
<a href="https://code.google.com/p/owasp-java-encoder/">OWASP Java Encoder</a><br/>
</p>
            ]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXSS2">Potential XSS in Servlet</BugCode>


    <!-- XML decoder -->
    <Detector class="com.h3xstream.findsecbugs.XmlDecoderDetector">
        <Details>Identify use of XMLDecoder (a dangerous XML serializer).</Details>
    </Detector>
    <BugPattern type="XML_DECODER">
        <ShortDescription>XMLDecoder usage</ShortDescription>
        <LongDescription>Its not safe to use an XMLDecoder to parse user supplied data</LongDescription>
        <Details>
            <![CDATA[
<p>
    XMLDecoder should not be used to parse untrusted data. Deserializing user input can lead to arbitrary code execution.
    This is possible because XMLDecoder supports arbitrary method invocation. This capability is intended to call setter methods,
    but in practice, any method can be called.
</p>
<p>
    <b>Malicious XML example:</b>
</p>
<pre>
&lt;?xml version="1.0" encoding="UTF-8" ?&gt;
&lt;java version="1.4.0" class="java.beans.XMLDecoder"&gt;
  &lt;object class="java.io.PrintWriter"&gt;
    &lt;string>/tmp/Hacked.txt&lt;/string&gt;
    &lt;void method="println"&gt;
      &lt;string>Hello World!&lt;/string&gt;
    &lt;/void&gt;
    &lt;void method="close"/&gt;
  &lt;/object&gt;
&lt;/java&gt;
</pre>
<p>
The XML code above will cause the creation of a file with the content "Hello World!".
</p>
<p>
    <b>Vulnerable Code:</b></br/>
    <pre>XMLDecoder d = new XMLDecoder(in);
try {
    Object result = d.readObject();
}
[...]</pre>
</p>
<p>
<b>Solution:</b></br/>
The solution is to avoid using XMLDecoder to parse content from an untrusted source.
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://blog.diniscruz.com/2013/08/using-xmldecoder-to-execute-server-side.html">Dinis Cruz Blog: Using XMLDecoder to execute server-side Java Code on an Restlet application</a><br/>
<a href="https://securityblog.redhat.com/2014/01/23/java-deserialization-flaws-part-2-xml-deserialization/">RedHat blog : Java deserialization flaws: Part 2, XML deserialization</a><br/>
<a href="http://cwe.mitre.org/data/definitions/20.html">CWE-20: Improper Input Validation</a>
</p>
            ]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="XMLDEC">XMLDecoder usage</BugCode>


    <!-- Static IV -->
    <Detector class="com.h3xstream.findsecbugs.crypto.StaticIvDetector">
        <Details>Identify initialization vectors (IV) that are not properly generated.</Details>
    </Detector>
    <BugPattern type="STATIC_IV">
        <ShortDescription>Static IV</ShortDescription>
        <LongDescription>The initialization vector (IV) is not properly generated</LongDescription>
        <Details>
            <![CDATA[
<p>
    Initialization vector must be regenerated for each message to be encrypted.
</p>
<p><b>Vulnerable Code:</b></p>
<p>
<pre>
private static byte[] IV = new byte[16] {(byte)0,(byte)1,(byte)2,[...]};

public void encrypt(String message) throws Exception {

    IvParameterSpec ivSpec = new IvParameterSpec(IV);
[...]
</pre>
<p><b>Solution:</b></p>
<p>
<pre>
public void encrypt(String message) throws Exception {

    byte[] iv = new byte[16];
    new SecureRandom().nextBytes(iv);

    IvParameterSpec ivSpec = new IvParameterSpec(iv);
[...]
</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://en.wikipedia.org/wiki/Initialization_vector">Wikipedia: Initialization vector</a><br/>
<a href="http://cwe.mitre.org/data/definitions/329.html">CWE-329: Not Using a Random IV with CBC Mode</a><br/>
<a href="https://defuse.ca/cbcmodeiv.htm">Encryption - CBC Mode IV: Secret or Not?</a>
</p>
            ]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="STAIV">Static IV</BugCode>


    <!-- Ciphers with no integrity -->
    <Detector class="com.h3xstream.findsecbugs.crypto.CipherWithNoIntegrityDetector">
        <Details>Identify ciphers that do not provide integrity.</Details>
    </Detector>

    <!-- ECB Mode -->
    <BugPattern type="ECB_MODE">
        <ShortDescription>ECB Mode Unsafe</ShortDescription>
        <LongDescription>The cipher chosen uses ECB mode, which provides poor confidentiality for encrypted data.</LongDescription>
        <Details>
            <![CDATA[
<p>An authentication cipher mode which provides better confidentiality of the encrypted data should be used instead of Electronic Codebook (ECB) mode, 
which does not provide good confidentiality. Specifically, ECB mode produces the same output for the same input each time. So, 
for example, if a user is sending a password, the encrypted value is the same each time. This allows an attacker to intercept 
and replay the data.</p>
<p>
To fix this, something like Galois/Counter Mode (GCM) should be used instead.
</p>
<p>
<b>Code at risk:</b>
    <pre>Cipher c = Cipher.getInstance("AES/ECB/NoPadding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
    <b>Solution:</b>
    <pre>Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<br/>
<p>
<b>References</b><br/>
<a href="http://en.wikipedia.org/wiki/Authenticated_encryption">Wikipedia: Authenticated encryption</a><br/>
<a href="http://csrc.nist.gov/groups/ST/toolkit/BCM/modes_development.html#01">NIST: Authenticated Encryption Modes</a><br/>
<a href="http://en.wikipedia.org/wiki/Block_cipher_modes_of_operation#Electronic_codebook_.28ECB.29">Wikipedia: Block cipher modes of operation</a><br/>
<a href="http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf">NIST: Recommendation for Block Cipher Modes of Operation</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECECB">ECB Mode</BugCode>


    <!-- Padding oracle -->
    <BugPattern type="PADDING_ORACLE">
        <ShortDescription>Cipher is Susceptible to Padding Oracle</ShortDescription>
        <LongDescription>The cipher is susceptible to padding oracle attacks</LongDescription>
        <Details>
<![CDATA[
<p>
    This specific mode of CBC with PKCS5Padding is susceptible to padding oracle attacks. An adversary could potentially decrypt the
    message if the system exposed the difference between plaintext with invalid padding or valid padding. The distinction between
    valid and invalid padding is usually revealed through distinct error messages being returned for each condition.
</p>
<p>
    <b>Code at risk:</b>
    <pre>Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
    <b>Solution:</b>
    <pre>Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<br/>
<p>
    <b>References</b><br/>
    <a href="http://www.infobytesec.com/down/paddingoracle_openjam.pdf">Padding Oracles for the masses (by Matias Soler)</a><br/>
    <a href="http://en.wikipedia.org/wiki/Authenticated_encryption">Wikipedia: Authenticated encryption</a><br/>
    <a href="http://csrc.nist.gov/groups/ST/toolkit/BCM/modes_development.html#01">NIST: Authenticated Encryption Modes</a><br/>
    <a href="http://capec.mitre.org/data/definitions/463.html">CAPEC: Padding Oracle Crypto Attack</a><br/>
    <a href="http://cwe.mitre.org/data/definitions/696.html">CWE-696: Incorrect Behavior Order</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="PADORA">Cipher is susceptible to padding oracle attack</BugCode>


    <!-- Integrity missing -->
    <BugPattern type="CIPHER_INTEGRITY">
        <ShortDescription>Cipher With No Integrity</ShortDescription>
        <LongDescription>The cipher used does not provide an data integrity</LongDescription>
        <Details>
<![CDATA[
<p>
    The ciphertext produced is susceptible to alteration by an adversary. This mean that the cipher provides no way to detect that the 
    data has been tampered with. If the ciphertext can be controlled by an attacker, it could be altered without detection.
</p>
<p>
    The solution is to used a cipher that includes a Hash based Message Authentication Code (HMAC) to sign the data. Combining a HMAC function to the 
    existing cipher is prone to error <sup><a href="http://www.thoughtcrime.org/blog/the-cryptographic-doom-principle/">[1]</a></sup>. Specifically,
    it is always recommended that you be able to verify the HMAC first, and only if the data is unmodified, do you then perform any cryptographic
    functions on the data.
</p>
<p>
    <b>Code at risk:</b><br/>
    <i>AES in CBC mode</i><br/>

    <pre>Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
    <br/>
    <i>Triple DES with ECB mode</i><br/>

<pre>Cipher c = Cipher.getInstance("DESede/ECB/PKCS5Padding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
    <b>Solution:</b>
    <pre>Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, k, iv);
byte[] cipherText = c.doFinal(plainText);</pre>
</p>
<p>
In the example solution above, the GCM mode introduces an HMAC into the resulting encrypted data, providing integrity of the result.
</p>
<br/>
<p>
    <b>References</b><br/>
    <a href="http://en.wikipedia.org/wiki/Authenticated_encryption">Wikipedia: Authenticated encryption</a><br/>
    <a href="http://csrc.nist.gov/groups/ST/toolkit/BCM/modes_development.html#01">NIST: Authenticated Encryption Modes</a><br/>
    <a href="http://www.thoughtcrime.org/blog/the-cryptographic-doom-principle/">Moxie Marlinspike's blog: The Cryptographic Doom Principle</a><br/>
    <a href="http://cwe.mitre.org/data/definitions/353.html">CWE-353: Missing Support for Integrity Check</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="CIPINT">Cipher with no integrity</BugCode>


    <!-- ESAPI Encryptor -->
    <Detector class="com.h3xstream.findsecbugs.crypto.EsapiEncryptorDetector">
        <Details>Identity usage of ESAPI Encryptor.</Details>
    </Detector>
    <BugPattern type="ESAPI_ENCRYPTOR">
        <ShortDescription>Usage of ESAPI Encryptor</ShortDescription>
        <LongDescription>The ESAPI encryptor API is used to encrypt data</LongDescription>
        <Details>
<![CDATA[
<p>
    The ESAPI has a small history of vulnerabilities within the cryptography component. Here is a quick validation list to
    make sure the Authenticated Encryption is working as expected.
</p>
<p><b>1. Library Version</b></p>
<p>
    This issue is corrected in ESAPI version 2.1.0. Versions <= 2.0.1 are vulnerable to a MAC bypass (CVE-2013-5679).<br/>
</p>
<p>
    For Maven users, the plugin <a href="http://mojo.codehaus.org/versions-maven-plugin/">versions</a> can called using the 
    following command. The effective version of ESAPI will be available in the output.<br/>
    <pre>$ mvn versions:display-dependency-updates</pre>
    <br/>Output:<br/>
    <pre>
[...]
[INFO] The following dependencies in Dependencies have newer versions:
[INFO]   org.slf4j:slf4j-api ................................... 1.6.4 -> 1.7.7
[INFO]   org.owasp.esapi:esapi ................................. 2.0.1 -> 2.1.0
[...]
    </pre>
</p>
<p>
    or by looking at the configuration directly.<br/>
    <pre>
&lt;dependency&gt;
    &lt;groupId&gt;org.owasp.esapi&lt;/groupId&gt;
    &lt;artifactId&gt;esapi&lt;/artifactId&gt;
    &lt;version&gt;2.1.0&lt;/version&gt;
&lt;/dependency&gt;</pre>
</p>
<p>
    For Ant users, the jar used should be <a href="http://repo1.maven.org/maven2/org/owasp/esapi/esapi/2.1.0/esapi-2.1.0.jar">esapi-2.1.0.jar</a>.
</p>
<p><b>2. Configuration:</b></p>
    <p>
    The library version 2.1.0 is still vulnerable to key size being changed in the ciphertext definition (CVE-2013-5960). Some precautions need to be taken.<br/>
    <br/>
    <div><b>The cryptographic configuration of ESAPI can also be vulnerable if any of these elements are present:</b><br/>
    <b>Insecure configuration:</b><br/>
    <pre>
Encryptor.CipherText.useMAC=false

Encryptor.EncryptionAlgorithm=AES
Encryptor.CipherTransformation=AES/CBC/PKCS5Padding

Encryptor.cipher_modes.additional_allowed=CBC</pre>
    </div>
</p>
<p>
    <div>
    <b>Secure configuration:</b><br/>
    <pre>
#Needed
Encryptor.CipherText.useMAC=true

#Needed to have a solid auth. encryption
Encryptor.EncryptionAlgorithm=AES
Encryptor.CipherTransformation=AES/GCM/NoPadding

#CBC mode should be removed to avoid padding oracle
Encryptor.cipher_modes.additional_allowed=</pre>
    </div>
</p>
<br/>
<p>
    <b>References</b><br/>
    <a href="http://owasp-esapi-java.googlecode.com/svn/trunk/documentation/ESAPI-security-bulletin1.pdf">ESAPI Security bulletin 1 (CVE-2013-5679)</a><br/>
    <a href="http://nvd.nist.gov/view/vuln/detail?vulnId=CVE-2013-5679">Vulnerability Summary for CVE-2013-5679</a><br/>
    <a href="http://www.synacktiv.com/ressources/synacktiv_owasp_esapi_hmac_bypass.pdf">Synactiv: Bypassing HMAC validation in OWASP ESAPI symmetric encryption</a><br/>
    <a href="http://cwe.mitre.org/data/definitions/310.html">CWE-310: Cryptographic Issues</a><br/>
    <a href="http://lists.owasp.org/pipermail/esapi-dev/2015-March/002533.html">ESAPI-dev mailing list: Status of CVE-2013-5960</a><br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="ESAPIENC">ESAPI Encryptor</BugCode>


    <!-- Android: External File Access -->
    <Detector class="com.h3xstream.findsecbugs.android.ExternalFileAccessDetector">
        <Details>Identity file access on external storage.</Details>
    </Detector>
    <BugPattern type="ANDROID_EXTERNAL_FILE_ACCESS">
        <ShortDescription>External File Access (Android)</ShortDescription>
        <LongDescription>Potentially unwanted file are being persist to external storage.</LongDescription>
        <Details>
            <![CDATA[
<p>
    The application write data to external storage (potentially SD card). There are multiple security implication to this
    action. First, file store on SD card will be accessible to the application having the
    <a href="http://developer.android.com/reference/android/Manifest.permission.html#READ_EXTERNAL_STORAGE"><code>READ_EXTERNAL_STORAGE</code></a> permission.
    Also, if the data persist contains confidential information about the user, encrypting the content would be needed.
</p>
<p>
    <b>Code at risk:</b><br/>
<pre>
file file = new File(getExternalFilesDir(TARGET_TYPE), filename);
fos = new FileOutputStream(file);
fos.write(confidentialData.getBytes());
fos.flush();
</pre>
</p>
<p>
    <b>Better alternative:</b><br/>
<pre>
fos = openFileOutput(filename, Context.MODE_PRIVATE);
fos.write(string.getBytes());
</pre>
</p>
<p>
    <b>References</b><br/>
    <a href="https://www.securecoding.cert.org/confluence/display/java/DRD00-J.+Do+not+store+sensitive+information+on+external+storage+%28SD+card%29+unless+encrypted+first">CERT: DRD00-J: Do not store sensitive information on external storage [...]</a><br/>
    <a href="http://developer.android.com/guide/topics/data/data-storage.html#filesExternal">Android Official Doc: Using the External Storage</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECEFA">External File Access (Android)</BugCode>



    <!-- Android: Broadcast -->
    <Detector class="com.h3xstream.findsecbugs.android.BroadcastDetector">
        <Details>Identity sendBroadcast() call and give security implications and helpful guidelines.</Details>
    </Detector>
    <BugPattern type="ANDROID_BROADCAST">
        <ShortDescription>Broadcast (Android)</ShortDescription>
        <LongDescription>Broadcast intents could be received by a malicious application.</LongDescription>
        <Details>
            <![CDATA[
<p>
    Broadcast intents can be listen by any application with the appropriate permission. It suggest to avoid transmitting
    sensitive information when possible.
</p>
<p>
    <b>Code at risk:</b><br/>
<pre>
Intent i = new Intent();
i.setAction("com.insecure.action.UserConnected");
i.putExtra("username", user);
i.putExtra("email", email);
i.putExtra("session", newSessionId);

this.sendBroadcast(v1);
</pre>
</p>
<br/>
<p>
    <b>Solution (if possible):</b><br/>
<pre>
Intent i = new Intent();
i.setAction("com.secure.action.UserConnected");

sendBroadcast(v1);
</pre>
</p>
<br/>
<p>
    <b>Configuration (receiver)<sup>[1] Source: StackOverflow</sup>:</b><br/>
<pre>
&lt;manifest ...&gt;

    &lt;!-- Permission declaration --&gt;
    &lt;permission android:name="my.app.PERMISSION" /&gt;

    &lt;receiver
        android:name="my.app.BroadcastReceiver"
        android:permission="com.secure.PERMISSION"&gt; &lt;!-- Permission enforcement --&gt;
        &lt;intent-filter>
            &lt;action android:name="com.secure.action.UserConnected" /&gt;
        &lt;/intent-filter&gt;
    &lt;/receiver&gt;

    ...
&lt;/manifest>
</pre>
</p>
<p>
    <b>Configuration (receiver)<sup>[1] Source: StackOverflow</sup>:</b><br/>
<pre>
&lt;manifest&gt;
    &lt;!-- We declare we own the permission to send broadcast to the above receiver --&gt;
    &lt;uses-permission android:name="my.app.PERMISSION" /&gt;
&lt;/manifest&gt;
</pre>
</p>
<p>
    <b>References</b><br/>
    <a href="https://www.securecoding.cert.org/confluence/display/java/DRD03-J.+Do+not+broadcast+sensitive+information+using+an+implicit+intent">CERT: DRD03-J. Do not broadcast sensitive information using an implicit intent</a><br/>
    <a href="http://developer.android.com/reference/android/content/BroadcastReceiver.html#Security">Android Official Doc: BroadcastReceiver (Security)</a><br/>
    <a href="http://developer.android.com/guide/topics/manifest/receiver-element.html">Android Official Doc: Receiver configuration (see <code>android:permission</code>)</a><br/>
    <sup>[1]</sup> <a href="http://stackoverflow.com/a/21513368/89769">StackOverflow: How to set permissions in broadcast sender and receiver in android</a><br/>

</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECBROAD">Broadcast (Android)</BugCode>


    <!-- Android: World Writable -->
    <Detector class="com.h3xstream.findsecbugs.android.WorldWritableDetector">
        <Details>Identity file written with the creation mode MODE_WORLD_READABLE.</Details>
    </Detector>
    <BugPattern type="ANDROID_WORLD_WRITABLE">
        <ShortDescription>World Writable File (Android)</ShortDescription>
        <LongDescription>The content that is written can be viewed by any application.</LongDescription>
        <Details>
            <![CDATA[
<p>
    The file written in this context is using the creation mode <code>MODE_WORLD_READABLE</code>. It might not be the
    expected behavior to exposed the content being written.
</p>
<p>
    <b>Code at risk:</b><br/>
<pre>
fos = openFileOutput(filename, MODE_WORLD_READABLE);
fos.write(userInfo.getBytes());
</pre>
</p>
<br/>
<p>
    <b>Solution (using MODE_PRIVATE):</b><br/>
<pre>
fos = openFileOutput(filename, MODE_PRIVATE);
</pre>
</p>
<p>
    <b>Solution (using local SQLite Database):</b><br/>
<pre>
SQLiteDatabase db = [...]

ContentValues values = new ContentValues();
values.put("username", userName);
values.put("rememberMeToken", token);
db.insert("USER_INFO", null, values);
</pre>
</p>
<p>
    <b>References</b><br/>
    <a href="https://www.securecoding.cert.org/confluence/display/java/DRD11-J.+Ensure+that+sensitive+data+is+kept+secure">CERT: DRD11-J. Ensure that sensitive data is kept secure</a><br/>
    <a href="http://developer.android.com/reference/android/content/Context.html#MODE_PRIVATE">Android Official Doc: MODE_PRIVATE</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWW">World Writable (Android)</BugCode>


    <!-- Android: Geolocation-->
    <Detector class="com.h3xstream.findsecbugs.android.GeolocationDetector">
        <Details>Identity usage of Geolocation API.</Details>
    </Detector>
    <BugPattern type="ANDROID_GEOLOCATION">
        <ShortDescription>Geolocation (Android)</ShortDescription>
        <LongDescription></LongDescription>
        <Details>
            <![CDATA[
<p>

</p>
<p>
    <b>Code at risk:</b><br/>
<pre>
TODO
</pre>
</p>
<br/>
<p>
    <b>Solution:</b><br/>
    Limit the sampling of geolocation.
</p>
<p>
    <b>References</b><br/>
    <a href="https://www.securecoding.cert.org/confluence/display/java/DRD15-J.+Consider+privacy+concerns+when+using+Geolocation+API">CERT: DRD15-J. Consider privacy concerns when using Geolocation API</a><br/>
    <a href="http://en.wikipedia.org/wiki/W3C_Geolocation_API">Wikipedia: W3C Geolocation API</a><br/>
    <a href="http://dev.w3.org/geo/api/spec-source.html">W3C: Geolocation Specification</a><br/>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECGEO">Geolocation (Android)</BugCode>
</MessageCollection>
