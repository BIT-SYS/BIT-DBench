package org.owasp.esapi.codecs;

public class WindowsCodec extends Codec {
}
