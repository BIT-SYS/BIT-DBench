package com.opensymphony.xwork2.util;

public interface ValueStack {
}
