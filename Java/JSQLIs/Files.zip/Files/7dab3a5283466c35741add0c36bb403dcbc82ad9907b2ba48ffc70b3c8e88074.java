"importId";"code";"name";"nextNum";"padding";"prefixe";"suffixe";"toBeAdded";"yearlyResetOk";"company.importId"
100;"accountClearance";"Apurement des trop-perçus";1;10;"APURMT_%Y_";;1;1;1
101;"chequeReject";"Rejet chèques";1;10;"REJCHQ_%Y_";;1;1;1
102;"invoice";"Facture de vente";1;7;"FC_%Y";;1;1;1
103;"invoice";"Avoir client";1;7;"AC_%Y";;1;1;1
104;"invoice";"Facture d'achat";1;7;"FF_%Y";;1;1;1
105;"invoice";"Avoir fournisseur";1;7;"AVF_%Y";;1;1;1
106;"debit";"Prélèvement (facture et echeanciers hors mensu)";1;7;"PREFAC_%Y_";;1;1;1
107;"debitReject";"Rejet des prélèvements";1;7;"REJPRL_%Y_";;1;1;1
108;"doubtfulCustomer";"Passage en créance douteuse";1;7;"CREDOU_%Y_";;1;1;1
109;"irrecoverable";"Passage en irrécouvrable";1;7;"IRRECOUV_%Y_";;1;1;1
110;"move";"Ecriture Vente";1;7;"ECRVTE_%Y_";;1;1;1
111;"move";"Ecriture avoir";1;10;"ECRAV_%Y_";;1;1;1
112;"move";"Ecriture Achat";1;7;"ECRACH_%Y_";;1;1;1
113;"move";"Ecriture avoir fournisseur";1;10;"ECRAVF_%Y_";;1;1;1
114;"move";"Ecriture Factice";1;7;"ECR_VIRT_%Y_";;1;1;1
115;"move";"Ecriture paiement en especes";1;7;"ECRESP_%Y_";;1;1;1
116;"move";"Ecriture paiement client par cheque";1;10;"ECRCHQ_%Y_";;1;1;1
117;"move";"Ecriture paiement client par CB";1;10;"ECRCB_%Y_";;1;1;1
118;"move";"Ecriture paiement client par internet";1;10;"ECRWEB_%Y_";;1;1;1
119;"move";"Ecriture paiement client par TIP";1;10;"ECRTIP_%Y_";;1;1;1
120;"move";"Ecriture paiement client par TIP+Cheque";1;10;"ECRTEC_%Y_";;1;1;1
121;"move";"Ecriture paiement client par virement";1;10;"ECRVIR_%Y_";;1;1;1
122;"move";"Ecriture paiement client par prélèvement  (factures et échéanciers hors mensu)";1;10;"ECRPRE_%Y_";;1;1;1
123;"move";"Ecriture paiement client par autres moyens";1;10;"ECROTH_%Y_";;1;1;1
124;"move";"Ecriture paiement client rejet d'opération bancaire";1;10;"ECRREJ_%Y_";;1;1;1
125;"move";"Ecriture de remboursement automatique";1;10;"ECRRBTCLT_%Y_";;1;1;1
126;"move";"Ecriture règlement fournisseur en especes";1;7;"ECRESP_%Y_";;1;1;1
127;"move";"Ecriture règlement fournisseur par cheque";1;10;"ECRCHQ_%Y_";;1;1;1
128;"move";"Ecriture règlement fournisseur par CB";1;10;"ECRCB_%Y_";;1;1;1
129;"move";"Ecriture règlement fournisseur par TIP";1;10;"ECRTIP_%Y_";;1;1;1
130;"move";"Ecriture règlement fournisseur par virement";1;10;"ECRVIR_%Y_";;1;1;1
131;"move";"Ecriture règlement fournisseur par prélèvement  (factures et échéanciers hors mensu)";1;10;"ECRPRE_%Y_";;1;1;1
132;"move";"Ecriture règlement fournisseur par autres moyens";1;10;"ECROTH_%Y_";;1;1;1
133;"move";"Ecriture d'OD automatique";1;10;"ECRODAUTO_%Y_";;1;1;1
134;"move";"Ecriture d'OD manuelle";1;10;"ECRODMANU_%Y_";;1;1;1
135;"move";"Ecriture d'apurements";1;10;"ECRAPUR_%Y_";;1;1;1
136;"move";"Ecriture passage en irrécouvrable";1;10;"ECRIRREC_%Y_";;1;1;1
137;"moveLineExport";"Export comptable";1;10;"EXPCPT_%Y_";;1;1;1
138;"moveLineReport";"Reporting comptable";1;10;"REPORTDF_%Y_";;1;1;1
139;"paymentSchedule";"N° écheancier";1;10;"ECHPAI_%Y_";;1;1;1
140;"paymentVoucher";"N° de paiement enc. espèces ";1;10;"ENC_ESP_%Y_";;1;1;1
141;"paymentVoucher";"N° de paiement enc. chèques ";1;10;"ENC_CHQ_%Y_";;1;1;1
142;"paymentVoucher";"N° de paiement enc. CB ";1;10;"ENC_CB_%Y_";;1;1;1
143;"paymentVoucher";"N° de paiement enc. internet ";1;10;"ENC_WEB_%Y_";;1;1;1
144;"paymentVoucher";"N° de paiement enc. TIP ";1;10;"ENC_TIP_%Y_";;1;1;1
145;"paymentVoucher";"N° de paiement enc. TIP+Cheque ";1;10;"ENC_TEC_%Y_";;1;1;1
146;"paymentVoucher";"N° de paiement enc. virement ";1;10;"ENC_VIR_%Y_";;1;1;1
147;"paymentVoucher";"N° de paiement enc. prélèvement  (factures et échéanciers hors mensu)";1;10;"ENC_PRE_%Y_";;1;1;1
148;"paymentVoucher";"N° de paiement enc. autres moyens ";1;10;"ENC_OTH_%Y_";;1;1;1
149;"paymentVoucher";"N° de paiement dec. espèces ";1;10;"DEC_ESP_%Y_";;1;1;1
150;"paymentVoucher";"N° de paiement dec. chèques ";1;10;"DEC_CHQ_%Y_";;1;1;1
151;"paymentVoucher";"N° de paiement dec. CB ";1;10;"DEC_CB_%Y_";;1;1;1
152;"paymentVoucher";"N° de paiement dec. TIP ";1;10;"DEC_TIP_%Y_";;1;1;1
153;"paymentVoucher";"N° de paiement dec. virement ";1;10;"DEC_VIR_%Y_";;1;1;1
154;"paymentVoucher";"N° de paiement dec. prélèvement  (factures et échéanciers hors mensu) ";1;10;"DEC_PRE_%Y_";;1;1;1
155;"paymentVoucher";"N° de paiement dec. autres moyens ";1;10;"DEC_OTH_%Y_";;1;1;1
156;"paymentVoucherReceiptNo";"N° de reçu";1;10;"RECU_%Y_";;1;1;1
157;"purchaseInterface";"Interface achat";1;10;"INTACH_%Y_";;1;1;1
158;"refundInterface";"Interface avoir";1;10;"INTAVO_%Y_";;1;1;1
159;"reimbursement";"Proposition remboursement";1;10;"REMB_%Y_";;1;1;1
160;"saleInterface";"Interface vente";1;10;"INTVEN_%Y_";;1;1;1
161;"treasuryInterface";"Interface trésorerie";1;10;"INTTRESO_%Y_";;1;1;1
1;"partner";"Numéro identifiant tiers";4;10;"T";;1;0;1
2;"saleOrder";"Devis/Cmde client";1;5;"VTE";;1;0;1
3;"purchaseOrder";"Cotations/Cmde fournisseur";1;5;"ACH";;1;0;1
4;"eventTicket";"N° de ticket";1;4;"TKT";;1;0;1
5;"intStockMove";"N° de bon de transfert de marchandise";1;4;"BT";;1;0;1
6;"outStockMove";"N° de bon de livraison";1;4;"BL";;1;0;1
7;"inStockMove";"N° de bon de réception";1;4;"BR";;1;0;1
8;"inventory";"N° inventaire";1;4;"INV%M%Y";;1;0;1
9;"productTrackingNumber";"N° de suivi";1;5;"NS";;1;0;1
10;"productionOrder";"Ordre de production";1;5;"OP";;1;0;1
11;"manufOrder";"Ordre de fabrication";1;5;"OF";;1;0;1
