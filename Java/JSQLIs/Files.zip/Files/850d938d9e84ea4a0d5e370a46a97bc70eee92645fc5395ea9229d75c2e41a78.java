{
    "msbuild-sdks": {
        "Peachpie.NET.Sdk": "0.9.910"
    }
}