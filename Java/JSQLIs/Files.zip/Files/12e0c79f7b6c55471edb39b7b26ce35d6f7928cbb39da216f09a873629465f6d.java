<?xml version="1.0" encoding="UTF-8"?>
<project-private xmlns="http://www.netbeans.org/ns/project-private/1">
    <editor-bookmarks xmlns="http://www.netbeans.org/ns/editor-bookmarks/2" lastBookmarkId="0"/>
    <open-files xmlns="http://www.netbeans.org/ns/projectui-open-files/2">
        <group>
            <file>file:/C:/Users/bugzy/Documents/NetBeansProjects/Burp_Plugins/Hack_Bar/src/burp/SQL_Menu.java</file>
            <file>file:/C:/Users/bugzy/Documents/NetBeansProjects/Burp_Plugins/Hack_Bar/src/burp/BurpExtender.java</file>
            <file>file:/C:/Users/bugzy/Documents/NetBeansProjects/Burp_Plugins/Hack_Bar/src/burp/RCE_Menu.java</file>
            <file>file:/C:/Users/bugzy/Documents/NetBeansProjects/Burp_Plugins/Hack_Bar/src/burp/WebShell_Menu.java</file>
        </group>
    </open-files>
</project-private>
