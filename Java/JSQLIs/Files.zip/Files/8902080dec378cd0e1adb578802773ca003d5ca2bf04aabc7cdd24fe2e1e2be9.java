@(user: String, csrfToken: String)(content: Html)
@import helper._

<!DOCTYPE html>

<html>
	<head>
		<title>WhereHows</title>
		<link rel="shortcut icon" type="image/png" href="@routes.Assets.at("images/icons/logo.png")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/jquery-ui-1.11.0/jquery-ui-custom.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/bootstrap/dist/css/bootstrap.min.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/bootstrap3-editable/css/bootstrap-editable.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/fancytree/src/skin-win8/ui.fancytree.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/fancytree/src/skin-wherehows/ui.wherehows.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/json.human.js-master/css/json.human.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/jquery.treegrid/css/jquery.treegrid.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/toastr/toastr.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/jquery-jsonview/dist/jquery.jsonview.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("stylesheets/main.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("stylesheets/comments.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("vendors/font-awesome-4.5.0/css/font-awesome.min.css")">
		<link rel="stylesheet" media="screen" href="@routes.Assets.at("stylesheets/wherehows.css")">
		<script src="@routes.Assets.at("vendors/jquery-2.1.4/jquery-2.1.4.min.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/jquery-ui-1.11.0/jquery-ui.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/bootstrap/dist/js/bootstrap.min.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/bootstrap3-editable/js/bootstrap-editable.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/bootstrap-validator-master/dist/validator.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/jquery.splitter-1.6/jquery.splitter.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/fancytree/src/jquery.fancytree.wherehows.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/fancytree/src/jquery.fancytree.filter.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/jquery.scrollTo-1.4.14/jquery.scrollTo.min.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/jquery.treegrid/js/jquery.treegrid.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/json.human.js-master/src/json.human.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/jquery-jsonview/dist/jquery.jsonview.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/CsvToMarkdownTable-master/src/CsvToMarkdown.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/marked/lib/marked.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/ace/src/ace.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/ace/src/theme-github.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/ace/src/mode-sql.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("vendors/toastr/toastr.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("javascripts/storage.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("javascripts/notification.js")" type="text/javascript"></script>
		<script src="@routes.Assets.at("javascripts/tracking.js")" type="text/javascript"></script>
	</head>
	<body>
		<nav class="navbar navbar-inverse navbar-fixed-top"	role="navigation">
			<div class="navbar-header">
				<button type="button"
					class="navbar-toggle collapsed"
					aria-expanded="false"
					aria-controls="navbar"
				>
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="/" class="navbar-brand">WhereHows</a>
			</div>
			<div id="mainnavbar" collapse="navCollapsed" class="navbar-collapse collapse" aria-expanded="false">
				@if(user) {
					<ul class="nav navbar-nav navbar-left category-header">
						<li id="datasetlink">
							<a href="/#/datasets/page/1">
								<span>Datasets</span>
							</a>
						</li>
						<li id="flowlink">
							<a href="/#/flows/page/1">
								<span>Flows</span>
							</a>
						</li>
						<li id = "toolslink" class="dropdown" dropdown>
							<a
							class="dropdown-toggle"
							data-toggle="dropdown"
							role="button"
							style="color : #808080"
							aria-expand="false"
							dropdown-toggle>
								Tools
								<i class="fa fa-angle-down"></i>
							</a>
							<ul class="dropdown-menu" role="menu">
								<li>
									<a href="/schemaHistory">
										<span>
											Schema History
										</span>
									</a>
								</li>
							</ul>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search">
						<div class="row">
							<div id="searchcategorybtngroup" class="btn-group" role="group">
							    <button style="height: 30px;margin-right:-4px;"
						            type="button"
						            data-toggle="dropdown"
						            aria-expanded="false">
							        <i id="categoryIcon" class="fa fa-database"></i>
							        <span class="caret"></span>
							    </button>
							    <ul class="dropdown-menu" role="menu">
							        <!--
							        <li class="active">
							            <a href="#" class="searchCategory">All</a>
							        </li>
							        -->
							        <li id="categoryDatasets" class="active">
							            <a href="#" class="searchCategory">Datasets</a>
							        </li>
							        <li id="categoryComments" >
							            <a href="#" class="searchCategory">Comments</a>
							        </li>
							        <!--
									<li id="categoryMetrics" >
							            <a href="#" class="searchCategory">Metrics</a>
							        </li>
							        -->
							        <li id="categoryFlows" >
							            <a href="#" class="searchCategory">Flows</a>
							        </li>
									<li id="categoryJobs" >
							            <a href="#" class="searchCategory">Jobs</a>
									</li>
								</ul>
							</div>
							<div class="input-group">
								<input id="searchInput"
									type="text"
									class="form-control input-sm keyword-search"
									placeholder="Enter Keywords..."
								/>
								<span class="input-group-btn">
									<button id="searchBtn"
										type="button"
										class="btn btn-sm btn-primary"
									>
										<i class="fa fa-search"></i>
									</button>
								</span>
							</div>
						</div>
					</form>
					<div class="nav nabar-nav navbar-left">
						<button
						class="btn btn-link btn-sm"
						data-toggle="modal"
						data-target="#myModal"
						title="Advanced Search"
						aria-label="Advanced Search"
						>
							Advanced
						</button>
					</div>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown" dropdown>
							<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expand="false" dropdown-toggle>
								<i class="fa fa-angle-down"></i>
							</a>
							<div id="loggedInUser" title=@user class="usericon"></div>
							<ul class="dropdown-menu" role="menu">
								<li>
									<a id="settingsbtn" role="button">
										<i class="fa fa-gear"></i>
										Settings
									</a>
								</li>
								<li>
									<a href="@routes.Application.logout()" title="Log out">
										<i class="fa fa-sign-out"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul>
				} else {
					<form class="navbar-form navbar-right" method="POST"
						action="@routes.Application.authenticate()?csrfToken=@csrfToken">
						<div class="form-group">
							<input
							id="username"
							type="text"
							placeholder="username"
							name="username"
							class="form-control"
							/>
						</div>
						<div class="form-group">
							<input
							id="password"
							type="password"
							placeholder="password"
							name="password"
							class="form-control"
							/>
						</div>
						<button type="submit" class="btn btn-primary">Sign In</button>
						<button type="button"
							class="btn btn-link"
							data-toggle="modal"
							data-target="#signUpModal"
							title="Sign Up"
							aria-label="Sign Up">
								Not a Member Yet? Join Now!
						</button>
					</form>
				}
			</div>
		</nav>

		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<h3 class="modal-title" id="myModalLabel">Advanced Search</h3>
					</div>
					<div class="modal-body advSearch">
						<ul id="advsearchtabs" class="nav nav-tabs">
							<li id="datasetAdvSearchLink"><a data-toggle="tab" href="#datasetAdvTab">Datasets</a></li>
							<li><a data-toggle="tab" href="#flowAdvtab">Flows</a></li>
						</ul>
						<div class="tab-content">
							<div id="datasetAdvTab" class="tab-pane">
								<div class="row">
									<div class="col-md-10 rightPartialBorder">
										<div class="row">
											<div class="col-md-12">
												<div class="control-group col-md-12">
													<label class="control-label">Scope</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									In
															</div>
															<div class="col-xs-9">
																<input
																	id="scopeInInput"
																	class="scopeInput"
																	placeholder="<db_name>, <top_level_dir>"
																	title="Scope can be database schema name or top level HDFS directory which is used to narrow down the search range"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Not In
															</div>
															<div class="col-xs-9">
																<input
																	id="scopeNotInInput"
																	class="scopeInput"
																	placeholder="<db_name_to_exclude>"
																	title="Scope can be database schema name or top level HDFS directory which is used to narrow down the search range"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="control-group col-md-12">
													<label class="control-label">Table</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									In
															</div>
															<div class="col-xs-9">
																<input
																	id="tableInInput"
																	class="tableInput"
																	placeholder="<table_name>, <view_name>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Not In
															</div>
															<div class="col-xs-9">
																<input
																	id="tableNotInInput"
																	class="tableInput"
																	placeholder="<table_name_to_exclude>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group col-md-12">
													<label class="control-label">Fields</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Contains Any
															</div>
															<div class="col-xs-9">
																<input
																	id="fieldAnyInput"
																	class="fieldInput"
																	placeholder="<partial_field_name>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Contains All
															</div>
															<div class="col-xs-9">
																<input
																	id="fieldAllInput"
																	class="fieldInput"
																	placeholder="<field_name_1>, <field_name_2>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Doesn't Contain
															</div>
															<div class="col-xs-9">
																<input
																	id="fieldNotInInput"
																	class="fieldInput"
																	placeholder="<field_name_to_exclude>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group col-md-12">
													<label class="control-label">Comments</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Contains
															</div>
															<div class="col-xs-9">
																<input
																	id="commentsInput"
																	type="text"
																	placeholder="<phrase_in_comment>"
																	class="col-md-4 form-control"/>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div id="advSearchSource" class="col-md-2">
										<h4>Sources</h4>
									</div>
								</div>
							</div>
							<div id="flowAdvtab" class="tab-pane">
								<div class="row">
									<div class="col-md-12 rightPartialBorder">
										<div class="row">
											<div class="col-md-12">
												<div class="control-group col-md-12">
													<label class="control-label">Cluster</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									In
															</div>
															<div class="col-xs-9">
																<input
																	id="appcodeInInput"
																	class="appcodeInput"
																	placeholder="<cluster1>, <cluster2>"
																	title="Cluster"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Not In
															</div>
															<div class="col-xs-9">
																<input
																	id="appcodeNotInInput"
																	class="appcodeInput"
																	placeholder="<cluster_to_exclude>"
																	title="Cluster"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="control-group col-md-12">
													<label class="control-label">Flow Name</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									In
															</div>
															<div class="col-xs-9">
																<input
																	id="flowInInput"
																	class="flowInput"
																	placeholder="<flow_name1>, <flow_name2>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Not In
															</div>
															<div class="col-xs-9">
																<input
																	id="flowNotInInput"
																	class="flowInput"
																	placeholder="<flow_name_to_exclude>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="control-group col-md-12">
													<label class="control-label">Job Name</label>
													<div class="controls">
														<div class="row">
															<div class="col-xs-3 text-right">
                            									In
															</div>
															<div class="col-xs-9">
																<input
																	id="jobInInput"
																	class="jobInput"
																	placeholder="<job_name1>, <job_name2>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-3 text-right">
                            									Not In
															</div>
															<div class="col-xs-9">
																<input
																	id="jobNotInInput"
																	class="jobInput"
																	placeholder="<job_name_to_exclude>"
																	style="width: 100%;">
                            									</input>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" id="advSearchBtn"
							data-dismiss="modal" class="btn btn-primary">Search</button>
						<button type="button" id="advSearchResetBtn" class="btn btn-default">Reset</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="signUpModal" tabindex="-1" role="dialog"
			aria-labelledby="signUpModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<form id="signUpForm" data-toggle="validator" method="POST"
					action="@routes.Application.signUp()?csrfToken=@csrfToken">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h3 class="modal-title" id="signUpModalLabel">Sign Up</h3>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<div class="row">
									<div class="col-xs-11">
										<input type="text" class="form-control" name="inputName"
											id="inputName" style="width: 100%;" placeholder="User Name" required>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-xs-5">
										<input type="text" class="form-control" name="inputFirstName"
											id="inputFistName" style="width: 100%;" placeholder="First Name" required>
									</div>
									<div class="col-xs-5 col-xs-offset-1">
										<input type="text" class="form-control" name="inputLastName"
											id="inputLastName" style="width: 100%;" placeholder="Last Name" required>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-xs-11">
										<input type="email" class="form-control" name="inputEmail" id="inputEmail"
											style="width: 100%;" placeholder="Email"
											data-error="Please input a valid email address" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-xs-11">
										<input type="password" data-minlength="6" class="form-control"
											name="inputPassword" id="inputPassword" style="width: 100%;"
											data-error="Minimum of 6 characters"
											placeholder="Password minimum of 6 characters" required>
										<span class="help-block with-errors"></span>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-xs-11">
										<input type="password" class="form-control" id="inputPasswordConfirm"
											style="width: 100%;" data-match="#inputPassword"
											data-match-error="Password does not match"
											placeholder="Confirm Password" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<div class="form-group">
								<button type="submit" class="btn btn-primary">Sign Up</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>

		<div id="mainContent">
			@content
		</div>
		<footer class="footer navbar-fixed-bottom">
			<input id="csrfToken" type="text" style="visibility: hidden;" value=@csrfToken/>
			<p class="pull-right">
				WhereHows 0.1.9
					&copy; LinkedIn 2016
				|
				<a href="https://www.github.com/linkedin/WhereHows/wiki">Help</a> | <a href="mailto:wherehows@@googlegroups.com">Contact Us</a>
			</p>
    </footer>
    <div class="modal" tabindex="-1" role="dialog" aria-labelledby="settingsModal" id="settingsModal">
      	<div class="modal-dialog modal-lg" role="document">
        	<div class="modal-content">
          		<div class="modal-header">
            		<h2>Settings</h2>
          		</div>
          		<div class="modal-body">
            		<form name="settingsForm">
              			<div class="form-group">
                			<label>Dataset Detail View Layout</label>
                			<select name="detailDefaultView" class="form-control">
                  				<option value="tab">Tab</option>
                  				<option value="accordion">Accordion</option>
                			</select>
              			</div>
            		</form>
          		</div>
          		<div class="modal-footer">
            		<button type="button" class="btn btn-default" data-dismiss="modal">
						Close
            		</button>
            		<button type="button" class="btn btn-primary" id="submitSettingsForm">
              			Save
            		</button>
          		</div>
        	</div>
      	</div>
    </div>

    <script type="text/x-handlebars" id="components/dataset-comments">
      <div class="row commentsHeader">
        <div class="col-xs-3">
        <b>Comments</b>
        </div>
        <div
          class="col-xs-6 text-center commentsPagination"
        >
          {{#if comments}}
          <ul class="pager">
            <li class="previous">
              <button
                class="btn btn-default btn-xs"
                {{action "pageBack"}}
              >
                <span aria-hidden="true">&larr;</span>
                Older
              </button>
            </li>
            <li>
              {{page}} of {{totalPages}}
            </li>
            <li class="next">
              <button
                class="btn btn-default btn-xs"
                {{action "pageForward"}}
              >
                Newer
                <span aria-hidden="true">&rarr;</span>
              </button>
            </li>
          </ul>
          {{/if}}
        </div>
        <div class="col-xs-3 text-right pull-right">
          <button
            type="button"
            class="btn btn-default btn-xs"
            {{action "showModal"}}
          >
            <i class="fa fa-plus"></i>
          </button>
        </div>
      </div>
      <div class="row commentsArea">
        {{#if comments}}
        {{#each comments as |comment|}}
        <div class="col-xs-12 well comment">
          <span class="bs-docs-example">
            {{comment.type}}
          </span>
          <div class="text comment-text">
            {{comment.html}}
          </div>
          <div class="meta">
            <a href="#" class="author">{{comment.authorName}}</a>
            <span class="date">{{comment.created }}</span>
            {{#if comment.isAuthor}}
            <div
              class="pull-right actions"
            >
              <i
                class="fa fa-pencil wh-clickable-icon"
                {{action "showModal" comment}}
              >
              </i>
              <i
                class="fa fa-trash wh-clickable-icon"
                {{action "remove" comment}}
              >
              </i>
            </div>
            {{/if}}
          </div>
        </div>
        {{/each}}
        {{else}}
        <div class="col-xs-12 well text-center">
          {{#if commentsLoading}}
            <i class="fa fa-spinner fa-3x spinning"></i>
          {{else}}
            No Comments.
          {{/if}}
        </div>
        {{/if}}
      </div>

      <div
        class="modal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="datasetCommentModal"
        id="datasetCommentModal"
      >
        <div class="modal-dialog modal-lg" role="document" style="top:30px;">
          <div class="modal-content">
            <div class="modal-header">
            Comment on <b>{{dataset.name}}</b>
            </div>
            <div class="modal-body">
              <div class="row">
                {{#ember-selector values=commentTypes selected=comment.type class="col-xs-3 pull-left text-right"}}
                {{/ember-selector}}
              </div>
              <div>
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active">
                    <a
                      href="#datasetComment-write"
                      aria-controls="datasetComment-write"
                      role="tab"
                      data-toggle="tab"
                    >
                      Write
                    </a>
                  </li>
                  <li role="presentation">
                    <a
                      href="#datasetComment-preview"
                      aria-controls="datasetComment-preview"
                      role="tab"
                      data-toggle="tab"
                    >
                      Preview
                    </a>
                  </li>
                </ul>
                <div class="tab-content">
                  <div
                    role="tabpanel"
                    class="tab-pane active"
                    id="datasetComment-write"
                  >
                    <div class="meldown_wrap" style="width: 787px;">
                      <div class="mdt_button mdt_button_bold" title="Bold" {{action 'insertElement' 'bold'}}>
                      </div>
                      <div class="mdt_button mdt_button_italic" title="Italic" {{action 'insertElement' 'italic'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_heading_1" title="H1" {{action 'insertElement' 'heading_1'}}>
                      </div>
                      <div class="mdt_button mdt_button_heading_2" title="H2" {{action 'insertElement' 'heading_2'}}>
                      </div>
                      <div class="mdt_button mdt_button_heading_3" title="H3" {{action 'insertElement' 'heading_3'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_list_bullets" title="Bulleted list" {{action 'insertList' 'bulleted'}}>
                      </div>
                      <div class="mdt_button mdt_button_list_numbers" title="Numbered list" {{action 'insertList' 'numbered'}}>
                      </div>
                      <div class="mdt_button mdt_button_blockquote" title="Blockquote" {{action 'insertList' 'blockquote'}}>
                      </div>
                      <div class="mdt_button mdt_button_code" title="Source Code" {{action 'insertSourcecode'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_image" title="Image" {{action 'insertImageOrLink' 'image'}}>
                      </div>
                      <div class="mdt_button mdt_button_link" title="Link" {{action 'insertImageOrLink' 'link'}}>
                      </div>
                      <div class="mdt_button mdt_button_table" {{action 'importCSVTable'}} title="Import CSV table">
                      </div>
                    </div>
                    {{textarea id="datasetcomment" value=comment.text name="text"
                        class="form-control" focus-out="updatePreview"}}
                  </div>
                  <div
                    role="tabpanel"
                    class="tab-pane commentsArea"
                    id="datasetComment-preview"
                  >
                  </div>

                </div>
              </div>
            </div>
            <div class="modal-footer">
              <div class="row">
                <div class="col-xs-6 pull-right text-right">
                  <button
                    type="button"
                    class="btn btn-default"
                    data-dismiss="modal"
                    {{action "hideModal"}}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    class="btn btn-primary"
                    {{action "create" comment}}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
    </script>

		<script type="text/x-handlebars" id="components/dataset-relations">
      {{#if hasDepends}}
			<table id="depends-table" class="columntreegrid tree table table-bordered dataset-detail-table">
				<thead>
					<tr class="results-header">
						<th class="span2">Depends on</th>
						<th class="span1">Object Type</th>
						<th class="span1">Object Sub Type</th>
						<th class="span2">Level</th>
					</tr>
				</thead>
				<tbody>
            {{#each depends as |depend|}}
					<tr class="{{depend.treeGridClass}}">
						<td>
                {{#if depend.isValidDataset}}
							<a href={{depend.datasetLink}}>
                    {{depend.objectName}}
							</a>
							{{else}}
							{{depend.objectName}}
							{{/if}}
						</td>
						<td>{{depend.objectType}}</td>
						<td>{{depend.objectSubType}}</td>
						<td>{{depend.level}}</td>
					</tr>
					{{/each}}
				</tbody>
			</table>
			{{/if}}
			{{#if hasReferences}}
			<table id="references-table" class="columntreegrid tree table table-bordered dataset-detail-table">
				<thead>
					<tr class="results-header">
						<th class="span2">Referred By</th>
						<th class="span1">Object Type</th>
						<th class="span1">Object Sub Type</th>
						<th class="span2">Level</th>
					</tr>
				</thead>
				<tbody>
            {{#each references as |reference|}}
					<tr class="{{reference.treeGridClass}}">
						<td>
                {{#if reference.isValidDataset}}
							<a href={{reference.datasetLink}}>
                    {{reference.objectName}}
							</a>
							{{else}}
							{{reference.objectName}}
							{{/if}}
						</td>
						<td>{{reference.objectType}}</td>
						<td>{{reference.objectSubType}}</td>
						<td>{{reference.level}}</td>
					</tr>
					{{/each}}
				</tbody>
			</table>
			{{/if}}
		</script>

		<script type="text/x-handlebars" id="components/dataset-access">
      {{#if hasAccess}}
			{{#each accessibilities as |accessibility|}}
			<h4>Partition By: {{accessibility.partition}}</h4>
			<table id="references-table" class="columntreegrid tree table table-bordered dataset-detail-table">
				<thead>
					<tr class="results-header">
						<th>Time</th>
						{{#each accessibility.instanceList as |instance|}}
						<th>{{instance}}</th>
						{{/each}}
					</tr>
				</thead>
				<tbody>
              {{#each accessibility.accessibilityList as |access|}}
					<tr>
						<td>{{access.dataTimeExpr}}</td>
						{{#each access.itemList as |item|}}
						<td>
                    {{#unless item.isPlaceHolder}}
							<div>
								<p>Log time: {{item.logTimeEpochStr}}</p>
								<p>Record count: {{item.recordCountStr}}</p>
							</div>
							{{/unless}}
						</td>
						{{/each}}
					</tr>
					{{/each}}
				</tbody>
			</table>
			{{/each}}
			{{else}}
			<p>Accessibility is not available</p>
			{{/if}}
		</script>

		<script type="text/x-handlebars" id="components/metric-detail">
			<div id="metric" class="container-fluid">
				<div class="row-fluid">
					<div class="col-xs-6">
						<h3>{{ model.name }}</h3>
					</div>
					<div class="col-xs-6 text-right">
						<ul class="datasetDetailsLinks">
							<li>
								<i class="fa fa-share-alt"></i>
								<span class="hidden-sm hidden-xs">
                  Share
								</span>
							</li>
							<li>
                {{#metric-watch metric=model showText=true getMetrics='getMetrics'}}
								{{/metric-watch}}
							</li>
							{{#if showLineage}}
							<li>
								<a target="_blank" href={{lineageUrl}}>
									<i class="fa fa-sitemap"></i>
									<span class="hidden-sm hidden-xs">
                    View Lineage
									</span>
								</a>
							</li>
							{{/if}}
						</ul>
					</div>
					<div class="col-xs-12">
            Metric Description:
						<a
						href="#"
						data-name="description"
						data-pk="{{model.id}}"
						class="xeditable"
						data-type="text"
						data-placement="right"
						data-title="Enter description"
						data-emptytext="Please Input"
						data-placeholder="Please Input"
						>
              {{model.description}}
						</a>
					</div>
				</div>
				<table class="tree table table-bordered">
					<tbody>
						<tr class="result">
							<td class="span2" style="min-width:200px;">Dashboard Name</td>
							<td>
								<a
								href="#"
								data-name="dashboardName"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter dashboard name"
								data-defaultValue="Please Input"
								data-emptytext="Please Input"
								data-value="{{model.dashboardName}}"
								>
                  {{model.dashboardName}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Category</td>
							<td>
								<a
								href="#"
								data-name="category"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter metric category"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.category}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Group</td>
							<td>
								<a
								href="#"
								data-name="group"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter group"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.group}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Type</td>
							<td>
								<a
								href="#"
								data-name="refIDType"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter Type"
								data-placement="right"
								data-emptytext="Please Input"
								data-value={{model.refIDType}}
								>
                </a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Grain</td>
							<td>
								<a
								href="#"
								data-name="grain"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter grain"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.grain}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Formula</td>
							<td>
                {{ace-editor content=model.formula itemId=model.id savePath="/api/v1/metrics/{id}/update" saveParam="formula"}}
							</td>
						</tr>
						<tr class="result">
							<td>Metric Display Factor</td>
							<td>
								<a
								href="#"
								data-name="displayFactory"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter display factor"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.displayFactory}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Display Factor Sym</td>
							<td>
								<a
								href="#"
								data-name="displayFactorSym"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter display factor symbol"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.displayFactorSym}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Sub Category</td>
							<td>
								<a
								href="#"
								data-name="subCategory"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter sub category"
								data-placement="right"
								data-emptytext="Please Input"
								>
                  {{model.subCategory}}
								</a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Source</td>
							<td>
								<a
								href="#"
								data-name="source"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter source"
								data-placement="right"
								data-emptytext="Please Input"
								data-value={{model.source}}
								>
                </a>
							</td>
						</tr>
						<tr class="result">
							<td>Metric Source Type</td>
							<td>
								<a
								href="#"
								data-name="sourceType"
								data-pk="{{model.id}}"
								class="xeditable"
								data-type="text"
								data-placement="right"
								data-title="Enter source type"
								data-placement="right"
								data-emptytext="Please Input"
								data-value={{model.sourceType}}
								>
                </a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</script>

    <script type="text/x-handlebars" id="components/schema-comment">
      <i
        class="fa fa-pencil pull-right wh-clickable-icon"
        {{action "openModal"}}
      ></i>
      {{#if propModal}}
      <div class="modal fade" id="datasetSchemaColumnCommentModal" tabindex="-1" role="dialog" aria-labelledby="Dataset Schema Column Comments">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" aria-label="Close" {{action "closeModal"}}>
              <span aria-hidden="true">&times;</span>
            </button>
              <h4 class="modal-title">Comments for <b>{{schema.fieldName}}</b></h4>
            </div>
            <div class="modal-body">
              {{#if loading}}
              <div class="row text-center">
                <div class="col-xs-10 col-xs-offset-1 text-center">
                  <i class="fa fa-spinner spinning fa-4x"></i>
                </div>
              </div>
              {{else}}
                {{#if comments}}
                  {{#each comments as |comment|}}
                  <div class="row">
                    <div class="col-xs-10 col-xs-offset-1 well comment">
                      {{#if comment.isDefault}}
                        <div class="bs-docs-example">
                          <i class="fa fa-star active"></i>
                          Default
                        </div>
                      {{/if}}
                      <div class="text wrap-all-word comment-text commentsArea">
                        {{comment.html}}
                      </div>
                      <div class="meta">
                        <a href="#" class="author">{{comment.authorName}}</a>
                        <span class="date">{{comment.created }}</span>
                        <div class="pull-right actions">
                          <i
                            class="fa fa-arrow-circle-o-up wh-clickable-icon"
                            title="Promote to Default Comment"
                            {{action "setDefault" comment}}
                          >
                          </i>
                          {{#if comment.isAuthor}}
                          <i
                            class="fa fa-pencil wh-clickable-icon"
                            title="Edit"
                            {{action "editMode" comment}}
                          >
                          </i>
                          <i
                            class="fa fa-trash wh-clickable-icon"
                            title="Remove"
                            {{action "remove" comment}}
                          >
                          </i>
                          {{/if}}
                        </div>
                      </div>
                    </div>
                  </div>
                  {{/each}}
                {{else}}
                <div class="row">
                  <div class="col-xs-10 col-xs-offset-1 well text-center">
                    No Comments
                  </div>
                </div>
                {{/if}}
              {{/if}}
              {{#if multiFields}}
              <div class="row">
                <div class="col-xs-12">
                  <div>
                    <ul class="nav nav-tabs" role="tablist">
                      <li role="presentation" class="active">
                        <a href="#similarColumns-view" aria-controls="similarColumns-view" role="tab" data-toggle="tab">
                          Datasets for <b>{{schema.fieldName}}</b>
                        </a>
                      </li>
                      <li role="presentation">
                        <a href="#similarColumns-selected" aria-controls="similarColumns-selected" role="tab" data-toggle="tab">
                          Selected ({{selectedSimilarColumns.length}})
                        </a>
                      </li>
                    </ul>
                    <div class="tab-content" style="overflow-x:hidden; overflow-y: auto; height:400px;">
                      <div role="tabpanel" class="tab-pane active" id="similarColumns-view">
                        <nav>
                          <ul class="pager">
                            <li class="previous">
                              <a href="#" {{action "similarColumnsPrevPage"}}>Prev</a>
                            </li>
                            <li>
                              {{ similarColumns.count }} comments - page {{ similarColumns.page }} of {{ similarColumns.totalPages }}
                            </li>
                            <li class="next">
                              <a href="#" {{action "similarColumnsNextPage"}}>Next</a>
                            </li>
                          </ul>
                        </nav>
                        <table class="table table-striped table-bordered" style="word-break: break-all;">
                          <thead>
                            <tr>
                              <th class="text-center col-xs-1">
                                {{#if similarColumns.selectedAll}}
                                    <input type="checkbox" checked {{action "selectAllSimilarColumn" false}} />
                                  {{else}}
                                    <input type="checkbox" {{action "selectAllSimilarColumn" true}} />
                                {{/if}}
                              </th>
                              <th class="text-center col-xs-2">Dataset Name</th>
                              <th class="text-center col-xs-2">Source</th>
                              <th class="text-center col-xs-2">Data Type</th>
                              <th class="text-center col-xs-5">Default Comment</th>
                            </tr>
                          </thead>
                          <tbody>
                            {{#unless similarColumns.count}}
                              {{#if similarColumns.loading}}
                                <tr>
                                  <td colspan="5">
                                    <div class="row">
                                      <div class="col-xs-12 text-center">
                                        <i
                                          class="fa fa-spinner spinning 2x"
                                        ></i>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              {{else }}
                                <tr>
                                  <td colspan="5">
                                    <div class="row">
                                      <div class="col-xs-12 text-center">
                                        No Similar Columns.
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              {{/if}}
                            {{/unless}}
                            {{#each similarColumns.data as |similar index|}}
                              <tr>
                                <td class="text-center">
                                  {{#if similar.selected}}
                                    <input type="checkbox" checked {{action "selectSimilarColumn" similar index}} />
                                  {{else}}
                                    <input type="checkbox" {{action "selectSimilarColumn" similar index}} />
                                  {{/if}}
                                </td>
                                <td>{{similar.datasetName}}</td>
                                <td>{{similar.source}}</td>
                                <td>{{similar.dataType}}</td>
                                <td>{{similar.html}}</td>
                              </tr>
                            {{/each}}
                          </tbody>
                        </table>
                      </div>
                      <div role="tabpanel" class="tab-pane" id="similarColumns-selected">
                        <table class="table table-striped table-bordered" style="word-break: break-all;">
                          <thead>
                            <tr>
                              <th class="text-center col-xs-1">
                              </th>
                              <th class="text-center col-xs-2">Dataset Name</th>
                              <th class="text-center col-xs-2">Source</th>
                              <th class="text-center col-xs-2">Data Type</th>
                              <th class="text-center col-xs-5">Default Comment</th>
                            </tr>
                          </thead>
                          <tbody>
                            {{#unless selectedSimilarColumns}}
                              <tr>
                                <td colspan="5">
                                  <div class="row">
                                    <div class="col-xs-12 text-center">
                                      No Similar Columns Selected.
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            {{/unless}}
                            {{#each selectedSimilarColumns as |similar index|}}
                              <tr>
                                <td class="text-center">
                                  {{#if similar.selected}}
                                    <input type="checkbox" checked {{action "selectSimilarColumn" similar index}} />
                                  {{else}}
                                    <input type="checkbox" {{action "selectSimilarColumn" similar index}} />
                                  {{/if}}
                                </td>
                                <td>{{similar.datasetName}}</td>
                                <td>{{similar.source}}</td>
                                <td>{{similar.dataType}}</td>
                                <td>{{similar.html}}</td>
                              </tr>
                            {{/each}}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {{/if}}
              {{#unless promotionFlow}}
              <div>
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active">
                    <a
                      href="#datasetSchemaComment-write"
                      aria-controls="datasetSchemaComment-write"
                      role="tab"
                      data-toggle="tab"
                      {{action "setTab" "write"}}>
                      Write
                    </a>
                  </li>
                  <li role="presentation">
                    <a
                      href="#datasetSchemaComment-preview"
                      aria-controls="datasetSchemaComment-preview"
                      role="tab"
                      data-toggle="tab"
                      {{action "setTab" "preview"}}>
                      Preview
                    </a>
                  </li>
                  <li role="presentation">
                    <a
                      href="#datasetSchemaComment-similar"
                      aria-controls="datasetSchemaComment-similar"
                      role="tab"
                      data-toggle="tab"
                      {{action "setTab" "similar"}}
                    >
                      Comments for Similar Fields
                    </a>
                  </li>
                </ul>
                <div class="tab-content">
                  <div
                    role="tabpanel"
                    class="tab-pane active"
                    id="datasetSchemaComment-write">
                    <div class="meldown_wrap" style="width: 787px;">
                      <div class="mdt_button mdt_button_bold" title="Bold" {{action 'insertElement' 'bold'}}>
                      </div>
                      <div class="mdt_button mdt_button_italic" title="Italic" {{action 'insertElement' 'italic'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_heading_1" title="H1" {{action 'insertElement' 'heading_1'}}>
                      </div>
                      <div class="mdt_button mdt_button_heading_2" title="H2" {{action 'insertElement' 'heading_2'}}>
                      </div>
                      <div class="mdt_button mdt_button_heading_3" title="H3" {{action 'insertElement' 'heading_3'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_list_bullets" title="Bulleted list" {{action 'insertList' 'bulleted'}}>
                      </div>
                      <div class="mdt_button mdt_button_list_numbers" title="Numbered list" {{action 'insertList' 'numbered'}}>
                      </div>
                      <div class="mdt_button mdt_button_blockquote" title="Blockquote" {{action 'insertList' 'blockquote'}}>
                      </div>
                      <div class="mdt_button mdt_button_code" title="Source Code" {{action 'insertSourcecode'}}>
                      </div>
                      <div class="mdt_button mdt_button_delimiter">
                      </div>
                      <div class="mdt_button mdt_button_image" title="Image" {{action 'insertImageOrLink' 'image'}}>
                      </div>
                      <div class="mdt_button mdt_button_link" title="Link" {{action 'insertImageOrLink' 'link'}}>
                      </div>
                      <div class="mdt_button mdt_button_table" {{action 'importCSVTable'}} title="Import CSV table">
                      </div>
                    </div>
                    {{textarea id="datasetschemacomment" value=comment.text name="text" class="form-control" focus-out="updatePreview"}}
                  </div>
                  <div
                    role="tabpanel"
                    class="tab-pane commentsArea"
                    id="datasetSchemaComment-preview">
                  </div>
                  <div
                    role="tabpanel"
                    class="tab-pane"
                    id="datasetSchemaComment-similar">
                    <div class="row">
                      <div class="col-xs-12 text-center">
                        <table class="table table-striped" style="word-break: break-all;">
                          <thead>
                            <tr>
                              <th class="col-xs-1"></th>
                              <th class="col-xs-9">Comment</th>
                              <th class="col-xs-2 text-center">Count</th>
                            </tr>
                          </thead>
                          <tbody>
                            {{#each similarComments as |comment index|}}
                            <tr>
                              <td>
                                <input
                                  type="radio"
                                  name="selectedComment"
                                  value={{index}}
                                />
                              </td>
                              <td class="text-left">{{comment.html}}</td>
                              <td>{{comment.count}}</td>
                            </tr>
                            {{/each}}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {{/unless}}
              {{#if commentError}}
              <div class="alert alert-danger alert-dismissible" role="alert">
				        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				        {{errorMsg}}
			        </div>
			        {{/if}}
            </div>
            <div class="modal-footer">
              {{#unless promotionFlow}}
                {{#unless similarFlow}}
                  <button type="button" class="btn btn-primary" {{action "create"}}>
                    Submit
                  </button>
                {{/unless}}
                {{#if similarFlow}}
                  <button type="button" class="btn btn-primary" {{action "promote"}}>
                    Set As Default Comment
                  </button>
                {{/if}}
              {{/unless}}
              {{#if promotionFlow}}
                {{#unless multiFields}}
                  <button
                    class="btn btn-primary"
                    {{action "promote"}}
                  >
                    This Dataset
                  </button>
                  <button
                    class="btn btn-warning"
                    {{action "setMultifields"}}
                  >
                    Multiple Datasets
                  </button>
                {{/unless}}
              {{/if}}
              {{#unless isEdit}}
                {{#if promotionFlow}}
                  {{#if multiFields}}
                  <button
                    class="btn btn-primary"
                    {{action "promote"}}
                  >
                    Promote
                    {{#if promoteLoading}}
                      <i
                        class="fa fa-spinner spinning"
                      >
                      </i>
                    {{/if}}
                  </button>
                  {{/if}}
                {{/if}}
              {{/unless}}

              <button
                type="button"
                class="btn btn-default"
                data-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
      {{/if}}
    </script>

		<!-- Piwik -->
		<script type="text/javascript">
				var _paq = _paq || [];
				_paq.push(['trackPageView']);
				_paq.push(['enableLinkTracking']);
				(function() {
					var u="//piwik.corp.linkedin.com/piwik/";
					_paq.push(['setTrackerUrl', u+'piwik.php']);
					_paq.push(['setSiteId', 94]);
					var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
					g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
				})();
		</script>
		<noscript><p><img src="//piwik.corp.linkedin.com/piwik/piwik.php?idsite=94" style="border:0;" alt="" /></p></noscript>
		<!-- End Piwik Code -->

  </body>
</html>
