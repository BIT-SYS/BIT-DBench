#Eclipse
.classpath
.project
test-output

#IntelliJ
*.iml
*.ipr
*.iws
.idea/

#Build directories
bin
target