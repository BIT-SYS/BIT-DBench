package android.webkit;

public class WebView {
    public void setWebViewClient (WebViewClient client) {}
    public void setWebChromeClient (WebChromeClient client) {}
}
