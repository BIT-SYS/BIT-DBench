package testcode.sqli;

public class JdoSql {



}
