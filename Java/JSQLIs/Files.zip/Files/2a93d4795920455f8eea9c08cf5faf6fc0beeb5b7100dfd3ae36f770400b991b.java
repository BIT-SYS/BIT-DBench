package com.h3xstream.findsecbugs.sql;

public class HibernateInjectionDetector {
}
