# Changelog
# $Id$
nn-nn-14 - Version 5.1.35

  - Fix for Bug#74998 (20112694), readRemainingMultiPackets not computed correctly for rows larger than 16 MB.

11-03-14 - Version 5.1.34

  - Fix for Bug#73012 (19219158), Precedence between timezone options is unclear.

  - Implement support for connecting through SOCKS proxies (WL#8105). Connection properties supporting this are socksProxyHost, socksProxyPort.

  - Ant buildfile reworked to fix incompatibilities with latest Eclipse, to remove dependency from ant-contrib and to improve structure and documentation.

  - Fix for Bug#18474141, TESTSUITE.FABRIC TEST CASES FAIL IF NO FABRIC.TESTSUITE PROPERTIES PROVIDED

  - Fix for Bug#19383371, CONNECT USING MYSQL_OLD_PASSWORD USER FAILS WHEN PWD IS BLANK

09-29-14 - Version 5.1.33

  - Fix for Bug#17441747, C/J DOESN'T SUPPORT XA RECOVER OUTPUT FORMAT CHANGED IN MYSQL 5.7.
    Test case was disabled for affected server versions 5.7.0 - 5.7.4.

  - Fix for Bug#19145408, Error messages may not be interpreted according to the proper character set

  - Fix for Bug#19505524, UNIT TEST SUITE DOES NOT CONSIDER ALL THE PARAMETERS PASSED TO BUILD.XML.

  - Fix for Bug#73474 (19365473), Invalid empty line in MANIFEST.MF

  - Fix for Bug#70436 (17527948), Incorrect mapping of windows timezone to Olson timezone.
    TimeZone mappings were revised in order to use latest data from IANA Time Zone Database and Unicode CLDR.

  - Fix for Bug73163 (19171665), IndexOutOfBoundsException thrown preparing statement.
    Regression test added. Fix was included in patch from 5.1.32: "Fix for failing tests when running test suite with Java 6+".

  - Added support for gb18030 character set

  - Fix for Bug#73663 (19479242), utf8mb4 does not work for connector/j >=5.1.13

  - Fix for Bug#73594 (19450418), ClassCastException in MysqlXADataSource if pinGlobalTxToPhysicalConnection=true

  - Fix for Bug#19354014, changeUser() call results in "packets out of order" error when useCompression=true.

  - Fix for Bug#73577 (19443777), CHANGEUSER() CALL WITH USECOMPRESSION=TRUE COULD LEAD TO IO FREEZE

  - Fix for Bug#19172037, TEST FAILURES WHEN RUNNING AGAINST 5.6.20 SERVER VERSION

08-04-14 - Version 5.1.32

  - Fix for Bug#71923 (18344403), Incorrect generated keys if ON DUPLICATE KEY UPDATE not exact.
    Additionally several methods in StringUtils were fixed/upgraded.

  - Fix for Bug#72502 (18691866), NullPointerException in isInterfaceJdbc() when using DynaTrace

  - Fix for Bug#72890 (18970520), Java jdbc driver returns incorrect return code when it's part of XA transaction.

  - Fabric client now supports Fabric 1.5. Older versions are no longer supported.

  - Fix for Bug#71672 (18232840), Every SQL statement is checked if it contains "ON DUPLICATE KEY UPDATE" or not.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#73070 (19034681), Preparing a stored procedure call with Fabric results in an exception

  - Fix for Bug#73053 (19022745), Endless loop in MysqlIO.clearInputStream due to Linux kernel bug.
    In the source of this issue is a Linux kernel bug described in the patch "tcp: fix FIONREAD/SIOCINQ" 
    (https://git.kernel.org/cgit/linux/kernel/git/torvalds/linux.git/commit/?id=a3374c4).

  - Fix for Bug#18869381, CHANGEUSER() FOR SHA USER RESULTS IN NULLPOINTEREXCEPTION

  - Fix for Bug#62577 (16722757), XA connection fails with ClassCastException

  - Fix for Bug#18852587, CONNECT WITH A USER CREATED USING SHA256_PASSWORD PLUGIN FAILS WHEN PWD IS BLANK

  - Fix for Bug#18852682, TEST TESTSHA256PASSWORDPLUGIN FAILS WHEN EXECUTE AGAINST COMMERCIAL SERVER

  - Fix for failing tests when running test suite with Java 6+.
    Includes fix for Bug#35829 (11748301), build.xml check for java6 should use or instead of and.

  - Charset mappings refactored.

  - Fix for Bug#72712 (18836319), No way to configure Connector JDBC to not do extra queries on connection

06-09-14 - Version 5.1.31

  - Fix for Bug#66947 (16004987), Calling ServerPreparedStatement.close() twice corrupts cached statements.

  - Fix for Bug#61213 (18009254), ON DUPLICATE KEY UPDATE breaks generated key list when extended INSERT is used

  - Test cases updated to comply with MySQL 5.7.4 new STRICT_MODE behavior and no longer supported IGNORE clause in
    ALTER TABLE statement.

  - Added support for sha256_password authentication with RSA encryption.

  - Fix for Bug#71753 (18260918), Bad SSL socket transform.

  - Added tests for changes in GET DIAGNOSTIC syntax introduced in MySQL 5.7.0.

  - Fix for Bug#67803 (16708231), XA commands sent twice to MySQL server.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#55680 (16737192), MySQL Connector/J memory leak

  - Fix for Bug#72326 (18598665), Typo in fullDebug.properties - gatherPerMetrics should be gatherPerfMetrics

  - Fix for Bug#72023 (18403456), Avoid byte array creation in MysqlIO#unpackBinaryResultSetRow.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#72000 (18402873), java.lang.ArrayIndexOutOfBoundsException on java.sql.ResultSet.getInt(String).

  - Fix for Bug#71850 (18318197), init() is called twice on exception interceptors

  - Fix for Bug#72008 (18389973), Avoid useless object creation in StringUtils#getBytes-methods.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#72006 (18403199), Avoid creation of a character array in PreparedStatement$ParseInfo.
    Thanks to Andrej Golovnin for his contribution.
    Additionally, unneeded StringBuffer replaced by StringBuilder instances in StringUtils.

  - Fix for Bug#72301 (18549472), Fabric driver swallows exceptions thrown during connection creation using JDBC4

03-28-14 - Version 5.1.30

  - Fix for Bug#71679 (18236388), Avoid iterator creation when invoking statement interceptors in MysqlIO.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#70944 (17831255), community and commercial builds should have the same line number tables

  - Fix for Bug#71861 (18327245), Avoid manual array copy in MysqlIO and LoadBalancingConnectionProxy.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#71623 (18228668), Field#getStringFromBytes() creates useless byte array when using JVM converter.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#71621 (18228302), MysqlXAConnection#xidToString(Xid xid) produces too much garbage.
    Thanks to Andrej Golovnin for his contribution.

  - Fix for Bug#67318 (16722637), SQLException thrown on already closed ResultSet. Thanks to Thomas Manville and Andrej Golovnin for their contribution.

  - Fix for Bug#71396 (18110320), setMaxRows (SQL_SELECT_LIMIT) from one query used in later queries (sometimes).
    Additionally, SQL_SELECT_LIMIT is no longer sent unnecessarily between consecutive queries.

  - Fix for Bug#71432 (18107621), Key store files not closed when making SSL connection

  - Reserved words lists updated from latest official SQL:92 and SQL:2003 specifications.

  - Fix for Bug#18091639, STRINGINDEXOUTOFBOUNDSEXCEPTION IN PREPAREDSTATEMENT.SETTIMESTAMP WITH 5.6.15

  - Added Fabric support

02-10-14 - Version 5.1.29

  - Fix for Bug#70701 (17647584), DatabaseMetaData.getSQLKeywords() doesn't match MySQL 5.6 reserved words.

  - Fix for Bug#17435879, REMOVE SRC/LIB-NODIST DIRECTORY FROM LAUNCHPAD DISTRIBUTION.
    Additional "com.mysql.jdbc.extra.libs" parameter must be used for ant build.

  - Fix for Bug#71038, Add an option for custom collations detection.
    Added new connection property detectCustomCollations=[true|false], with default false.
    Please be aware that these changed the previous default behavior and if you use custom charsets or collations
    you need to set detectCustomCollations=true.

  - Added tests for new index renaming syntax introduced in 5.7.1.

12-23-13 - Version 5.1.28

  - Fix for Bug#69579, DriverManager.setLoginTimeout not honored.

  - Fix for Bug#51313, Escape processing is confused by multiple backslashes.

  - Fix for Bug#55340, initializeResultsMetadataFromCache fails on second call to stored proc.

  - Fix for Bug#70969, Shadow declaration of OperationNotSupportedException in RowDataDynamic.

  - Fix for Bug#70835 (17750877), SQLExceptions thrown because of query interruption (KILL QUERY, query timeout, etc.)
    didn't extend java.sql.SQLNonTransientException for JDBC4+ deployments.

  - Fix for Bug#24344 test case, test fails if it's run with UTC timezone settings. 

  - Fix for Bug#69777, Setting maxAllowedPacket below 8203 makes blobSendChunkSize negative.

  - Fix for Bug#35115, yearIsDateType=false has no effect on result's column type and class.

  - Fix for Bug#68916 (16691047), closeOnCompletion doesn't work.

  - Fix for Bug #69746 (17164058), ResultSet closed after Statement.close() when dontTrackOpenResources=true

  - Fix for Bug#70842 (17753369), Adding live management of replication host topographies.

11-04-13 - Version 5.1.27

  - Fix for Bug#17248345, getFunctionColumns() method returns columns of procedure.

  - Fix for Bug#69290 (16879239), JDBC Table type "SYSTEM TABLE" is used inconsistently.

  - Fix for Bug#68562, Combination rewriteBatchedStatements and useAffectedRows not working as expected.

  - Fix for Bug#69452 (17015673), memory size connection property doesn't support large values well.

  - Added tests for InnoDB full-text search support introduced in 5.6GA.

  - Extended slow query warning with query execution plan for INSERT, REPLACE, UPDATE and DELETE.

  - Added tests for IPv6 functions introduced in 5.6GA.

  - Added support of authentication data up to 2^64-1 bytes.

  - Fix for Bug#38252, ResultSet.absolute(0) is not behaving according to JDBC specification.

  - Fix for Bug#62469, JDBC Authentication Fails with Null Byte in Scramble

  - Fix for Bug#69506, XAER_DUPID error code is not returned when a duplicate XID is offered in Java.

  - Added support for multi-master replication topographies in ReplicationDriver.  ReplicationDriver now uses two discrete load-balanced
    connections, one each for master and slave connections.  The same load-balancing options which apply to load-balanced connections
    now also apply to ReplicationConnections.  By default, this means that when a ReplicationConnection uses master connections
    (because the read-only property of the Connection is false), work may be re-balanced between configured master hosts at transaction 
    boundaries.  As with load-balanced connections, the ReplicationConnection host list may be managed within the JVM (see
    com.mysql.jdbc.ReplicationConnectionGroupManager) or optionally via JMX (using replicationEnableJMX configuration option; see
    com.mysql.jdbc.jmx.ReplicationGroupManagerMBean).  To specify multi-master replication topographies, define each host "type"
    property using the following format:
 
    address=(host=hostname)(port=3306)(type=[master|slave])

    In the absense of explicit type definitions, the driver will assume a single master listed first, with all subsequently-listed
    hosts configured as slaves.

  - Fix for Bug#63354 (16443992), JDBC cannot make new connections if master is down.

  - Fix for Bug#17003626, REGRESSION TEST FAILURE WITH SERVER VERSION 5.7.1

  - Removed ant-contrib.jar from C/J distribution.

  - Added tests for GIS precise spatial operations introduced in 5.6GA.

  - Fixed META-INF information

  - Fix for Bug#17251955, ARRAYINDEXOUTOFBOUNDSEXCEPTION ON LONG MULTI-BYTE DB/USER NAMES

  - Fix for Bug#50538, DatabaseMetaData.getDriverVersion() contains unexpanded ${bzr.revision-id}

08-05-13 - Version 5.1.26

  - Fix for Bug#69298 (16845965), Methods DatabaseMetaData.getProcedures() and DatabaseMetaData.getProcedureColumns(), in JDBC4,
    return stored procedure only or both stored procedures and functions metadata information, depending on the value set in the
    connection property "getProceduresReturnsFunctions", having default value 'true'. Several fixes in Functions and
    Procedures metadata so that consulting I__S and MySQL/DDL returns the same info.

  - Fix for Bug#69308 (16879267), Avoid calling batchedStatement.close() twice, and thus raising and ignoring an undercover SQLException, in methods
    PreparedStatement.executeBatchedInserts and PreparedStatement.executePreparedBatchAsMultiStatement.

  - Fix for Bug#68400, useCompression=true and connect to server, zip native method cause out of memory.
    CompressedInputStream now does not keep reference to connection.
    Thank Dominic Tootell for his investigation, proposed solution and all the help he provided.

  - Fix for Bug#65871, DatabaseMetaData.getColumns() throws an MySQLSyntaxErrorException.
    Delimited names of databases and tables are handled correctly now. The edge case is ANSI quoted
    identifiers with leading and trailing "`" symbols, for example CREATE DATABASE "`dbname`". Methods
    like DatabaseMetaData.getColumns() allow parameters passed both in unquoted and quoted form,
    quoted form is not JDBC-compliant but used by third party tools. So when you pass the indentifier
    "`dbname`" in unquoted form (`dbname`) driver handles it as quoted by "`" symbol. To handle such
    identifiers correctly a new behavior was added to pedantic mode (connection property pedantic=true),
    now if it set to true methods like DatabaseMetaData.getColumns() treat all parameters as unquoted.

  - Fix for Bug#45757 (11754192), Don't allow updateRow() to be called when updatable cursor is positioned on insert row.

  - Fix for Bug#68098 (16224299), Return indexes sorted by NON_UNIQUE, TYPE, INDEX_NAME, and ORDINAL_POSITION in DatabaseMetaData.getIndexInfo.
  
  - Fix for Bug#68307 (16707803), Return correct COLUMN_TYPE from both getProcedureColumns() and getFunctionColumns().

  - Fix for Bug#42267, PreparedStatementWrapper doesn't have a toString() implementation

  - Fix for Bug#44451 (11753081), Added missing fields in methods getColumns(), getProcedureColumns(), getTables() and getUDTs().
    Methods getClientInfoProperties() and getFunctions() were made available in all *DatabaseMetaDataUsingInfoSchema implementations.

05-06-13 - Version 5.1.25

  - Fix for Bug#68801, java webstart mysql-connector-java lib calls -bin library.

  - Fix for Bug#16426462, SyntaxRegressionTest failing on C/J 5.1.24 against MySQL 5.6.10

  - Fix for Bug#60816, Cannot pass NULL to an INOUT procedure parameter.

  - Added support for Connection Attributes when used with MySQL Server versions (5.6+) which support this feature.  
    By default, the following standard attributes are sent to the server, where they can be seen in the 
    performance_schema.session_connect_attrs table:
     * _client_version : the version of MySQL Connector Java in use
     * _client_name : "MySQL Connector Java"
     * _runtime_version : the version of the Java runtime environment in which the driver is running
     * _runtime_vendor : the name of company which produced the Java runtime environment
    Additionally, users may supply their own key/value attributes to be exposed by providing them in 
    "key1:value1,key2:value2" format in the connectionAttributes connection property.
    To avoid sending any connection attributes to the server, set connectionAttributes property to "none".
    
  - Fix for Bug#68763 (16545334), ReplicationConnection.isMasterConnection() returns false always.

  - Fix for Bug#68733 (16526938), ReplicationConnection doesn't ping all slaves.

  - Fix for Bug#68556, Tomcat can't stop a cleanup thread by clearReferencesStopThreads.

  - Fix for Bug#16436511, getDriverName() returns a string with company name "MySQL-AB". Driver name changed to "MySQL Connector Java".

  - Fix for Bug#68664 (16486957), Enable packaging of .JAR file from Eclipse.

03-05-13 - Version 5.1.24

  - Fix for Bug#64204, ResultSet.close hangs if streaming query is killed.

  - Fix for Bug#16224249, Deadlock on concurrently used LoadBalancedMySQLConnection:
    1) abortInternal() method was moved from com.mysql.jdbc.MySQLConnection to com.mysql.jdbc.Connection interface;
    2) load-balanced/failover proxy now broadcasts abortInternal() to all underlying physical connections;
    3) load-balanced/failover proxy now prevents picking of new physical connection after close() or abortInternal() were called explicitly on proxy;
    4) connection synchronization mutex was refactored, now mutex is proxy instance for proxied connection or connection instance itself if there is no proxy.

  - Fix for Bug#64805, StatementImpl$CancelTask occasionally throws NullPointerExceptions.

  - Fixed typos in descriptions of properties.

  - Fix for Bug#68011, Invalid error message noDatetimeSync property instead of noDatetimeStringSync.

02-04-13 - Version 5.1.23

  - Fix for Bug#35653, executeQuery() in Statement.java let "TRUNCATE" queries being executed. "TRUNCATE" and "RENAME" are now filtered for executeQuery().

  - Fix for Bug#65909, referenceThread causes memory leak in Tomcat.
    Abandoned connection cleanup thread was refactored to have static shutdown method.
    If you encountered this leak problem, your application should implement context listener with
    AbandonedConnectionCleanupThread.shutdown() call in contextDestroyed method.

    For example:
       @WebListener
       public class YourThreadsListener implements ServletContextListener {
          public void contextDestroyed(ServletContextEvent arg0) {
             try {
                 AbandonedConnectionCleanupThread.shutdown();
             } catch (InterruptedException e) {
             }
          }
          ...
       }

    Note that if container does not support annotations you should add description to web.xml:
       <listener>
          <listener-class>user.package.YourThreadsListener</listener-class>
       </listener>

  - Added tests for explicit partition selection syntax introduced in 5.6GA.

  - Added support of password expiration protocol. This introduces new boolean connection property disconnectOnExpiredPasswords.
    If disconnectOnExpiredPasswords = true and password expired then connection will be rejected by server with ErrorCode == 1820 (ER_MUST_CHANGE_PASSWORD).
    If disconnectOnExpiredPasswords = false then connection will enter to "sandbox" mode,
    all commands except SET PASSWORD = ... and SET PASSWORD FOR CURRRENT_USER() = ... will cause an error to be thrown.

  - Added tests for EXCHANGE PARTITION syntax introduced in 5.6GA.

  - Added tests for transportable tablespaces syntax introduced in 5.6GA.

  - Added tests for CREATE TABLE syntax changed in 5.6GA: CREATE TABLE ... DATA DIRECTORY = 'absolute/path/to/directory/'

  - Added tests for ALTER TABLE syntax changed in 5.6GA: ALGORITHM and LOCK keywords.

  - Fix for Bug#67954, stack trace used for point-of-origin in log and exception messages
    causes permgen leak with webapp classloader on application redeploy. We no longer store the entire
    stack trace, only the calling class and method, and even then, that only when using the usage advisor
    or when profiling.
    
  - Fix for Bug#11237, useCompression=true and LOAD DATA LOCAL INFILE SQL Command.

  - Static charset/collation maps were updated.

  - Fix for Bug#14260352, difference in Timestamp value returned with rewriteBatchedStatements=true.

  - Fix for Bug#60598, nativeSQL() truncates fractional seconds.

  - Fix for Bug#40279, Timestamp values get truncated when passed as prepared statement parameters.
    This was partly fixed in 5.1.19 but that fix did not cover useLegacyDatetimeCode=true case.

  - Fix for Bug#14665141, Diff results returned from ResultSet and CachedRowSet with new password hashing.
    Test suite modified to don't perform comparison of PASSWORD() results if old_passwords=2
    because with SHA-256 password hashing enabled they are nondeterministic.
    
  - The driver now allows the mechanism for caching MySQL server configuration values replaceable at runtime,
    via the "serverConfigCacheFactory" property. The default is an implementation that is a per-VM concurrent
    map, keyed by URL. The driver will invalidate cache entries when SQLExceptions that indicate communications
    errors are thrown (on the assumption that the server has been or is restarting), or if the server version
    that is being connected to, differs from the one that was present when the cached values were populated.
    
    To replace the default implementation, implement CacheAdapterFactory<String, Map<String, String>>, and
    use the fully-qualified class name of this implementation for "serverConfigCacheFactory".
    
  - Connection.setReadOnly() will take advantage of server-side support for read-only transactions
    present in MySQL-5.6 and newer. Calling .isReadOnly() will incur a round-trip if useLocalSessionState
    is not enabled.

09-06-12 - Version 5.1.22
  - Fix for Bug#57662, Incorrect Query Duration When useNanosForElapsedTime Enabled.

  - Fix for Bug#65503, ResultSets created by PreparedStatement.getGeneratedKeys() are not close()d.

  - Fix for Bug#63800, getVersionColumns() does not return timestamp fields; always empty.
    Added support of ON UPDATE CURRENT_TIMESTAMP for TIMESTAMP and DATETIME fields.

  - Fix for Bug#41752, Can't connect mysqld which character_set_server=ucs2.

  - Fix for Bug#65508, getCharsetNameForIndex() should be faster.

  - Fix for Bug#14563127, Load-balanced connection fails to select valid host, closes connection
    on re-balance.

07-05-12 - Version 5.1.21
  - Added new built-in authentication plugin com.mysql.jdbc.authentication.Sha256PasswordPlugin
    ("sha256_password").

  - Fix for Bug#64731, StringUtils.getBytesWrapped throws StringIndexOutOfBoundsException.

  - Added new built-in authentication plugin com.mysql.jdbc.authentication.MysqlClearPasswordPlugin
    ("mysql_clear_password"). It allows C/J based clients to connect to MySQL accounts which use
    PAM authentication for example. SSL connection required for this authentication method.
    If SSL is not enabled then authentication which requires "mysql_clear_password" will lead to an error.

  - Fix for Bug#13980303, Auth plugin's confidentiality requirements are not checked after Auth Switch Request.

  - Fix for Bug#64205, Connected through Connector/J 5.1 to MySQL 5.5, the error message is garbled.

  - Fix for Bug#37931, Null Pointer Exception Thrown When specifying invalid character_set_results enc.

  - Fix for Bug#36662, TimeUtil.java: MEST mapping n/a.

  - Fix a scalability/memory footprint issue where Object.finalize() was being used on 
    ConnectionImpl to clean up the low-level network connection to MySQL should a 
    connection be abandoned by the application before being cleanly close()d. We now
    track connections in a phantom reference queue, and have a single thread per-vm
    clean these up when the VM notices the connection is no longer referenced by
    anything else.
    
  - Added the ability to add new client-side prepared statement parse info caches by
    implementing com.mysql.jdbc.CacheAdapterFactory and telling the driver to use it
    when "cachePrepStmts=true" via the "parseInfoCacheFactory" configuration property. 
    
  - Implemented JDBC-4.1 methods from Java-7:
  
       - Connection.setSchema(String) - no-op, until we support database==schema in the driver
       - Connection.getSchema() - see above
       - Connection.abort(Executor executor)
       - Connection.setNetworkTimeout(Executor, int)
       - Connection.getNetworkTimeout() throws SQLException;
       - CallableStatement.getObject(int, Class<T>)
       - CallableStatement.getObject(String, Class<T>)
       - DBMD.getPseudoColumns() - returns an empty result set
       - DBMD.generatedKeyAlwaysReturned() - always true for MySQL
       - ResultSet.getObject(int, Class<T>)
       - ResultSet.getObject(String, Class<T>)
       - Statement.closeOnCompletion()
       - Statement.isCloseOnCompletion()

05-02-12 - Version 5.1.20
  - Fix for Bug#64983, 5.1.19 not working with JBoss AS 4.2.3.GA.

  - Fix for Bug#13960556, java.lang.StringIndexOutOfBoundsException in com.mysql.jdbc.PreparedStatement.formatNanos(int nanos).

  - Fix for pluggable authentication tests to run on Windows.

  - Fix for Bug#13897714, NPE in testsuite.regression.StatementRegressionTest.testBug1933() with 5.6.5_m8 server.

  - Fix for Bug#55962, Savepoint identifier is occasionally considered as floating point numbers.

  - Fix for Bug#13955027, SET OPTION syntax was removed starting from 5.6.5 server version.

  - Fix for Bug#13958793, ClassCastException in ConnectionImpl.buildCollationMapping() with 4.1 server.

  - Fix for Bug#36478, Client prepared statement bugged if word 'limit' included in the query.

04-02-12 - Version 5.1.19
  - Fix for Bug#64621, setMaxRows was not correctly processed during CS PS metadata
    collection causing entire resultset to be fetched and possibly leading to OOM.

  - Fix for Bug#63456, MetaData precision is different when using UTF8 or Latin1 tables.
	The problem was in finding maxBytesPerChar through versioned mapping from Java charset to MySQL charset.
	That map returns "utf8mb4" instead "utf8" for server versions starting with 5.5.2.
	CharsetMapping, ConnectionImpl and Field have been reorganized to use static maps INDEX_TO_MYSQL_CHARSET,
	STATIC_CHARSET_TO_NUM_BYTES_MAP instead. Also dynamic maps ConnectionImpl.indexToCustomMysqlCharset
	and ConnectionImpl.mysqlCharsetToCustomMblen have been added for custom charsets.

  - Added support for pluggable authentication via the com.mysql.jdbc.AuthenticationPlugin
    interface (which extends standard "extension" interface). Examples are in
    com/mysql/jdbc/authentication and in testsuite.regression.ConnectionRegressionTest.
    This introduces three new properties:

       authenticationPlugins defines comma-delimited list of classes that implement
       com.mysql.jdbc.AuthenticationPlugin and which will be used for authentication
       unless disabled by "disabledAuthenticationPlugins" property.

       disabledAuthenticationPlugins defines comma-delimited list of classes implementing
       com.mysql.jdbc.AuthenticationPlugin or mechanisms, i.e. "mysql_native_password".
       The authentication plugins or mechanisms listed will not be used for authentication
       which will fail if it requires one of them. It is an error to disable the default
       authentication plugin (either the one named by "defaultAuthenticationPlugin" property
       or the hard-coded one if "defaultAuthenticationPlugin" propery is not set).

       defaultAuthenticationPlugin defines name of a class implementing
       com.mysql.jdbc.AuthenticationPlugin which will be used as the default authentication
       plugin. It is an error to use a class which is not listed in "authenticationPlugins"
       nor it is one of the built-in plugins. It is an error to set as default a plugin
       which was disabled with "disabledAuthenticationPlugins" property. It is an error
       to set this value to null or the empty string (i.e. there must be at least a valid
       default authentication plugin specified for the connection, meeting all constraints
       listed above).

  - Fix for Bug#63526. The problem happens in com.mysql.jdbc.EscapeProcessor#escapeSQL.  The function recognizes the string in the create table statement as an escape sequence (line 136+138). The "if" construct beginning in line 182 tries to match a white-space collapsed version of the string to prefixes for valid jdbc-escapes (till line 300). Since no matching escape sequence is found and no "else" clause is defined, neither the token, nor replacement are added to the resulting escaped SQL string.

  - Fix for Bug#61203, noAccessToProcedureBodies does not work anymore.

  - Fix for Bug#63811, pointless Socket.bind() when using ephemeral ports and interfaces, which limits scalability on some platforms.
    
  - Connection.changeUser() would not check for closed connections, leading to NPEs when this method was called on a closed connection.
	
  - Fix for Bug#63284, memory leak with Failover proxied Statement/PreparedStatement with DBCP due to improper implementation of equals().
    
  - Prepared statements would needlessly allocate a 4K buffer for converting
    streams when no set*Stream() methods had been used.
  
10-03-11 - Version 5.1.18
 
  - Fix for Bug#12565726, not putting the space between VALUES() and ON DUPLICATE KEY UPDATE
	causes C/J a) enter rewriting the query although it has ON UPDATE 
	and b) to generate the wrong query with multiple ON DUPLICATE KEY

  - Fix for Bug#12784170, "process fork failure" errors while running test suite via ant on Windows.
    Added new ant flag, com.mysql.jdbc.junit.fork, which controls whether JUnit will fork new processes
    for testing ("on", default and legacy behavior) or not ("off", required for Windows).  

  - Reverting changes made to ConnectionImpl.java,
    private boolean characterSetNamesMatches function.

  - Added function MYSQL_INDEX_TO_MYSQL_CHARSET to retrieve server charset name
    using index instead of parsing variables to CharsetMapping.java.

  - Completed fix for Bug#61201/12649557, fixed tests failures.
  
  - Fix for Bug#61201/12649557, Can't establish connection when url has
    sessionVariables and characterEncoding. Fix covers only MySQL server 4.1+
    
  - Fix for Bug#61501 - Calling Statement.cancel() on a statement that isn't
    currently executing will cause some later-executed query on the same
    connection to be cancelled unexpectedly. The driver now guards against this
    condition, but it is an underlying server issue. The MySQL statement "KILL QUERY"
    (which is what the driver uses to implement Statement.cancel()) is rather
    non-deterministic, and thus the use of Statement.cancel() should be avoided
    if possible.
    
  - Fix for Bug#61866/12791594 - Calling Statement.getWarnings() after
    Statement.clearWarnings() has been called, returns the "old" warnings.
    
  - Fix for Bug#13036537 - LRUCache was really a least-recently-added cache.

  - Fix for Bug#13036309, Correcting parameter name in maxPerformance.properties.


07-04-11 - Version 5.1.17

  - Fix for Bug#61332 - LIKE not optimized in server when run against I__S tables and no wildcards used.
    Databases/tables with "_" and/or "%" in their names (escaped or not) will be handled by this code path,
	although slower, since it's rare to find these characters in table names in SQL. If there's a "_" or "%"
	in the string, LIKE will take care of that, otherwise we now use = . The only exception is
	information_schema database which is handled separately. Patch covers both getTables() and getColumns().

  - Fix for Bug#61150 - First call to stored procedure fails with "No Database Selected".
	The workaround introduced in DatabaseMetaData.getCallStmtParameterTypes to fix
	the bug in server where SHOW CREATE PROCEDURE was not respecting lower-case table names
	is misbehaving when connection is not attached to database and on non-casesensitive OS.

  - Fix for Bug#61105 - Avoid a concurrent bottleneck in Java's character set
    encoding/decoding when converting bytes to/from Strings.
    
04-21-11 - Version 5.1.16

  - Partial fix for BUG#54135 - setQueryTimeout unsafe across VIP. Fix prevents c/J from 
    killing the right ConnectionID but on wrong server.

  - Fix for BUG#57808 - wasNull not set for DATE field with value 0000-00-00
	in getDate() although zeroDateTimeBehavior is convertToNull.

  - Fix for Bug#54425 - Bypassing the server protocol bug where DB should be null-terminated
    whether it exists or not. Affects COM_CHANGE_USER.
	
  - Fix for Bug#60313 (11890729), bug in 
    com.mysql.jdbc.ResultSetRow.getTimestampFast().

  - Fix for bug 11782297, DBMD.getTables (so thus getColumns too) fails with 
    table names containing dot (like "junk_[Sp:e,c/ C-h+a=.r]").
  
  - Added the ability to determine if the connection is against a server on the 
    same host via the Connection.isServerLocal() method.
    
  - Fix for bug 12325877, Setting "autoReconnect=true" and 
    "cacheServerConfiguration=true" would cause connections created after
    an existing connection fails to have non-existent values for server
    variables which lead to exceeding of max allowed packet exceptions when the
    new connections were used.

02-08-11 - Version 5.1.15

   - Fix for Bug#38367, parameters metadata did not reflect the fact that NULL is allowed 
     parameter value. So DatabaseMetaData.getProcedureColumns will set isNullable member to
	 java.sql.DatabaseMetaData.procedureNullable now.

   - Completed fix for Bug#27916.

   - Fix for Bug#59224, adding 5.5 reserved words to DatabaseMetaData.getSQLKeywords().

   - Fixed an issue where statement comments set via Connection.setStatementComment()
     weren't represented in autoGenerateTestcaseScript=true output.
     
   - Added ability to include the current java thread dump in the exception message
     given for deadlock/wait lock timeout exceptions, enable with 
     "includeThreadDumpInDeadlockExceptions=true" in your JDBC url.

   - Added ability to include current thread name as a statement comment visible
     in MySQL's "SHOW PROCESSLIST" and Innodb deadlock diagnostics, enable with
     "includeThreadNamesAsStatementComment=true".
     
   - Added an SLF4J logging adapter. Enable by adding setting the connection 
     property "logger" to "Slf4JLogger" and placing the appropriate bridge
     from SLF4J to the logging framework of choice in your CLASSPATH. As with
     other Connector/J logging adapters, the log category name used by the 
     driver is "MySQL". See http://www.slf4j.org/manual.html for more details. 
     
12-06-10 - Version 5.1.14

   - Fix for Bug#58728, NPE in com.mysql.jdbc.jdbc2.optional.StatementWrappe.getResultSet()
     if rs is null. Regression test case added to Statement regression tests.

   - Fix for Bug#58751, DatabaseMetadata.getIndexInfo() CARDINALITY now clamped
     to Integer.MAX_VALUE.

   - Fix for BUG#58590
   - Testsuite.Simple.DateTest, MetadataTest, NumbersTest and StatementsTest cleaned and fixed.

   - Testsuite.simple, ConenctionTest & DataSourceTest are up to date. Major rework on 
     ConnectionTest.testDeadlockDetection (Sveta) and testUseCompress.
   
   - Testsuite.simple, CallableStatementTest & CharsetTests are up to date.
   
   - Testsuite.regression SubqueriesRegressionTest and StringRegressionTest are up to date.

   - Testsuite.regression MicroPerformanceRegressionTest, NumbersRegressionTest, PooledConnectionRegressionTest,
     ResultSetRegressionTest are up to date.

   - Testsuite.regression.MetaDataRegressionTest up to date.
   
   - Typo in StatementRegressionTest.testLikeWithBackslashes fixed. StatementRegressionTest
     is up to date.

   - Fix for Bug#58232 - CallableStatement fails to fetch OUT parameter against 5.5 server
   
   - Testsuite.regression.Connection, tests for BUG#45419 refined by Todd so not to cause failures.

   - Testsuite.regression.CallableStatement, tests for BUG#26959 failing against 5.5+ server.

   - Bringing testsuite.regression.CachedRowsetTest up to date.

   - Bringing BLOBregression tests up to date.

   - Fix for Bug#58042 - Statements test failure not handled.

   - Fix for Bug#57850 - Refresh SELECT statement doesn't use correct data type.
     Added Field.valueNeedsQuoting (private final boolean) and protected boolean getvalueNeedsQuoting().
	 UpdatableResultSet refresher and updater call upon this value now.
	 
   - Removing commented source in fix for Bug#57697
   - Fix for Bug#57697 - Metadata getTables() was not checking for table_name already been quoted.
   - Fix for Bug#57694 - 3byte UTF8 can not be used with 5.5.3+ server.
   - Fix for Bug#57701 - StatementsTest.testBatchRewriteErrors() failing on new servers.
   
   - Fix for Bug#54756 - Cannot retrieve data from ResultSet by column name from a Sphinx daemon.
     We were relying only on "server version string" passed. Now, determining
	 server version is done via protocol flags too, where applicable.

   - Fix for Bug#57022 - cannot execute a store procedure with output parameters,
     database parameter was ignored in db.sp notation. The fix is to "sanitize" 
	 db.sp call just like in patch for noAccessToProcedureBodies. BaseTestCase
	 extended with createDatabase and dropDatabase. Regression test added.

   - Fix for Bug#57262 - "useOldUTF8Behavior" behavior was broken since 5.1.3,
     now explicitly sets connection character set to latin1 ("SET NAMES latin1")
     during connection post-handshake process.
     
   - Patch for problem where "noAccessToProcedureBodies=true" was causing 
     "underprivileged" user not to have access to procedures created by him.

   - Patch for Bug#56305, unhandled NPE in DatabaseMetaData.java when calling 
     wrong-cased function without access to mysql.proc. Although simple by 
     itself, some more enhancements were needed for everything to function 
     properly.  So, along with catching potential NPE due to server bug, a 
     guard against calling JDBC functions with db_name.proc_name notation was 
     also added. Necessary changes added to StringUtils.java too.

   - Added ability to load-balance while auto-commit is enabled.  This 
     introduces two new properties:

       loadBalanceAutoCommitStatementThreshold defines the number of matching 
       statements which will trigger the driver to (potentially) swap physical 
       server connections, 

       loadBalanceAutoCommitStatementRegex defines the regular expression 
       against which statements must match.  The default values (0 and blank, 
       respectively) retain the previously-established behavior that 
       connections with auto-commit enabled are never balanced.  Feature 
       request documented in Bug#55723.

   - Minor fix in getProcedureColumns() DisplaySize for Bug#51712. Fix for 
     Bug#41269 is not complete without this.  getColumnDisplaySize on a 
     ResultSet already consisting of metadata is now functional thanks to 
     Bogdan.

   - Minor fix for Bug#55217, return 4 as a result of DataBaseMetadata.getJDBCMajorVersion() as per manual.

   - Added support for hosts specified in the URL of the form: 
     address=(key=value), supported keys are:
       
       (protocol=tcp or pipe (for named pipes on Windows)
       (path=[] for named pipes)
       (host=[]) for TCP connections 
       (port=[]) for TCP connections 
       
       An example would be:
       
       jdbc:mysql://address=(protocol=tcp)(host=localhost)(port=3306)(user=test)/db
       
      Any other parameters are treated as host-specific properties that follow 
      the conventions of the JDBC URL properties. This now allows per-host 
      overrides of any configuration property for multi-host connections 
      (failover, loadbalance, replication). We do recommend that the overrides 
      are limited to user, password, network timeouts and statement and 
      metadata cache sizes. Unexpected behavior may be observed with other 
      per-host overrides.

    - Fix for Bug#56099 - Added support for JDBC4-specific functionality when 
      using load-balanced connections.

    - Fix for Bug#56200 - Added diagnostic information to SQLException message 
      thrown when a closed load-balanced connection is reused.  This 
      information will identify the conditions which caused the connection to 
      be closed.
      
    - Fix for Bug#56429 - When using Connector/J configured for failover 
      (jdbc:mysql://host1,host2,... URLs), the non-primary servers re-balance 
      and spawned new idle connections when the transactions on the master were
      committed or rolled-back, eventually exceeding max_connections. It was 
      also discovered that session state (autocommit, isolation level, catalog)
      wasn't  being copied from the primary connection to secondary 
      connections correctly because of the same changes that caused this bug, 
      and this was fixed as well.
     
    - Fix for Bug#56706 - Ensure read-only state is synchronized when new 
      load-balanced connections are selected.
      
    - Fixed Bug#56955 - Connection properties "trustCertificateKeyStoreType" 
      and "clientCertificateKeyStoreType" have invalid defaults, therefore 
      connections that specify "useSSL" will sometimes fail with exceptions 
      from JSSE unless "JKS" has been specified for both of these properties. 
      The default value for these properties is now "JKS", and thus it no 
      longer has to be specified.
      
    - Fixed Bug#56979 - Improper connection closing logic leads to TIME_WAIT 
      sockets on server
      
    - Fixed Bug#57380 - DatabaseMetaData.supportsMultipleResultSets() now returns
      true when connected to a 4.1 version or later server.
      
    - Fixed Bug#58706 - Failover connections didn't honor "failOverReadOnly=false", and in some
      situations would not fall back.
      
    - Removed logging integrations with log4j and apache-commons-logging due to license 
      incompatibility. Replacing with SLF4J integration in next release.

06-24-10 - Version 5.1.13

   - Minor fix in previous patch for Bug#51904. Function ConnectionImpl.setCatalog() was passed quoted argument thus breaking with "...for the right syntax to use near 'test``'"
	  
    - Fix for Bug#51912 - Passing NULL as cat. param to getProcedureColumns with !nullCatalogMeansCurrent
	
    - Fix for Bug#52167 - Can't parse parameter list with special characters inside
	
    - Fix for Bug#51904 - getProcedureColumns() always returns PROCEDURE_CAT result column as NULL
	
    - Fix for Bug#51712 - Display Size is always 0 for columns returned by getProcedureColumns()

    - Fix for Bug#51908 - db variable might have end up unassigned when calling
      getProcedureColumns()/Functions(). This is a followup on code changes made
      for Bug#51022.
    
    - Fixed Bug#51266 - jdbc:mysql:loadbalance:// would stick to the first
      host in the list in some cases, especially exacerbated if the host was
      down.
      
    - Replaced URLs of the form jdbc:mysql://host-1,host-2 with a composite of
      a normal connection and a jdbc:mysql:loadbalance:// connection for more 
      robustness and cleaner code.
      
    - Fixed BUG#51643 - Connections using jdbc:mysql:loadbalance:// would 
      have statements (and prepared statements) that did not have their connections
      changed upon commit()/rollback(), and thus applications that held statement
      instances past commit()/rollback() could have data written to or read from
      un-intended connections.
      
    - Fixed BUG#51666 - StatementInterceptors were never "un-safed" after connection 
      establishment, causing interceptors which returned result sets pre/post execution
      would not work.
      
    - Fixed BUG#51783 - Load-balanced connections could throw a SQLException
      incorrectly on commit() or rollback().  This was not caused by failures in commit
      or rollback, but rather by the possibility that the newly-selected physical
      connection was stale.  Added logic to catch and retry if this happens, up to
      the number of hosts specified for load-balancing.  Also added new property,
      loadBalanceValidateConnectionOnSwapServer, which controls whether to explicitly
      ping the selected host (otherwise, the host is presumed to be up, and will only
      be noticed if auto-commit or transaction isolation state needs to be set and
      fails).
      
    - Added loadBalancePingTimeout property to allow a specific timeout to be set
      for each ping executed against the servers.  This ping is executed when the
      physical connections are rebalanced (commit/rollback or communication exception),
      or when a query starting with (exactly) "/* ping */" is executed.  The latter
      causes each open underlying physical connection to be pinged.

    - Fixed BUG#51776 - Connection.rollback() could swallow exceptions incorrectly.

    - Fixed BUG#52231 - Differences in definitions of which SQLExceptions trigger
      a failover event could result in failure to try more than a single host in 
      certain situations.
      
    - Fixed BUG#52534 - Performance regression using load-balanced connection.  

    - More aggressively purge the statement timeout timers after they've been cancelled to
      trade time for memory. This purge only happens if statement timeouts are in use.
      
    - Added management of running load-balanced connections.  Statistics can be obtained,
      and hosts added/dropped via com.mysql.jdbc.ConnectionGroupManager or the JMX
      implementation.  This functionality is enabled by setting the new paramenter,
      loadBalanceConnectionGroup to the name of the logical grouping of connections.
      All load-balanced connections sharing the same loadBalanceConnectionGroup value,
      regardless of how the application creates them, will be managed together.  To
      enable JMX-based management, set loadBalanceEnableJMX=true and ensure that remote
      JMX is enabled in the JRE (eg, use -Dcom.sun.management.jmxremote).
      
    - Added loadBalanceExceptionChecker property, which takes a fully-qualified class
      name implementing com.mysql.jdbc.LoadBalancedExceptionChecker interface.  This
      allows custom evaluation of SQLExceptions thrown to determine whether they should
      trigger failover to an alternate host in load-balanced deployments.  The default
      is com.mysql.jdbc.StandardLoadBalanceExceptionChecker.
      
    - Added two new properties which allow more flexibility in determining which
      SQLExceptions should trigger failover in a load-balanced deployment.  The new
      loadBalanceSQLStateFailover property takes a comma-delimited list of SQLState
      codes which are compared to the SQLState of the SQLException (matching done
      with trailing wildcard), while loadBalanceSQLExceptionSubclassFailover takes
      a comma-delimited list of fully-qualified class/interface names, against
      which the SQLException is checked to determine if it is an instance of any.
      Matches trigger failover to an alternate host.
      
    - Fixed Bug#51704 - Re-written batched statements don't honor escape processing 
      flag of their creator.
      
    - Fixed Bug#43576 - Sometimes not able to register OUT parameters for 
      CallableStatements.
      
    - Fixed Bug#54175 - Driver doesn't support utf8mb4 for servers 5.5.2 and newer. The
      driver now auto-detects servers configured with character_set_server=utf8mb4 or
      treats the Java encoding "utf-8" passed via "characterEncoding=..." as utf8mb4 in
      the "SET NAMES=" calls it makes when establishing the connection. 
    
02-18-10 - Version 5.1.12

    - NO_INDEX_USED and NO_GOOD_INDEX used were only being set when profileSQL 
      was set to "true", and in some cases their values were reversed.

    - Fix for Bug#51022 - conn.getMetaData().getProcedures("schema",null,"%"); 
      returns all stored procedures from all databases and not only for given 
      one.
	
    - Fixed Bug#50538 - ${svn.revno} shows up in DBMD.getDriverVersion().
    
    - Removed usage of timestamp nanoseconds in PreparedStatement.setTimestamp(),
      as long as Bug#50774 exists in the server and there's no real support
      for nanos/micros in TIMESTAMPs, avoid the performance regression usage of 
      them causes.

    
01-20-10 - Version 5.1.11
 
    - Fix for BUG#50288 - NullPointerException possible during invalidateCurrentConnection() for load-balanced
      connections.
 
    - Fix for BUG#49745 - deleteRow() for updatable result sets can cause full table scan because escaped hex 
      values are used for primary key identifiers.
 
    - Fix for BUG#49607 - Provide Connection context in ExceptionInterceptor.
 
    - Fix for BUG#48605 - Ping leaves closed connections in liveConnections, causing subsequent Exceptions when
      that connection is used.
 
    - Fix for BUG#48442 - Load-balanced Connection object returns inconsistent results for hashCode() and equals()
      dependent upon state of underlying connections.
 
    - Fix for BUG#48172 - Batch rewrite requires space immediately after "VALUES"
    
    - Statement Interceptors didn't completely intercept server-side prepared statements.
    
    - Fix for BUG#48486 Cannot use load balanced connections with MysqlConnectionPoolDataSource.
    
    - Fix for Bug#32525 - "noDatetimeStringSync" doesn't work for server-side prepared statements. Now it does.

    - Hooked up exception interceptors so they get called now.
    
    - Rev'd the statement interceptor interface to pass on some server flags, warning counts and errors. See 
      the com.mysql.jdbc.StatementInteceptorsV2 interface for more details. The driver will create adaptors to
      transparently convert older implementations to the newer interface at runtime.
      
    - Statement Interceptors are now enabled at connection instantiation, but 
      can not return result sets (they will be ignored)  until the connection 
      has bootstrapped itself. If during the init() method your interceptor 
      requires access to the connection itself, it should ensure that methods 
      that might throw exceptions if the connection is closed should handle 
      this in a robust manner.
      
    - "Replication" connections (those with URLs that start with 
      jdbc:mysql:replication) now use a jdbc:mysql:loadbalance connection
      under the hood for the slave "pool". This also means that one can set
      load balancing properties such as "loadBalanceBlacklistTimeout" and
      "loadBalanceStrategy" to choose a mechanism for balancing the load and
      failover/fault tolerance strategy for the slave pool. This work was done
      in order to fix Bug#49537.
      
    - Fixed Bug#36565 - permgen leak from java.util.Timer. Unfortunately no great
      fix exists that lets us keep the timer shared amongst connection instances, so
      instead it's lazily created if need be per-instance, and torn down when the 
      connection is closed.
      
    - Fixed BUG#49700 - Connections from ConnectionPoolDataSource don't
      maintain any values set with "sesssionVariables=...". This was a bug
      in Connection.changeUser()/resetServerState(), we now resubmit the
      session variables during the execution of these methods.
    
09-22-09 - Version 5.1.10

    - Fix for BUG#47494 - Non standard port numbers in the URL are not honored.

09-16-09 - Version 5.1.9

    - The driver has been OSGi-ified. The bundle symbolic name is "com.mysql.jdbc", see META-INF/MANIFEST.MF to see
      what interfaces we export.
      
    - Fixed BUG#45040, adding missing tags from SVN import to BZR branch for
      5.1.
      
    - Fix for a variant of Bug#41484 - ResultSet.find*(String) failed when using cached result set
      metadata.
      
    - Fixed BUG#46637 - When the driver encounters an error condition that causes it to create a 
      CommunicationsException, it tries to build a friendly error message that helps diagnose 
      what is wrong. However, if there has been no network packets received from the server, 
      the error message contains bogus information like:

      "The last packet successfully received from the server was 1,249,932,468,916 milliseconds ago.  
      The last packet sent successfully to the server was 0 milliseconds ago."
      
      Now the error message states that it has never received any packets from the server in this
      scenario.
      
    - Added a new option, "queryTimeoutKillsConnection", when set to "true" will cause timeouts set
      by Statement.setQueryTimeout() to forcibly kill the connection, not just the query.
      
    - Fixed BUG#32216, "PORT" property filled in by Driver.parseURL() not always present. The driver 
      will now always fill in the "PORT" (using 3306 if not specified) property, and the "HOST" property 
      (using "localhost" if not specified) when parseURL() is called. The driver also parses a list of hosts 
      into HOST.n and PORT.n properties as well as adding a property "NUM_HOSTS" for the number of hosts 
      it has found. If a list of hosts is passed to the driver, "HOST" and "PORT" will be set to the 
      values given by "HOST.1" and "PORT.1" respectively. This change has centralized and cleaned up a large
      swath of code used to generate lists of hosts, both for load-balanced and fault tolerant connections and
      their tests.
      
    - Fixed the ResultSet side of BUG#23584 - Calendar discared when retrieving dates from server-side prepared
      statements. The other cases of this bug were fixed when "useLegacyDatetimeCode=false" became the default.

    - Fixed Bug#44324 - Data truncation exceptions did not return the vendor error code from the server. Note that
      the vendor error code is not hard-coded to 1265 as in the bug report, because the server returns different
      error codes for different types of truncations, and we did not want to mask those.
      
    - Fixed Bug#27431 - ResultSet.deleteRow() advances the cursor. The driver now places the cursor on the prior
      row in the result set, or before the start of the result set if the result set is empty after the deletion.
      
    - Fixed Bug#43759 - ResultSet.deleteRow() generates corrupt DELETE statement for primary keys with binary
      data.
      
    - Fixed Bug#46925 - Suspendable XA connections were not pinned to the XID for the global transaction, leading
      to failure when attempting to suspend/resume/commit from different logical XA connections.
      
    - Fixed Bug#44508 - DatabaseMetadata.getSuperTypes() returns result set with incorrect column names.
      
    - Fixed Bug#46788 - Batched prepared statements with ON DUPLICATE KEY UPDATE are rewritten incorrectly when
      when there are parameters as part of the UPDATE clause. Statements of this form can not be rewritten
      as multi-value INSERTs so they are rewritten into multi-statements instead.

07-16-09 - Version 5.1.8
    - Fixed BUG#44588 - Fixed error message for connection exceptions when
      streaming result sets are used.
      
    - Modified/fixed test cases using UnreliableSocketFactory.

    - Fixed BUG#43421 - Made doPing() global blacklist-aware, so that it does not
      throw Exceptions when at least a single load-balanced server is available.

    - Fixed BUG#43071 - Specifying ASCII encoding for converting seed String to
      byte array; allowing system default encoding to be used causes auth failures
      on EBCDIC platforms.

    - Fixed BUG#43070 - traceProtocol parameter isn't configured early enough to
      capture handshake protocol.

    - Fixed BUG#41161 - PreparedStatement.addBatch() doesn't check for all parameters
      being set, which leads to a NullPointerException when calling executeBatch() and
      rewriting batched statements into multi-value or multi-statement statements.

    - Fixed BUG#42055 - ConcurrentModificationException possible when removing items
      from global blacklist.
      
    - Fixed Bug #42309 - Statement.getGeneratedKeys() returns 2 keys when
      using ON DUPLICATE KEY UPDATE
      
    - Fixed some quoting of substituted parameter issues in localized error messages.
    
    - Added a version check around getting the variable 'auto_increment_increment' for
      servers < 5.0.2, which quiets down a warning message that the driver would log
      when connecting to MySQL-4.1 or older.
      
    - The driver will automatically disable elideSetAutoCommit and useLocalTransactionState
      if it detects a MySQL server version older than 6.0.10 with the query cache enabled, due
      to Bug#36326 which can cause the server to report bogus transaction state.
      
    - Fixed a performance regression (Bug#41532) in rewritten batched inserts when "ON DUPLICATE KEY" 
      was present.
      
      Fixes include an improvement to token searching in the statement, and the ability for the driver
      to rewrite prepared statements that include "ON DUPLICATE KEY UPDATE" into multi-valued inserts as
      long as there is no use of LAST_INSERT_ID() in the update clause (as this would render 
      getGeneratedKey() values incorrect).
      
    - Fixed Bug#44056 - Statement.getGeneratedKeys() retains result set instances until statement is closed,
      thus causing memory leaks for long-lived statements, or statements used in tight loops.
      
    - Fixed issues with server-side prepared statement batch re-writing caused by the fix to Bug#41532.
      Rewriting of batched statements now works the same between normal prepared statements and server-side
      prepared statements.
      
    - Fixed Bug#44862 - getBestRowIdentifier does not return resultset as per JDBC API specifications

    - Fixed Bug#44683 - getVersionColumns does not return resultset as per JDBC API specifications

    - Fixed Bug#44865 - getColumns does not return resultset as per JDBC API specifications

    - Fixed Bug#44868 - getTypeInfo does not return resultset as per JDBC API specifications

    - Fixed Bug#44869 - getIndexInfo does not return resultset as per JDBC API specifications

    - Fixed Bug#44867 - getImportedKeys/exportedKeys/crossReference doesn't have correct type for DEFERRABILITY

    - Fixed Bug#41730 - SQL Injection when using U+00A5 and SJIS
    
    - Fixed Bug#43196 - Statement.getGeneratedKeys() doesn't return values for UNSIGNED BIGINTS with values > Long.MAX_VALUE.
      Unfortunately, because the server doesn't tell clients what TYPE the auto increment value is, the driver can't consistently 
      return BigIntegers for the result set returned from getGeneratedKeys(), it will only return them if the value is > Long.MAX_VALUE. 
      If your application needs this consistency, it will need to check the class of the return value from .getObject() on the 
      ResultSet returned by Statement.getGeneratedKeys() and if it's not a BigInteger, create one based on the java.lang.Long that 
      is returned.
      
    - Fixed Bug#38387 - "functionsNeverReturnBlobs=true" now works for SQL functions that return binary/binary collation VAR_STRINGS.

    - Fixed Bug#45171 - Connection.serverPrepareStatement() returns wrong default result set types
    
    - Fixed Bug #43714 - useInformationSchema with
      DatabaseMetaData.getExportedKeys() throws exception

    - Fixed Bug #42253 - multiple escaped quotes cause exception from
      EscapeProcessor

    - Fixed Bug #41566 - Quotes within comments not correctly ignored by
      statement parser

    - Fixed Bug #41269 - DatabaseMetadata.getProcedureColumns() returns
      wrong value for column length

    - Fixed Bug #40439 - Error rewriting batched statement if table name
      ends with "values".

    - Fixed Bug #41484 Accessing fields by name after the ResultSet is closed throws
      NullPointerException.

    - Fixed Bug #39426 - executeBatch passes most recent PreparedStatement params
      to StatementInterceptor
      
    - Support use of INFORMATION_SCHEMA.PARAMETERS when "useInformationSchema" is set "true" and the view exists
      for DatabaseMetaData.getProcedureColumns() and getFunctionColumns().
      
    - When "logSlowQueries" is set to "true", and the driver has made a connection to a server that has suport
      for the SERVER_QUERY_WAS_SLOW flag in the protocol, the query will be logged if the server indicates the
      query has passed the slow query threshold.

    - Added new property, "maxAllowedPacket" to set maximum allowed packet size to
      send to server.

10-22-08 - Version 5.1.7
	- Fixed BUG#33861 - Added global blacklist for LoadBalancingConnectionProxy and
	  implemented in RandomBalanceStrategy and BestResponseTimeBalanceStrategy.
	  Added new property, "loadBalanceBlacklistTimeout", to control how long a
	  server lives in the global blacklist.
	  
	- Fixed BUG#38782 - Possible IndexOutOfBoundsException in random load balancing
	  strategy.
	  
	- Fixed BUG#39784 - invalidateCurrentConnection() does not manage global blacklist
	  when handling connection exceptions.

	- Fixed BUG#40031 - Adding support for CallableStatement.execute() to call
	  stored procedures that are defined as NO SQL or SQL READ DATA when failed
	  over to a read-only slave with replication driver.

	- Fixed BUG#35170- ResultSet.isAfterLast() doesn't work with for
	  streaming result sets.
	  
	- Fixed BUG#35199 - Parse error for metadata in stored function.
	
	- Fixed BUG#35415 - When result set is from views without access to underlying
	  columns and is opened with CONCUR_UPDATABLE, don't throw SQLExceptions when
	  checking updatability due to access permissions, instead return
	  CONCUR_READONLY from getConcurrency.
	  
	- Fixed BUG#35666 - NullPointerException when using "logSlowQueries=true" with
	  server-side prepared statements enabled.
	  
	- Fixed BUG#35660 - Calling equals() on connections created with "jdbc:mysql:loadbalance:"
	  URLs did not have the same behavior as "plain" connections. The behavior we use
	  is the implementation in java.lang.Object, load-balanced connections just happened
	  to be using a java.lang.reflect.Proxy which required some custom behavior in 
	  equals() to make it work the same as "plain" connections.
	  
	  Note that there is no *specified* equals contract for JDBC connections in the
	  JDBC specification itself, but the test makes sure that our implementation is
	  at least consistent.
	    
	- Fixed BUG#35810 - Properties set in URLs and then passed to DataSources via setUrl() 
	  did not take effect in certain circumstances. This also fixes related bugs BUG#13261 and
	  BUG#35753.
	  
	- Fixed BUG#36051 - ResultSet.getTime() won't accept value of '24' for hours component of
	  a java.sql.Time.
	  
	- Fixed BUG#36830 - DBMD.getColumns() doesn't return correct COLUMN_SIZE for SET columns. The
	  logic wasn't accounting for the ","s in the column size.
	  
    - Fixed BUG#35610, BUG#35150- ResultSet.findColumn() and ResultSet.get...(String) doesn't allow
      column names to be used, and isn't congruent with ResultSetMetadata.getColumnName().
      
      By default, we follow the JDBC Specification here, in that the 4.0 behavior
	  is correct. Calling programs should use ResultSetMetaData.getColumnLabel() to dynamically determine
	  the correct "name" to pass to ResultSet.findColumn() or ResultSet.get...(String) whether or not the
	  query specifies an alias via "AS" for the column. ResultSetMetaData.getColumnName() will return the
	  actual name of the column, if it exists, and this name can *not* be used as input to ResultSet.findColumn()
	  or ResultSet.get...(String).
	  
	  The JDBC-3.0 (and earlier) specification has a bug, but you can get the buggy behavior
	  (allowing column names *and* labels to be used for ResultSet.findColumn() and get...(String)) by setting 
	  "useColumnNamesInFindColumn" to "true".
	
	- Fixed BUG#35489 - Prepared statements from pooled connections cause NPE when closed() under JDBC-4.0.
	
	- Added connection property "useLocalTransactionState" which configures if the driver use the in-transaction 
	  state provided by the MySQL protocol to determine if a commit() or rollback() should actually be sent to the database.
	  (disabled by default).
	  
	- Use socket timeouts for JDBC-4.0's Connection.isValid(int timeout) instead of timer tasks, for scalability. As a side effect
	  internally, any communications with the database can use a timeout different than the configured timeout, but this isn't currently
	  used.
	  
	- The number and position of columns for "SHOW INNODB STATUS" changed in MySQL-5.1, which caused the 
	  "includeInnodbStatusInDeadlockExceptions" feature to not show data about the deadlock.
	  
	- Implemented support of INFORMATION_SCHEMA for DatabaseMetadata.getTables() (views there are available as "SYSTEM TABLE"), and thus
	  also made INFORMATION_SCHEMA tables available via DatabaseMetadata.getColumns().
	  
	- Fixed BUG#39352, "INSERT ... ON DUPLICATE KEY UPDATE" doesn't return "0" for un-affected rows. This requires the driver to not
	  send the "CLIENT_FOUND_ROWS" flag to the server when it connects if the connection property "useAffectedRows" is set to "true", 
	  which breaks JDBC-compliance, but currently there is no other way to get correct return values from the server.
	  
	- Fixed BUG#38747 - ResultSets in "streaming" mode throw an exception when closed when the connection is set as "read-only".
	  
	- Fixed BUG#37570 - Can't use non-latin1 passwords. Added connection property "passwordCharacterEncoding". Leaving this set to 
	  the default value (null), uses the platform character set, which works for ISO8859_1 (i.e. "latin1") passwords. For passwords 
	  in other character encodings, the encoding will have to be specified with this property, as it's not possible for the driver to 
	  auto-detect this.
	  
	- Fixed BUG#39911 - We don't retrieve nanos correctly when -parsing- a string for a TIMESTAMP. MySQL itself doesn't support micros
	  or nanos in timestamp values, but if they're stored as strings, historically we try and parse the nanos portion as well. 
	  Unfortunately we -interpreted- them as micros. This fix includes correcting that behavior, and setting the milliseconds portion of
	  such TIMESTAMPs to a correct value as well.
	  
	- Fixed BUG#39962 - ResultSet.findColumn() is slow for applications that call it too often (we're looking at -you- Hibernate). We're
	  using TreeMaps to get case-insensitive comparisons (required for JDBC compliance), but they can be slower than hash maps, so using the
	  approach Alex Burgel points out in this bug seems to help.
	  
	- Fixed BUG#39956 - Statement.getGeneratedKeys() doesn't respect the 'auto_increment_increment' value. We now grab the *session-scoped* 
	  value, and use that. Beware that using "cacheServerConfig=true" will cause us to cache this value, so new connections won't see changes
	  that are applied via something like "init-sql".
	  
	- Fixed BUG#39611 - ReplicationConnection never sends queries to last host in slave list.
	
	- Fixed BUG#34185 - Statement.getGeneratedKeys() does not raise exception when statement was not 
	  created with Statement.RETURN_GENERATED_KEYS flags.
	  
	- Using autoGenerateTestcaseScript=true now logs all statements, regardless or not if they cause errors when processed by MySQL.
	  A "clock" value (millis since epoch) was added in the comment that is pre-pended with the idea that it can then be used
	  when post-processing output to sequence things correctly for a multi-threaded testcase, or to replay the test case with the
	  correct think times.
	
03-06-08 - Version 5.1.6

    - JDBC-4.0-ized XAConnections and datasources.
    
    - Fixed BUG#31790 MysqlValidConnectionChecker 
      doesn't properly handle ReplicationConnection
    
    - Fixed Bug#20491 - DatabaseMetadata.getColumns() doesn't
      return correct column names if connection character set
      isn't UTF-8. (There was a server-side component of this that
      was fixed late in the 5.0 development cycle, it seems, this
      is the last piece that fixes some loose ends in the JDBC
      driver). This fix touches *all* metadata information coming
      from the MySQL server itself.
      
    - Fixed MysqlIO.nextRowFast() to only attempt to read server
      warning counts and status if talking to a 4.1 or newer server
      (fixes a hang when reading data from 4.0 servers).
      
    - Made profiler event handling extensible via the "profilerEventHandler"
      connection property.
      
    - Fixed Bug#31823 - CallableStatement.setNull() on a stored function would 
      throw an ArrayIndexOutOfBounds when setting the last parameter to null when calling setNull().

    - Added SSL-related configuration property "verifyServerCertificate". If set to "false", the driver won't verify 
      the server's certificate when "useSSL" is set to "true".
      
      When using this feature, the keystore parameters should be specified by the 
      "clientCertificateKeyStore*" properties, rather than system properties, as the JSSE doesn't
      make it straightforward to have a non-verifying trust store and the "default" key store.
      
    - Fixed ResultSetMetadata.getColumnName() for result sets returned from
      Statement.getGeneratedKeys() - it was returning null instead of
      "GENERATED_KEY" as in 5.0.x.
      
    - More applicable fix for the "random" load balance strategy in the face
      of node non-responsive, it re-tries a *different* random node, rather 
      than waiting for the node to recover (for BUG#31053)
      
    - Fixed BUG#32577 - no way to store two timestamp/datetime values that happens
      over the DST switchover, as the hours end up being the same when sent as
      the literal that MySQL requires.

      Note that to get this scenario to work with MySQL (since it doesn't support
      per-value timezones), you need to configure your server (or session) to be in UTC,
      and tell the driver not to use the legacy date/time code by setting
      "useLegacyDatetimeCode" to "false". This will cause the driver to always convert
      to/from the server and client timezone consistently.
      
      This bug fix also fixes BUG#15604, by adding entirely new date/time handling
      code that can be switched on by "useLegacyDatetimeCode" being set to "false" as
      a JDBC configuration property. For Connector/J 5.1.x, the default is "true",
      in trunk and beyond it will be "false" (i.e. the old date/time handling code, warts
      and all will be deprecated).
      
    - Fixed BUG#32877 - Load balancing connection using best response time would incorrectly
      "stick" to hosts that were down when the connection was first created.
      
      We solve this problem with a black list that is used during the picking of new hosts.
      If the black list ends up including all configured hosts, the driver will retry for
      a configurable number of times (the "retriesAllDown" configuration property, with a default
      of 120 times), sleeping 250ms between attempts to pick a new connection.
      
      We've also went ahead and made the balancing strategy extensible. To create a new strategy,
      implement the interface com.mysql.jdbc.BalanceStrategy (which also includes our standard
      "extension" interface), and tell the driver to use it by passing in the
      class name via the "loadBalanceStrategy" configuration property. 
      
    - Fixed BUG#30508 - ResultSet returned by Statement.getGeneratedKeys() is not closed 
      automatically when statement that created it is closed.
      
    - Added two new connection properties, "selfDestructOnPingSecondsLifetime" and 
      "selfDestructOnPingMaxOperations" designed to control overall connection lifetime
      (useful to reclaim resources on the server side) for connection pools that don't have such a 
      facility. 
      
      The driver will consult the values of these properties when a ping is sent, either through 
      calling Connection.ping(), issuing the "ping marker" query (any query that starts with 
      "/* ping */"), or when using JDBC-4.0, calling Connection.isValid(). 
      
      If the connection has issued too many operations, or is too old, the driver will
      throw a SQLException with the SQLState of "08S01" at the time of the ping, which
      will cause the connection to be invalidated with most pools in use today.
      
    - Fixed issue where driver could send invalid server-side prepared statement 
      IDs to the server when the driver was setup to do auto-reconnect as the
      connection could get set up enough to start sending queries on one thread,
      while the thread that "noticed" the connection was down hasn't completed
      re-preparing all of the server-side prepared statements that were open when
      the connection died.
      
      Potentially fixes cause for bug 28934. Potentially fixes other possible race
      conditions where one thread that has created a connection "shares" it with other
      threads if the connection is reconnected due to auto-reconnect functionality.
      
    - Fixed BUG#33823 - Public interface ResultSetInternalMethods with reference to 
      non-public class com.mysql.jdbc.CachedResultSetMetaData.
      
    - For any SQLException caused by another Throwable, besides dumping the message or stack
      trace as a string into the message, set the underlying Throwable as the cause for
      the SQLException, making it accessible via getCause().  
     
    - Fixed BUG#34093 - Statements with batched values do not return correct values for 
      getGeneratedKeys() when "rewriteBatchedStatements" is set to "true", and the 
      statement has an "ON DUPLICATE KEY UPDATE" clause.

    - Fixed BUG#31192 - Encoding Issue retrieving serverVersion in MysqlIO in the 
      method doHandshake when encoding doesn't contain ASCII characters in the "standard"
      place (i.e. ebcdic).
      
    - Fixed issue where META-INF in the binary .jar file wasn't packed correctly,
      leading to failure of the JDBC-4.0 SPI mechanism.
       
    - CallableStatements that aren't really stored procedure or stored function calls can
      now be used, for tools such as Oracle JDeveloper ADF that issue statements such as 
      DDL through CallableStatements.
    
    - Fixed BUG#34518 - Statements using cursor fetch leaked internal prepared statements
      until connection was closed. The internal prepared statement is now held open while
      the result set is open, and closed by the result set itself being closed.

    - Fixed BUG#34677 - Blob.truncate() wouldn't take "0" as an argument.

    - CommunicationExceptions now carry information about the last time a packet
      was received from the MySQL server, as well as when the last packet was sent
      to one, in an effort to make it easier to debug communications errors caused
      by network timeouts.
      
    - Reverted a change to DatabaseMetadata.getColumns() from 5.0, where
      getColumns() would report NULL for COLUMN_SIZE for TIME, DATE, DATETIME
      and TIMESTAMP types. It now reports the column size, in the 
      DatabaseMetadata implementations that use "SHOW" commands, and the 
      INFORMATION_SCHEMA.
      
    - Fixed Bug#34762 - RowDataStatic does't always set the metadata in 
      ResultSetRow, which can lead to failures when unpacking DATE,
      TIME, DATETIME and TIMESTAMP types when using absolute, relative,
      and previous result set navigation methods.
      
    - Fixed BUG#34703 - Connection.isValid() invalidates connection after
      timeout, even if connection is actually valid.
      
    - Fixed BUG#34194 - ResultSetMetaData.getColumnTypeName() returns
      "UNKNOWN" for GEOMETRY type.
      
    - Fixed BUG#33162 - NullPointerException instead of SQLException 
      thrown for ResultSet.getTimestamp() when not positioned on a
      row.

    - The ConnectionLifecycleInterceptor interface now has callback methods for
      transaction initiation (transactionBegun()), and completion 
      (transactionCompleted()), as reported by the *server* (i.e. 
      calling Connection.setAutoCommit(false) will not trigger 
      transactionBegun() being called, however the first statement
      which causes a transaction to start on the server will cause
      transactionBegun() to be called *after* the statement has been processed
      on the server).

    - Fixed Bug#34913 - ResultSet.getTimestamp() returns incorrect
      values for month/day of TIMESTAMPs when using server-side
      prepared statements (not enabled by default).
      
    - Fixed BUG#34937 - MysqlConnectionPoolDataSource does not support 
      ReplicationConnection. Notice that we implemented com.mysql.jdbc.Connection
      for ReplicationConnection, however, only accessors from ConnectionProperties
      are implemented (not the mutators), and they return values from the currently
      active connection. All other methods from com.mysql.jdbc.Connection are
      implemented, and operate on the currently active connection, with the exception of
      resetServerState() and changeUser().
      
    - Connections created with jdbc:mysql:replication:// URLs now force
      roundRobinLoadBalance=true on the slaves, and round-robin loadbalancing
      now uses a "random" choice to more evenly distribute load across slave
      servers, especially in connection pools. Connections that are configured
      with "roundRobinLoadBalance=true" no longer set the failover state,
      as it's assumed that we're not attempting to fall-back to a master
      server. This fixes BUG#34963.
    
10-09-07 - Version 5.1.5

    - Released instead of 5.1.4 to pickup patch for BUG#31053
      from 5.0.8.
      
10-09-07 - Version 5.1.4 

    - Added "autoSlowLog" configuration property, overrides 
      "slowQueryThreshold*" properties, driver determines slow
      queries by those that are slower than 5 * stddev of the mean
      query time (outside the 96% percentile).
      
    - Fixed BUG#28256 - When connection is in read-only mode, 
      queries that are wrapped in parentheses incorrectly identified 
      as DML.
       
09-07-07 - Version 5.1.3 RC

	- Setting "useBlobToStoreUTF8OutsideBMP" to "true" tells the
	  driver to treat [MEDIUM/LONG/TINY]BLOB columns as [LONG]VARCHAR
	  columns holding text encoded in UTF-8 that has characters
	  outside the BMP (4-byte encodings), which MySQL server
	  can't handle natively.

	  Set "utf8OutsideBmpExcludedColumnNamePattern" to a regex so that
	  column names matching the given regex will still be treated
	  as BLOBs The regex must follow the patterns used for the
	  java.util.regex package. The default is to exclude no columns,
	  and include all columns.

	  Set "utf8OutsideBmpIncludedColumnNamePattern" to specify exclusion
	  rules to "utf8OutsideBmpExcludedColumnNamePattern". The regex must
	  follow the patterns used for the java.util.regex package.

	- New methods on com.mysql.jdbc.Statement: setLocalInfileInputStream()
	  and getLocalInfileInputStream().

	  setLocalInfileInputStream() sets an InputStream instance that will be used to send data
      to the MySQL server for a "LOAD DATA LOCAL INFILE" statement
      rather than a FileInputStream or URLInputStream that represents
      the path given as an argument to the statement.

      This stream will be read to completion upon execution of a
      "LOAD DATA LOCAL INFILE" statement, and will automatically
      be closed by the driver, so it needs to be reset
      before each call to execute*() that would cause the MySQL
      server to request data to fulfill the request for
      "LOAD DATA LOCAL INFILE".

      If this value is set to NULL, the driver will revert to using
      a FileInputStream or URLInputStream as required.

      getLocalInfileInputStream() returns the InputStream instance that will be used to send
      data in response to a "LOAD DATA LOCAL INFILE" statement.

      This method returns NULL if no such stream has been set
      via setLocalInfileInputStream().

    - The driver now connects with an initial character set
      of "utf-8" solely for the purposes of authentication to
      allow usernames and database names in any character set to
      be used in the JDBC URL.

    - Errors encountered during Statement/PreparedStatement/CallableStatement.executeBatch()
      when "rewriteBatchStatements" has been set to "true" now return
      BatchUpdateExceptions according to the setting of "continueBatchOnError".
      
      If "continueBatchOnError" is set to "true", the update counts for the
      "chunk" that were sent as one unit will all be set to EXECUTE_FAILED, but
      the driver will attempt to process the remainder of the batch. You can determine which
      "chunk" failed by looking at the update counts returned in the BatchUpdateException.
      
      If "continueBatchOnError" is set to "false", the update counts returned
      will contain the failed "chunk", and stop with the failed chunk, with all 
      counts for the failed "chunk" set to EXECUTE_FAILED.
      
      Since MySQL doesn't return multiple error codes for multiple-statements, or
      for multi-value INSERT/REPLACE, it is the application's responsibility to handle 
      determining which item(s) in the "chunk" actually failed.
      
    - Statement.setQueryTimeout()s now affect the entire batch for batched 
      statements, rather than the individual statements that make up the batch.
      
06-29-07 - Version 5.1.2 Beta

    - Setting the configuration property "rewriteBatchedStatements"
      to "true" will now cause the driver to rewrite batched prepared
      statements with more than 3 parameter sets in a batch into
      multi-statements (separated by ";") if they are not plain
      (i.e. without SELECT or ON DUPLICATE KEY UPDATE clauses) INSERT
      or REPLACE statements.

06-22-07 - Version 5.1.1 Alpha

    - Pulled vendor-extension methods of Connection implementation out
      into an interface to support java.sql.Wrapper functionality from
      ConnectionPoolDataSource. The vendor extensions are javadoc'd in
      the com.mysql.jdbc.Connection interface.

      For those looking further into the driver implementation, it is not
      an API that is used for plugability of implementations inside our driver
      (which is why there are still references to ConnectionImpl throughout the
      code).

      Incompatible change: Connection.serverPrepare(String) has been re-named
      to Connection.serverPrepareStatement() for consistency with
      Connection.clientPrepareStatement().

      We've also added server and client prepareStatement() methods that cover
      all of the variants in the JDBC API.

    - Similar to Connection, we pulled out vendor extensions to Statement
      into an interface named "com.mysql.Statement", and moved the Statement
      class into com.mysql.StatementImpl. The two methods (javadoc'd in
      "com.mysql.Statement" are enableStreamingResults(), which already existed,
      and disableStreamingResults() which sets the statement instance back to
      the fetch size and result set type it had before enableStreamingResults()
      was called.

    - Added experimental support for statement "interceptors" via the
      com.mysql.jdbc.StatementInterceptor interface, examples are
      in com/mysql/jdbc/interceptors.

      Implement this interface to be placed "in between" query execution, so that
      you can influence it. (currently experimental).

      StatementInterceptors are "chainable" when configured by the user, the
      results returned by the "current" interceptor will be passed on to the next
      on in the chain, from left-to-right order, as specified by the user in the
      JDBC configuration property "statementInterceptors".

      See the sources (fully javadoc'd) for com.mysql.jdbc.StatementInterceptor
      for more details until we iron out the API and get it documented in the
      manual.

    - Externalized the descriptions of connection properties.

    - The data (and how it's stored) for ResultSet rows are now behind an
      interface which allows us (in some cases) to allocate less memory
      per row, in that for "streaming" result sets, we re-use the packet
      used to read rows, since only one row at a time is ever active.

    - Made it possible to retrieve prepared statement parameter bindings
      (to be used in StatementInterceptors, primarily).

    - Row navigation now causes any streams/readers open on the result set
      to be closed, as in some cases we're reading directly from a shared network
      packet and it will be overwritten by the "next" row.

    - Setting "rewriteBatchedStatements" to "true" now causes CallableStatements
      with batched arguments to be re-written in the form "CALL (...); CALL (...); ..."
      to send the batch in as few client-server round trips as possible.

    - Driver now picks appropriate internal row representation (whole row in one
      buffer, or individual byte[]s for each column value) depending on heuristics,
      including whether or not the row has BLOB or TEXT types and the overall
      row-size. The threshold for row size that will cause the driver to
      use a buffer rather than individual byte[]s is configured by the
      configuration property "largeRowSizeThreshold", which has a default
      value of 2KB.

04-11-07 - Version 5.1.0 Alpha

	- Bumped JDBC Specification version number in jar-file manifest.

	- Re-worked Ant buildfile to build JDBC-4.0 classes separately, as well
	  as support building under Eclipse (since Eclipse can't mix/match JDKs).

	  To build, you must set JAVA_HOME to J2SDK-1.4.2 or Java-5, and set
	  the following properties on your Ant commandline:

	  com.mysql.jdbc.java6.javac - full path to your Java-6 javac executable
	  com.mysql.jdbc.java6.rtjar - full path to your Java-6 rt.jar file

	- New feature - driver will automatically adjust session variable
	  "net_write_timeout" when it determines its been asked for a "streaming"
	  result, and resets it to the previous value when the result set
	  has been consumed. (configuration property is named
	  "netTimeoutForStreamingResults", value has unit of seconds,
	  the value '0' means the driver will not try and adjust this value).

    - Added support for JDBC-4.0 categorized SQLExceptions.

	- Refactored CommunicationsException into a JDBC3 version, and a JDBC4
	  version (which extends SQLRecoverableException, now that it exists).

	  This change means that if you were catching
	  com.mysql.jdbc.CommunicationsException in your applications instead
	  of looking at the SQLState class of "08", and are moving to Java 6
	  (or newer), you need to change your imports to that exception
	  to be com.mysql.jdbc.exceptions.jdbc4.CommunicationsException, as
	  the old class will not be instantiated for communications link-related
	  errors under Java 6.

	- Added support for JDBC-4.0's client information. The backend storage
	  of information provided via Connection.setClientInfo() and retrieved
	  by Connection.getClientInfo() is pluggable by any class that implements
	  the com.mysql.jdbc.JDBC4ClientInfoProvider interface and has a no-args
	  constructor.

	  The implementation used by the driver is configured using the
	  "clientInfoProvider" configuration property (with a default of value
	  of "com.mysql.jdbc.JDBC4CommentClientInfoProvider", an implementation
	  which lists the client info as a comment prepended to every query
	  sent to the server).

	  This functionality is only available when using Java-6 or newer.

	- Added support for JDBC-4.0's SQLXML interfaces.

	- Added support for JDBC-4.0's Wrapper interface.

	- Added support for JDBC-4.0's NCLOB, and NCHAR/NVARCHAR types.

nn-nn-07 - Version 5.0.9

    - Driver now calls SocketFactory.afterHandshake() at appropriate time.
    
10-09-07 - Version 5.0.8

    - Fixed BUG#30550, executeBatch() would fail with an ArithmeticException
      and/or NullPointerException when the batch had zero members and
      "rewriteBatchedStatements" was set to "true" for the connection.
    
    - Added two configuration parameters (both default to "false")
    
            * blobsAreStrings  - Should the driver always treat BLOBs as Strings 
                                 specifically to work around dubious metadata returned 
                                 by the server for GROUP BY clauses?
            
            * functionsNeverReturnBlobs - Should the driver always treat data from 
                                          functions returning BLOBs as Strings - 
                                          specifically to work around dubious metadata 
                                          returned by the server for GROUP BY clauses?

    - Fixed BUG#29106 - Connection checker for JBoss didn't use same method parameters
      via reflection, causing connections to always seem "bad".
      
    - Fixed BUG#30664 - Note that this fix only works for MySQL server 
      versions 5.0.25 and newer, since earlier versions didn't consistently 
      return correct metadata for functions, and thus results from 
      subqueries and functions were indistinguishable from each other, 
      leading to type-related bugs.

    - Fixed BUG#28972 - DatabaseMetaData.getTypeInfo() for the types DECIMAL
      and NUMERIC will return a precision of 254 for server versions older than
      5.0.3, 64 for versions 5.0.3-5.0.5 and 65 for versions newer than 5.0.5.
    
    - Fixed BUG#29852 - Closing a load-balanced connection would cause a
      ClassCastException.
    
    - Fixed BUG#27867 - Schema objects with identifiers other than
      the connection character aren't retrieved correctly in 
      ResultSetMetadata.
      
    - Fixed BUG#28689 - CallableStatement.executeBatch() doesn't work when 
      connection property "noAccessToProcedureBodies" has been set to "true".
     
      The fix involves changing the behavior of "noAccessToProcedureBodies",in 
      that the driver will now report all paramters as "IN" paramters
      but allow callers to call registerOutParameter() on them without throwing
      an exception.
      
    - Fixed BUG#27182 - Connection.getServerCharacterEncoding() doesn't work
      for servers with version >= 4.1.

    - Fixed BUG#27915 - DatabaseMetaData.getColumns() doesn't
      contain SCOPE_* or IS_AUTOINCREMENT columns.

    - Fixed BUG#30851, NPE with null column values when
      "padCharsWithSpace" is set to "true".
    
    - Specifying a "validation query" in your connection pool 
      that starts with "/* ping */" _exactly_ will cause the driver to 
      instead send a ping to the server and return a fake result set (much 
      lighter weight), and when using a ReplicationConnection or a LoadBalancedConnection, 
      will send the ping across all active connections.
      
    - Fixed Bug#30892 setObject(int, Object, int, int) delegate in
      PreparedStatmentWrapper delegates to wrong method.
      
    - XAConnections now start in auto-commit mode (as per JDBC-4.0 specification
      clarification).
     
    - Fixed Bug#27412 - cached metadata with PreparedStatement.execute()
      throws NullPointerException.
      
    - Driver will now fall back to sane defaults for max_allowed_packet and
      net_buffer_length if the server reports them incorrectly (and will log
      this situation at WARN level, since it's actually an error condition).
    
    - Fixed BUG#27916 - UNSIGNED types not reported via DBMD.getTypeInfo(), and 
      capitalization of type names is not consistent between DBMD.getColumns(), 
      RSMD.getColumnTypeName() and DBMD.getTypeInfo().

      This fix also ensures that the precision of UNSIGNED MEDIUMINT
      and UNSIGNED BIGINT is reported correctly via DBMD.getColumns().

    - Fixed BUG#31053 - Connections established using URLs of the form
      "jdbc:mysql:loadbalance://" weren't doing failover if they tried to 
      connect to a MySQL server that was down. The driver now attempts
      connections to the next "best" (depending on the load balance strategy
      in use) server, and continues to attempt connecting to the next "best"
      server every 250 milliseconds until one is found that is up and running 
      or 5 minutes has passed.
      
      If the driver gives up, it will throw the last-received SQLException.
      
07-19-07 - Version 5.0.7

    - Setting the configuration parameter "useCursorFetch" to "true" for
      MySQL-5.0+ enables the use of cursors that allow Connector/J to save
      memory by fetching result set rows in chunks (where the chunk size
      is set by calling setFetchSize() on a Statement or ResultSet) by
      using fully-materialized cursors on the server.

      The driver will will now automatically set "useServerPrepStmts" to
      "true" when "useCursorFetch" has been set to "true", since the feature
      requires server-side prepared statements in order to function.

	- Fixed BUG#28469 - PreparedStatement.getMetaData() for statements
	  containing leading one-line comments is not returned correctly.

	  As part of this fix, we also overhauled detection of DML for
	  executeQuery() and SELECTs for executeUpdate() in plain and
	  prepared statements to be aware of the same  types of comments.

    - Added configuration property "useNanosForElapsedTime" - for
      profiling/debugging functionality that measures elapsed time,
      should the driver try to use nanoseconds resolution if available
      (requires JDK >= 1.5)?

    - Added configuration property "slowQueryThresholdNanos" - if
      "useNanosForElapsedTime" is set to "true", and this property
      is set to a non-zero value the driver will use this threshold
      (in nanosecond units) to determine if a query was slow, instead
      of using millisecond units.

      Note, that if "useNanosForElapsedTime" is set to "true", and this
      property is set to "0" (or left default), then elapsed times will
      still be measured in nanoseconds (if possible), but the slow query
      threshold will be converted from milliseconds to nanoseconds, and thus
      have an upper bound of approximately 2000 millesconds (as that threshold
      is represented as an integer, not a long).

	- Added configuration properties to allow tuning of TCP/IP socket
	  parameters:

	  	"tcpNoDelay" - Should the driver set SO_TCP_NODELAY (disabling the
	  	               Nagle Algorithm, default "true")?

		"tcpKeepAlive" - Should the driver set SO_KEEPALIVE (default "true")?

		"tcpRcvBuf" - Should the driver set SO_RCV_BUF to the given value?
		              The default value of '0', means use the platform default
		              value for this property.

		"tcpSndBuf" - Should the driver set SO_SND_BUF to the given value?
		              The default value of '0', means use the platform default
		              value for this property.

		"tcpTrafficClass" - Should the driver set traffic class or
		                    type-of-service fields? See the documentation
		                    for java.net.Socket.setTrafficClass() for more
		                    information.

	- Give more information in EOFExceptions thrown out of MysqlIO (how many
	  bytes the driver expected to read, how many it actually read, say that
	  communications with the server were unexpectedly lost).

	- Setting "useDynamicCharsetInfo" to "false" now causes driver to use
	  static lookups for collations as well (makes
	  ResultSetMetadata.isCaseSensitive() much more efficient, which leads
	  to performance increase for ColdFusion, which calls this method for
	  every column on every table it sees, it appears).

	- Driver detects when it is running in a ColdFusion MX server (tested
	  with version 7), and uses the configuration bundle "coldFusion",
	  which sets useDynamicCharsetInfo to "false" (see previous entry), and
	  sets useLocalSessionState and autoReconnect to "true".

	- Fixed BUG#28851 - parser in client-side prepared statements
	  eats character following '/' if it's not a multi-line comment.

	- Fixed BUG#28956 - parser in client-side prepared statements
	  runs to end of statement, rather than end-of-line for '#' comments.

	  Also added support for '--' single-line comments.

	- Don't send any file data in response to LOAD DATA LOCAL INFILE
	  if the feature is disabled at the client side. This is to prevent
	  a malicious server or man-in-the-middle from asking the client for
	  data that the client is not expecting. Thanks to Jan Kneschke for
	  discovering the exploit and Andrey "Poohie" Hristov, Konstantin Osipov
	  and Sergei Golubchik for discussions about implications and possible
	  fixes. This fixes BUG 29605 for JDBC.

	- Added new debugging functionality - Setting configuration property
	  "includeInnodbStatusInDeadlockExceptions" to "true" will cause the driver
	  to append the output of "SHOW ENGINE INNODB STATUS" to deadlock-related
	  exceptions, which will enumerate the current locks held inside InnoDB.

05-15-07 - Version 5.0.6

	- Fixed BUG#25545 - Client options not sent correctly when using SSL,
	  leading to stored procedures not being able to return results. Thanks
	  to Don Cohen for the bug report, testcase and patch.

	- Fixed BUG#26592 - PreparedStatement is not closed in
	  BlobFromLocator.getBytes().

	- Fixed BUG#25624 - Whitespace surrounding storage/size specifiers in
	  stored procedure parameters declaration causes NumberFormatException to
	  be thrown when calling stored procedure on JDK-1.5 or newer, as the Number
	  classes in JDK-1.5+ are whitespace intolerant.

	- Fixed BUG#26173 - When useCursorFetch=true, sometimes server would return
	  new, more exact metadata during the execution of the server-side prepared
	  statement that enables this functionality, which the driver ignored (using
	  the original metadata returned during prepare()), causing corrupt reading
	  of data due to type mismatch when the actual rows were returned.

	- Fixed BUG#26959 - comments in DDL of stored procedures/functions confuse
	  procedure parser, and thus metadata about them can not be created, leading to
	  inability to retrieve said metadata, or execute procedures that have certain
	  comments in them.

	- Give better error message when "streaming" result sets, and the connection
	  gets clobbered because of exceeding net_write_timeout on the server. (which is
	  basically what the error message says too).

	- Fixed BUG#26789 - fast date/time parsing doesn't take into
	  account 00:00:00 as a legal value.

	- Fixed BUG#27317 - ResultSet.get*() with a column index < 1 returns
	  misleading error message.

	- Fixed BUG#25517 - Statement.setMaxRows() is not effective on result
	  sets materialized from cursors.

	- New configuration property, "enableQueryTimeouts" (default "true").
	  When enabled, query timeouts set via Statement.setQueryTimeout() use a
	  shared java.util.Timer instance for scheduling. Even if the timeout
	  doesn't expire before the query is processed, there will be
	  memory used by the TimerTask for the given timeout which won't be
	  reclaimed until the time the timeout would have expired if it
	  hadn't been cancelled by the driver. High-load environments
	  might want to consider disabling this functionality. (this configuration
	  property is part of the "maxPerformance" configuration bundle).

	- Fixed BUG#27400 - CALL /* ... */ some_proc() doesn't work. As a side effect
	  of this fix, you can now use /* */ and # comments when preparing statements using
	  client-side prepared statement emulation.

	  If the comments happen to contain parameter markers '?', they will be treated
	  as belonging to the comment (i.e. not recognized) rather than being a parameter
	  of the statement.

	  Note that the statement when sent to the server will contain the comments
	  as-is, they're not stripped during the process of preparing the PreparedStatement
	  or CallableStatement.

	- Fixed BUG#25328 - BIT(> 1) is returned as java.lang.String from ResultSet.getObject()
	  rather than byte[].

	- Fixed BUG#25715 - CallableStatements with OUT/INOUT parameters that
	  are "binary" (blobs, bits, (var)binary, java_object) have extra 7 bytes
	  (which happens to be the _binary introducer!)

	- Added configuration property "padCharsWithSpace" (defaults to "false"). If set
	  to "true", and a result set column has the CHAR type and the value does not
	  fill the amount of characters specified in the DDL for the column, the driver
	  will pad the remaining characters with space (for ANSI compliance).

	- Fixed BUG#27655 - Connection.getTransactionIsolation() uses
	  "SHOW VARIABLES LIKE" which is very inefficient on MySQL-5.0+

	- Added configuration property "useDynamicCharsetInfo". If set to "false"
	  (the default), the driver will use a per-connection cache of character set
	  information queried from the server when necessary, or when set to "true",
	  use a built-in static mapping that is more efficient, but isn't aware of
	  custom character sets or character sets implemented after the release of
	  the JDBC driver.

	  Note: this only affects the "padCharsWithSpace" configuration property and the
            ResultSetMetaData.getColumnDisplayWidth() method.

	- More intelligent initial packet sizes for the "shared" packets are used
	  (512 bytes, rather than 16K), and initial packets used during handshake are
	  now sized appropriately as to not require reallocation.

	- Fixed issue where calling getGeneratedKeys() on a prepared statement after
	  calling execute() didn't always return the generated keys (executeUpdate()
	  worked fine however).

	- Fixed issue where a failed-over connection would let an application call
	  setReadOnly(false), when that call should be ignored until the connection
	  is reconnected to a writable master unless "failoverReadOnly" had been set
	  to "false".

	- Fixed BUG#28085 - Generate more useful error messages for diagnostics
	  when the driver thinks a result set isn't updatable. (Thanks to Ashley Martens
	  for the patch).

	- Driver will now use INSERT INTO ... VALUES (DEFAULT) form of statement
	  for updatable result sets for ResultSet.insertRow(), rather than
	  pre-populating the insert row with values from DatabaseMetaData.getColumns()
	  (which results in a "SHOW FULL COLUMNS" on the server for every result
	  set). If an application requires access to the default values before
	  insertRow() has been called, the JDBC URL should be configured with
	  "populateInsertRowWithDefaultValues" set to "true".

	  This fix specifically targets performance issues with ColdFusion and the
	  fact that it seems to ask for updatable result sets no matter what the
	  application does with them.

	- com.mysql.jdbc.[NonRegistering]Driver now understands URLs of the format
	  "jdbc:mysql:replication://" and "jdbc:mysql:loadbalance://" which will
	  create a ReplicationConnection (exactly like when
	  using [NonRegistering]ReplicationDriver) and an experimenal load-balanced
	  connection designed for use with SQL nodes in a MySQL Cluster/NDB environment,
	  respectively.

	  In an effort to simplify things, we're working on deprecating multiple
	  drivers, and instead specifying different core behavior based upon JDBC URL
	  prefixes, so watch for [NonRegistering]ReplicationDriver to eventually
	  disappear, to be replaced with com.mysql.jdbc[NonRegistering]Driver with
	  the new URL prefix.

	- Added an experimental load-balanced connection designed for use with SQL nodes
      in a MySQL Cluster/NDB environment (This is not for master-slave replication.
      For that, we suggest you look at ReplicationConnection or "lbpool").

	  If the JDBC URL starts with "jdbc:mysql:loadbalance://host-1,host-2,...host-n",
	  the driver will create an implementation of java.sql.Connection that load
	  balances requests across a series of MySQL JDBC connections to the given hosts,
	  where the balancing takes place after transaction commit.

      Therefore, for this to work (at all), you must use transactions, even if only
      reading data.

      Physical connections to the given hosts will not be created until needed.

      The driver will invalidate connections that it detects have had
      communication errors when processing a request. A new connection to the
      problematic host will be attempted the next time it is selected by the load
      balancing algorithm.

      There are two choices for load balancing algorithms, which may be specified
      by the "loadBalanceStrategy" JDBC URL configuration property:

      * "random" - the driver will pick a random host for each request. This tends
        to work better than round-robin, as the randomness will somewhat account for
        spreading loads where requests vary in response time, while round-robin
        can sometimes lead to overloaded nodes if there are variations in response times
        across the workload.

      * "bestResponseTime" - the driver will route the request to the host that had
        the best response time for the previous transaction.

    - When "useLocalSessionState" is set to "true" and connected to a MySQL-5.0 or
      later server, the JDBC driver will now determine whether an actual "commit" or
      "rollback" statement needs to be sent to the database when Connection.commit()
      or Connection.rollback() is called.

      This is especially helpful for high-load situations with connection pools that
      always call Connection.rollback() on connection check-in/check-out because it
      avoids a round-trip to the server.

03-01-07 - Version 5.0.5

    - Fixed BUG#23645 - Some collations/character sets reported as "unknown"
	  (specifically cias variants of existing character sets), and inability to override
	  the detected server character set.

	- Performance enhancement of initial character set configuration, driver
      will only send commands required to configure connection character set
      session variables if the current values on the server do not match
      what is required.

    - Fixed BUG#24360 .setFetchSize() breaks prepared SHOW and other commands.

    - Fixed BUG#24344 - useJDBCCompliantTimezoneShift with server-side prepared
	  statements gives different behavior than when using client-side prepared
	  statements. (this is now fixed if moving from server-side prepared statements
	  to client-side prepared statements by setting "useSSPSCompatibleTimezoneShift" to
	  true", as the driver can't tell if this is a new deployment that never used
	  server-side prepared statements, or if it is an existing deployment that is
	  switching to client-side prepared statements from server-side prepared statements.

    - Fixed BUG#23304 - DBMD using "show" and DBMD using information_schema do
      not return results consistent with each other. (note this fix only
      addresses the inconsistencies, not the issue that the driver is
      treating schemas differently than some users expect. We will revisit
      this behavior when there is full support for schemas in MySQL).

    - Fixed BUG#25073 - rewriting batched statements leaks internal statement
	  instances, and causes a memory leak.

	- Fixed issue where field-level for metadata from DatabaseMetaData when using
	  INFORMATION_SCHEMA didn't have references to current connections,
	  sometimes leading to NullPointerExceptions when intropsecting them via
	  ResultSetMetaData.

	- Fixed BUG#25025 - Client-side prepared statement parser gets confused by
	  in-line (/* ... */) comments and therefore can't rewrite batched statements
	  or reliably detect type of statements when they're used.

	- Fixed BUG#24065 - Better error message when server doesn't return enough
	  information to determine stored procedure/function parameter types.

	- Fixed BUG#21438 - Driver sending nanoseconds to server for timestamps when
	  using server-side prepared statements, when server expects microseconds.

	- Fixed BUG#25514 - Timer instance used for Statement.setQueryTimeout()
	  created per-connection, rather than per-VM, causing memory leak

	- Fixed BUG#25009 - Results from updates not handled correctly in
	  multi-statement queries, leading to erroneous "Result is from UPDATE"
	  exceptions.

	- Fixed BUG#25047 - StringUtils.indexOfIgnoreCaseRespectQuotes() isn't
	  case-insensitive on the first character of the target. This bug broke
	  rewriteBatchedStatements functionality when prepared statements don't
	  use upper-case for the VALUES clause in their statements.

	- Fixed BUG#21480 - Some exceptions thrown out of StandardSocketFactory
	  were needlessly wrapped, obscurring their true cause, especially when
	  using socket timeouts.

	- Fixed BUG#23303 - DatabaseMetaData.getSchemas() doesn't return a
	  TABLE_CATALOG column.

    - Fixed BUG#25399 - EscapeProcessor gets confused by multiple
      backslashes. We now push the responsibility of syntax errors back
      on to the server for most escape sequences.

	- Fixed BUG#25379 - INOUT parameters in CallableStatements get
	  doubly-escaped.

	- Removed non-short-circuited logical ORs from "if" statements.

	- Re-worked stored procedure parameter parser to be more robust. Driver no
	  longer requires "BEGIN" in stored procedure definition, but does have
	  requirement that if a stored function begins with a label directly after the
	  "returns" clause, that the label is not a quoted identifier.
    - Reverted back to internal character conversion routines for single-byte
      character sets, as the ones internal to the JVM are using much more CPU
      time than our internal implementation.

	- Changed cached result set metadata (when using
	  "cacheResultSetMetadata=true") to be cached per-connection rather
	  than per-statement as previously implemented.

	- Use a java.util.TreeMap to map column names to ordinal indexes for
	  ResultSet.findColumn() instead of a HashMap. This allows us to have
	  case-insensitive lookups (required by the JDBC specification) without
	  resorting to the many transient object instances needed to support this
	  requirement with a normal HashMap with either case-adjusted keys, or
	  case-insensitive keys. (In the worst case scenario for lookups of a 1000
	  column result set, TreeMaps are about half as fast wall-clock time as
	  a HashMap, however in normal applications their use gives many orders
	  of magnitude reduction in transient object instance creation which pays
	  off later for CPU usage in garbage collection).

	- Avoid static synchronized code in JVM class libraries for dealing with
	  default timezones.

	- Fixed cases where ServerPreparedStatements weren't using cached metadata
	  when "cacheResultSetMetadata=true" was configured.

	- Use faster datetime parsing for ResultSets that come from plain or
	  non-server-side prepared statements. (Enable old implementation with
	  "useFastDateParsing=false" as a configuration parameter).

	- Fixed BUG#24794 - DatabaseMetaData.getSQLKeywords() doesn't return
	  all reserved words for current MySQL version. The current fix/implementation
	  returns keywords for MySQL-5.1, and doesn't distinguish between different
	  versions of the server.

	- When using cached metadata, skip field-level metadata packets coming from
	  the server, rather than reading them and discarding them without creating
	  com.mysql.jdbc.Field instances.

	- Fixed BUG#25836 - Statement execution which timed out doesn't always
	  throw MySQLTimeoutException.

	- Throw exceptions encountered during timeout to thread
	  calling Statement.execute*(), rather than RuntimeException.

	- Added configuration property "localSocketAddress",which is the hostname or
	  IP address given to explicitly configure the interface that the driver will
	  bind the client side of the TCP/IP connection to when connecting.

	- Take "localSocketAddress" property into account when creating instances
	  of CommunicationsException when the underyling exception is a
	  java.net.BindException, so that a friendlier error message is given with
	  a little internal diagnostics.

	- Fixed some NPEs when cached metadata was used with UpdatableResultSets.

	- The "rewriteBatchedStatements" feature can now be used with server-side
	  prepared statements.

	- Fixed BUG#26326 - Connection property "socketFactory" wasn't exposed via
	  correctly named mutator/accessor, causing data source implementations that
	  use JavaBean naming conventions to set properties to fail to set the property
	  (and in the case of SJAS, fail silently when trying to set this parameter).

	- Fixed BUG#25787 - java.util.Date should be serialized for
	  PreparedStatement.setObject().

	  We've added a new configuration option "treatUtilDateAsTimestamp", which is
	  false by default, as (1) We already had specific behavior to treat
	  java.util.Date as a java.sql.Timestamp because it's useful to many folks,
	  and (2) that behavior will very likely be required for drivers JDBC-post-4.0.

    - Fixed BUG#22628 - Driver.getPropertyInfo() throws NullPointerException for
      URL that only specifies host and/or port.

	- Fixed BUG#21267, ParameterMetaData throws NullPointerException when
	  prepared SQL actually has a syntax error. Added
	  "generateSimpleParameterMetadata" configuration property, which when set
	  to "true" will generate metadata reflecting VARCHAR for every parameter
	  (the default is "false", which will cause an exception to be thrown if no
	  parameter metadata for the statement is actually available).

	- When extracting foreign key information from "SHOW CREATE TABLE " in
	  DatabaseMetaData, ignore exceptions relating to tables being missing
	  (which could happen for cross-reference or imported-key requests, as
	  the list of tables is generated first, then iterated).

	- Fixed logging of XA commands sent to server, it's now configurable
	  via "logXaCommands" property (defaults to "false").

	- Fixed issue where XADataSources couldn't be bound into JNDI,
	  as the DataSourceFactory didn't know how to create instances
	  of them.

	- Fixed issue where XADataSources couldn't be bound into JNDI,
	  as the DataSourceFactory didn't know how to create instances
	  of them.

	- Usage advisor will now issue warnings for result sets with large numbers
	  of rows (size configured by "resultSetSizeThreshold" property, default
	  value is 100).

10-20-06 - Version 5.0.4

    - Fixed BUG#21379 - column names don't match metadata in cases
      where server doesn't return original column names (column functions)
	  thus breaking compatibility with applications that expect 1-1 mappings
	  between findColumn() and rsmd.getColumnName(), usually manifests itself
	  as "Can't find column ('')" exceptions.

    - Fixed BUG#21544 - When using information_schema for metadata,
	  COLUMN_SIZE for getColumns() is not clamped to range of
	  java.lang.Integer as is the case when not using
	  information_schema, thus leading to a truncation exception that
	  isn't present when not using information_schema.

    - Fixed configuration property "jdbcCompliantTruncation" was not
      being used for reads of result set values.

    - Fixed BUG#22024 - Newlines causing whitespace to span confuse
	  procedure parser when getting parameter metadata for stored
	  procedures.

	- Driver now supports {call sp} (without "()" if procedure has no
	  arguments).

	- Fixed BUG#22359 - Driver was using milliseconds for
	  Statement.setQueryTimeout() when specification says argument is
	  to be in seconds.

	- Workaround for server crash when calling stored procedures
	  via a server-side prepared statement (driver now detects
	  prepare(stored procedure) and substitutes client-side prepared
	  statement), addresses BUG#22297.

	- Added new _ci collations to CharsetMapping, fixing
	  Bug#22456 - utf8_unicode_ci not working.

	- Fixed BUG#22290 - Driver issues truncation on write exception when
	  it shouldn't (due to sending big decimal incorrectly to server with
	  server-side prepared statement).

	- Fixed BUG#22613 - DBMD.getColumns() does not return expected
	  COLUMN_SIZE for the SET type, now returns length of largest possible
	  set disregarding whitespace or the "," delimitters to be consistent
	  with the ODBC driver.

	- Driver now sends numeric 1 or 0 for client-prepared statement
	  setBoolean() calls instead of '1' or '0'.

	- DatabaseMetaData correctly reports true for supportsCatalog*()
	  methods.

07-26-06 - Version 5.0.3

    - Fixed BUG#20650 - Statement.cancel() causes NullPointerException
      if underlying connection has been closed due to server failure.

    - Added configuration option "noAccessToProcedureBodies" which will
      cause the driver to create basic parameter metadata for
      CallableStatements when the user does not have access to procedure
      bodies via "SHOW CREATE PROCEDURE" or selecting from mysql.proc
      instead of throwing an exception. The default value for this option
      is "false".

07-11-06 - Version 5.0.2-beta (5.0.1 not released due to packaging error)

    - Fixed BUG#17401 - Can't use XAConnection for local transactions when
      no global transaction is in progress.

    - Fixed BUG#18086 - Driver fails on non-ASCII platforms. The driver
      was assuming that the platform character set would be a superset
      of MySQL's "latin1" when doing the handshake for authentication,
      and when reading error messages. We now use Cp1252 for all strings
      sent to the server during the handshake phase, and a hard-coded mapping
      of the "language" server variable to the character set that
      is used for error messages.

    - Fixed BUG#19169 - ConnectionProperties (and thus some
	  subclasses) are not serializable, even though some J2EE containers
	  expect them to be.

	- Fixed BUG#20242 - MysqlValidConnectionChecker for JBoss doesn't
	  work with MySQLXADataSources.

	- Better caching of character set converters (per-connection)
	  to remove a bottleneck for multibyte character sets.

	- Added connection/datasource property  "pinGlobalTxToPhysicalConnection"
	  (defaults to "false"). When set to "true", when using XAConnections, the
	  driver ensures that operations on a given XID are always routed to the
	  same physical connection. This allows the XAConnection to support
	  "XA START ... JOIN" after "XA END" has been called, and is also a
	  workaround for transaction managers that don't maintain thread affinity
	  for a global transaction (most either always maintain thread affinity,
	  or have it as a configuration option).

	- MysqlXaConnection.recover(int flags) now allows combinations of
	  XAResource.TMSTARTRSCAN and TMENDRSCAN. To simulate the "scanning"
	  nature of the interface, we return all prepared XIDs for TMSTARTRSCAN,
	  and no new XIDs for calls with TMNOFLAGS, or TMENDRSCAN when not in
	  combination with TMSTARTRSCAN. This change was made for API compliance,
	  as well as integration with IBM WebSphere's transaction manager.

12-23-05 - Version 5.0.0-beta

    - XADataSource implemented (ported from 3.2 branch which won't be
      released as a product). Use
      "com.mysql.jdbc.jdbc2.optional.MysqlXADataSource" as your datasource
      class name in your application server to utilize XA transactions
      in MySQL-5.0.10 and newer.

    - PreparedStatement.setString() didn't work correctly when
      sql_mode on server contained NO_BACKSLASH_ESCAPES, and no characters
      that needed escaping were present in the string.

    - Attempt detection of the MySQL type "BINARY" (it's an alias, so this isn't
      always reliable), and use the java.sql.Types.BINARY type mapping for it.

    - Moved -bin-g.jar file into separate "debug" subdirectory to avoid confusion.

    - Don't allow .setAutoCommit(true), or .commit() or .rollback() on an XA-managed
      connection as-per the JDBC specification.

    - If the connection "useTimezone" is set to "true", then also respect timezone
      conversions in escape-processed string literals (e.g. "{ts ...}" and
      "{t ...}").

    - Return original column name for RSMD.getColumnName() if the column was aliased,
      alias name for .getColumnLabel() (if aliased), and original table name
      for .getTableName(). Note this only works for MySQL-4.1 and newer, as
      older servers don't make this information available to clients.

    - Setting "useJDBCCompliantTimezoneShift=true" (it's not the default)
      causes the driver to use GMT for _all_ TIMESTAMP/DATETIME timezones,
      and the current VM timezone for any other type that refers to timezones.
      This feature can not be used when "useTimezone=true" to convert between
      server and client timezones.

    - Add one level of indirection of internal representation of CallableStatement
      parameter metadata to avoid class not found issues on JDK-1.3 for
      ParameterMetadata interface (which doesn't exist prior to JDBC-3.0).

    - Added unit tests for XADatasource, as well as friendlier exceptions
      for XA failures compared to the "stock" XAException (which has no
      messages).

    - Fixed BUG#14279 - Idle timeouts cause XAConnections to whine about rolling
      themselves back

    - Added support for Connector/MXJ integration via url subprotocol
      "jdbc:mysql:mxj://....".

    - Moved all SQLException constructor usage to a factory in SQLError
      (ground-work for JDBC-4.0 SQLState-based exception classes).

    - Removed Java5-specific calls to BigDecimal constructor (when
      result set value is '', (int)0 was being used as an argument
      in-directly via method return value. This signature doesn't exist
      prior to Java5.)

    - Moved all SQLException creation to a factory method in SQLError,
      groundwork for JDBC-4.0 SQLState class-based exceptions.

    - Added service-provider entry to META-INF/services/java.sql.Driver
      for JDBC-4.0 support.

    - Return "[VAR]BINARY" for RSMD.getColumnTypeName() when that is actually
      the type, and it can be distinguished (MySQL-4.1 and newer).

    - When fix for BUG#14562 was merged from 3.1.12, added functionality
      for CallableStatement's parameter metadata to return correct
      information for .getParameterClassName().

    - Fuller synchronization of Connection to avoid deadlocks when
      using multithreaded frameworks that multithread a single connection
      (usually not recommended, but the JDBC spec allows it anyways),
      part of fix to BUG#14972).

    - Implementation of Statement.cancel() and Statement.setQueryTimeout().
      Both require MySQL-5.0.0 or newer server, require a separate connection
      to issue the "KILL QUERY" command, and in the case of setQueryTimeout()
      creates an additional thread to handle the timeout functionality.

      Note: Failures to cancel the statement for setQueryTimeout() may manifest
      themselves as RuntimeExceptions rather than failing silently, as there
      is currently no way to unblock the thread that is executing the query being
      cancelled due to timeout expiration and have it throw the exception
      instead.

    - Removed dead code in com.mysql.jdbc.Connection.

    - Made construction of com.mysql.jdbc.Field (result set metadata)
      instances more efficient for non-string types by not doing
      character set initialization, or detection of type changes due to
      temporary tables.

    - Removed redundant code in com.mysql.jdbc.MysqlIO.

    - Removed work done for BUG#14652, and instead loosened synchronization
      to solve a number of deadlock issues in BUG#18719, BUG#18367, BUG#17709
      and BUG#15067. New strategy basically makes Connection instances threadsafe
      and thus shareable across threads, and anything else threadsafe, but not
      necessarily shareable across threads due to JDBC API interactions that
      can cause non-obvious behavior and/or deadlock scenarios to occur since
      the API is not designed to be used from multiple threads at once.

      Therefore, unless external synchronization is provided, clients should
      not allow multiple threads to share a given statement or result set. Examples
      of issues with the API itself not being multi-thread suitable include,
      but are not limited to race conditions between modifiers and execution and
      retrieval methods on statements and result sets that are not synchronizable
      such as ResultSet.get*() and traversal methods, or Statement.execute*() closing
      result sets without effectively making the driver itself serializable across the
      board.

      These changes should not have any effect on "normal" J(2)EE use cases
      where only one thread ever uses a connection instance and the objects created by
      it.

    - Use a java.util.Timer to schedule cancellation of queries via
      Statement.setQueryTimeout() rather than one thread per potential cancellation.

      A new thread will be used to actually cancel a running query, as there's potential
      for a cancel request to block other cancel requests if all run from the
      same thread.

nn-nn-07 - Version 3.1.15

	- Fixed BUG#23281 - Downed slave caused round-robin load balance to
	  not cycle back to first host in list.

	- Disabled use of server-side prepared statements by default.

	- Handle YYYY-MM-DD hh:mm:ss format of timestamp in
	  ResultSet.getTimeFromString().

	- Fixed BUG#24840 - character encoding of "US-ASCII" doesn't map correctly
	  for 4.1 or newer

	- Added Implementation-Vendor-Id attribute to jar manifest per request
	  in BUG#15641.

	- C3P0 >= version 0.9.1 passes non-proxied connections to
	  MysqlConnectionTester,  thus it began throwing ClassCastExceptions.
	  MysqlConnectionTester now checks if it has a plain Connection and uses
	  that if possible. Thanks to Brian Skrab for the fix.

10-19-06 - Version 3.1.14

    - Fixed BUG#20479 - Updatable result set throws ClassCastException
	  when there is row data and moveToInsertRow() is called.

	- Fixed BUG#20485 - Updatable result set that contains
	  a BIT column fails when server-side prepared statements are used.

	- Fixed BUG#16987 - Memory leak with profileSQL=true.

	- Fixed BUG#19726 - Connection fails to localhost when using
	  timeout and IPv6 is configured.

	- Fixed BUG#16791 - NullPointerException in MysqlDataSourceFactory
	  due to Reference containing RefAddrs with null content.

	- Fixed BUG#20306 - ResultSet.getShort() for UNSIGNED TINYINT
	  returns incorrect values when using server-side prepared statements.

	- Fixed BUG#20687 - Can't pool server-side prepared statements, exception
	  raised when re-using them.

	- Fixed BUG#21062 - ResultSet.getSomeInteger() doesn't work for BIT(>1).

	- Fixed BUG#18880 - ResultSet.getFloatFromString() can't retrieve
	  values near Float.MIN/MAX_VALUE.

	- Fixed BUG#20888 - escape of quotes in client-side prepared
	  statements parsing not respected. Patch covers more than bug report,
	  including NO_BACKSLASH_ESCAPES being set, and stacked quote characters
	  forms of escaping (i.e. '' or "").

	- Fixed BUG#19993 - ReplicationDriver does not always round-robin load
	  balance depending on URL used for slaves list.

	- Fixed calling toString() on ResultSetMetaData for driver-generated
	  (i.e. from DatabaseMetaData method calls, or from getGeneratedKeys())
	  result sets would raise a NullPointerException.

	- Fixed Bug#21207 - Driver throws NPE when tracing prepared statements that
	  have been closed (in asSQL()).

	- Removed logger autodectection altogether, must now specify logger
	  explitly if you want to use a logger other than one that logs
	  to STDERR.

	- Fixed BUG#22290 - Driver issues truncation on write exception when
	  it shouldn't (due to sending big decimal incorrectly to server with
	  server-side prepared statement).

	- Driver now sends numeric 1 or 0 for client-prepared statement
	  setBoolean() calls instead of '1' or '0'.

	- Fixed bug where driver would not advance to next host if
	  roundRobinLoadBalance=true and the last host in the list is down.

	- Fixed BUG#18258 - DatabaseMetaData.getTables(), columns() with bad
	  catalog parameter threw exception rather than return empty result
	  set (as required by spec).

	- Check and store value for continueBatchOnError property in constructor
      of Statements, rather than when executing batches, so that Connections
      closed out from underneath statements don't cause NullPointerExceptions
      when it's required to check this property.

    - Fixed bug when calling stored functions, where parameters weren't
      numbered correctly (first parameter is now the return value, subsequent
      parameters if specified start at index "2").

	- Fixed BUG#21814 - time values outside valid range silently wrap.

05-26-06 - Version 3.1.13

    - Fixed BUG#15464 - INOUT parameter does not store IN value.

    - Fixed BUG#14609 - Exception thrown for new decimal type when
      using updatable result sets.

    - Fixed BUG#15544, no "dos" character set in MySQL > 4.1.0

    - Fixed BUG#15383 - PreparedStatement.setObject() serializes
      BigInteger as object, rather than sending as numeric value
      (and is thus not complementary to .getObject() on an UNSIGNED
      LONG type).

    - Fixed BUG#11874 - ResultSet.getShort() for UNSIGNED TINYINT
      returned wrong values.

    - Fixed BUG#15676 - lib-nodist directory missing from
      package breaks out-of-box build

    - Fixed BUG#15854 - DBMD.getColumns() returns wrong type for BIT.

    - Fixed BUG#16169 - ResultSet.getNativeShort() causes stack overflow error
      via recurisve calls.

    - Fixed BUG#14938 - Unable to initialize character set mapping tables.
      Removed reliance on .properties files to hold this information, as it
      turns out to be too problematic to code around class loader hierarchies
      that change depending on how an application is deployed. Moved information
      back into the CharsetMapping class.

    - Fixed BUG#16841 - updatable result set doesn't return AUTO_INCREMENT
      values for insertRow() when multiple column primary keys are used. (the
      driver was checking for the existence of single-column primary keys and
      an autoincrement value > 0 instead of a straightforward isAutoIncrement()
      check).

    - Fixed BUG#17099 - Statement.getGeneratedKeys() throws NullPointerException
      when no query has been processed.

    - Fixed BUG#13469 - Driver tries to call methods that don't exist on older and
      newer versions of Log4j. The fix is not trying to auto-detect presense of log4j,
      too many different incompatible versions out there in the wild to do this reliably.

      If you relied on autodetection before, you will need to add
      "logger=com.mysql.jdbc.log.Log4JLogger" to your JDBC URL to enable Log4J usage,
      or alternatively use the new "CommonsLogger" class to take care of this.

    - Added support for Apache Commons logging, use "com.mysql.jdbc.log.CommonsLogger"
      as the value for the "logger" configuration property.

    - LogFactory now prepends "com.mysql.jdbc.log" to log class name if it can't be
      found as-specified. This allows you to use "short names" for the built-in log
      factories, for example "logger=CommonsLogger" instead of
      "logger=com.mysql.jdbc.log.CommonsLogger".

    - Fixed BUG#15570 - ReplicationConnection incorrectly copies state,
	  doesn't transfer connection context correctly when transitioning between
	  the same read-only states.

	- Fixed BUG#18041 - Server-side prepared statements don't cause
	  truncation exceptions to be thrown when truncation happens.

	- Added performance feature, re-writing of batched executes for
	  Statement.executeBatch() (for all DML statements) and
	  PreparedStatement.executeBatch() (for INSERTs with VALUE clauses
	  only). Enable by using "rewriteBatchedStatements=true" in your JDBC URL.

	- Fixed BUG#17898 - registerOutParameter not working when some
	  parameters pre-populated. Still waiting for feedback from JDBC experts
	  group to determine what correct parameter count from getMetaData()
	  should be, however.

	- Fixed BUG#17587 - clearParameters() on a closed prepared statement
	  causes NPE.

	- Map "latin1" on MySQL server to CP1252 for MySQL > 4.1.0.

	- Added additional accessor and mutator methods on ConnectionProperties
	  so that DataSource users can use same naming as regular URL properties.

	- Fixed BUG#18740 - Data truncation and getWarnings() only returns last
	  warning in set.

	- Improved performance of retrieving BigDecimal, Time, Timestamp and Date
	  values from server-side prepared statements by creating fewer short-lived
	  instances of Strings when the native type is not an exact match for
	  the requested type. Fixes BUG#18496 for BigDecimals.

	- Fixed BUG#18554 - Aliased column names where length of name > 251
	  are corrupted.

	- Fixed BUG#17450 - ResultSet.wasNull() not always reset
	  correctly for booleans when done via conversion for server-side
	  prepared statements.

	- Fixed BUG#16277 - Invalid classname returned for
	  RSMD.getColumnClassName() for BIGINT type.

	- Fixed case where driver wasn't reading server status correctly when
	  fetching server-side prepared statement rows, which in some cases
	  could cause warning counts to be off, or multiple result sets to not
	  be read off the wire.

	- Driver now aware of fix for BIT type metadata that went into
	  MySQL-5.0.21 for server not reporting length consistently (bug
	  number 13601).

	- Fixed BUG#19282 - ResultSet.wasNull() returns incorrect value
	  when extracting native string from server-side prepared statement
	  generated result set.

11-30-05 - Version 3.1.12

    - Fixed client-side prepared statement bug with embedded ? inside
      quoted identifiers (it was recognized as a placeholder, when it
      was not).

    - Don't allow executeBatch() for CallableStatements with registered
      OUT/INOUT parameters (JDBC compliance).

    - Fall back to platform-encoding for URLDecoder.decode() when
      parsing driver URL properties if the platform doesn't have a
      two-argument version of this method.

    - Fixed BUG#14562 - Java type conversion may be incorrect for
      mediumint.

    - Added configuration property "useGmtMillisForDatetimes" which
      when set to true causes ResultSet.getDate(), .getTimestamp() to
      return correct millis-since GMT when .getTime() is called on
      the return value (currently default is "false" for legacy
      behavior).

    - Fixed DatabaseMetaData.stores*Identifiers():

        * if lower_case_table_names=0 (on server):

            storesLowerCaseIdentifiers() returns false
            storesLowerCaseQuotedIdentifiers() returns false
            storesMixedCaseIdentifiers() returns true
            storesMixedCaseQuotedIdentifiers() returns true
            storesUpperCaseIdentifiers() returns false
            storesUpperCaseQuotedIdentifiers() returns true

        * if lower_case_table_names=1 (on server):

            storesLowerCaseIdentifiers() returns true
            storesLowerCaseQuotedIdentifiers() returns true
            storesMixedCaseIdentifiers() returns false
            storesMixedCaseQuotedIdentifiers() returns false
            storesUpperCaseIdentifiers() returns false
            storesUpperCaseQuotedIdentifiers() returns true

    - Fixed BUG#14815 - DatabaseMetaData.getColumns() doesn't
      return TABLE_NAME correctly.

    - Fixed BUG#14909 - escape processor replaces quote character
      in quoted string with string delimiter.

    - Fixed BUG#12975 - OpenOffice expects
      DBMD.supportsIntegrityEnhancementFacility() to return "true"
      if foreign keys are supported by the datasource, even though
      this method also covers support for check constraints,
	  which MySQL _doesn't_ have. Setting the configuration property
	  "overrideSupportsIntegrityEnhancementFacility" to "true" causes
	  the driver to return "true" for this method.

    - Added "com.mysql.jdbc.testsuite.url.default" system property to
	  set default JDBC url for testsuite (to speed up bug resolution
	  when I'm working in Eclipse).

	- Fixed BUG#14938 - Unable to initialize character set mapping
	  tables (due to J2EE classloader differences).

	- Fixed BUG#14972 - Deadlock while closing server-side prepared
	  statements from multiple threads sharing one connection.

	- Fixed BUG#12230 -	logSlowQueries should give better info.

	- Fixed BUG#13775 - Extraneous sleep on autoReconnect.

	- Fixed BUG#15024 - Driver incorrectly closes streams passed as
	  arguments to PreparedStatements. Reverts to legacy behavior by
	  setting the JDBC configuration property "autoClosePStmtStreams"
	  to "true" (also included in the 3-0-Compat configuration "bundle").

	- Fixed BUG#13048 - maxQuerySizeToLog is not respected. Added logging of
	  bound values for execute() phase of server-side prepared statements
	  when profileSQL=true as well.

	- Fixed BUG#15065 - Usage advisor complains about unreferenced
	  columns, even though they've been referenced.

	- Don't increase timeout for failover/reconnect (BUG#6577)

	- Process escape tokens in Connection.prepareStatement(...), fix
	  for BUG#15141. You can disable this behavior by setting
	  the JDBC URL configuration property "processEscapeCodesForPrepStmts"
	  to "false".

	- Fixed BUG#13255 - Reconnect during middle of executeBatch()
	  should not occur if autoReconnect is enabled.

10-07-05 - Version 3.1.11

    - Fixed BUG#11629 - Spurious "!" on console when character
      encoding is "utf8".

    - Fixed statements generated for testcases missing ";" for
      "plain" statements.

    - Fixed BUG#11663 - Incorrect generation of testcase scripts
      for server-side prepared statements.

    - Fixed regression caused by fix for BUG#11552 that caused driver
      to return incorrect values for unsigned integers when those
      integers where within the range of the positive signed type.

    - Moved source code to svn repo.

    - Fixed BUG#11797 - Escape tokenizer doesn't respect stacked single quotes
	  for escapes.

	- GEOMETRY type not recognized when using server-side prepared statements.

    - Fixed BUG#11879 -- ReplicationConnection won't switch to slave, throws
      "Catalog can't be null" exception.

    - Fixed BUG#12218, properties shared between master and slave with
      replication connection.

    - Fixed BUG#10630, Statement.getWarnings() fails with NPE if statement
      has been closed.

    - Only get char[] from SQL in PreparedStatement.ParseInfo() when needed.

    - Fixed BUG#12104 - Geometry types not handled with server-side prepared
      statements.

    - Fixed BUG#11614 - StringUtils.getBytes() doesn't work when using
      multibyte character encodings and a length in  _characters_ is
      specified.

    - Fixed BUG#11798 - Pstmt.setObject(...., Types.BOOLEAN) throws exception.

    - Fixed BUG#11976 - maxPerformance.properties mis-spells
	  "elideSetAutoCommits".

	- Fixed BUG#11575 -- DBMD.storesLower/Mixed/UpperIdentifiers()
	  reports incorrect values for servers deployed on Windows.

	- Fixed BUG#11190 - ResultSet.moveToCurrentRow() fails to work when
	  preceeded by a call to ResultSet.moveToInsertRow().

	- Fixed BUG#11115, VARBINARY data corrupted when using server-side
	  prepared statements and .setBytes().

	- Fixed BUG#12229 - explainSlowQueries hangs with server-side
	  prepared statements.

	- Fixed BUG#11498 - Escape processor didn't honor strings demarcated
	  with double quotes.

	- Lifted restriction of changing streaming parameters with server-side
	  prepared statements. As long as _all_ streaming parameters were set
	  before execution, .clearParameters() does not have to be called.
	  (due to limitation of client/server protocol, prepared statements
	   can not reset _individual_ stream data on the server side).

	- Reworked Field class, *Buffer, and MysqlIO to be aware of field
	  lengths > Integer.MAX_VALUE.

	- Updated DBMD.supportsCorrelatedQueries() to return true for versions >
	  4.1, supportsGroupByUnrelated() to return true and
	  getResultSetHoldability() to return HOLD_CURSORS_OVER_COMMIT.

	- Fixed BUG#12541 - Handling of catalog argument in
	  DatabaseMetaData.getIndexInfo(), which also means changes to the following
	  methods in DatabaseMetaData:

	    - getBestRowIdentifier()
	    - getColumns()
	    - getCrossReference()
	    - getExportedKeys()
	    - getImportedKeys()
	    - getIndexInfo()
	    - getPrimaryKeys()
	    - getProcedures() (and thus indirectly getProcedureColumns())
	    - getTables()

	  The "catalog" argument in all of these methods now behaves in the following
	  way:

	    - Specifying NULL means that catalog will not be used to filter the
	      results (thus all databases will be searched), unless you've
	      set "nullCatalogMeansCurrent=true" in your JDBC URL properties.

	    - Specifying "" means "current" catalog, even though this isn't quite
	      JDBC spec compliant, it's there for legacy users.

	    - Specifying a catalog works as stated in the API docs.

	- Made Connection.clientPrepare() available from "wrapped" connections
	  in the jdbc2.optional package (connections built by
	  ConnectionPoolDataSource instances).

    - Added Connection.isMasterConnection() for clients to be able to determine
      if a multi-host master/slave connection is connected to the first host
      in the list.

    - Fixed BUG#12753 - Tokenizer for "=" in URL properties was causing
      sessionVariables=.... to be parameterized incorrectly.

    - Fixed BUG#11781, foreign key information that is quoted is
      parsed incorrectly when DatabaseMetaData methods use that
      information.

    - The "sendBlobChunkSize" property is now clamped to "max_allowed_packet"
      with consideration of stream buffer size and packet headers to avoid
      PacketTooBigExceptions when "max_allowed_packet" is similar in size
      to the default "sendBlobChunkSize" which is 1M.

    - CallableStatement.clearParameters() now clears resources associated
      with INOUT/OUTPUT parameters as well as INPUT parameters.

    - Fixed BUG#12417 - Connection.prepareCall() is database name
      case-sensitive (on Windows systems).

    - Fixed BUG#12752 - Cp1251 incorrectly mapped to win1251 for
      servers newer than 4.0.x.

    - Fixed BUG#12970 - java.sql.Types.OTHER returned for
	  BINARY and VARBINARY columns when using
	  DatabaseMetaData.getColumns().

	- ServerPreparedStatement.getBinding() now checks if the statement
	  is closed before attempting to reference the list of parameter
	  bindings, to avoid throwing a NullPointerException.

    - Fixed BUG#13277 - ResultSetMetaData from
      Statement.getGeneratedKeys() caused NullPointerExceptions to be
      thrown whenever a method that required a connection reference
      was called.

    - Removed support for java.nio I/O. Too many implementations
      turned out to be buggy, and there was no performance difference
      since MySQL is a blocking protocol anyway.

06-23-05 - Version 3.1.10-stable

	- Fixed connecting without a database specified raised an exception
	  in MysqlIO.changeDatabaseTo().

	- Initial implemention of ParameterMetadata for
	  PreparedStatement.getParameterMetadata(). Only works fully
	  for CallableStatements, as current server-side prepared statements
	  return every parameter as a VARCHAR type.

	- Fixed BUG#11552 - Server-side prepared statements return incorrect
	  values for unsigned TINYINT, SMALLINT, INT and Long.

	- Fixed BUG#11540 - Incorrect year conversion in setDate(..) for
	  system that use B.E. year in default locale.

06-22-05 - Version 3.1.9-stable

	- Overhaul of character set configuration, everything now
	  lives in a properties file.

	- Driver now correctly uses CP932 if available on the server
	  for Windows-31J, CP932 and MS932 java encoding names,
	  otherwise it resorts to SJIS, which is only a close
	  approximation. Currently only MySQL-5.0.3 and newer (and
	  MySQL-4.1.12 or .13, depending on when the character set
	  gets backported) can reliably support any variant of CP932.

	- Fixed BUG#9064 - com.mysql.jdbc.PreparedStatement.ParseInfo
	  does unnecessary call to toCharArray().

	- Fixed Bug#10144 - Memory leak in ServerPreparedStatement if
	  serverPrepare() fails.

	- Actually write manifest file to correct place so it ends up
	  in the binary jar file.

	- Added "createDatabaseIfNotExist" property (default is "false"),
	  which will cause the driver to ask the server to create the
	  database specified in the URL if it doesn't exist. You must have
	  the appropriate privileges for database creation for this to
	  work.

	- Fixed BUG#10156 - Unsigned SMALLINT treated as signed for ResultSet.getInt(),
	  fixed all cases for UNSIGNED integer values and server-side prepared statements,
	  as well as ResultSet.getObject() for UNSIGNED TINYINT.

	- Fixed BUG#10155, double quotes not recognized when parsing
	  client-side prepared statements.

	- Made enableStreamingResults() visible on
	  com.mysql.jdbc.jdbc2.optional.StatementWrapper.

	- Made ServerPreparedStatement.asSql() work correctly so auto-explain
	  functionality would work with server-side prepared statements.

	- Made JDBC2-compliant wrappers public in order to allow access to
	  vendor extensions.

	- Cleaned up logging of profiler events, moved code to dump a profiler
	  event as a string to com.mysql.jdbc.log.LogUtils so that third
	  parties can use it.

	- DatabaseMetaData.supportsMultipleOpenResults() now returns true. The
	  driver has supported this for some time, DBMD just missed that fact.

	- Fixed BUG#10310 - Driver doesn't support {?=CALL(...)} for calling
	  stored functions. This involved adding support for function retrieval
	  to DatabaseMetaData.getProcedures() and getProcedureColumns() as well.

	- Fixed BUG#10485, SQLException thrown when retrieving YEAR(2)
	  with ResultSet.getString(). The driver will now always treat YEAR types
	  as java.sql.Dates and return the correct values for getString().
	  Alternatively, the "yearIsDateType" connection property can be set to
	  "false" and the values will be treated as SHORTs.

	- The datatype returned for TINYINT(1) columns when "tinyInt1isBit=true"
	  (the default) can be switched between Types.BOOLEAN and Types.BIT
	  using the new configuration property "transformedBitIsBoolean", which
	  defaults to "false". If set to "false" (the default),
	  DatabaseMetaData.getColumns() and ResultSetMetaData.getColumnType()
	  will return Types.BOOLEAN for TINYINT(1) columns. If "true",
	  Types.BOOLEAN will be returned instead. Irregardless of this configuration
	  property, if "tinyInt1isBit" is enabled, columns with the type TINYINT(1)
	  will be returned as java.lang.Boolean instances from
	  ResultSet.getObject(..), and ResultSetMetaData.getColumnClassName()
	  will return "java.lang.Boolean".

	- Fixed BUG#10496 - SQLException is thrown when using property
	  "characterSetResults" with cp932 or eucjpms.

	- Reorganized directory layout, sources now in "src" folder,
	  don't pollute parent directory when building, now output goes
	  to "./build", distribution goes to "./dist".

	- Added support/bug hunting feature that generates .sql test
	  scripts to STDERR when "autoGenerateTestcaseScript" is set
	  to "true".

	- Fixed BUG#10850 - 0-length streams not sent to server when
	  using server-side prepared statements.

	- Setting "cachePrepStmts=true" now causes the Connection to also
	  cache the check the driver performs to determine if a prepared
	  statement can be server-side or not, as well as caches server-side
	  prepared statements for the lifetime of a connection. As before,
	  the "prepStmtCacheSize" parameter controls the size of these
	  caches.

	- Try to handle OutOfMemoryErrors more gracefully. Although not
	  much can be done, they will in most cases close the connection
	  they happened on so that further operations don't run into
	  a connection in some unknown state. When an OOM has happened,
	  any further operations on the connection will fail with a
	  "Connection closed" exception that will also list the OOM exception
	  as the reason for the implicit connection close event.

	- Don't send COM_RESET_STMT for each execution of a server-side
	  prepared statement if it isn't required.

	- Driver detects if you're running MySQL-5.0.7 or later, and does
	  not scan for "LIMIT ?[,?]" in statements being prepared, as the
	  server supports those types of queries now.

	- Fixed BUG#11115, Varbinary data corrupted when using server-side
	  prepared statements and ResultSet.getBytes().

	- Connection.setCatalog() is now aware of the "useLocalSessionState"
	  configuration property, which when set to true will prevent
	  the driver from sending "USE ..." to the server if the requested
	  catalog is the same as the current catalog.

	- Added the following configuration bundles, use one or many via
	  the "useConfigs" configuration property:

	    * maxPerformance -- maximum performance without being reckless
	    * solarisMaxPerformance -- maximum performance for Solaris,
	                               avoids syscalls where it can
	    * 3-0-Compat -- Compatibility with Connector/J 3.0.x functionality

	- Added "maintainTimeStats" configuration property (defaults to "true"),
	  which tells the driver whether or not to keep track of the last query time
	  and the last successful packet sent to the server's time. If set to
	  false, removes two syscalls per query.

	- Fixed BUG#11259, autoReconnect ping causes exception on connection
	  startup.

	- Fixed BUG#11360 Connector/J dumping query into SQLException twice

	- Fixed PreparedStatement.setClob() not accepting null as a parameter.

	- Fixed BUG#11411 - Production package doesn't include JBoss integration
	  classes.

	- Removed nonsensical "costly type conversion" warnings when using
	  usage advisor.

04-14-05 - Version 3.1.8-stable

	- Fixed DatabaseMetaData.getTables() returning views when they were
	  not asked for as one of the requested table types.

	- Added support for new precision-math DECIMAL type in MySQL >= 5.0.3.

	- Fixed ResultSet.getTime() on a NULL value for server-side prepared
	  statements throws NPE.

	- Made Connection.ping() a public method.

	- Fixed Bug#8868, DATE_FORMAT() queries returned as BLOBs from getObject().

	- ServerPreparedStatements now correctly 'stream' BLOB/CLOB data to the
	  server. You can configure the threshold chunk size using the
	  JDBC URL property 'blobSendChunkSize' (the default is one megabyte).

    - BlobFromLocator now uses correct identifier quoting when generating
      prepared statements.

    - Server-side session variables can be preset at connection time by
      passing them as a comma-delimited list for the connection property
      'sessionVariables'.

	- Fixed regression in ping() for users using autoReconnect=true.

	- Fixed BUG#9040 - PreparedStatement.addBatch() doesn't work with server-side
	  prepared statements and streaming BINARY data.

	- Fixed BUG#8800 - DBMD.supportsMixedCase*Identifiers() returns wrong
	  value on servers running on case-sensitive filesystems.

	- Fixed BUG#9206, can not use 'UTF-8' for characterSetResults
      configuration property.

    - Fixed BUG#9236, a continuation of BUG#8868, where functions used in queries
      that should return non-string types when resolved by temporary tables suddenly
      become opaque binary strings (work-around for server limitation). Also fixed
      fields with type of CHAR(n) CHARACTER SET BINARY to return correct/matching
      classes for RSMD.getColumnClassName() and ResultSet.getObject().

    - Fixed BUG#8792 - DBMD.supportsResultSetConcurrency() not returning
	  true for forward-only/read-only result sets (we obviously support this).

	- Fixed BUG#8803, 'DATA_TYPE' column from DBMD.getBestRowIdentifier()
	  causes ArrayIndexOutOfBoundsException when accessed (and in fact, didn't
	  return any value).

	- Check for empty strings ('') when converting char/varchar column data to numbers,
	  throw exception if 'emptyStringsConvertToZero' configuration property is set
	  to 'false' (for backwards-compatibility with 3.0, it is now set to 'true'
	  by default, but will most likely default to 'false' in 3.2).

	- Fixed BUG#9320 - PreparedStatement.getMetaData() inserts blank row in database
	  under certain conditions when not using server-side prepared statements.

	- Connection.canHandleAsPreparedStatement() now makes 'best effort' to distinguish
	  LIMIT clauses with placeholders in them from ones without in order to have fewer
	  false positives when generating work-arounds for statements the server cannot
	  currently handle as server-side prepared statements.

	- Fixed build.xml to not compile log4j logging if log4j not available.

	- Added support for the c3p0 connection pool's (http://c3p0.sf.net/)
	  validation/connection checker interface which uses the lightweight
	  'COM_PING' call to the server if available. To use it, configure your
	  c3p0 connection pool's 'connectionTesterClassName' property to use
	  'com.mysql.jdbc.integration.c3p0.MysqlConnectionTester'.

	- Better detection of LIMIT inside/outside of quoted strings so that
	  the driver can more correctly determine whether a prepared statement
	  can be prepared on the server or not.

	- Fixed BUG#9319 - Stored procedures with same name in
	  different databases confuse the driver when it tries to determine
	  parameter counts/types.

    - Added finalizers to ResultSet and Statement implementations to be JDBC
      spec-compliant, which requires that if not explicitly closed, these
      resources should be closed upon garbage collection.

    - Fixed BUG#9682 - Stored procedures with DECIMAL parameters with
	  storage specifications that contained "," in them would fail.

	- PreparedStatement.setObject(int, Object, int type, int scale) now
	  uses scale value for BigDecimal instances.

	- Fixed BUG#9704 - Statement.getMoreResults() could throw NPE when
	  existing result set was .close()d.

	- The performance metrics feature now gathers information about
	  number of tables referenced in a SELECT.

	- The logging system is now automatically configured. If the value has
	  been set by the user, via the URL property "logger" or the system
	  property "com.mysql.jdbc.logger", then use that, otherwise, autodetect
	  it using the following steps:

    	 Log4j, if it's available,
    	 Then JDK1.4 logging,
    	 Then fallback to our STDERR logging.

   	- Fixed BUG#9778, DBMD.getTables() shouldn't return tables if views
	  are asked for, even if the database version doesn't support views.

	- Fixed driver not returning 'true' for '-1' when ResultSet.getBoolean()
	  was called on result sets returned from server-side prepared statements.

	- Added a Manifest.MF file with implementation information to the .jar
	  file.

	- More tests in Field.isOpaqueBinary() to distinguish opaque binary (i.e.
	  fields with type CHAR(n) and CHARACTER SET BINARY) from output of
	  various scalar and aggregate functions that return strings.

	- Fixed BUG#9917 - Should accept null for catalog (meaning use current)
	  in DBMD methods, even though it's not JDBC-compliant for legacy's sake.
	  Disable by setting connection property "nullCatalogMeansCurrent" to "false"
	  (which will be the default value in C/J 3.2.x).

	- Fixed BUG#9769 - Should accept null for name patterns in DBMD (meaning "%"),
	  even though it isn't JDBC compliant, for legacy's sake. Disable by setting
	  connection property "nullNamePatternMatchesAll" to "false" (which will be
	  the default value in C/J 3.2.x).

02-18-05 - Version 3.1.7-stable


    - Fixed BUG#7686, Timestamp key column data needed "_binary'"
      stripped for UpdatableResultSet.refreshRow().

    - Fixed BUG#7715 - Timestamps converted incorrectly to strings
      with Server-side prepared statements and updatable result sets.

    - Detect new sql_mode variable in string form (it used to be
      integer) and adjust quoting method for strings appropriately.

    - Added 'holdResultsOpenOverStatementClose' property (default is
      false), that keeps result sets open over statement.close() or new
      execution on same statement (suggested by Kevin Burton).

    - Fixed BUG#7952 -- Infinite recursion when 'falling back' to master
      in failover configuration.

    - Disable multi-statements (if enabled) for MySQL-4.1 versions prior
      to version 4.1.10 if the query cache is enabled, as the server
      returns wrong results in this configuration.

    - Fixed duplicated code in configureClientCharset() that prevented
      useOldUTF8Behavior=true from working properly.

    - Removed 'dontUnpackBinaryResults' functionality, the driver now
      always stores results from server-side prepared statements as-is
      from the server and unpacks them on demand.

    - Fixed BUG#8096 where emulated locators corrupt binary data
      when using server-side prepared statements.

    - Fixed synchronization issue with
      ServerPreparedStatement.serverPrepare() that could cause
      deadlocks/crashes if connection was shared between threads.

    - By default, the driver now scans SQL you are preparing via all
      variants of Connection.prepareStatement() to determine if it is a
      supported type of statement to prepare on the server side, and if
      it is not supported by the server, it instead prepares it as a
      client-side emulated prepared statement (BUG#4718). You can
      disable this by passing 'emulateUnsupportedPstmts=false' in your
      JDBC URL.

    - Remove _binary introducer from parameters used as in/out
      parameters in CallableStatement.

    - Always return byte[]s for output parameters registered as *BINARY.

    - Send correct value for 'boolean' "true" to server for
      PreparedStatement.setObject(n, "true", Types.BIT).

    - Fixed bug with Connection not caching statements from
      prepareStatement() when the statement wasn't a server-side
      prepared statement.

    - Choose correct 'direction' to apply time adjustments when both
      client and server are in GMT timezone when using
      ResultSet.get(..., cal) and PreparedStatement.set(...., cal).

    - Added 'dontTrackOpenResources' option (default is false, to be
      JDBC compliant), which helps with memory use for non-well-behaved
      apps (i.e applications which don't close Statements when they
      should).

    - Fixed BUG#8428 - ResultSet.getString() doesn't maintain format
      stored on server, bug fix only enabled when 'noDatetimeStringSync'
      property is set to 'true' (the default is 'false').

    - Fixed NPE in ResultSet.realClose() when using usage advisor and
      result set was already closed.

    - Fixed BUG#8487 - PreparedStatements not creating streaming result
      sets.

    - Don't pass NULL to String.valueOf() in
      ResultSet.getNativeConvertToString(), as it stringifies it (i.e.
      returns "null"), which is not correct for the method in question.

    - Fixed BUG#8484 - ResultSet.getBigDecimal() throws exception
      when rounding would need to occur to set scale. The driver now
      chooses a rounding mode of 'half up' if non-rounding
      BigDecimal.setScale() fails.

    - Added 'useLocalSessionState' configuration property, when set to
      'true' the JDBC driver trusts that the application is well-behaved
      and only sets autocommit and transaction isolation levels using
      the methods provided on java.sql.Connection, and therefore can
      manipulate these values in many cases without incurring
      round-trips to the database server.

    - Added enableStreamingResults() to Statement for connection pool
      implementations that check Statement.setFetchSize() for
      specification-compliant values. Call Statement.setFetchSize(>=0)
      to disable the streaming results for that statement.

    - Added support for BIT type in MySQL-5.0.3. The driver will treat
      BIT(1-8) as the JDBC standard BIT type (which maps to
      java.lang.Boolean), as the server does not currently send enough
      information to determine the size of a bitfield when < 9 bits are
      declared. BIT(>9) will be treated as VARBINARY, and will return
      byte[] when getObject() is called.

12-23-04 - Version 3.1.6-stable

    - Fixed hang on SocketInputStream.read() with Statement.setMaxRows() and
      multiple result sets when driver has to truncate result set directly,
      rather than tacking a 'LIMIT n' on the end of it.

    - Fixed BUG#7026 - DBMD.getProcedures() doesn't respect catalog parameter.

    - Respect bytes-per-character for RSMD.getPrecision().

12-02-04 - Version 3.1.5-gamma

	- Fix comparisons made between string constants and dynamic strings that
	  are either toUpperCase()d or toLowerCase()d to use Locale.ENGLISH, as
	  some locales 'override' case rules for English. Also use
	  StringUtils.indexOfIgnoreCase() instead of .toUpperCase().indexOf(),
	  avoids creating a very short-lived transient String instance.

	- Fixed BUG#5235 - Server-side prepared statements did not honor
      'zeroDateTimeBehavior' property, and would cause class-cast
      exceptions when using ResultSet.getObject(), as the all-zero string
      was always returned.

    - Fixed batched updates with server prepared statements weren't looking if
      the types had changed for a given batched set of parameters compared
      to the previous set, causing the server to return the error
      'Wrong arguments to mysql_stmt_execute()'.

    - Handle case when string representation of timestamp contains trailing '.'
      with no numbers following it.

    - Fixed BUG#5706 - Inefficient detection of pre-existing string instances
      in ResultSet.getNativeString().

    - Don't throw exceptions for Connection.releaseSavepoint().

    - Use a per-session Calendar instance by default when decoding dates
      from ServerPreparedStatements (set to old, less performant behavior by
      setting property 'dynamicCalendars=true').

    - Added experimental configuration property 'dontUnpackBinaryResults',
      which delays unpacking binary result set values until they're asked for,
      and only creates object instances for non-numerical values (it is set
      to 'false' by default). For some usecase/jvm combinations, this is
      friendlier on the garbage collector.

    - Fixed BUG#5729 - UNSIGNED BIGINT unpacked incorrectly from
      server-side prepared statement result sets.

    - Fixed BUG#6225 - ServerSidePreparedStatement allocating short-lived
      objects un-necessarily.

    - Removed un-wanted new Throwable() in ResultSet constructor due to bad
      merge (caused a new object instance that was never used for every result
      set created) - Found while profiling for BUG#6359.

    - Fixed too-early creation of StringBuffer in EscapeProcessor.escapeSQL(),
      also return String when escaping not needed (to avoid unnecssary object
      allocations). Found while profiling for BUG#6359.

    - Use null-safe-equals for key comparisons in updatable result sets.

    - Fixed BUG#6537, SUM() on Decimal with server-side prepared statement ignores
      scale if zero-padding is needed (this ends up being due to conversion to DOUBLE
      by server, which when converted to a string to parse into BigDecimal, loses all
      'padding' zeros).

    - Use DatabaseMetaData.getIdentifierQuoteString() when building DBMD
      queries.

    - Use 1MB packet for sending file for LOAD DATA LOCAL INFILE if that
      is < 'max_allowed_packet' on server.

    - Fixed BUG#6399, ResultSetMetaData.getColumnDisplaySize() returns incorrect
      values for multibyte charsets.

    - Make auto-deserialization of java.lang.Objects stored in BLOBs
      configurable via 'autoDeserialize' property (defaults to 'false').

    - Re-work Field.isOpaqueBinary() to detect 'CHAR(n) CHARACTER SET BINARY'
      to support fixed-length binary fields for ResultSet.getObject().

    - Use our own implementation of buffered input streams to get around
      blocking behavior of java.io.BufferedInputStream. Disable this with
      'useReadAheadInput=false'.

    - Fixed BUG#6348, failing to connect to the server when one of the
      addresses for the given host name is IPV6 (which the server does
      not yet bind on). The driver now loops through _all_ IP addresses
      for a given host, and stops on the first one that accepts() a
      socket.connect().

09-04-04 - Version 3.1.4-beta

    - Fixed BUG#4510 - connector/j 3.1.3 beta does not handle integers
      correctly (caused by changes to support unsigned reads in
      Buffer.readInt() -> Buffer.readShort()).

    - Added support in DatabaseMetaData.getTables() and getTableTypes()
      for VIEWs which are now available in MySQL server version 5.0.x.

    - Fixed BUG#4642 -- ServerPreparedStatement.execute*() sometimes
      threw ArrayIndexOutOfBoundsException when unpacking field metadata.

    - Optimized integer number parsing, enable 'old' slower integer parsing
      using JDK classes via 'useFastIntParsing=false' property.

    - Added 'useOnlyServerErrorMessages' property, which causes message text
      in exceptions generated by the server to only contain the text sent by
      the server (as opposed to the SQLState's 'standard' description, followed
      by the server's error message). This property is set to 'true' by default.

    - Fixed BUG#4689 - ResultSet.wasNull() does not work for primatives if a
      previous null was returned.

    - Track packet sequence numbers if enablePacketDebug=true, and throw an
      exception if packets received out-of-order.

    - Fixed BUG#4482, ResultSet.getObject() returns wrong type for strings
      when using prepared statements.

    - Calling MysqlPooledConnection.close() twice (even though an application
      error), caused NPE. Fixed.

    - Fixed BUG#5012 -- ServerPreparedStatements dealing with return of
	  DECIMAL type don't work.

	- Fixed BUG#5032 -- ResultSet.getObject() doesn't return
      type Boolean for pseudo-bit types from prepared statements on 4.1.x
      (shortcut for avoiding extra type conversion when using binary-encoded
      result sets obscurred test in getObject() for 'pseudo' bit type)

    - You can now use URLs in 'LOAD DATA LOCAL INFILE' statements, and the
      driver will use Java's built-in handlers for retreiving the data and
      sending it to the server. This feature is not enabled by default,
      you must set the 'allowUrlInLocalInfile' connection property to 'true'.

    - The driver is more strict about truncation of numerics on
      ResultSet.get*(), and will throw a SQLException when truncation is
      detected. You can disable this by setting 'jdbcCompliantTruncation' to
      false (it is enabled by default, as this functionality is required
      for JDBC compliance).

    - Added three ways to deal with all-zero datetimes when reading them from
      a ResultSet, 'exception' (the default), which throws a SQLException
      with a SQLState of 'S1009', 'convertToNull', which returns NULL instead of
      the date, and 'round', which rounds the date to the nearest closest value
      which is '0001-01-01'.

    - Fixed ServerPreparedStatement to read prepared statement metadata off
      the wire, even though it's currently a placeholder instead of using
      MysqlIO.clearInputStream() which didn't work at various times because
      data wasn't available to read from the server yet. This fixes sporadic
      errors users were having with ServerPreparedStatements throwing
      ArrayIndexOutOfBoundExceptions.

    - Use com.mysql.jdbc.Message's classloader when loading resource bundle,
      should fix sporadic issues when the caller's classloader can't locate
      the resource bundle.

07-07-04 - Version 3.1.3-beta

	- Mangle output parameter names for CallableStatements so they
	  will not clash with user variable names.

	- Added support for INOUT parameters in CallableStatements.

	- Fix for BUG#4119, null bitmask sent for server-side prepared
	  statements was incorrect.

	- Use SQL Standard SQL states by default, unless 'useSqlStateCodes'
	  property is set to 'false'.

	- Added packet debuging code (see the 'enablePacketDebug' property
	  documentation).

	- Added constants for MySQL error numbers (publicly-accessible,
	  see com.mysql.jdbc.MysqlErrorNumbers), and the ability to
	  generate the mappings of vendor error codes to SQLStates
	  that the driver uses (for documentation purposes).

	- Externalized more messages (on-going effort).

	- Fix for BUG#4311 - Error in retrieval of mediumint column with
	  prepared statements and binary protocol.

	- Support new timezone variables in MySQL-4.1.3 when
	  'useTimezone=true'

	- Support for unsigned numerics as return types from prepared statements.
	  This also causes a change in ResultSet.getObject() for the 'bigint unsigned'
	  type, which used to return BigDecimal instances, it now returns instances
	  of java.lang.BigInteger.

06-09-04 - Version 3.1.2-alpha

	- Fixed stored procedure parameter parsing info when size was
	  specified for a parameter (i.e. char(), varchar()).

	- Enabled callable statement caching via 'cacheCallableStmts'
	  property.

	- Fixed case when no output parameters specified for a
	  stored procedure caused a bogus query to be issued
	  to retrieve out parameters, leading to a syntax error
	  from the server.

	- Fixed case when no parameters could cause a NullPointerException
	  in CallableStatement.setOutputParameters().

	- Removed wrapping of exceptions in MysqlIO.changeUser().

	- Fixed sending of split packets for large queries, enabled nio
	  ability to send large packets as well.

	- Added .toString() functionality to ServerPreparedStatement,
	  which should help if you're trying to debug a query that is
	  a prepared statement (it shows SQL as the server would process).

	- Added 'gatherPerformanceMetrics' property, along with properties
	  to control when/where this info gets logged (see docs for more
	  info).

	- ServerPreparedStatements weren't actually de-allocating
	  server-side resources when .close() was called.

	- Added 'logSlowQueries' property, along with property
	  'slowQueriesThresholdMillis' to control when a query should
	  be considered 'slow'.

	- Correctly map output parameters to position given in
	  prepareCall() vs. order implied during registerOutParameter() -
	  fixes BUG#3146.

	- Correctly detect initial character set for servers >= 4.1.0

	- Cleaned up detection of server properties.

	- Support placeholder for parameter metadata for server >= 4.1.2

	- Fix for BUG#3539 getProcedures() does not return any procedures in
	  result set

	- Fix for BUG#3540 getProcedureColumns() doesn't work with wildcards
	  for procedure name

	- Fixed BUG#3520 -- DBMD.getSQLStateType() returns incorrect value.

	- Added 'connectionCollation' property to cause driver to issue
	  'set collation_connection=...' query on connection init if default
	  collation for given charset is not appropriate.

	- Fixed DatabaseMetaData.getProcedures() when run on MySQL-5.0.0 (output of
	'show procedure status' changed between 5.0.1 and 5.0.0.

	- Fixed BUG#3804 -- getWarnings() returns SQLWarning instead of DataTruncation

	- Don't enable server-side prepared statements for server version 5.0.0 or 5.0.1,
	as they aren't compatible with the '4.1.2+' style that the driver uses (the driver
	expects information to come back that isn't there, so it hangs).


02-14-04 - Version 3.1.1-alpha

    - Fixed bug with UpdatableResultSets not using client-side
	  prepared statements.

	- Fixed character encoding issues when converting bytes to
	  ASCII when MySQL doesn't provide the character set, and
	  the JVM is set to a multibyte encoding (usually affecting
	  retrieval of numeric values).

	- Unpack 'unknown' data types from server prepared statements
	  as Strings.

	- Implemented long data (Blobs, Clobs, InputStreams, Readers)
	  for server prepared statements.

	- Implemented Statement.getWarnings() for MySQL-4.1 and newer
	  (using 'SHOW WARNINGS').

	- Default result set type changed to TYPE_FORWARD_ONLY
	  (JDBC compliance).

	- Centralized setting of result set type and concurrency.

	- Re-factored how connection properties are set and exposed
	  as DriverPropertyInfo as well as Connection and DataSource
	  properties.

	- Support for NIO. Use 'useNIO=true' on platforms that support
	  NIO.

	- Support for SAVEPOINTs (MySQL >= 4.0.14 or 4.1.1).

	- Support for mysql_change_user()...See the changeUser() method
	  in com.mysql.jdbc.Connection.

	- Reduced number of methods called in average query to be more
	  efficient.

	- Prepared Statements will be re-prepared on auto-reconnect. Any errors
	  encountered are postponed until first attempt to re-execute the
	  re-prepared statement.

	- Ensure that warnings are cleared before executing queries
	  on prepared statements, as-per JDBC spec (now that we support
	  warnings).

	- Support 'old' profileSql capitalization in ConnectionProperties.
	  This property is deprecated, you should use 'profileSQL' if possible.

	- Optimized Buffer.readLenByteArray() to return shared empty byte array
	  when length is 0.

	- Allow contents of PreparedStatement.setBlob() to be retained
	  between calls to .execute*().

	- Deal with 0-length tokens in EscapeProcessor (caused by callable
	  statement escape syntax).

	- Check for closed connection on delete/update/insert row operations in
	  UpdatableResultSet.

	- Fix support for table aliases when checking for all primary keys in
	  UpdatableResultSet.

	- Removed useFastDates connection property.

	- Correctly initialize datasource properties from JNDI Refs, including
	  explicitly specified URLs.

	- DatabaseMetaData now reports supportsStoredProcedures() for
	  MySQL versions >= 5.0.0

	- Fixed stack overflow in Connection.prepareCall() (bad merge).

	- Fixed IllegalAccessError to Calendar.getTimeInMillis() in DateTimeValue
	  (for JDK < 1.4).

	- Fix for BUG#1673, where DatabaseMetaData.getColumns() is not
      returning correct column ordinal info for non '%' column name patterns.

    - Merged fix of datatype mapping from MySQL type 'FLOAT' to
      java.sql.Types.REAL from 3.0 branch.

    - Detect collation of column for RSMD.isCaseSensitive().

    - Fixed sending of queries > 16M.

    - Added named and indexed input/output parameter support to CallableStatement.
      MySQL-5.0.x or newer.

    - Fixed NullPointerException in ServerPreparedStatement.setTimestamp(),
      as well as year and month descrepencies in
      ServerPreparedStatement.setTimestamp(), setDate().

    - Added ability to have multiple database/JVM targets for compliance
      and regression/unit tests in build.xml.

    - Fixed NPE and year/month bad conversions when accessing some
      datetime functionality in ServerPreparedStatements and their
      resultant result sets.

    - Display where/why a connection was implicitly closed (to
      aid debugging).

    - CommunicationsException implemented, that tries to determine
      why communications was lost with a server, and displays
      possible reasons when .getMessage() is called.

    - Fixed BUG#2359, NULL values for numeric types in binary
      encoded result sets causing NullPointerExceptions.

    - Implemented Connection.prepareCall(), and DatabaseMetaData.
      getProcedures() and getProcedureColumns().

    - Reset 'long binary' parameters in ServerPreparedStatement when
      clearParameters() is called, by sending COM_RESET_STMT to the
      server.

    - Merged prepared statement caching, and .getMetaData() support
      from 3.0 branch.

    - Fixed off-by-1900 error in some cases for
      years in TimeUtil.fastDate/TimeCreate() when unpacking results
      from server-side prepared statements.

    - Fixed BUG#2502 -- charset conversion issue in getTables().

    - Implemented multiple result sets returned from a statement
      or stored procedure.

    - Fixed BUG#2606 -- Server side prepared statements not returning
      datatype 'YEAR' correctly.

    - Enabled streaming of result sets from server-side prepared
      statements.

    - Fixed BUG#2623 -- Class-cast exception when using
      scrolling result sets and server-side prepared statements.

	- Merged unbuffered input code from 3.0.

	- Fixed ConnectionProperties that weren't properly exposed
	  via accessors, cleaned up ConnectionProperties code.

	- Fixed BUG#2671, NULL fields not being encoded correctly in
	  all cases in server side prepared statements.

	- Fixed rare buffer underflow when writing numbers into buffers
	  for sending prepared statement execution requests.

	- Use DocBook version of docs for shipped versions of drivers.


02-18-03 - Version 3.1.0-alpha

    - Added 'requireSSL' property.

    - Added 'useServerPrepStmts' property (default 'false'). The
      driver will use server-side prepared statements when the
      server version supports them (4.1 and newer) when this
      property is set to 'true'. It is currently set to 'false'
      by default until all bind/fetch functionality has been
      implemented. Currently only DML prepared statements are
      implemented for 4.1 server-side prepared statements.

    - Track open Statements, close all when Connection.close()
      is called (JDBC compliance).

06-22-05 - Version 3.0.17-ga

    - Fixed BUG#5874, Timestamp/Time conversion goes in the wrong 'direction'
      when useTimeZone='true' and server timezone differs from client timezone.

	- Fixed BUG#7081, DatabaseMetaData.getIndexInfo() ignoring 'unique'
	  parameter.

	- Support new protocol type 'MYSQL_TYPE_VARCHAR'.

	- Added 'useOldUTF8Behavoior' configuration property, which causes
	  JDBC driver to act like it did with MySQL-4.0.x and earlier when
	  the character encoding is 'utf-8' when connected to MySQL-4.1 or
	  newer.

	- Fixed BUG#7316 - Statements created from a pooled connection were
	  returning physical connection instead of logical connection when
	  getConnection() was called.

	- Fixed BUG#7033 - PreparedStatements don't encode Big5 (and other
	  multibyte) character sets correctly in static SQL strings.

	- Fixed BUG#6966, connections starting up failed-over (due to down master)
      never retry master.

    - Fixed BUG#7061, PreparedStatement.fixDecimalExponent() adding extra
      '+', making number unparseable by MySQL server.

    - Fixed BUG#7686, Timestamp key column data needed "_binary'" stripped for
      UpdatableResultSet.refreshRow().

    - Backported SQLState codes mapping from Connector/J 3.1, enable with
      'useSqlStateCodes=true' as a connection property, it defaults to
      'false' in this release, so that we don't break legacy applications (it
      defaults to 'true' starting with Connector/J 3.1).

    - Fixed BUG#7601, PreparedStatement.fixDecimalExponent() adding extra
      '+', making number unparseable by MySQL server.

    - Escape sequence {fn convert(..., type)} now supports ODBC-style types
      that are prepended by 'SQL_'.

    - Fixed duplicated code in configureClientCharset() that prevented
      useOldUTF8Behavior=true from working properly.

    - Handle streaming result sets with > 2 billion rows properly by fixing
      wraparound of row number counter.

    - Fixed BUG#7607 - MS932, SHIFT_JIS and Windows_31J not recog. as
      aliases for sjis.

    - Fixed BUG#6549 (while fixing #7607), adding 'CP943' to aliases for
      sjis.

    - Fixed BUG#8064, which requires hex escaping of binary data when using
      multibyte charsets with prepared statements.

    - Fixed BUG#8812, NON_UNIQUE column from DBMD.getIndexInfo() returned
      inverted value.

    - Workaround for server BUG#9098 - default values of CURRENT_* for
      DATE/TIME/TIMESTAMP/TIMESTAMP columns can't be distinguished from
      'string' values, so UpdatableResultSet.moveToInsertRow() generates
      bad SQL for inserting default values.

    - Fixed BUG#8629 - 'EUCKR' charset is sent as 'SET NAMES euc_kr' which
      MySQL-4.1 and newer doesn't understand.

    - DatabaseMetaData.supportsSelectForUpdate() returns correct value based
      on server version.

    - Use hex escapes for PreparedStatement.setBytes() for double-byte charsets
      including 'aliases' Windows-31J, CP934, MS932.

    - Added support for the "EUC_JP_Solaris" character encoding, which maps
      to a MySQL encoding of "eucjpms" (backported from 3.1 branch). This only
      works on servers that support eucjpms, namely 5.0.3 or later.

11-15-04 - Version 3.0.16-ga

	- Re-issue character set configuration commands when re-using pooled
	  connections and/or Connection.changeUser() when connected to MySQL-4.1
	  or newer.

	- Fixed ResultSetMetaData.isReadOnly() to detect non-writable columns
	  when connected to MySQL-4.1 or newer, based on existence of 'original'
	  table and column names.

	- Fixed BUG#5664, ResultSet.updateByte() when on insert row
      throws ArrayOutOfBoundsException.

    - Fixed DatabaseMetaData.getTypes() returning incorrect (i.e. non-negative)
      scale for the 'NUMERIC' type.

    - Fixed BUG#6198, off-by-one bug in Buffer.readString(string).

    - Made TINYINT(1) -> BIT/Boolean conversion configurable via 'tinyInt1isBit'
      property (default 'true' to be JDBC compliant out of the box).

    - Only set 'character_set_results' during connection establishment if
      server version >= 4.1.1.

    - Fixed regression where useUnbufferedInput was defaulting to 'false'.

    - Fixed BUG#6231, ResultSet.getTimestamp() on a column with TIME in it
      fails.

09-04-04 - Version 3.0.15-ga

	- Fixed BUG#4010 - StringUtils.escapeEasternUnicodeByteStream is still
	  broken for GBK

	- Fixed BUG#4334 - Failover for autoReconnect not using port #'s for any
	  hosts, and not retrying all hosts. (WARN: This required a change to
	  the SocketFactory connect() method signature, which is now

	    public Socket connect(String host, int portNumber, Properties props),

	  therefore any third-party socket factories will have to be changed
	  to support this signature.

	- Logical connections created by MysqlConnectionPoolDataSource will
	  now issue a rollback() when they are closed and sent back to the pool.
	  If your application server/connection pool already does this for you, you
	  can set the 'rollbackOnPooledClose' property to false to avoid the
	  overhead of an extra rollback().

	- Removed redundant calls to checkRowPos() in ResultSet.

	- Fixed BUG#4742, 'DOUBLE' mapped twice in DBMD.getTypeInfo().

	- Added FLOSS license exemption.

	- Fixed BUG#4808, calling .close() twice on a PooledConnection causes NPE.

	- Fixed BUG#4138 and BUG#4860, DBMD.getColumns() returns incorrect JDBC
	  type for unsigned columns. This affects type mappings for all numeric
	  types in the RSMD.getColumnType() and RSMD.getColumnTypeNames() methods
	  as well, to ensure that 'like' types from DBMD.getColumns() match up
	  with what RSMD.getColumnType() and getColumnTypeNames() return.

	- 'Production' - 'GA' in naming scheme of distributions.

	- Fix for BUG#4880, RSMD.getPrecision() returning 0 for non-numeric types
	  (should return max length in chars for non-binary types, max length
	  in bytes for binary types). This fix also fixes mapping of
	  RSMD.getColumnType() and RSMD.getColumnTypeName() for the BLOB types based
	  on the length sent from the server (the server doesn't distinguish between
	  TINYBLOB, BLOB, MEDIUMBLOB or LONGBLOB at the network protocol level).

	- Fixed BUG#5022 - ResultSet should release Field[] instance in .close().

    - Fixed BUG#5069 -- ResultSet.getMetaData() should not return
	  incorrectly-initialized metadata if the result set has been closed, but
	  should instead throw a SQLException. Also fixed for getRow() and
	  getWarnings() and traversal methods by calling checkClosed() before
	  operating on instance-level fields that are nullified during .close().

	- Parse new timezone variables from 4.1.x servers.

	- Use _binary introducer for PreparedStatement.setBytes() and
	  set*Stream() when connected to MySQL-4.1.x or newer to avoid
	  misinterpretation during character conversion.

05-28-04 - Version 3.0.14-production

	- Fixed URL parsing error

05-27-04 - Version 3.0.13-production

	- Fixed BUG#3848 - Using a MySQLDatasource without server name fails

	- Fixed BUG#3920 - "No Database Selected" when using
	  MysqlConnectionPoolDataSource.

	- Fixed BUG#3873 - PreparedStatement.getGeneratedKeys() method returns only
	  1 result for batched insertions

05-18-04 - Version 3.0.12-production

	- Add unsigned attribute to DatabaseMetaData.getColumns() output
	  in the TYPE_NAME column.

	- Added 'failOverReadOnly' property, to allow end-user to configure
	  state of connection (read-only/writable) when failed over.

	- Backported 'change user' and 'reset server state' functionality
      from 3.1 branch, to allow clients of MysqlConnectionPoolDataSource
      to reset server state on getConnection() on a pooled connection.

    - Don't escape SJIS/GBK/BIG5 when using MySQL-4.1 or newer.

    - Allow 'url' parameter for MysqlDataSource and MysqlConnectionPool
      DataSource so that passing of other properties is possible from
      inside appservers.

    - Map duplicate key and foreign key errors to SQLState of
      '23000'.

    - Backport documentation tooling from 3.1 branch.

    - Return creating statement for ResultSets created by
      getGeneratedKeys() (BUG#2957)

    - Allow java.util.Date to be sent in as parameter to
      PreparedStatement.setObject(), converting it to a Timestamp
      to maintain full precision (BUG#3103).

    - Don't truncate BLOBs/CLOBs when using setBytes() and/or
      setBinary/CharacterStream() (BUG#2670).

    - Dynamically configure character set mappings for field-level
      character sets on MySQL-4.1.0 and newer using 'SHOW COLLATION'
      when connecting.

    - Map 'binary' character set to 'US-ASCII' to support DATETIME
      charset recognition for servers >= 4.1.2

    - Use 'SET character_set_results" during initialization to allow any
      charset to be returned to the driver for result sets.

    - Use charsetnr returned during connect to encode queries before
      issuing 'SET NAMES' on MySQL >= 4.1.0.

    - Add helper methods to ResultSetMetaData (getColumnCharacterEncoding()
      and getColumnCharacterSet()) to allow end-users to see what charset
      the driver thinks it should be using for the column.

    - Only set character_set_results for MySQL >= 4.1.0.

    - Fixed BUG#3511, StringUtils.escapeSJISByteStream() not covering all
      eastern double-byte charsets correctly.

    - Renamed StringUtils.escapeSJISByteStream() to more appropriate
      escapeEasternUnicodeByteStream().

    - Fixed BUG#3554 - Not specifying database in URL caused MalformedURL
      exception.

    - Auto-convert MySQL encoding names to Java encoding names if used
      for characterEncoding property.

    - Added encoding names that are recognized on some JVMs to fix case
      where they were reverse-mapped to MySQL encoding names incorrectly.

    - Use junit.textui.TestRunner for all unit tests (to allow them to be
      run from the command line outside of Ant or Eclipse).

    - Fixed BUG#3557 - UpdatableResultSet not picking up default values
      for moveToInsertRow().

    - Fixed BUG#3570 - inconsistent reporting of column type. The server
      still doesn't return all types for *BLOBs *TEXT correctly, so the
      driver won't return those correctly.

    - Fixed BUG#3520 -- DBMD.getSQLStateType() returns incorrect value.

    - Fixed regression in PreparedStatement.setString() and eastern character
      encodings.

    - Made StringRegressionTest 4.1-unicode aware.

02-19-04 - Version 3.0.11-stable

	- Trigger a 'SET NAMES utf8' when encoding is forced to 'utf8' _or_
	  'utf-8' via the 'characterEncoding' property. Previously, only the
	  Java-style encoding name of 'utf-8' would trigger this.

	- AutoReconnect time was growing faster than exponentially (BUG#2447).

	- Fixed failover always going to last host in list (BUG#2578)

	- Added 'useUnbufferedInput' parameter, and now use it by default
	  (due to JVM issue
	  http://developer.java.sun.com/developer/bugParade/bugs/4401235.html)

	- Detect 'on/off' or '1','2','3' form of lower_case_table_names on
	  server.

	- Return 'java.lang.Integer' for TINYINT and SMALLINT types from
	  ResultSetMetaData.getColumnClassName() (fix for BUG#2852).

	- Return 'java.lang.Double' for FLOAT type from ResultSetMetaData.
	  getColumnClassName() (fix for BUG#2855).

	- Return '[B' instead of java.lang.Object for BINARY, VARBINARY and
	  LONGVARBINARY types from ResultSetMetaData.getColumnClassName()
	  (JDBC compliance).

01-13-04 - Version 3.0.10-stable

    - Don't count quoted id's when inside a 'string' in PreparedStatement
      parsing (fix for BUG#1511).

    - 'Friendlier' exception message for PacketTooLargeException
       (BUG#1534).

    - Backported fix for aliased tables and UpdatableResultSets in
      checkUpdatability() method from 3.1 branch.

    - Fix for ArrayIndexOutOfBounds exception when using Statement.setMaxRows()
      (BUG#1695).

    - Fixed BUG#1576, dealing with large blobs and split packets not being
      read correctly.

    - Fixed regression of Statement.getGeneratedKeys() and REPLACE statements.

    - Fixed BUG#1630, subsequent call to ResultSet.updateFoo() causes NPE if
      result set is not updatable.

    - Fix for 4.1.1-style auth with no password.

    - Fix for BUG#1731, Foreign Keys column sequence is not consistent in
      DatabaseMetaData.getImported/Exported/CrossReference().

    - Fix for BUG#1775 - DatabaseMetaData.getSystemFunction() returning
      bad function 'VResultsSion'.

    - Fix for BUG#1592 -- cross-database updatable result sets
      are not checked for updatability correctly.

    - DatabaseMetaData.getColumns() should return Types.LONGVARCHAR for
      MySQL LONGTEXT type.

    - ResultSet.getObject() on TINYINT and SMALLINT columns should return
      Java type 'Integer' (BUG#1913)

    - Added 'alwaysClearStream' connection property, which causes the driver
      to always empty any remaining data on the input stream before
      each query.

    - Added more descriptive error message 'Server Configuration Denies
      Access to DataSource', as well as retrieval of message from server.

    - Autoreconnect code didn't set catalog upon reconnect if it had been
      changed.

    - Implement ResultSet.updateClob().

    - ResultSetMetaData.isCaseSensitive() returned wrong value for CHAR/VARCHAR
      columns.

    - Fix for BUG#1933 -- Connection property "maxRows" not honored.

    - Fix for BUG#1925 -- Statements being created too many times in
      DBMD.extractForeignKeyFromCreateTable().

    - Fix for BUG#1914 -- Support escape sequence {fn convert ... }

    - Fix for BUG#1958 -- ArrayIndexOutOfBounds when parameter number ==
      number of parameters + 1.

    - Fix for BUG#2006 -- ResultSet.findColumn() should use first matching
      column name when there are duplicate column names in SELECT query
      (JDBC-compliance).

    - Removed static synchronization bottleneck from
      PreparedStatement.setTimestamp().

    - Removed static synchronization bottleneck from instance factory
      method of SingleByteCharsetConverter.

    - Enable caching of the parsing stage of prepared statements via
      the 'cachePrepStmts', 'prepStmtCacheSize' and 'prepStmtCacheSqlLimit'
      properties (disabled by default).

    - Speed up parsing of PreparedStatements, try to use one-pass whenever
      possible.

    - Fixed security exception when used in Applets (applets can't
      read the system property 'file.encoding' which is needed
      for LOAD DATA LOCAL INFILE).

    - Use constants for SQLStates.

    - Map charset 'ko18_ru' to 'ko18r' when connected to MySQL-4.1.0 or
      newer.

    - Ensure that Buffer.writeString() saves room for the \0.

    - Fixed exception 'Unknown character set 'danish' on connect w/ JDK-1.4.0

    - Fixed mappings in SQLError to report deadlocks with SQLStates of '41000'.

    - 'maxRows' property would affect internal statements, so check it for all
      statement creation internal to the driver, and set to 0 when it is not.

10-07-03 - Version 3.0.9-stable

	- Faster date handling code in ResultSet and PreparedStatement (no longer
	  uses Date methods that synchronize on static calendars).

	- Fixed test for end of buffer in Buffer.readString().

	- Fixed ResultSet.previous() behavior to move current
	  position to before result set when on first row
	  of result set (bugs.mysql.com BUG#496)

	- Fixed Statement and PreparedStatement issuing bogus queries
	  when setMaxRows() had been used and a LIMIT clause was present
	  in the query.

	- Fixed BUG#661 - refreshRow didn't work when primary key values
	  contained values that needed to be escaped (they ended up being
	  doubly-escaped).

	- Support InnoDB contraint names when extracting foreign key info
	  in DatabaseMetaData BUG#517 and BUG#664
	  (impl. ideas from Parwinder Sekhon)

	- Backported 4.1 protocol changes from 3.1 branch (server-side SQL
	  states, new field info, larger client capability flags,
	  connect-with-database, etc).

	- Fix UpdatableResultSet to return values for getXXX() when on
	  insert row (BUG#675).

	- The insertRow in an UpdatableResultSet is now loaded with
	  the default column values when moveToInsertRow() is called
	  (BUG#688)

	- DatabaseMetaData.getColumns() wasn't returning NULL for
	  default values that are specified as NULL.

	- Change default statement type/concurrency to TYPE_FORWARD_ONLY
	  and CONCUR_READ_ONLY (spec compliance).

	- Don't try and reset isolation level on reconnect if MySQL doesn't
	  support them.

	- Don't wrap SQLExceptions in RowDataDynamic.

	- Don't change timestamp TZ twice if useTimezone==true (BUG#774)

	- Fixed regression in large split-packet handling (BUG#848).

	- Better diagnostic error messages in exceptions for 'streaming'
	  result sets.

	- Issue exception on ResultSet.getXXX() on empty result set (wasn't
	  caught in some cases).

	- Don't hide messages from exceptions thrown in I/O layers.

	- Don't fire connection closed events when closing pooled connections, or
	  on PooledConnection.getConnection() with already open connections (BUG#884).

	- Clip +/- INF (to smallest and largest representative values for the type in
	  MySQL) and NaN (to 0) for setDouble/setFloat(), and issue a warning on the
	  statement when the server does not support +/- INF or NaN.

	- Fix for BUG#879, double-escaping of '\' when charset is SJIS or GBK and '\'
	  appears in non-escaped input.

	- When emptying input stream of unused rows for 'streaming' result sets,
	  have the current thread yield() every 100 rows in order to not monopolize
	  CPU time.

	- Fixed BUG#1099, DatabaseMetaData.getColumns() getting confused about the
	  keyword 'set' in character columns.

	- Fixed deadlock issue with Statement.setMaxRows().

	- Fixed CLOB.truncate(), BUG#1130

	- Optimized CLOB.setChracterStream(), BUG#1131

	- Made databaseName, portNumber and serverName optional parameters
	  for MysqlDataSourceFactory (BUG#1246)

	- Fix for BUG#1247 -- ResultSet.get/setString mashing char 127

	- Backported auth. changes for 4.1.1 and newer from 3.1 branch.

	- Added com.mysql.jdbc.util.BaseBugReport to help creation of testcases
	  for bug reports.

	- Added property to 'clobber' streaming results, by setting the
	  'clobberStreamingResults' property to 'true' (the default is 'false').
	  This will cause a 'streaming' ResultSet to be automatically
	  closed, and any oustanding data still streaming from the server to
	  be discarded if another query is executed before all the data has been
	  read from the server.

05-23-03 - Version 3.0.8-stable

	- Allow bogus URLs in Driver.getPropertyInfo().

	- Return list of generated keys when using multi-value INSERTS
	  with Statement.getGeneratedKeys().

	- Use JVM charset with filenames and 'LOAD DATA [LOCAL] INFILE'

	- Fix infinite loop with Connection.cleanup().

	- Changed Ant target 'compile-core' to 'compile-driver', and
	  made testsuite compilation a separate target.

	- Fixed result set not getting set for Statement.executeUpdate(),
	  which affected getGeneratedKeys() and getUpdateCount() in
	  some cases.

	- Unicode character 0xFFFF in a string would cause the driver to
	  throw an ArrayOutOfBoundsException (Bug #378)

	- Return correct amount of generated keys when using 'REPLACE'
	  statements.

	- Fix problem detecting server character set in some cases.

	- Fix row data decoding error when using _very_ large packets.

	- Optimized row data decoding.

	- Issue exception when operating on an already-closed
	  prepared statement.

	- Fixed SJIS encoding bug, thanks to Naoto Sato.

    - Optimized usage of EscapeProcessor.

    - Allow multiple calls to Statement.close()

04-08-03 - Version 3.0.7-stable

    - Fixed MysqlPooledConnection.close() calling wrong event type.

    - Fixed StringIndexOutOfBoundsException in PreparedStatement.
      setClob().

    - 4.1 Column Metadata fixes

    - Remove synchronization from Driver.connect() and
      Driver.acceptsUrl().

    - IOExceptions during a transaction now cause the Connection to
      be closed.

    - Fixed missing conversion for 'YEAR' type in ResultSetMetaData.
      getColumnTypeName().

    - Don't pick up indexes that start with 'pri' as primary keys
      for DBMD.getPrimaryKeys().

    - Throw SQLExceptions when trying to do operations on a forcefully
      closed Connection (i.e. when a communication link failure occurs).

    - You can now toggle profiling on/off using
      Connection.setProfileSql(boolean).

    - Fixed charset issues with database metadata (charset was not
      getting set correctly).

    - Updatable ResultSets can now be created for aliased tables/columns
      when connected to MySQL-4.1 or newer.

    - Fixed 'LOAD DATA LOCAL INFILE' bug when file > max_allowed_packet.

    - Fixed escaping of 0x5c ('\') character for GBK and Big5 charsets.

    - Fixed ResultSet.getTimestamp() when underlying field is of type DATE.

    - Ensure that packet size from alignPacketSize() does not
      exceed MAX_ALLOWED_PACKET (JVM bug)

    - Don't reset Connection.isReadOnly() when autoReconnecting.

02-18-03 - Version 3.0.6-stable

    - Fixed ResultSetMetaData to return "" when catalog not known.
      Fixes NullPointerExceptions with Sun's CachedRowSet.

    - Fixed DBMD.getTypeInfo() and DBMD.getColumns() returning
      different value for precision in TEXT/BLOB types.

    - Allow ignoring of warning for 'non transactional tables' during
      rollback (compliance/usability) by setting 'ignoreNonTxTables'
      property to 'true'.

    - Fixed SQLExceptions getting swallowed on initial connect.

    - Fixed Statement.setMaxRows() to stop sending 'LIMIT' type queries
      when not needed (performance)

    - Clean up Statement query/method mismatch tests (i.e. INSERT not
      allowed with .executeQuery()).

    - More checks added in ResultSet traversal method to catch
      when in closed state.

    - Fixed ResultSetMetaData.isWritable() to return correct value.

    - Add 'window' of different NULL sorting behavior to
      DBMD.nullsAreSortedAtStart (4.0.2 to 4.0.10, true, otherwise,
      no).

    - Implemented Blob.setBytes(). You still need to pass the
      resultant Blob back into an updatable ResultSet or
      PreparedStatement to persist the changes, as MySQL does
      not support 'locators'.

    - Backported 4.1 charset field info changes from Connector/J 3.1

01-22-03 - Version 3.0.5-gamma

    - Fixed Buffer.fastSkipLenString() causing ArrayIndexOutOfBounds
      exceptions with some queries when unpacking fields.

    - Implemented an empty TypeMap for Connection.getTypeMap() so that
      some third-party apps work with MySQL (IBM WebSphere 5.0 Connection
      pool).

    - Added missing LONGTEXT type to DBMD.getColumns().

    - Retrieve TX_ISOLATION from database for
      Connection.getTransactionIsolation() when the MySQL version
      supports it, instead of an instance variable.

    - Quote table names in DatabaseMetaData.getColumns(),
      getPrimaryKeys(), getIndexInfo(), getBestRowIdentifier()

    - Greatly reduce memory required for setBinaryStream() in
      PreparedStatements.

    - Fixed ResultSet.isBeforeFirst() for empty result sets.

    - Added update options for foreign key metadata.


01-06-03 - Version 3.0.4-gamma

    - Added quoted identifiers to database names for
      Connection.setCatalog.

    - Added support for quoted identifiers in PreparedStatement
      parser.

    - Streamlined character conversion and byte[] handling in
      PreparedStatements for setByte().

    - Reduce memory footprint of PreparedStatements by sharing
      outbound packet with MysqlIO.

    - Added 'strictUpdates' property to allow control of amount
      of checking for 'correctness' of updatable result sets. Set this
      to 'false' if you want faster updatable result sets and you know
      that you create them from SELECTs on tables with primary keys and
      that you have selected all primary keys in your query.

    - Added support for 4.0.8-style large packets.

    - Fixed PreparedStatement.executeBatch() parameter overwriting.

12-17-02 - Version 3.0.3-dev

    - Changed charsToByte in SingleByteCharConverter to be non-static

    - Changed SingleByteCharConverter to use lazy initialization of each
      converter.

    - Fixed charset handling in Fields.java

    - Implemented Connection.nativeSQL()

    - More robust escape tokenizer -- recognize '--' comments, and allow
      nested escape sequences (see testsuite.EscapeProcessingTest)

    - DBMD.getImported/ExportedKeys() now handles multiple foreign keys
      per table.

    - Fixed ResultSetMetaData.getPrecision() returning incorrect values
      for some floating point types.

    - Fixed ResultSetMetaData.getColumnTypeName() returning BLOB for
      TEXT and TEXT for BLOB types.

    - Fixed Buffer.isLastDataPacket() for 4.1 and newer servers.

    - Added CLIENT_LONG_FLAG to be able to get more column flags
      (isAutoIncrement() being the most important)

    - Because of above, implemented ResultSetMetaData.isAutoIncrement()
      to use Field.isAutoIncrement().

    - Honor 'lower_case_table_names' when enabled in the server when
      doing table name comparisons in DatabaseMetaData methods.

    - Some MySQL-4.1 protocol support (extended field info from selects)

    - Use non-aliased table/column names and database names to fullly
      qualify tables and columns in UpdatableResultSet (requires
      MySQL-4.1 or newer)

    - Allow user to alter behavior of Statement/
      PreparedStatement.executeBatch() via 'continueBatchOnError' property
      (defaults to 'true').

    - Check for connection closed in more Connection methods
      (createStatement, prepareStatement, setTransactionIsolation,
      setAutoCommit).

    - More robust implementation of updatable result sets. Checks that
      _all_ primary keys of the table have been selected.

    - 'LOAD DATA LOCAL INFILE ...' now works, if your server is configured
      to allow it. Can be turned off with the 'allowLoadLocalInfile'
      property (see the README).

    - Substitute '?' for unknown character conversions in single-byte
      character sets instead of '\0'.

    - NamedPipeSocketFactory now works (only intended for Windows), see
      README for instructions.

11-08-02 - Version 3.0.2-dev

    - Fixed issue with updatable result sets and PreparedStatements not
      working

    - Fixed ResultSet.setFetchDirection(FETCH_UNKNOWN)

    - Fixed issue when calling Statement.setFetchSize() when using
      arbitrary values

    - Fixed incorrect conversion in ResultSet.getLong()

    - Implemented ResultSet.updateBlob().

    - Removed duplicate code from UpdatableResultSet (it can be inherited
      from ResultSet, the extra code for each method to handle updatability
      I thought might someday be necessary has not been needed).

    - Fixed "UnsupportedEncodingException" thrown when "forcing" a
      character encoding via properties.

    - Fixed various non-ASCII character encoding issues.

    - Added driver property 'useHostsInPrivileges'. Defaults to true.
      Affects whether or not '@hostname' will be used in
      DBMD.getColumn/TablePrivileges.

    - All DBMD result set columns describing schemas now return NULL
      to be more compliant with the behavior of other JDBC drivers
      for other databases (MySQL does not support schemas).

    - Added SSL support. See README for information on how to use it.

    - Properly restore connection properties when autoReconnecting
      or failing-over, including autoCommit state, and isolation level.

    - Use 'SHOW CREATE TABLE' when possible for determining foreign key
      information for DatabaseMetaData...also allows cascade options for
      DELETE information to be returned

    - Escape 0x5c character in strings for the SJIS charset.

    - Fixed start position off-by-1 error in Clob.getSubString()

    - Implemented Clob.truncate()

    - Implemented Clob.setString()

    - Implemented Clob.setAsciiStream()

    - Implemented Clob.setCharacterStream()

    - Added com.mysql.jdbc.MiniAdmin class, which allows you to send
      'shutdown' command to MySQL server...Intended to be used when 'embedding'
      Java and MySQL server together in an end-user application.

    - Added 'connectTimeout' parameter that allows users of JDK-1.4 and newer
      to specify a maxium time to wait to establish a connection.

    - Failover and autoReconnect only work when the connection is in a
      autoCommit(false) state, in order to stay transaction safe

    - Added 'queriesBeforeRetryMaster' property that specifies how many
      queries to issue when failed over before attempting to reconnect
      to the master (defaults to 50)

    - Fixed DBMD.supportsResultSetConcurrency() so that it returns true
      for ResultSet.TYPE_SCROLL_INSENSITIVE and ResultSet.CONCUR_READ_ONLY or
      ResultSet.CONCUR_UPDATABLE

    - Fixed ResultSet.isLast() for empty result sets (should return false).

    - PreparedStatement now honors stream lengths in setBinary/Ascii/Character
      Stream() unless you set the connection property
      'useStreamLengthsInPrepStmts' to 'false'.

    - Removed some not-needed temporary object creation by using Strings
      smarter in EscapeProcessor, Connection and DatabaseMetaData classes.

09-21-02 - Version 3.0.1-dev

    - Fixed ResultSet.getRow() off-by-one bug.

    - Fixed RowDataStatic.getAt() off-by-one bug.

    - Added limited Clob functionality (ResultSet.getClob(),
      PreparedStatemtent.setClob(),
      PreparedStatement.setObject(Clob).

    - Added socketTimeout parameter to URL.

    - Connection.isClosed() no longer "pings" the server.

    - Connection.close() issues rollback() when getAutoCommit() == false

    - Added "paranoid" parameter...sanitizes error messages removing
      "sensitive" information from them (i.e. hostnames, ports,
      usernames, etc.), as well as clearing "sensitive" data structures
      when possible.

    - Fixed ResultSetMetaData.isSigned() for TINYINT and BIGINT.

    - Charsets now automatically detected. Optimized code for single-byte
      character set conversion.

    - Implemented ResultSet.getCharacterStream()

    - Added "LOCAL TEMPORARY" to table types in DatabaseMetaData.getTableTypes()

    - Massive code clean-up to follow Java coding conventions (the time had come)


07-31-02 - Version 3.0.0-dev

    - !!! LICENSE CHANGE !!! The driver is now GPL. If you need
      non-GPL licenses, please contact me <mark@mysql.com>

    - JDBC-3.0 functionality including
      Statement/PreparedStatement.getGeneratedKeys() and
      ResultSet.getURL()

    - Performance enchancements - driver is now 50-100% faster
      in most situations, and creates fewer temporary objects

    - Repackaging...new driver name is "com.mysql.jdbc.Driver",
      old name still works, though (the driver is now provided
      by MySQL-AB)

    - Better checking for closed connections in Statement
      and PreparedStatement.

    - Support for streaming (row-by-row) result sets (see README)
      Thanks to Doron.

    - Support for large packets (new addition to MySQL-4.0 protocol),
      see README for more information.

    - JDBC Compliance -- Passes all tests besides stored procedure tests


    - Fix and sort primary key names in DBMetaData (SF bugs 582086 and 582086)

    - Float types now reported as java.sql.Types.FLOAT (SF bug 579573)

    - ResultSet.getTimestamp() now works for DATE types (SF bug 559134)

    - ResultSet.getDate/Time/Timestamp now recognizes all forms of invalid
      values that have been set to all zeroes by MySQL (SF bug 586058)

    - Testsuite now uses Junit (which you can get from www.junit.org)

    - The driver now only works with JDK-1.2 or newer.

    - Added multi-host failover support (see README)

    - General source-code cleanup.

    - Overall speed improvements via controlling transient object
      creation in MysqlIO class when reading packets

    - Performance improvements in  string handling and field
      metadata creation (lazily instantiated) contributed by
      Alex Twisleton-Wykeham-Fiennes


05-16-02 - Version 2.0.14

    - More code cleanup

    - PreparedStatement now releases resources on .close() (SF bug 553268)

    - Quoted identifiers not used if server version does not support them. Also,
      if server started with --ansi or --sql-mode=ANSI_QUOTES then '"' will be
      used as an identifier quote, otherwise '`' will be used.

    - ResultSet.getDouble() now uses code built into JDK to be more precise (but slower)

    - LogicalHandle.isClosed() calls through to physical connection

    - Added SQL profiling (to STDERR). Set "profileSql=true" in your JDBC url.
      See README for more information.

    - Fixed typo for relaxAutoCommit parameter.

04-24-02 - Version 2.0.13

    - More code cleanup.

    - Fixed unicode chars being read incorrectly (SF bug 541088)

    - Faster blob escaping for PrepStmt

    - Added set/getPortNumber() to DataSource(s) (SF bug 548167)

    - Added setURL() to MySQLXADataSource (SF bug 546019)

    - PreparedStatement.toString() fixed (SF bug 534026)

    - ResultSetMetaData.getColumnClassName() now implemented

    - Rudimentary version of Statement.getGeneratedKeys() from JDBC-3.0
      now implemented (you need to be using JDK-1.4 for this to work, I
      believe)

    - DBMetaData.getIndexInfo() - bad PAGES fixed (SF BUG 542201)

04-07-02 - Version 2.0.12

    - General code cleanup.

    - Added getIdleFor() method to Connection and MysqlLogicalHandle.

    - Relaxed synchronization in all classes, should fix 520615 and 520393.

    - Added getTable/ColumnPrivileges() to DBMD (fixes 484502).

    - Added new types to getTypeInfo(), fixed existing types thanks to
      Al Davis and Kid Kalanon.

    - Added support for BIT types (51870) to PreparedStatement.

    - Fixed getRow() bug (527165) in ResultSet

    - Fixes for ResultSet updatability in PreparedStatement.
    - Fixed timezone off by 1-hour bug in PreparedStatement (538286, 528785).

    - ResultSet: Fixed updatability (values being set to null
      if not updated).

    - DataSources - fixed setUrl bug (511614, 525565),
      wrong datasource class name (532816, 528767)

    - Added identifier quoting to all DatabaseMetaData methods
      that need them (should fix 518108)

    - Added support for YEAR type (533556)

    - ResultSet.insertRow() should now detect auto_increment fields
      in most cases and use that value in the new row. This detection
      will not work in multi-valued keys, however, due to the fact that
      the MySQL protocol does not return this information.

    - ResultSet.refreshRow() implemented.

    - Fixed testsuite.Traversal afterLast() bug, thanks to Igor Lastric.

01-27-02 - Version 2.0.11

    - Fixed missing DELETE_RULE value in
      DBMD.getImported/ExportedKeys() and getCrossReference().

    - Full synchronization of Statement.java.

    - More changes to fix "Unexpected end of input stream"
      errors when reading BLOBs. This should be the last fix.

01-24-02 - Version 2.0.10

     - Fixed spurious "Unexpected end of input stream" errors in
       MysqlIO (bug 507456).

     - Fixed null-pointer-exceptions when using
       MysqlConnectionPoolDataSource with Websphere 4 (bug 505839).

01-13-02 - Version 2.0.9

     - Ant build was corrupting included jar files, fixed
       (bug 487669).

     - Fixed extra memory allocation in MysqlIO.readPacket()
       (bug 488663).

     - Implementation of DatabaseMetaData.getExported/ImportedKeys() and
       getCrossReference().

     - Full synchronization on methods modifying instance and class-shared
       references, driver should be entirely thread-safe now (please
       let me know if you have problems)

     - DataSource implementations moved to org.gjt.mm.mysql.jdbc2.optional
       package, and (initial) implementations of PooledConnectionDataSource
       and XADataSource are in place (thanks to Todd Wolff for the
       implementation and testing of PooledConnectionDataSource with
       IBM WebSphere 4).

     - Added detection of network connection being closed when reading packets
       (thanks to Todd Lizambri).

     - Fixed quoting error with escape processor (bug 486265).

     - Report batch update support through DatabaseMetaData (bug 495101).

     - Fixed off-by-one-hour error in PreparedStatement.setTimestamp()
       (bug 491577).

     - Removed concatenation support from driver (the '||' operator),
       as older versions of VisualAge seem to be the only thing that
       use it, and it conflicts with the logical '||' operator. You will
       need to start mysqld with the "--ansi" flag to use the '||'
       operator as concatenation (bug 491680)

     - Fixed casting bug in PreparedStatement (bug 488663).

11-25-01 - Version 2.0.8

     - Batch updates now supported (thanks to some inspiration
       from Daniel Rall).

     - XADataSource/ConnectionPoolDataSource code (experimental)

     - PreparedStatement.setAnyNumericType() now handles positive
       exponents correctly (adds "+" so MySQL can understand it).

     - DatabaseMetaData.getPrimaryKeys() and getBestRowIdentifier()
       are now more robust in identifying primary keys (matches
       regardless of case or abbreviation/full spelling of Primary Key
       in Key_type column).

10-24-01 - Version 2.0.7

     - PreparedStatement.setCharacterStream() now implemented

     - Fixed dangling socket problem when in high availability
       (autoReconnect=true) mode, and finalizer for Connection will
       close any dangling sockets on GC.

     - Fixed ResultSetMetaData.getPrecision() returning one
       less than actual on newer versions of MySQL.

     - ResultSet.getBlob() now returns null if column value
       was null.

     - Character sets read from database if useUnicode=true
       and characterEncoding is not set. (thanks to
       Dmitry Vereshchagin)

     - Initial transaction isolation level read from
       database (if avaialable) (thanks to Dmitry Vereshchagin)

     - Fixed DatabaseMetaData.supportsTransactions(), and
       supportsTransactionIsolationLevel() and getTypeInfo()
       SQL_DATETIME_SUB and SQL_DATA_TYPE fields not being
       readable.

     - Fixed PreparedStatement generating SQL that would end
       up with syntax errors for some queries.

     - Fixed ResultSet.isAfterLast() always returning false.

     - Fixed timezone issue in PreparedStatement.setTimestamp()
       (thanks to Erik Olofsson)

     - Captialize type names when "captializeTypeNames=true"
       is passed in URL or properties (for WebObjects, thanks
       to Anjo Krank)

     - Updatable result sets now correctly handle NULL
       values in fields.

     - PreparedStatement.setDouble() now uses full-precision
       doubles (reverting a fix made earlier to truncate them).

     - PreparedStatement.setBoolean() will use 1/0 for values
       if your MySQL Version >= 3.21.23.

06-16-01 - Version 2.0.6

Fixed PreparedStatement parameter checking

     - Fixed case-sensitive column names in ResultSet.java

06-13-01 - Version 2.0.5

     - Fixed ResultSet.getBlob() ArrayIndex out-of-bounds

     - Fixed ResultSetMetaData.getColumnTypeName for TEXT/BLOB

     - Fixed ArrayIndexOutOfBounds when sending large BLOB queries
       (Max size packet was not being set)

     - Added ISOLATION level support to Connection.setIsolationLevel()

     - Fixed NPE on PreparedStatement.executeUpdate() when all columns
       have not been set.

     - Fixed data parsing of TIMESTAMPs with 2-digit years

     - Added Byte to PreparedStatement.setObject()

     - ResultSet.getBoolean() now recognizes '-1' as 'true'

     - ResultSet has +/-Inf/inf support

     - ResultSet.insertRow() works now, even if not all columns are
       set (they will be set to "NULL")

     - DataBaseMetaData.getCrossReference() no longer ArrayIndexOOB

     - getObject() on ResultSet correctly does TINYINT->Byte and
       SMALLINT->Short

12-03-00 - Version 2.0.3

     - Implemented getBigDecimal() without scale component
       for JDBC2.

     - Fixed composite key problem with updateable result sets.

     - Added detection of -/+INF for doubles.

     - Faster ASCII string operations.

     - Fixed incorrect detection of MAX_ALLOWED_PACKET, so sending
       large blobs should work now.

     - Fixed off-by-one error in java.sql.Blob implementation code.

     - Added "ultraDevHack" URL parameter, set to "true" to allow
       (broken) Macromedia UltraDev to use the driver.

04-06-00 - Version 2.0.1

     - Fixed RSMD.isWritable() returning wrong value.
       Thanks to Moritz Maass.

     - Cleaned up exception handling when driver connects

     - Columns that are of type TEXT now return as Strings
       when you use getObject()

     - DatabaseMetaData.getPrimaryKeys() now works correctly wrt
       to key_seq. Thanks to Brian Slesinsky.

     - No escape processing is done on PreparedStatements anymore
       per JDBC spec.

     - Fixed many JDBC-2.0 traversal, positioning bugs, especially
       wrt to empty result sets. Thanks to Ron Smits, Nick Brook,
       Cessar Garcia and Carlos Martinez.

     - Fixed some issues with updatability support in ResultSet when
       using multiple primary keys.

02-21-00 - Version 2.0pre5

     - Fixed Bad Handshake problem.

01-10-00 - Version 2.0pre4

     - Fixes to ResultSet for insertRow() - Thanks to
       Cesar Garcia

     - Fix to Driver to recognize JDBC-2.0 by loading a JDBC-2.0
       class, instead of relying on JDK version numbers. Thanks
       to John Baker.

     - Fixed ResultSet to return correct row numbers

     - Statement.getUpdateCount() now returns rows matched,
       instead of rows actually updated, which is more SQL-92
       like.

10-29-99

     - Statement/PreparedStatement.getMoreResults() bug fixed.
       Thanks to Noel J. Bergman.

     - Added Short as a type to PreparedStatement.setObject().
       Thanks to Jeff Crowder

     - Driver now automagically configures maximum/preferred packet
       sizes by querying server.

     - Autoreconnect code uses fast ping command if server supports
       it.

     - Fixed various bugs wrt. to packet sizing when reading from
       the server and when alloc'ing to write to the server.

08-17-99 - Version 2.0pre

     - Now compiles under JDK-1.2. The driver supports both JDK-1.1
       and JDK-1.2 at the same time through a core set of classes.
       The driver will load the appropriate interface classes at
       runtime by figuring out which JVM version you are using.

     - Fixes for result sets with all nulls in the first row.
       (Pointed out by Tim Endres)

     - Fixes to column numbers in SQLExceptions in ResultSet
       (Thanks to Blas Rodriguez Somoza)

     - The database no longer needs to specified to connect.
       (Thanks to Christian Motschke)

07-04-99 - Version 1.2b

     - Better Documentation (in progress), in doc/mm.doc/book1.html

     - DBMD now allows null for a column name pattern (not in
       spec), which it changes to '%'.

     - DBMD now has correct types/lengths for getXXX().

     - ResultSet.getDate(), getTime(), and getTimestamp() fixes.
       (contributed by Alan Wilken)

     - EscapeProcessor now handles \{ \} and { or } inside quotes
       correctly. (thanks to Alik for some ideas on how to fix it)

     - Fixes to properties handling in Connection.
       (contributed by Juho Tikkala)

     - ResultSet.getObject() now returns null for NULL columns
       in the table, rather than bombing out.
       (thanks to Ben Grosman)

     - ResultSet.getObject() now returns Strings for types
       from MySQL that it doesn't know about. (Suggested by
       Chris Perdue)

     - Removed DataInput/Output streams, not needed, 1/2 number
       of method calls per IO operation.

     - Use default character encoding if one is not specified. This
       is a work-around for broken JVMs, because according to spec,
       EVERY JVM must support "ISO8859_1", but they don't.

     - Fixed Connection to use the platform character encoding
       instead of "ISO8859_1" if one isn't explicitly set. This
       fixes problems people were having loading the character-
       converter classes that didn't always exist (JVM bug).
       (thanks to Fritz Elfert for pointing out this problem)

     - Changed MysqlIO to re-use packets where possible to reduce
       memory usage.

     - Fixed escape-processor bugs pertaining to {} inside
       quotes.

04-14-99 - Version 1.2a

     - Fixed character-set support for non-Javasoft JVMs
       (thanks to many people for pointing it out)

     - Fixed ResultSet.getBoolean() to recognize 'y' & 'n'
       as well as '1' & '0' as boolean flags.
       (thanks to Tim Pizey)

     - Fixed ResultSet.getTimestamp() to give better performance.
       (thanks to Richard Swift)

     - Fixed getByte() for numeric types.
       (thanks to Ray Bellis)

     - Fixed DatabaseMetaData.getTypeInfo() for DATE type.
       (thanks to Paul Johnston)

     - Fixed EscapeProcessor for "fn" calls.
       (thanks to Piyush Shah at locomotive.org)

     - Fixed EscapeProcessor to not do extraneous work if there
       are no escape codes.
       (thanks to Ryan Gustafson)

     - Fixed Driver to parse URLs of the form "jdbc:mysql://host:port"
       (thanks to Richard Lobb)

03-24-99 - Version 1.1i

     - Fixed Timestamps for PreparedStatements

     - Fixed null pointer exceptions in RSMD and RS

     - Re-compiled with jikes for valid class files (thanks ms!)

03-08-99 - Version 1.1h

     - Fixed escape processor to deal with un-matched { and }
       (thanks to Craig Coles)

     - Fixed escape processor to create more portable (between
       DATETIME and TIMESTAMP types) representations so that
       it will work with BETWEEN clauses.
       (thanks to Craig Longman)

     - MysqlIO.quit() now closes the socket connection. Before,
       after many failed connections some OS's would run out
       of file descriptors. (thanks to Michael Brinkman)

     - Fixed NullPointerException in Driver.getPropertyInfo.
       (thanks to Dave Potts)

     - Fixes to MysqlDefs to allow all *text fields to be
       retrieved as Strings.
       (thanks to Chris at Leverage)

     - Fixed setDouble in PreparedStatement for large numbers
       to avoid sending scientific notation to the database.
       (thanks to J.S. Ferguson)

     - Fixed getScale() and getPrecision() in RSMD.
       (contrib'd by James Klicman)

     - Fixed getObject() when field was DECIMAL or NUMERIC
       (thanks to Bert Hobbs)

     - DBMD.getTables() bombed when passed a null table-name
       pattern. Fixed. (thanks to Richard Lobb)

     - Added check for "client not authorized" errors during
       connect. (thanks to Hannes Wallnoefer)

02-19-99 - Version 1.1g

     - Result set rows are now byte arrays. Blobs and Unicode
       work bidriectonally now. The useUnicode and encoding
       options are implemented now.

     - Fixes to PreparedStatement to send binary set by
       setXXXStream to be sent un-touched to the MySQL server.

     - Fixes to getDriverPropertyInfo().

12-31-98 - Version 1.1f

     - Changed all ResultSet fields to Strings, this should allow
       Unicode to work, but your JVM must be able to convert
       between the character sets. This should also make reading
       data from the server be a bit quicker, because there is now
       no conversion from StringBuffer to String.

     - Changed PreparedStatement.streamToString() to be more
       efficient (code from Uwe Schaefer).

     - URL parsing is more robust (throws SQL exceptions on errors
       rather than NullPointerExceptions)

     - PreparedStatement now can convert Strings to Time/Date values
       via setObject() (code from Robert Currey).

     - IO no longer hangs in Buffer.readInt(), that bug was
       introduced in 1.1d when changing to all byte-arrays for
       result sets. (Pointed out by Samo Login)

11-03-98 - Version 1.1b

     - Fixes to DatabaseMetaData to allow both IBM VA and J-Builder
       to work. Let me know how it goes. (thanks to Jac Kersing)

     - Fix to ResultSet.getBoolean() for NULL strings
       (thanks to Barry Lagerweij)

     - Beginning of code cleanup, and formatting. Getting ready
       to branch this off to a parallel JDBC-2.0 source tree.

     - Added "final" modifier to critical sections in MysqlIO and
       Buffer to allow compiler to inline methods for speed.

9-29-98

     - If object references passed to setXXX() in PreparedStatement are
       null, setNull() is automatically called for you. (Thanks for the
       suggestion goes to Erik Ostrom)

     - setObject() in PreparedStatement will now attempt to write a
       serialized  representation of the object to the database for
       objects of Types.OTHER and objects of unknown type.

     - Util now has a static method readObject() which given a ResultSet
       and a column index will re-instantiate an object serialized in
       the above manner.

9-02-98 - Vesion 1.1

     - Got rid of "ugly hack" in MysqlIO.nextRow(). Rather than
       catch an exception, Buffer.isLastDataPacket() was fixed.

     - Connection.getCatalog() and Connection.setCatalog()
       should work now.

     - Statement.setMaxRows() works, as well as setting
       by property maxRows. Statement.setMaxRows() overrides
       maxRows set via properties or url parameters.

     - Automatic re-connection is available. Because it has
       to "ping" the database before each query, it is
       turned off by default. To use it, pass in "autoReconnect=true"
       in the connection URL. You may also change the number of
       reconnect tries, and the initial timeout value via
       "maxReconnects=n" (default 3) and "initialTimeout=n"
       (seconds, default 2) parameters. The timeout is an
       exponential backoff type of timeout, e.g. if you have initial
       timeout of 2 seconds, and maxReconnects of 3, then the driver
       will timeout 2 seconds, 4 seconds, then 16 seconds between each
       re-connection attempt.

8-24-98 - Version 1.0

     - Fixed handling of blob data in Buffer.java

     - Fixed bug with authentication packet being
       sized too small.

     - The JDBC Driver is now under the LPGL

8-14-98 -

     - Fixed Buffer.readLenString() to correctly
          read data for BLOBS.

     - Fixed PreparedStatement.stringToStream to
          correctly read data for BLOBS.

     - Fixed PreparedStatement.setDate() to not
       add a day.
       (above fixes thanks to Vincent Partington)

     - Added URL parameter parsing (?user=... etc).


8-04-98 - Version 0.9d

     - Big news! New package name. Tim Endres from ICE
       Engineering is starting a new source tree for
       GNU GPL'd Java software. He's graciously given
       me the org.gjt.mm package directory to use, so now
       the driver is in the org.gjt.mm.mysql package scheme.
       I'm "legal" now. Look for more information on Tim's
       project soon.

     - Now using dynamically sized packets to reduce
       memory usage when sending commands to the DB.

     - Small fixes to getTypeInfo() for parameters, etc.

     - DatabaseMetaData is now fully implemented. Let me
       know if these drivers work with the various IDEs
       out there. I've heard that they're working with
       JBuilder right now.

     - Added JavaDoc documentation to the package.

     - Package now available in .zip or .tar.gz.

7-28-98 - Version 0.9

     - Implemented getTypeInfo().
       Connection.rollback() now throws an SQLException
       per the JDBC spec.

     - Added PreparedStatement that supports all JDBC API
       methods for PreparedStatement including InputStreams.
       Please check this out and let me know if anything is
       broken.

     - Fixed a bug in ResultSet that would break some
       queries that only returned 1 row.

     - Fixed bugs in DatabaseMetaData.getTables(),
       DatabaseMetaData.getColumns() and
       DatabaseMetaData.getCatalogs().

     - Added functionality to Statement that allows
       executeUpdate() to store values for IDs that are
       automatically generated for AUTO_INCREMENT fields.
       Basically, after an executeUpdate(), look at the
       SQLWarnings for warnings like "LAST_INSERTED_ID =
       'some number', COMMAND = 'your SQL query'".

       If you are using AUTO_INCREMENT fields in your
       tables and are executing a lot of executeUpdate()s
       on one Statement, be sure to clearWarnings() every
       so often to save memory.

7-06-98 - Version 0.8

     - Split MysqlIO and Buffer to separate classes. Some
       ClassLoaders gave an IllegalAccess error for some
       fields in those two classes. Now mm.mysql works in
       applets and all classloaders.

       Thanks to Joe Ennis <jce@mail.boone.com> for pointing
       out the problem and working on a fix with me.

7-01-98 - Version 0.7

     - Fixed DatabaseMetadata problems in getColumns() and
       bug in switch statement in the Field constructor.

       Thanks to Costin Manolache <costin@tdiinc.com> for
       pointing these out.

5-21-98 - Version 0.6

     - Incorporated efficiency changes from
       Richard Swift <Richard.Swift@kanatek.ca> in
       MysqlIO.java and ResultSet.java

     - We're now 15% faster than gwe's driver.

     - Started working on DatabaseMetaData.

       The following methods are implemented:
        * getTables()
        * getTableTypes()
        * getColumns
        * getCatalogs()
