package android.database.sqlite;

import android.database.SQLException;

public class SQLiteException
        extends SQLException
{
    public SQLiteException()
    {
        throw new RuntimeException("Stub!");
    }

    public SQLiteException(String error)
    {
        throw new RuntimeException("Stub!");
    }

    public SQLiteException(String error, Throwable cause)
    {
        throw new RuntimeException("Stub!");
    }
}
