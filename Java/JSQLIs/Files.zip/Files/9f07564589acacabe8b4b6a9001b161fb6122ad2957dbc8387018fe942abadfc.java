<?xml version="1.0" encoding="UTF-8"?>
<MessageCollection xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xsi:noNamespaceSchemaLocation="messagecollection.xsd">

    <Plugin>
        <ShortDescription>Find Security Bugs</ShortDescription>
        <Details>Highlight part of the source code that should be analyze in a security audit.
        </Details>
    </Plugin>

    <!-- Predictable Pseudo Random Generator (PRG) -->
    <Detector class="com.h3xstream.findsecbugs.PredictableRandomDetector">
        <Details>Detect the use of predictable Pseudo Random Generator (PRG).
        </Details>
    </Detector>

    <BugPattern type="PREDICTABLE_RANDOM">
        <ShortDescription>Predictable Pseudo Random Generator (PRG)</ShortDescription>
        <LongDescription>Use of {3} is predictable.</LongDescription>
        <Details>
            <![CDATA[
<p>The use of a predictable random value can lead to vulnerability if it is use for:</p>
<ul>
<li>CSRF token</li>
<li>password reset token (sent by email)</li>
<li>or any other secret value</li>
</ul>
<p>A quick fix would be to replace the instanciation of <b>java.util.Random</b> by <b>java.security.SecureRandom</b>.
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPR">Predictable Pseudo Random Generator (PRG)</BugCode>

    <!-- Servlet parameter -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.ServletEndpointDetector">
        <Details>Identify the unfilter value coming from ServletRequest and HttpServletRequest.
        </Details>
    </Detector>

    <BugPattern type="SERVLET_PARAMETER">
        <ShortDescription>Servlet parameter</ShortDescription>
        <LongDescription>The method {3} return a String value that is control by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The Servlet can read GET and POST parameters from various method. The value obtain should be consider unsafe.
In may be needed to sanitize those values when calling sensitive api such as:</p>
<ul>
<li>SQL query</li>
<li>File opening</li>
<li>Command execution</li>
<li>HTML construction</li>
<li>etc...</li>
</ul>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSP">Request parameter</BugCode>

    <BugPattern type="SERVLET_CONTENT_TYPE">
        <ShortDescription>Request Content-Type</ShortDescription>
        <LongDescription>The HTTP header Content-Type can be control by the client.</LongDescription>
        <Details>
            <![CDATA[
The HTTP header Content-Type can be control by the client.
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSCT">Request Content-Type</BugCode>


    <BugPattern type="SERVLET_SERVER_NAME">
        <ShortDescription>Request Hostname (ServerName/Host)</ShortDescription>
        <LongDescription>The hostname received can often be control by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The hostname can often be control by the client. Both <i>ServletRequest.getServerName()</i> and
<i>HttpServletRequest.getHeader("Host")</i> have the same behavior which is to extract the <i>"Host"</i> header.</p>
<pre>
GET /test HTTP/1.1
Host: www.example.com
[...]
</pre>
<p>
The web container serving your application may redirect request to your application by default. This would allow
a malicious user to place any value. It is recommended to have no assumption on the value and therefor to proper
escaping and validation if needed.
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSN">Request Server Name (Hostname)</BugCode>


    <BugPattern type="SERVLET_SESSION_ID">
        <ShortDescription>Request Session Id</ShortDescription>
        <LongDescription>To be confirmed...</LongDescription>
        <Details>
            <![CDATA[
To be confirmed...
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSID">Request Session Id</BugCode>

    <BugPattern type="SERVLET_QUERY_STRING">
        <ShortDescription>Request Query String</ShortDescription>
        <LongDescription>The query string can be any value.</LongDescription>
        <Details>
            <![CDATA[
<p>The query string is the concatenation of the GET parameters and values. Parameter others that those intended can
be passed.</p>
<p>For the url request <i>/app/servlet.htm?a=1&b=2</i>, the query string extract will be <i>a=1&b=2</i></p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSQ">Request Query String</BugCode>


    <BugPattern type="SERVLET_HEADER">
        <ShortDescription>Request Header</ShortDescription>
        <LongDescription>Request header can easily be alter by the client</LongDescription>
        <Details>
            <![CDATA[
<p>Request header can easily be alter by the client. No assumption should be make that the request come from a regular browser</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSH">Request Header</BugCode>


    <BugPattern type="SERVLET_HEADER_REFERER">
        <ShortDescription>Request Header "Referer"</ShortDescription>
        <LongDescription>The header "Referer" can be easily spoofed by the client.</LongDescription>
        <Details>
            <![CDATA[
Behavior:
<ul>
<li>Any value can be assigned to this header</li>
<li>The "Referer" will not be present if the request was initiated from another origin that is secure (https).</li>
</ul>
<p>
Recommendations:
<ul>
<li>No access control should be base on this header.</li>
<li>No CSRF protection should be based only on this value (Because it is optional).</li>
</ul>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSHR">Request Header "Referer"</BugCode>

    <BugPattern type="SERVLET_HEADER_USER_AGENT">
        <ShortDescription>Request Header "User-Agent"</ShortDescription>
        <LongDescription>The header "User-Agent" can be easily spoofed by the client.</LongDescription>
        <Details>
            <![CDATA[
The header "User-Agent" can be easily spoofed by the client. Adopting different behavior base on the User-Agent (for
crawler UA) is not recommended.
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSHUA">>Request Header "User-Agent"</BugCode>

    <BugPattern type="SERVLET_HEADER">
        <ShortDescription>Request Header</ShortDescription>
        <LongDescription>Request header can easily be alter by the client</LongDescription>
        <Details>
            <![CDATA[
<p>Request header can easily be alter by the client. No assumption should be make that the request come from a regular browser</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSSH">Request Header</BugCode>

    <!-- Cookie usage -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.CookieDetector">
        <Details>Identy direct cookie usage</Details>
    </Detector>

    <BugPattern type="COOKIE_USAGE">
        <ShortDescription>Cookie usage</ShortDescription>
        <LongDescription>Cookie value can be change by the client.</LongDescription>
        <Details>
            <![CDATA[
<p>The information store in the cookie should not be sensitive or related to the session. In most case, session
variables should be used. see HttpSession (HttpServletRequest.getSession())</p>
<p>Cookies can be use for information that need live longer than the session.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCU">Cookie usage</BugCode>

    <!-- Path traversal -->
    <Detector class="com.h3xstream.findsecbugs.PathTraversalDetector">
        <Details>Identify the different access to the filesystem that takes a path as parameter.</Details>
    </Detector>

    <BugPattern type="PATH_TRAVERSAL_IN">
        <ShortDescription>Path traversal (read file)</ShortDescription>
        <LongDescription>An instance of {3} is created to read a file.</LongDescription>
        <Details>
            <![CDATA[
<p>The class selected is use to open a file handle using a <b>dynamic</b> parameter.</p>
<p>If unfiltered input is pass to this function, content from an arbitrary path could be read.</p>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/Path_Traversal">OWASP : Path Traversal</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPTI">Path traversal to read file</BugCode>

    <BugPattern type="PATH_TRAVERSAL_OUT">
        <ShortDescription>Path traversal (write file)</ShortDescription>
        <LongDescription>An instance of {3} is created to write a file.</LongDescription>
        <Details>
            <![CDATA[
<p>The class selected is use to open a file handle using a <b>dynamic</b> parameter.</p>
<p>If unfiltered input is pass to this function, content could be writen to an arbitrary path.</p>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/Command_Injection">OWASP : Command Injection</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECPTO">Path traversal to write file</BugCode>


    <!-- Command injection -->
    <Detector class="com.h3xstream.findsecbugs.CommandInjectionDetector">
        <Details>Identify source of command injection</Details>
    </Detector>

    <BugPattern type="COMMAND_INJECTION">
        <ShortDescription>Command Injection</ShortDescription>
        <LongDescription>{3} is used to executed system command.</LongDescription>
        <Details>
            <![CDATA[
<p>{3} is used to executed system command. If unfiltered input is passed to this api, it can lead </p>
<p>
<b>References</b><br/>
<a href="https://www.owasp.org/index.php/Command_Injection">OWASP : Command Injection</a>
</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCI">Command Injection</BugCode>

    <!-- Weak FilenameUtils method -->
    <Detector class="com.h3xstream.findsecbugs.WeakFilenameUtilsMethodDetector">
        <Details>Identify the usage of some FilenameUtils methods</Details>
    </Detector>

    <BugPattern type="WEAK_FILENAMEUTILS">
        <ShortDescription>FilenameUtils partial filtering</ShortDescription>
        <LongDescription>FilenameUtils.{3} doesn't filter NULL byte.</LongDescription>
        <Details>
            <![CDATA[
<p>Some FilenameUtils' methods doesn't filter nullbyte.</p>
<p>The risk come from the removal of characters following the NULL byte. This
removal can occurs with many system API (ie. usage of the File object).</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWF">FilenameUtils partial filtering</BugCode>


    <!-- Weak TrustManager -->
    <Detector class="com.h3xstream.findsecbugs.crypto.WeakTrustManagerDetector">
        <Details>Identify weak TrustManager implementation</Details>
    </Detector>

    <BugPattern type="WEAK_TRUST_MANAGER">
        <ShortDescription>Weak TrustManager implementation</ShortDescription>
        <LongDescription>The implementation of TrustManager is vulnerable to MITM attack.</LongDescription>
        <Details>
            <![CDATA[
<p>Empty TrustManager are generally implemented to connected to host that are not signed by root authorities.</p>
<p>A TrustManager allowing the specific certificate should be build. Details information for a proper implementation :
<a href="http://stackoverflow.com/a/6378872/89769">[1]</a> <a href="http://stackoverflow.com/a/5493452/89769">[2]</a></p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWTM">Identify weak TrustManager implementation</BugCode>

    <!-- JAXWS -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.JaxWsEndpointDetector">
        <Details>Identify web services endpoint that implements JAX-WS API</Details>
    </Detector>

    <BugPattern type="JAXWS_ENDPOINT">
        <ShortDescription>JAX-WS (JSR224) endpoint</ShortDescription>
        <LongDescription>{0}.{1} is SOAP Web Service endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This method is part of a SOAP Web Service.</p>
<b>Analysis needed</b>
<ul>
<li>The input should be track for potential vulnerability.</li>
<li>The authentification (if inforce) should be tested using a web client.</li>
<li>The communication should ideally be over SSL.</li>
</ul>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECJWS">JAX-WS (JSR224) endpoint</BugCode>

    <!-- JAXRS -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.JaxRsEndpointDetector">
        <Details>Identify web services endpoint that implements JAX-RS API</Details>
    </Detector>

    <BugPattern type="JAXRS_ENDPOINT">
        <ShortDescription>JAX-RS (JSR311) endpoint</ShortDescription>
        <LongDescription>{0}.{1} is REST Web Service endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This method is part of a REST Web Service.</p>
<b>Analysis needed</b>
<ul>
<li>The input should be track for potential vulnerability.</li>
<li>The authentification (if inforce) should be tested using a web client.</li>
<li>The communication should ideally be over SSL.</li>
<li>If the method allow include GET/POST, CSRF vulnerability should investigate.<sup>[1]</sup></li>
</ul>
<p>
1. <a href="https://www.owasp.org/index.php/Cross-Site_Request_Forgery_(CSRF)">OWASP - Cross-Site Request Forgery</a>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECJRS">JAX-RS (JSR311) endpoint</BugCode>

    <!-- Tapestry -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.TapestryEndpointDetector">
        <Details>Identify Tapestry "Pages" that serve as input</Details>
    </Detector>

    <BugPattern type="TAPESTRY_ENDPOINT">
        <ShortDescription>Tapestry Page</ShortDescription>
        <LongDescription>{0} is a Tapestry Page</LongDescription>
        <Details>
            <![CDATA[
<p>Tapestry endpoint are discover at the application startup and are requires to be in <i>[base.package.name].pages</i>.
When a request is received, the GET/POST parameters are mapped to field. The mapping is either done with fieldName:</p>
<pre><code>
    [...]
    protected String input;
    [...]
</code></pre>
<p>or
the definition of an explicit annotation:
</p>
<pre><code>
    [...]
    @org.apache.tapestry5.annotations.Parameter
    protected String parameter1;

    @org.apache.tapestry5.annotations.Component(id = "password")
    private PasswordField passwordField;
    [...]
</code></pre>
<p>The current page is mapped to the view [/package/PageName].tml.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECTE">Tapestry Page</BugCode>


    <!-- Wicket -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.WicketEndpointDetector">
        <Details>Identify Wicket "WebPages" that serve as input</Details>
    </Detector>

    <BugPattern type="WICKET_ENDPOINT">
        <ShortDescription>Wicket WebPage</ShortDescription>
        <LongDescription>{0} is a Wicket WebPage</LongDescription>
        <Details>
            <![CDATA[
<p>This class represent a Wicket WebPage.</p>
<p>The input are read from a PageParameters instance passed to the constructor.</p>
<p>The current page is mapped to the view [/package/WebPageName].html.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWE">Wicket WebPage</BugCode>

    <!-- Weak Message Digest -->
    <Detector class="com.h3xstream.findsecbugs.crypto.WeakMessageDigestDetector">
        <Details>Identify the use of weak MessageDigest that could be replace recommended standards.</Details>
    </Detector>

    <BugPattern type="WEAK_MESSAGE_DIGEST">
        <ShortDescription>Weak MessageDigest</ShortDescription>
        <LongDescription>{3} is not a recommended MessageDigest</LongDescription>
        <Details>
            <![CDATA[
<p>The algorithm used is not a recommended MessageDigest.</p>
<p>The <a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST</a> recommended to use either SHA-1, SHA-224*, SHA-256, SHA-384 or SHA-512.</p>
<p><small>* SHA-224 algorithm is not provided by <a href="http://docs.oracle.com/javase/6/docs/technotes/guides/security/SunProviders.html#SUNProvider"> SUN provider.</a></small></p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECWMD">Weak MessageDigest</BugCode>

    <!-- Custom Message Digest -->
    <Detector class="com.h3xstream.findsecbugs.crypto.CustomMessageDigestDetector">
        <Details>Identify the implementation of custom MessageDigest</Details>
    </Detector>

    <BugPattern type="CUSTOM_MESSAGE_DIGEST">
        <ShortDescription>Custom MessageDigest</ShortDescription>
        <LongDescription>{0} is a custom MessageDigest</LongDescription>
        <Details>
            <![CDATA[
<p>Implementing custom MessageDigest is error-prone.</p>
<p>The <a href="http://csrc.nist.gov/groups/ST/toolkit/secure_hashing.html">NIST</a> recommended to use either SHA-1, SHA-224*, SHA-256, SHA-384 or SHA-512.</p>
<p><small>* SHA-224 algorithm is not provided by <a href="http://docs.oracle.com/javase/6/docs/technotes/guides/security/SunProviders.html#SUNProvider"> SUN provider.</a></small></p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECCMD">Custom MessageDigest</BugCode>

    <!-- FileUpload Filename -->
    <Detector class="com.h3xstream.findsecbugs.FileUploadFilenameDetector">
        <Details>The filename given by FileUpload api can be tampered by the client.</Details>
    </Detector>

    <BugPattern type="FILE_UPLOAD_FILENAME">
        <ShortDescription>Tainted filename read</ShortDescription>
        <LongDescription>The filename read can be tampered by the client</LongDescription>
        <Details>
            <![CDATA[
<p>The filename given by FileUpload api can be tampered by the client.</p>
<p>It can take value such as:</p>
<ul>
<li><code>"../../../config/overide_file"</code></li>
<li><code>shell.jsp\u0000expected.gif</code></li>
</ul>
<p>Therefore it should not be passed directly to filesystem api.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECFUN">Tainted filename read</BugCode>

    <!-- ReDOS -->
    <Detector class="com.h3xstream.findsecbugs.ReDosDetector">
        <Details>The regular expression can grow exponentially with some input.</Details>
    </Detector>

    <BugPattern type="REDOS">
        <ShortDescription>ReDOS</ShortDescription>
        <LongDescription>The regular expression "{3}" is vulnerable to ReDOS</LongDescription>
        <Details>
            <![CDATA[
<a href="https://www.owasp.org/index.php/Regular_expression_Denial_of_Service_-_ReDoS">OWASP : Regular expression Denial of Service</a>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECRD">ReDOS</BugCode>


    <!-- SAXParser XXE -->
    <Detector class="com.h3xstream.findsecbugs.xxe.SaxParserXxeDetector">
        <Details>Identify SAXParser usage vulnerable to XXE</Details>
    </Detector>

    <BugPattern type="XXE">
        <ShortDescription>XML parsing vulnerable to XXE attacks</ShortDescription>
        <LongDescription>The usage of {3} is vulnerable to Xml External Entity attacks</LongDescription>
        <Details>
            <![CDATA[
<p>Xml External Entity attacks can occurs when the XML parsers support XML entities and received
user input as XML content.</p>
<b>Risk 1: Expose local file content</b>
<p>...</p>
<b>Risk 2: Denial of service</b>
<p>...</p>
<a href="https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=61702260">CERT: IDS10-J. Prevent XML external entity attacks</a>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXXE">XML parsing vulnerable to XXE attacks</BugCode>

    <!-- XPath Injection for Javax -->
    <Detector class="com.h3xstream.findsecbugs.xpath.XPathInjectionJavaxDetector">
        <Details>Find XPath query that use tainted input (javax.xml api)</Details>
    </Detector>

    <Detector class="com.h3xstream.findsecbugs.xpath.XPathInjectionApacheXPathApiDetector">
        <Details>Find XPath query that use tainted input (org.apache.xpath api)</Details>
    </Detector>

    <BugPattern type="XPATH_INJECTION">
        <ShortDescription>XPath Injection</ShortDescription>
        <LongDescription>The use of {3} is vulnerable to injection</LongDescription>
        <Details>
            <![CDATA[

]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECXPI">XPath Injection</BugCode>

    <!-- Struts1 -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.Struts1EndpointDetector">
        <Details>Identify Struts 1 endpoint (also called Action)</Details>
    </Detector>

    <BugPattern type="STRUTS1_ENDPOINT">
        <ShortDescription>Struts 1 Action</ShortDescription>
        <LongDescription>{0} is a Struts 1 endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>This class is Struts Action.</p>
<p>Once a request is route to this controller, a Form object will be builded that constains
the HTTP parameters.</p>
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSTR1">Struts 1 Action</BugCode>

    <!-- Struts2 -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.Struts2EndpointDetector">
        <Details>Identify Struts 2 endpoint</Details>
    </Detector>
    <BugPattern type="STRUTS2_ENDPOINT">
        <ShortDescription>Struts 2 endpoint</ShortDescription>
        <LongDescription>{0} is a Struts 2 endpoint</LongDescription>
        <Details>
            <![CDATA[
<p>In struts 2, the endpoint are Plain Old Java Object (POJO) which means no Interface/Class are implements/extends.</p>
<p>When a request is route to its controller (like the selected class). The different HTTP parameters are mapped to setter of
the class. Therefor all setter of this class should be consider as input even if the form expected to be used doesn't include
all of them.</p>

]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSTR2">Struts 2 endpoint</BugCode>

    <!-- Spring Controller -->
    <Detector class="com.h3xstream.findsecbugs.endpoint.SpringMvcEndpointDetector">
        <Details>Identify Spring Controller (also called Controller)</Details>
    </Detector>
    <BugPattern type="SPRING_ENDPOINT">
        <ShortDescription>Spring endpoint</ShortDescription>
        <LongDescription>{0} is a Spring controller</LongDescription>
        <Details>
            <![CDATA[
This class is a Spring Controller. All method annotated with <code>RequestMapping</code> are reachable remotely.
]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSC">Spring Controller</BugCode>

    <!-- Sql Injection -->
    <Detector class="com.h3xstream.findsecbugs.sql.HibernateInjectionDetector">
        <Details>Identify SQL injection on hibernate API</Details>
    </Detector>

    <Detector class="com.h3xstream.findsecbugs.sql.JpaInjectionDetector">
        <Details>Identify SQL injection on JPA API</Details>
    </Detector>

    <Detector class="com.h3xstream.findsecbugs.sql.JdoInjectionDetector">
        <Details>Identify SQL injection on JDO API</Details>
    </Detector>

    <BugPattern type="SQL_INJECTION">
        <ShortDescription>SQL Injection</ShortDescription>
        <LongDescription>The query is vulnerable SQL injection</LongDescription>
        <Details>
            <![CDATA[

]]>
        </Details>
    </BugPattern>
    <BugCode abbrev="SECSQLI">SQL Injection</BugCode>
</MessageCollection>