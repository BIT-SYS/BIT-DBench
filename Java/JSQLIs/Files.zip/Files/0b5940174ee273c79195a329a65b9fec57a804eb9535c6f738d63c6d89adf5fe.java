java/net/URLEncoder.encode(Ljava/lang/String;)Ljava/lang/String;:0|+CR_ENCODED,+LF_ENCODED,+XSS_SAFE,+HTTP_POLLUTION_SAFE
java/net/URLEncoder.encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;:1|+CR_ENCODED,+LF_ENCODED,+XSS_SAFE,+HTTP_POLLUTION_SAFE
java/net/URLDecoder.decode(Ljava/lang/String;)Ljava/lang/String;:0|-CR_ENCODED,-LF_ENCODED,-XSS_SAFE,-HTTP_POLLUTION_SAFE
java/net/URLDecoder.decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;:1|-CR_ENCODED,-LF_ENCODED,-XSS_SAFE,-HTTP_POLLUTION_SAFE


--Spring Framework
org/springframework/web/util/HtmlUtils.htmlEscape(Ljava/lang/String;)Ljava/lang/String;:0|+XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlEscape(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;:1|+XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlUnescape(Ljava/lang/String;)Ljava/lang/String;:0|-XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlEscapeDecimal(Ljava/lang/String;)Ljava/lang/String;:0|+XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlEscapeDecimal(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;:1|+XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlEscapeHex(Ljava/lang/String;)Ljava/lang/String;:0|+XSS_SAFE
org/springframework/web/util/HtmlUtils.htmlEscapeHex(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;:1|+XSS_SAFE
org/springframework/web/util/JavaScriptUtils.javaScriptEscape(Ljava/lang/String;)Ljava/lang/String;:0|+XSS_SAFE

org/springframework/util/StringUtils.getFilename(Ljava/lang/String;)Ljava/lang/String;:SAFE
org/springframework/util/StringUtils.getFilenameExtension(Ljava/lang/String;)Ljava/lang/String;:SAFE
