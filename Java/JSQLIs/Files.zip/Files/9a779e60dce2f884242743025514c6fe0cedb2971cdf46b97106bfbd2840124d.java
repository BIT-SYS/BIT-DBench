package javax.servlet.http;

public class HttpServletResponseWrapper {
    public HttpServletResponseWrapper(HttpServletResponse resp) {

    }

    public void setHeader(String name, String value) {}

    public void addHeader(String name, String value) {}
}
