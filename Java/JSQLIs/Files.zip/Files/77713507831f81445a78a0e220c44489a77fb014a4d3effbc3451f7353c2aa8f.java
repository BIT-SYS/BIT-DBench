package ognl;

public interface TypeConverter {
}
