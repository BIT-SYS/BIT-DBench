<idea-plugin>
  <extensionPoints>
    <extensionPoint name="regExpLanguageHost" beanClass="com.intellij.openapi.util.ClassExtensionPoint"/>
    <extensionPoint qualifiedName="com.intellij.regExpRangeProvider" interface="org.intellij.lang.regexp.RegExpRangeProvider"/>
  </extensionPoints>
  <extensions defaultExtensionNs="com.intellij">
    <lang.documentationProvider language="RegExp" implementationClass="org.intellij.lang.regexp.RegExpDocumentationProvider"/>
    <completion.contributor language="RegExp" implementationClass="org.intellij.lang.regexp.RegExpCompletionContributor"/>
    <fileTypeFactory implementation="org.intellij.lang.regexp.RegExpSupportLoader" />
    <annotator language="RegExp" implementationClass="org.intellij.lang.regexp.validation.RegExpAnnotator"/>
    <lang.parserDefinition language="RegExp" implementationClass="org.intellij.lang.regexp.RegExpParserDefinition"/>
    <lang.syntaxHighlighterFactory key="RegExp" implementationClass="org.intellij.lang.regexp.RegExpSyntaxHighlighterFactory"/>
    <lang.braceMatcher language="RegExp" implementationClass="org.intellij.lang.regexp.RegExpBraceMatcher"/>
    <lang.surroundDescriptor language="RegExp" implementationClass="org.intellij.lang.regexp.surroundWith.SimpleSurroundDescriptor"/>
    <colorSettingsPage implementation="org.intellij.lang.regexp.RegExpColorsPage"/>
    <basicWordSelectionFilter implementation="org.intellij.lang.regexp.RegExpWordSelectionFilter"/>

    <intentionAction>
      <className>org.intellij.lang.regexp.intention.CheckRegExpIntentionAction</className>
      <category>Declaration</category>
    </intentionAction>
  </extensions>
</idea-plugin>
