javax/portlet/PortletRequest.getPortletMode()Ljavax/portlet/PortletMode;:TAINTED
javax/portlet/PortletRequest.getWindowState()Ljavax/portlet/WindowState;:TAINTED
javax/portlet/PortletRequest.getPreferences()Ljavax/portlet/PortletPreferences;:SAFE
javax/portlet/PortletRequest.getPortletSession()Ljavax/portlet/PortletSession;:SAFE
javax/portlet/PortletRequest.getPortletSession(Z)Ljavax/portlet/PortletSession;:SAFE
javax/portlet/PortletRequest.getPropertyNames()Ljava/util/Enumeration;:SAFE
javax/portlet/PortletRequest.getPortalContext()Ljavax/portlet/PortalContext;:SAFE
javax/portlet/PortletRequest.getAuthType()Ljava/lang/String;:SAFE
javax/portlet/PortletRequest.getContextPath()Ljava/lang/String;:SAFE
javax/portlet/PortletRequest.getRemoteUser()Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getUserPrincipal()Ljava/security/Principal;:TAINTED
javax/portlet/PortletRequest.getAttributeNames()Ljava/util/Enumeration;:SAFE
javax/portlet/PortletRequest.getParameter(Ljava/lang/String;)Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getParameterMap()Ljava/util/Map;:TAINTED
javax/portlet/PortletRequest.getParameterNames()Ljava/util/Enumeration;:TAINTED
javax/portlet/PortletRequest.getParameterValues(Ljava/lang/String;)[Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getRequestedSessionId()Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getResponseContentType()Ljava/util/Enumeration;:TAINTED
javax/portlet/PortletRequest.getResponseContentTypes()Ljava/util/Enumeration;:TAINTED
javax/portlet/PortletRequest.getLocale()Ljava/util/Locale;:TAINTED
javax/portlet/PortletRequest.getLocales()Ljava/util/Enumeration;:SAFE
javax/portlet/PortletRequest.getScheme()Ljava/lang/String;:SAFE
javax/portlet/PortletRequest.getServerName()Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getWindowID()Ljava/lang/String;:TAINTED
javax/portlet/PortletRequest.getCookies()[Ljavax/portlet/http/Cookie;:TAINTED
javax/portlet/PortletRequest.getPrivateParameterMap()Ljava/util/Map;:TAINTED
javax/portlet/PortletRequest.getPublicParameterMap()Ljava/util/Map;:TAINTED

javax/portlet/ActionRequest.getReader()Ljava/io/BufferedReader;:TAINTED
javax/portlet/ActionRequest.getCharacterEncoding()Ljava/lang/String;:TAINTED
javax/portlet/ActionRequest.getContentType()Ljava/lang/String;:TAINTED

javax/portlet/ClientDataRequest.getPortletInputStream()Ljava/io/InputStream;:TAINTED
javax/portlet/ClientDataRequest.getReader()Ljava/io/BufferedReader;:TAINTED
javax/portlet/ClientDataRequest.getCharacterEncoding()Ljava/lang/String;:SAFE
javax/portlet/ClientDataRequest.getContentType()Ljava/lang/String;:TAINTED
javax/portlet/ClientDataRequest.getMethod()Ljava/lang/String;:SAFE

javax/portlet/RenderRequest.getETag()Ljava/lang/String;:TAINTED

javax/portlet/ResourceRequest.getETag()Ljava/lang/String;:TAINTED
javax/portlet/ResourceRequest.getResourceID()Ljava/lang/String;:TAINTED
javax/portlet/ResourceRequest.getPrivateRenderParameterMap()Ljava/util/Map;:TAINTED

javax/portlet/PortletResponse.encodeURL(Ljava/lang/String;)Ljava/lang/String;:0|+CR_ENCODED,+LF_ENCODED,+QUOTE_ENCODED,+LT_ENCODED
javax/portlet/PortletResponse.getNamespace()Ljava/lang/String;:SAFE

javax/portlet/MimeResponse.createRenderURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/MimeResponse.createActionURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/MimeResponse.createResourceURL()Ljavax/portlet/PortletURL;:SAFE

javax/portlet/RenderResponse.createRenderURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/RenderResponse.createActionURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/RenderResponse.getNamespace()Ljava/lang/String;:SAFE

javax/portlet/ResourceResponse.createRenderURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/ResourceResponse.createActionURL()Ljavax/portlet/PortletURL;:SAFE
javax/portlet/ResourceResponse.createResourceURL()Ljavax/portlet/PortletURL;:SAFE

javax/portlet/BaseURL.setParameter(Ljava/lang/String;Ljava/lang/String;)V:0,1#2
javax/portlet/BaseURL.setParameter(Ljava/lang/String;[Ljava/lang/String;)V:0,1#2
javax/portlet/BaseURL.setParameters(Ljava/util/Map;)V:0#1
javax/portlet/BaseURL.addProperty(Ljava/lang/String;Ljava/lang/String;)V:0,1#2
javax/portlet/BaseURL.setProperty(Ljava/lang/String;Ljava/lang/String;)V:0,1#2
javax/portlet/BaseURL.toString()Ljava/lang/String;:0|+CR_ENCODED,+LF_ENCODED,+QUOTE_ENCODED,+LT_ENCODED
