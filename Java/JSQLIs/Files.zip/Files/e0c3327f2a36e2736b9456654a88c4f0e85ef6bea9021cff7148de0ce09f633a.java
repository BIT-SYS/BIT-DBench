<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8" />
    <title>Home Page</title>
</head>
<body>
    <p>Hello <span th:text="${user}"></span>.</p>
    <p>Welcome to login java-sec-code application. <a th:href="@{/appInfo}">Application Infomation</a></p>
    <p>
        <a th:href="@{/codeinject?filepath=/tmp;cat /etc/passwd}">CmdInject</a>&nbsp;&nbsp;
        <a th:href="@{/jsonp/getToken?_callback=test}">JSONP</a>&nbsp;&nbsp;
        <a th:href="@{/file/pic}">FileUpload</a>&nbsp;&nbsp;
        <a th:href="@{cors/sec/originFilter}">Cors</a>&nbsp;&nbsp;
        <a th:href="@{/path_traversal/vul?filepath=../../../../../etc/passwd}">PathTraversal</a>&nbsp;&nbsp;
        <a th:href="@{sqli/mybatis/vuln01?username=joychou' or '1'='1}">SqlInject</a>&nbsp;&nbsp;
        <a th:href="@{/ssrf/urlConnection?url=file:///etc/passwd}">SSRF</a>&nbsp;&nbsp;
        <a th:href="@{/rce/exec?cmd=whoami}">RCE</a>&nbsp;&nbsp;
        <a th:href="@{/ooxml/upload}">ooxml XXE</a>&nbsp;&nbsp;
        <a th:href="@{/xlsx-streamer/upload}">xlsx-streamer XXE</a>
    </p>
    <p>...</p>
    <a th:href="@{/logout}">logout</a>

</body>
</html>