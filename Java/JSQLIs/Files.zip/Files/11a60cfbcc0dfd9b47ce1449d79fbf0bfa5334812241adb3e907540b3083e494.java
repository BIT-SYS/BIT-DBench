INVOKEVIRTUAL\ testcode/sqli/MySqlWrapper.executeQuery\:(Ljava/lang/String;)Ljava/sql/ResultSet; = 0; SQL_INJECTION
