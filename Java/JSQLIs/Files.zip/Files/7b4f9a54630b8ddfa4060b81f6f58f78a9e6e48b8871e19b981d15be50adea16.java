package android.content;

public abstract class ContentResolver {
}
