package org.owasp.esapi.codecs;

public abstract class Codec {
}
