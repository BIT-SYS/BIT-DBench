
spring.datasource.url=jdbc:mysql://localhost:3306/java_sec_code?AllowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=woshishujukumima
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
mybatis.mapper-locations=classpath:mapper/*.xml

# Spring Boot Actuator Vulnerable Config
management.security.enabled=false
# logging.config=classpath:logback-online.xml

# 业务的callback参数，不支持多个
joychou.business.callback = callback_

### check referer configuration begins ###
joychou.security.referer.enabled = false
joychou.security.referer.host = joychou.org, joychou.com
# Only support ant url style.
joychou.security.referer.uri = /jsonp/**
### check referer configuration ends ###


### csrf configuration begins ###
# csrf token check
joychou.security.csrf.enabled = true
# URI without CSRF check (only support ANT url format)
joychou.security.csrf.exclude.url = /xxe/**, /fastjson/**, /xstream/**
# method for CSRF check
joychou.security.csrf.method = POST
### csrf configuration ends ###


### jsonp configuration begins ###  # auto convert json to jsonp
# referer check
joychou.security.jsonp.referer.check.enabled = true
joychou.security.jsonp.referer.host = joychou.org, joychou.com
joychou.security.jsonp.callback = callback, _callback
### jsonp configuration ends ###