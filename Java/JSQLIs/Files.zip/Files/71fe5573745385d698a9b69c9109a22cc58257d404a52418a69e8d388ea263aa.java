<?xml version="1.0" encoding="UTF-8"?>
<domain-models xmlns="http://axelor.com/xml/ns/domain-models"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://axelor.com/xml/ns/domain-models http://axelor.com/xml/ns/domain-models/domain-models_4.0.xsd">

  <module name="base" package="com.axelor.apps.base.db"/>

  <entity name="Year" lang="java" cachable="true">
  
    <date name="reportedBalanceDate" title="Reported balance Date"/>
<!--     <one-to-many name="reportedBalanceLineList" ref="com.axelor.apps.account.db.ReportedBalanceLine" mappedBy="year" title="Reported balace lines"/> -->
  
  </entity>

</domain-models>
