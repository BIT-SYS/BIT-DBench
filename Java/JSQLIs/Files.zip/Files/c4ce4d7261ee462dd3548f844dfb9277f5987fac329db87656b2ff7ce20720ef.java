{
  "framework": "orion",
  "tests": [
    {
      "default": {
        "json_url": "/json",
        "plaintext_url": "/plaintext",
        "db_url": "/db",
        "query_url": "/queries?queries=",
        "fortune_url": "/fortunes",
        "update_url": "/updates?queries=",
        "port": 8080,
        "approach": "Realistic",
        "classification": "Micro",
        "database": "postgres",
        "framework": "orion",
        "language": "Crystal",
        "flavor": "None",
        "orm": "Micro",
        "platform": "None",
        "webserver": "None",
        "os": "Linux",
        "database_os": "Linux",
        "display_name": "orion",
        "notes": "",
        "versus": "None"
      }
    }
  ]
}
