Manifest-Version: 1.0

