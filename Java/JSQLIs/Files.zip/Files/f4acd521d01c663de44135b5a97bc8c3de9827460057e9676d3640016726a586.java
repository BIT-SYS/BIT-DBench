package org.apache.turbine.util.db.pool;

public class DBConnection {
}
