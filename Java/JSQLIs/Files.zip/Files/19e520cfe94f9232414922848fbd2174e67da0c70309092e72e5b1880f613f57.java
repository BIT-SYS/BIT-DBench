<!--  SyntaxHighlighter resources:  should be included at end of body -->
<link rel="stylesheet" type="text/css" href="./style/sh-3.0.83/shCore.css"/>
<link rel="stylesheet" type="text/css" href="./style/sh-3.0.83/shThemeRDark.css"/>
<script language="javascript" src="./js/sh-3.0.83/shCore.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushBash.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushCss.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushDiff.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushGroovy.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushJava.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushJScript.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushPlain.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushPython.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushRuby.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushScala.js"></script>
<script language="javascript" src="./js/sh-3.0.83/shBrushXml.js"></script>
<script language="javascript" src="./js/shBrushBdd.js"></script>
<script type="text/javascript">
    SyntaxHighlighter.defaults['gutter'] = false;
    SyntaxHighlighter.defaults['toolbar'] = false;    
    SyntaxHighlighter.all();
</script>
<script style="text/javascript">
        var linksCount = document.getElementsByTagName("div").length;
        for (var i= 0; i < linksCount; i++) {
            var val = document.getElementsByTagName("div")[i];
            if(val.className === "property") {
                function replacer(str) {
                    return "<a href=" + str  + ">" + str + "</a";
                }
                document.getElementsByTagName("div")[i].innerHTML = val.innerHTML.replace(/http:\/\/.*/, replacer);
            }
        }
</script>
