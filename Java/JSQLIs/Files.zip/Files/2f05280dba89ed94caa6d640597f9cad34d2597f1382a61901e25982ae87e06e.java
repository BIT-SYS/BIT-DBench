package android.database.sqlite;

//import android.os.ParcelFileDescriptor;

public final class SQLiteStatement
        extends SQLiteProgram
{
    SQLiteStatement()
    {
        throw new RuntimeException("Stub!");
    }

    public void execute()
    {
        throw new RuntimeException("Stub!");
    }

    public int executeUpdateDelete()
    {
        throw new RuntimeException("Stub!");
    }

    public long executeInsert()
    {
        throw new RuntimeException("Stub!");
    }

    public long simpleQueryForLong()
    {
        throw new RuntimeException("Stub!");
    }

    public String simpleQueryForString()
    {
        throw new RuntimeException("Stub!");
    }

//    public ParcelFileDescriptor simpleQueryForBlobFileDescriptor()
//    {
//        throw new RuntimeException("Stub!");
//    }

    public String toString()
    {
        throw new RuntimeException("Stub!");
    }
}
