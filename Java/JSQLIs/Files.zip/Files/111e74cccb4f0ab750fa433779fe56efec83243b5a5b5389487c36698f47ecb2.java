<?xml version="1.0" encoding="UTF-8"?>
<domain-models xmlns="http://axelor.com/xml/ns/domain-models" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://axelor.com/xml/ns/domain-models http://axelor.com/xml/ns/domain-models/domain-models_4.0.xsd">
  
  <module name="account" package="com.axelor.apps.account.db"/>
  
  <entity sequential="true" name="Reconcile" lang="java">
  
    <decimal name="amount" title="Amount reconciled" default="0.0" initParam="true"/>
    <many-to-one name="debitMoveLine" ref="MoveLine" title="Debit line" required="true" initParam="true"/>
    <many-to-one name="creditMoveLine" ref="MoveLine" title="Credit line" required="true" initParam="true"/>
    <integer name="statusSelect" title="Status" default="1" readonly="true" selection="account.reconcile.status.select" initParam="true"/>
    
    <!--  Will be fully reconciled if the payment amount is with a range of +/-20 cts compare to the amount remaining to pay  -->
    <boolean name="canBeZeroBalanceOk" title="Clear remaining amount" default="false" initParam="true"/>
    
    <!--  Will be fully reconciled if there is a currency delta amount -->
    <boolean name="mustBeZeroBalanceOk" title="Must be solded out" default="false"/>
    
    <finder-method name="findByMoveLines" using="debitMoveLine,creditMoveLine"/>
    
     <extra-code><![CDATA[
	
	   	// STATUS SELECT
		public static final int STATUS_DRAFT = 1;
		public static final int STATUS_CONFIRMED = 2;
		public static final int STATUS_CANCELED = 3;
	
	]]></extra-code>
    
  </entity>

</domain-models>
