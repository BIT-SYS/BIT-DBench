## Resources

Website : http://h3xstream.github.com/find-sec-bugs/

Build status : http://travis-ci.org/#!/h3xstream/find-sec-bugs [![Build Status](https://secure.travis-ci.org/h3xstream/find-sec-bugs.png?branch=master)](http://travis-ci.org/h3xstream/find-sec-bugs)

## License

This software is release under [LGPL](http://www.gnu.org/licenses/lgpl.html).
