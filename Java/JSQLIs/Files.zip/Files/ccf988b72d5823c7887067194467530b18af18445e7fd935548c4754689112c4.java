package android.content;

public class OperationApplicationException extends Exception {
}
