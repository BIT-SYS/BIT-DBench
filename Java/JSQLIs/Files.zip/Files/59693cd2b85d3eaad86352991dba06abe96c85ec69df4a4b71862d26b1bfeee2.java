<?xml version="1.0" encoding="UTF-8"?>
<component name="LanguageInjectionConfiguration">
  <injection language="Groovy" injector-id="java">
    <display-name>GroovyShell (groovy.lang)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "java.lang.String").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "java.lang.String", "java.lang.String").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("parse").withParameters("java.lang.String").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("parse").withParameters("java.lang.String", "java.lang.String").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("run").withParameters("java.lang.String", "java.lang.String", "java.lang.String[]").definedInClass("groovy.lang.GroovyShell"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("run").withParameters("java.lang.String", "java.lang.String", "java.util.List").definedInClass("groovy.lang.GroovyShell"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>BatchSqlUpdate (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("BatchSqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.BatchSqlUpdate"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("BatchSqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String", "int[]").definedInClass("org.springframework.jdbc.object.BatchSqlUpdate"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("BatchSqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String", "int[]", "int").definedInClass("org.springframework.jdbc.object.BatchSqlUpdate"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>Connection (java.sql)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("nativeSQL").withParameters("java.lang.String").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareCall").withParameters("java.lang.String").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareCall").withParameters("java.lang.String", "int", "int").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareCall").withParameters("java.lang.String", "int", "int", "int").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String", "int").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String", "int", "int").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String", "int", "int", "int").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String", "int[]").definedInClass("java.sql.Connection"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("prepareStatement").withParameters("java.lang.String", "java.lang.String[]").definedInClass("java.sql.Connection"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>EntityManager.createNativeQuery (javax.persistence)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createNativeQuery").withParameters("java.lang.String").definedInClass("javax.persistence.EntityManager"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createNativeQuery").withParameters("java.lang.String", "java.lang.Class").definedInClass("javax.persistence.EntityManager"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createNativeQuery").withParameters("java.lang.String", "java.lang.String").definedInClass("javax.persistence.EntityManager"))]]></place>
  </injection>
  <injection language="JPAQL" injector-id="java">
    <display-name>EntityManager.createQuery (javax.persistence)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createQuery").withParameters("java.lang.String").definedInClass("javax.persistence.EntityManager"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createQuery").withParameters("java.lang.String", "java.lang.Class").definedInClass("javax.persistence.EntityManager"))]]></place>
  </injection>
  <injection language="HQL" injector-id="java">
    <display-name>HibernateOperations (org.springframework.orm.hibernate)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String").definedInClass("org.springframework.orm.hibernate.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object", "net.sf.hibernate.type.Type").definedInClass("org.springframework.orm.hibernate.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.orm.hibernate.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object[]", "net.sf.hibernate.type.Type[]").definedInClass("org.springframework.orm.hibernate.HibernateOperations"))]]></place>
  </injection>
  <injection language="HQL" injector-id="java">
    <display-name>HibernateOperations (org.springframework.orm.hibernate3)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("bulkUpdate").withParameters("java.lang.String").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("bulkUpdate").withParameters("java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("bulkUpdate").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("findByNamedParam").withParameters("java.lang.String", "java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("findByNamedParam").withParameters("java.lang.String", "java.lang.String[]", "java.lang.Object[]").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("findByValueBean").withParameters("java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("iterate").withParameters("java.lang.String").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("iterate").withParameters("java.lang.String", "java.lang.Object").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("iterate").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.orm.hibernate3.HibernateOperations"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>JdbcOperations (org.springframework.jdbc.core)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String", "org.springframework.jdbc.core.BatchPreparedStatementSetter").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "org.springframework.jdbc.core.CallableStatementCallback").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "org.springframework.jdbc.core.PreparedStatementCallback").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "org.springframework.jdbc.core.ResultSetExtractor").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "org.springframework.jdbc.core.RowCallbackHandler").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "org.springframework.jdbc.core.ResultSetExtractor").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "org.springframework.jdbc.core.RowCallbackHandler").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "java.lang.Object[]", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.PreparedStatementSetter", "org.springframework.jdbc.core.ResultSetExtractor").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.PreparedStatementSetter", "org.springframework.jdbc.core.RowCallbackHandler").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.PreparedStatementSetter", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.ResultSetExtractor").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.RowCallbackHandler").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Object[]", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Object[]", "int[]", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Object[]", "java.lang.Class").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Object[]", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForRowSet").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForRowSet").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForRowSet").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "java.lang.Object[]", "int[]").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "org.springframework.jdbc.core.PreparedStatementSetter").definedInClass("org.springframework.jdbc.core.JdbcOperations"))]]></place>
  </injection>
  <injection language="JPAQL" injector-id="java">
    <display-name>JpaOperations (org.springframework.orm.jpa)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String").definedInClass("org.springframework.orm.jpa.JpaOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("find").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.orm.jpa.JpaOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("findByNamedParams").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.orm.jpa.JpaOperations"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>MappingSqlQuery.MappingSqlQuery (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("MappingSqlQuery").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.MappingSqlQuery"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>MappingSqlQueryWithParameters.MappingSqlQueryWithParameters (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("MappingSqlQueryWithParameters").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.MappingSqlQueryWithParameters"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>NamedNativeQuery.query (javax.persistence)</display-name>
    <place><![CDATA[psiMethod().withName("query").withParameters().definedInClass("javax.persistence.NamedNativeQuery")]]></place>
  </injection>
  <injection language="JPAQL" injector-id="java">
    <display-name>NamedQuery.query (javax.persistence)</display-name>
    <place><![CDATA[psiMethod().withName("query").withParameters().definedInClass("javax.persistence.NamedQuery")]]></place>
  </injection>
  <injection language="XPath" injector-id="java">
    <display-name>Node.createXPath (org.dom4j)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createXPath").withParameters("java.lang.String").definedInClass("org.dom4j.Node"))]]></place>
  </injection>
  <injection language="XPath" injector-id="java">
    <display-name>Node.selectNodes (org.dom4j)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("selectNodes").withParameters("java.lang.String").definedInClass("org.dom4j.Node"))]]></place>
  </injection>
  <injection language="XPath" injector-id="java">
    <display-name>Node.selectSingleNode (org.dom4j)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("selectSingleNode").withParameters("java.lang.String").definedInClass("org.dom4j.Node"))]]></place>
  </injection>
  <injection language="RegExp" injector-id="java">
    <display-name>Path.value (javax.ws.rs)</display-name>
    <value-pattern>[^:]*:[\s]*([^\}]*)</value-pattern>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("value").withParameters().definedInClass("javax.ws.rs.Path"))]]></place>
  </injection>
  <injection language="RegExp" injector-id="java">
    <display-name>Pattern (java.util.regex)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("compile").withParameters("java.lang.String").definedInClass("java.util.regex.Pattern"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("compile").withParameters("java.lang.String", "int").definedInClass("java.util.regex.Pattern"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("matches").withParameters("java.lang.String", "java.lang.CharSequence").definedInClass("java.util.regex.Pattern"))]]></place>
  </injection>
  <injection language="RegExp" injector-id="java">
    <display-name>Pattern.regexp (javax.validation.constraints)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("regexp").withParameters().definedInClass("javax.validation.constraints.Pattern"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>RdbmsOperation.setSql (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("setSql").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.object.RdbmsOperation"))]]></place>
  </injection>
  <injection language="HQL" injector-id="java">
    <display-name>Session.createQuery (org.hibernate)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createQuery").withParameters("java.lang.String").definedInClass("org.hibernate.Session"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>Session.createSQLQuery (org.hibernate)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("createSQLQuery").withParameters("java.lang.String").definedInClass("org.hibernate.Session"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SimpleJdbcOperations (org.springframework.jdbc.core.simple)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String", "java.util.List").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String", "java.util.List", "int[]").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String", "java.util.Map[]").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("batchUpdate").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource[]").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("query").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForInt").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForList").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForLong").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForMap").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Class", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Class", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "java.lang.Class", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.RowMapper", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("queryForObject").withParameters("java.lang.String", "org.springframework.jdbc.core.simple.ParameterizedRowMapper", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "java.lang.Object...").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("update").withParameters("java.lang.String", "org.springframework.jdbc.core.namedparam.SqlParameterSource").definedInClass("org.springframework.jdbc.core.simple.SimpleJdbcOperations"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlCall.SqlCall (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlCall").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.SqlCall"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlFunction (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String", "int[]").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String", "int[]", "java.lang.Class").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlFunction.SqlFunction (org.springframework.jdbc.object)</display-name>
    <place disabled="true"><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
    <place disabled="true"><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String", "int[]").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlFunction").withParameters("javax.sql.DataSource", "java.lang.String", "int[]", "java.lang.Class").definedInClass("org.springframework.jdbc.object.SqlFunction"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlOperation.newPreparedStatementCreator (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("newPreparedStatementCreator").withParameters("java.lang.String", "java.lang.Object[]").definedInClass("org.springframework.jdbc.object.SqlOperation"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlQuery (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String").definedInClass("org.springframework.jdbc.object.SqlQuery"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "java.util.Map").definedInClass("org.springframework.jdbc.object.SqlQuery"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlQuery").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.SqlQuery"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>SqlUpdate (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.SqlUpdate"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String", "int[]").definedInClass("org.springframework.jdbc.object.SqlUpdate"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("SqlUpdate").withParameters("javax.sql.DataSource", "java.lang.String", "int[]", "int").definedInClass("org.springframework.jdbc.object.SqlUpdate"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>Statement (java.sql)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("addBatch").withParameters("java.lang.String").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "int").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "int[]").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("execute").withParameters("java.lang.String", "java.lang.String[]").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("executeQuery").withParameters("java.lang.String").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("executeUpdate").withParameters("java.lang.String").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("executeUpdate").withParameters("java.lang.String", "int").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("executeUpdate").withParameters("java.lang.String", "int[]").definedInClass("java.sql.Statement"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("executeUpdate").withParameters("java.lang.String", "java.lang.String[]").definedInClass("java.sql.Statement"))]]></place>
  </injection>
  <injection language="RegExp" injector-id="java">
    <display-name>String (java.lang)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("replaceAll").withParameters("java.lang.String", "java.lang.String").definedInClass("java.lang.String"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("replaceFirst").withParameters("java.lang.String", "java.lang.String").definedInClass("java.lang.String"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("split").withParameters("java.lang.String").definedInClass("java.lang.String"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("split").withParameters("java.lang.String", "int").definedInClass("java.lang.String"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("matches").withParameters("java.lang.String").definedInClass("java.lang.String"))]]></place>
  </injection>
  <injection language="SQL" injector-id="java">
    <display-name>UpdatableSqlQuery.UpdatableSqlQuery (org.springframework.jdbc.object)</display-name>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("UpdatableSqlQuery").withParameters("javax.sql.DataSource", "java.lang.String").definedInClass("org.springframework.jdbc.object.UpdatableSqlQuery"))]]></place>
  </injection>
  <injection language="XPath" injector-id="java">
    <display-name>XPath (javax.xml.xpath)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("compile").withParameters("java.lang.String").definedInClass("javax.xml.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "java.lang.Object").definedInClass("javax.xml.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "java.lang.Object", "javax.xml.namespace.QName").definedInClass("javax.xml.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "org.xml.sax.InputSource").definedInClass("javax.xml.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("evaluate").withParameters("java.lang.String", "org.xml.sax.InputSource", "javax.xml.namespace.QName").definedInClass("javax.xml.xpath.XPath"))]]></place>
  </injection>
  <injection language="XPath" injector-id="java">
    <display-name>XPath (org.jdom.xpath)</display-name>
    <place><![CDATA[psiParameter().ofMethod(0, psiMethod().withName("newInstance").withParameters("java.lang.String").definedInClass("org.jdom.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("selectNodes").withParameters("java.lang.Object", "java.lang.String").definedInClass("org.jdom.xpath.XPath"))]]></place>
    <place><![CDATA[psiParameter().ofMethod(1, psiMethod().withName("selectSingleNode").withParameters("java.lang.Object", "java.lang.String").definedInClass("org.jdom.xpath.XPath"))]]></place>
  </injection>
</component>
