<?xml version="1.0" encoding="UTF-8"?>

<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-build</artifactId>
        <version>3.1.1</version>
        <relativePath/>
    </parent>

    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-alibaba</artifactId>
    <version>${revision}</version>
    <packaging>pom</packaging>
    <name>Spring Cloud Alibaba</name>
    <description>Spring Cloud Alibaba</description>
    <url>https://github.com/alibaba/spring-cloud-alibaba</url>

    <licenses>
        <license>
            <name>Apache License, Version 2.0</name>
            <url>https://www.apache.org/licenses/LICENSE-2.0.txt</url>
            <distribution>repo</distribution>
        </license>
    </licenses>

    <scm>
        <url>https://github.com/alibaba/spring-cloud-alibaba</url>
        <connection>
            scm:git:git://github.com/alibaba/spring-cloud-alibaba.git
        </connection>
        <developerConnection>
            scm:git:ssh://git@github.com/alibaba/spring-cloud-alibaba.git
        </developerConnection>
        <tag>HEAD</tag>
    </scm>

    <developers>
        <developer>
            <name>xiaojing</name>
            <email>flystar32@163.com</email>
        </developer>
        <developer>
            <name>Jim Fang</name>
            <email>fangjian0423@gmail.com</email>
            <organization>Alibaba</organization>
            <url>https://github.com/fangjian0423</url>
        </developer>
        <developer>
            <name>xiaolongzuo</name>
            <email>150349407@qq.com</email>
        </developer>
        <developer>
            <name>hengyunabc</name>
            <email>hengyunabc@gmail.com</email>
        </developer>
        <developer>
            <id>mercyblitz</id>
            <name>Mercy Ma</name>
            <email>mercyblitz@gmail.com</email>
            <organization>Alibaba</organization>
            <url>https://github.com/mercyblitz</url>
        </developer>
        <developer>
            <name>yunzheng</name>
            <email>yunzheng1228@gmail.com</email>
        </developer>
        <developer>
            <id>theonefx</id>
            <name>theonefx</name>
            <email>chenxilzx1@gmail.com</email>
            <organization>Alibaba</organization>
            <url>https://github.com/theonefx</url>
        </developer>
    </developers>

    <properties>
        <!-- Project revision -->
        <revision>2021.0.1.1-SNAPSHOT</revision>

        <!-- Spring Cloud -->
        <spring.cloud.version>2021.0.1</spring.cloud.version>

        <!-- Apache Dubbo -->
        <dubbo.version>2.7.15</dubbo.version>
        <curator.version>4.0.1</curator.version>

        <!-- Apache RocketMQ -->
        <rocketmq.version>4.9.2</rocketmq.version>

        <!-- Maven Plugin Versions -->
        <maven-compiler-plugin.version>3.8.1</maven-compiler-plugin.version>
        <maven-deploy-plugin.version>2.8.2</maven-deploy-plugin.version>
        <!-- JUnit 5 requires Surefire version 2.22.0 or higher -->
        <maven-surefire-plugin.version>2.22.2</maven-surefire-plugin.version>
        <maven-source-plugin.version>3.2.1</maven-source-plugin.version>
        <maven-javadoc-plugin.version>3.1.1</maven-javadoc-plugin.version>
        <maven-gpg-plugin.version>3.0.1</maven-gpg-plugin.version>
        <flatten-maven-plugin.version>1.2.7</flatten-maven-plugin.version>
        <gmavenplus-plugin.version>1.6</gmavenplus-plugin.version>
        <jacoco.version>0.8.5</jacoco.version>
    </properties>

    <modules>
        <module>spring-cloud-alibaba-dependencies</module>
        <module>spring-cloud-alibaba-examples</module>
        <module>spring-cloud-alibaba-docs</module>
        <module>spring-cloud-alibaba-starters</module>
        <module>spring-cloud-alibaba-coverage</module>
        <module>spring-cloud-alibaba-tests</module>
    </modules>

    <dependencyManagement>
        <dependencies>

            <!-- Spring Dependencies -->
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-dependencies</artifactId>
                <version>${spring-boot.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>

            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>${spring.cloud.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>

            <dependency>
                <groupId>com.alibaba.cloud</groupId>
                <artifactId>spring-cloud-alibaba-dependencies</artifactId>
                <version>${project.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>

            <!-- Dubbo Dependencies -->
            <dependency>
                <groupId>org.apache.dubbo</groupId>
                <artifactId>dubbo-dependencies-bom</artifactId>
                <version>${dubbo.version}</version>
                <type>pom</type>
                <scope>import</scope>
                <exclusions>
                    <exclusion>
                        <groupId>org.springframework</groupId>
                        <artifactId>spring-framework-bom</artifactId>
                    </exclusion>
                </exclusions>
            </dependency>

            <dependency>
                <groupId>org.apache.dubbo</groupId>
                <artifactId>dubbo-spring-boot-starter</artifactId>
                <version>${dubbo.version}</version>
            </dependency>

            <dependency>
                <groupId>org.apache.dubbo</groupId>
                <artifactId>dubbo-spring-boot-actuator</artifactId>
                <version>${dubbo.version}</version>
            </dependency>

            <dependency>
                <groupId>org.apache.dubbo</groupId>
                <artifactId>dubbo</artifactId>
                <version>${dubbo.version}</version>
                <exclusions>
                    <exclusion>
                        <groupId>org.springframework</groupId>
                        <artifactId>spring-context</artifactId>
                    </exclusion>
                </exclusions>
            </dependency>

            <dependency>
                <groupId>org.apache.rocketmq</groupId>
                <artifactId>rocketmq-client</artifactId>
                <version>${rocketmq.version}</version>
            </dependency>
            <dependency>
                <groupId>org.apache.rocketmq</groupId>
                <artifactId>rocketmq-acl</artifactId>
                <version>${rocketmq.version}</version>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <build>
        <pluginManagement>
            <plugins>
                <plugin>
                    <groupId>org.jacoco</groupId>
                    <artifactId>jacoco-maven-plugin</artifactId>
                    <version>${jacoco.version}</version>
                </plugin>

                <!-- disable auto format from parent -->
                <plugin>
                    <groupId>io.spring.javaformat</groupId>
                    <artifactId>spring-javaformat-maven-plugin</artifactId>
                    <version>${spring-javaformat.version}</version>
                    <executions>
                        <execution>
                            <phase>validate</phase>
                            <configuration>
                                <skip>true</skip>
                            </configuration>
                        </execution>
                    </executions>
                </plugin>
            </plugins>
        </pluginManagement>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-eclipse-plugin</artifactId>
                <configuration>
                    <useProjectReferences>false</useProjectReferences>
                    <additionalConfig>
                        <file>
                            <name>.settings/org.eclipse.jdt.ui.prefs</name>
                            <location>
                                ${maven.multiModuleProjectDirectory}/eclipse/org.eclipse.jdt.ui.prefs
                            </location>
                        </file>
                        <file>
                            <name>.settings/org.eclipse.jdt.core.prefs</name>
                            <location>
                                ${maven.multiModuleProjectDirectory}/eclipse/org.eclipse.jdt.core.prefs
                            </location>
                        </file>
                    </additionalConfig>
                </configuration>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-checkstyle-plugin</artifactId>
                <executions>
                    <execution>
                        <id>checkstyle-validation</id>
                        <phase>validate</phase>
                        <goals>
                            <goal>check</goal>
                        </goals>
                        <configuration>
                            <!-- Checkstyle rules inherited from spring-cloud-build -->
                            <suppressionsLocation>${session.executionRootDirectory}/eclipse/checkstyle-suppressions.xml</suppressionsLocation>
                            <includeTestSourceDirectory>true</includeTestSourceDirectory>
                            <consoleOutput>true</consoleOutput>
                            <failsOnError>true</failsOnError>
                            <failOnViolation>true</failOnViolation>
                            <violationSeverity>warning</violationSeverity>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>${maven-compiler-plugin.version}</version>
                <inherited>true</inherited>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                </configuration>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-surefire-plugin</artifactId>
                <version>${maven-surefire-plugin.version}</version>
                <inherited>true</inherited>
                <configuration>
                    <forkCount>1</forkCount>
                    <reuseForks>false</reuseForks>
                </configuration>
            </plugin>
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>flatten-maven-plugin</artifactId>
                <version>${flatten-maven-plugin.version}</version>
                <configuration>
                    <updatePomFile>true</updatePomFile>
                    <flattenMode>resolveCiFriendliesOnly</flattenMode>
                </configuration>
                <executions>
                    <execution>
                        <id>flatten</id>
                        <phase>process-resources</phase>
                        <goals>
                            <goal>flatten</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>flatten.clean</id>
                        <phase>clean</phase>
                        <goals>
                            <goal>clean</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>

    <reporting>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-checkstyle-plugin</artifactId>
            </plugin>
        </plugins>
    </reporting>

    <profiles>
        <profile>
            <id>release</id>
            <build>
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-source-plugin</artifactId>
                        <version>${maven-source-plugin.version}</version>
                        <executions>
                            <execution>
                                <phase>package</phase>
                                <goals>
                                    <goal>jar-no-fork</goal>
                                </goals>
                            </execution>
                        </executions>
                    </plugin>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-javadoc-plugin</artifactId>
                        <version>${maven-javadoc-plugin.version}</version>
                        <executions>
                            <execution>
                                <phase>package</phase>
                                <goals>
                                    <goal>jar</goal>
                                </goals>
                            </execution>
                        </executions>
                    </plugin>

                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-gpg-plugin</artifactId>
                        <version>${maven-gpg-plugin.version}</version>
                        <executions>
                            <execution>
                                <phase>verify</phase>
                                <goals>
                                    <goal>sign</goal>
                                </goals>
                            </execution>
                        </executions>
                    </plugin>
                </plugins>
            </build>

            <distributionManagement>
                <snapshotRepository>
                    <id>sonatype-nexus-snapshots</id>
                    <name>Sonatype Nexus Snapshots</name>
                    <url>https://oss.sonatype.org/content/repositories/snapshots/</url>
                </snapshotRepository>
                <repository>
                    <id>sonatype-nexus-staging</id>
                    <name>Nexus Release Repository</name>
                    <url>https://oss.sonatype.org/service/local/staging/deploy/maven2/</url>
                </repository>
            </distributionManagement>
        </profile>
    </profiles>

</project>
