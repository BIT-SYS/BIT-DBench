<div class="line line-small">
  <span class="coding-rules-detail-status">{{default language manualRuleLabel}}</span>

  {{#if allTags}}
    &nbsp;&nbsp;
    <span class="coding-rules-list-tags">
      <i class="icon-tags"></i>
      <span>{{join allTags ', '}}</span>
    </span>
  {{/if}}

  {{#notEq status 'READY'}}
    <div class="line-right">
      <span class="coding-rules-detail-not-ready">{{status}}</span>
    </div>
  {{/notEq}}
</div>

<div class="line" title="{{name}}" name="{{key}}">{{name}}</div>
