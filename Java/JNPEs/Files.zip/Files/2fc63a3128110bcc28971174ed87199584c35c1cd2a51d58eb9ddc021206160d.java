<?xml version="1.0" encoding="UTF-8" ?>
<configuration>

  <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
      <pattern>
        %d{HH:mm:ss.SSS} %-5level %logger{20} %X - %msg%n
      </pattern>
    </encoder>
  </appender>

  <logger name="rails">
    <level value="DEBUG"/>
  </logger>

  <logger name="org.hibernate.cache.ReadWriteCache">
    <!-- removing "An item was expired by the cache while it was locked (increase your cache timeout)" msg -->
    <level value="ERROR"/>
  </logger>
  <logger name="org.hibernate">
    <level value="WARN"/>
  </logger>

  <!-- Display SQL requests and results by setting the following loggers to level DEBUG -->
  <logger name="org.hibernate.SQL">
    <level value="WARN"/>
  </logger>
  <logger name="org.apache.ibatis">
    <level value="DEBUG"/>
  </logger>
  <logger name="java.sql">
    <level value="DEBUG"/>
  </logger>
  <logger name="java.sql.ResultSet">
    <level value="WARN"/>
  </logger>

  <root>
    <level value="INFO"/>
    <appender-ref ref="STDOUT"/>
  </root>

</configuration>
