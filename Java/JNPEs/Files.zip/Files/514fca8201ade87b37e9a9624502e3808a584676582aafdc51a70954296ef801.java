package test.reflective;


@ReflectiveUse("remove all public methods")
public class IgnorePublicReflecto {
    public void reflecto() {
    }
    
    private void ignore() { 
    }
}