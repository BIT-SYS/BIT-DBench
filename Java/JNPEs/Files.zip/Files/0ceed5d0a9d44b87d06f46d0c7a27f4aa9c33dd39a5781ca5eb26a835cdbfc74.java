-- Oozie 4.2.0 release (trunk - unreleased)

OOZIE-1653 Support ALL to allowed error code of the user retry (seoeun25 via rkanter)
OOZIE-1923 ZKLocksService locks are not re-entrant like MemoryLocks (puru)
OOZIE-1843 Bulk update for coord last modified time for CoordMaterializeTriggerService (puru)
OOZIE-1941 Bundle coordinator name can't be parameterized (puru)
OOZIE-1966 Fix Headers in java code (shwethags via rkanter)
OOZIE-1428 The delay time for requeue should be configurable (sree2k via rkanter)
OOZIE-1830 Change hadoop-1 profile to use 1.2.1 (seoeun25 via rkanter)
OOZIE-1677 Add Oozie servers to instrumentation info (rkanter)
OOZIE-1968 Building modules independently (shwethags)
OOZIE-1939 Incorrect job information is set while logging (seoeun25 via shwethags)
OOZIE-1846 Convert CoordActionMaterializeCommand to an XCommand and remove Command (seoeun25 via shwethags)
OOZIE-1943 Bump up trunk to 4.2.0-SNAPSHOT (bzhang)

-- Oozie 4.1.0 release (4.1 - unreleased)

OOZIE-1945 NPE in JaveActionExecutor#check() (sree2k via rkanter)
OOZIE-1984 SLACalculator in HA mode performs duplicate operations on records with completed jobs (mona)
OOZIE-1958 address duplication of env variables in oozie.launcher.yarn.app.mapreduce.am.env when running with uber mode (ryota)
OOZIE-1920 Capture Output for SSH Action doesn't work (Richard Williams via rkanter)
OOZIE-1961 Remove requireJavaVersion from enforcer rules (lars_francke via rkanter)
OOZIE-1883 hostnameFilter has invalid url-pattern (dvillegas via rkanter)
OOZIE-1811 Current test failures in trunk (mona)
OOZIE-1930 oozie coordinator "-info desc" returns earliest instead of latest actions when specifying "len" after oozie-1532 (bzhang)
OOZIE-1944 Recursive variable resolution broken when same parameter name in config-default and action conf (mona)
OOZIE-1906 Service to periodically remove ZK lock (puru via rohini)
OOZIE-1812 Bulk API with bundle Id should relax regex check for Id (puru via rohini)
OOZIE-1915 Move system properties to conf properties (puru via rohini)
OOZIE-1934 coordinator action repeatedly picked up by cachePurgeWorker of PartitionDependencyManagerService (ryota)
OOZIE-1925 upgrade tomcat to 6.0.41 (rkanter via shwethags)
OOZIE-1933 SLACalculatorMemory HA changes assume SLARegistrationBean exists for all jobs (mona)
OOZIE-1935 Log level (ActionStartXCommand) and Doc fix (CoordinatorFunctionalSpec) (mona)
OOZIE-1586 upgrade oozie to hive 13.1 (including hcatalog) (raviprak via rkanter)
OOZIE-1932 Services should load CallableQueueService after MemoryLocksService (mona)
OOZIE-1740 Add a new function hadoop:conf() that can be invoked from the workflow.xml and will return a hadoop configuration option (sam liu via rkanter)
OOZIE-1911 SLA calculation in HA mode does wrong bit comparison for 'start' and 'duration' (mona)
OOZIE-1926 make gz blob compression as default (ryota)
OOZIE-1916 Use Curator leader latch instead of checking the order of Oozie servers (rkanter)
OOZIE-1886 Queue operation talking longer time (shwethags via rohini)
OOZIE-1865 Oozie servers can't talk to each other with Oozie HA and Kerberos (rkanter)
OOZIE-1821 Oozie java action fails due to AlreadyBeingCreatedException (abhishek.agarwal via rkanter)
OOZIE-1532 Purging should remove completed children job for long running coordinator jobs (bzhang)
OOZIE-1909 log prefix information missing in JavaActionExecutor.check (ryota)
OOZIE-1907 DB upgrade from 3.3.0 to trunk fails on derby (rkanter)
OOZIE-1877 Setting to fail oozie server startup in case of sharelib misconfiguration (puru via rohini)
OOZIE-1388 Add a admin servlet to show thread stack trace and CPU usage per thread (rohini)
OOZIE-1893 Recovery service will never recover bundle action if CoordSubmitXCommand command is lost (puru via rohini)
OOZIE-1878 Can't execute dryrun on the CLI (puru via rohini)
OOZIE-1741 Add new coord EL function to get input partitions value string (satish.mittal via rohini) 
OOZIE-1817 Oozie timers are not biased (rkanter)
OOZIE-1807 Make bundle change command synchronous (puru via rohini)
OOZIE-1678 HA support for SLA (ryota)
OOZIE-1685 Oozie doesn’t process correctly workflows with a non-default name node (benjzh via rohini)
OOZIE-1875 Add "NONE" to coordinator job execution_order (bzhang)
OOZIE-1879 Workflow Rerun causes error depending on the order of forked nodes (rkanter)
OOZIE-1659 oozie-site is missing email-action-0.2 schema (jagatsingh via rkanter)
OOZIE-1492 Make sure HA works with HCat (ryota)
OOZIE-1869 Sharelib update shows vip/load balancer address as one of the hostname (puru via ryota)
OOZIE-1861 Pig action should work with tez mode (rohini)
OOZIE-1703 User should be able to set coord end-time before start time (puru via rohini)
OOZIE-1715 Distributed ID sequence for HA (puru via rkanter)
OOZIE-1870 Workflow action doen't resolve retry-max and retry-interval (puru via rohini)
OOZIE-1686 Typo in DG_CommandLineTool (anbu78 via ryota)
OOZIE-1804 Improve documentation for Coordinator Specification (lars_francke via rkanter)
OOZIE-1828 Introduce counters JobStatus terminal states metrics (rkanter)
OOZIE-1724 Make it easier to specify the HCat hive-site.xml for the Oozie Server (rkanter)
OOZIE-1812 Bundle status is always in RUNNING if one of the action status is in PREP (puru via rohini)
OOZIE-1848 Pig actions fail due to missing joda-time jar from pig sharelib (bzhang)
OOZIE-1319 "LAST_ONLY" in execution control for coordinator job still runs all the actions (rkanter)
OOZIE-1862 Add hadoop token file location for Hive/Tez jobs (venkatnrangan via bzhang)
OOZIE-1775 TestEventGeneration.testCoordinatorActionEvent is failing and CoordRerunX should generate event (mona)
OOZIE-1844 HA - Lock mechanism for CoordMaterializeTriggerService (puru via rohini)
OOZIE-1834 sla should-start is supposed to be optional but it is not (rkanter)
OOZIE-1838 jdbc.connections.active sampler does not show up (rkanter)
OOZIE-1801 ZKLocksService instrumentation should say how many locks this server has (rkanter)
OOZIE-1819 Avoid early queueing of CoordActionInputCheckXCommand (shwethags via rohini)
OOZIE-1783 Sharelib purging only occurs at Oozie startup (rkanter)
OOZIE-1689 HA support for OOZIE-7(Ability to view the log information corresponding to particular coordinator action) (puru via mona)
OOZIE-1849 If the underlying job finishes while a Workflow is suspended, Oozie can take a while to realize it (rkanter)
OOZIE-1835 NullPointerException from SLAEmailEventListener (rkanter)
OOZIE-1809 offset and len options are ignored in oozie job -info for workflow (ryota)
OOZIE-1826 Add thread which detects JVM pauses (rkanter)
OOZIE-1791 add IGNORED status to Coordinator Job and Action (ryota)
OOZIE-1825 Optimize wf_jobs protoconf storage (puru via rohini)
OOZIE-1831 Oozie upgrade fails if workflow jobs are in running or suspended state (satish.mittal via rohini)
OOZIE-1690 TestShellActionExecutor#testEnvVar failed for Windows (omaliuvanchuk via rkanter)
OOZIE-1243 libtools dir should not include hadoop JARs (satish.mittal via rohini)
OOZIE-1806 Java Action type jobs are failing with hadoop-0.20.0 and earlier versions on oozie trunk (satish.mittal via rohini)
OOZIE-1823 OozieSharelibCLI shouldn't load ext services (rkanter)
OOZIE-1762 Sharelib with oozie.action.ship.launcher.jar=true should copy oozie-hadoop-utils.jar (puru via mona)
OOZIE-1709 CoordELFunctions.getCurrentInstance() is expensive (shwethags via rohini) 
OOZIE-1787 parameterize interval of SLAService updating SlaStatus (ryota)
OOZIE-1777 duplicated log message in Pig launcher's stdout (ryota)
OOZIE-1748 When using cron-like syntax, the "Time Unit" field says "MINUTE"
OOZIE-1737 Oozie log streaming is slow (puru via rohini)
OOZIE-1794 java-opts and java-opt in the Java action don't always work properly in YARN (rkanter)
OOZIE-1799 Document hcatalog integration steps for Oozie in a secure cluster (venkatnrangan via bzhang)
OOZIE-1585 Upgrade oozie to pig 0.12.1 (bzhang)
OOZIE-1768 Workflow schema 0.4.5 was removed (rkanter)
OOZIE-1621 Add proper error code and error message for sharelib exceptions. (rkanter)
OOZIE-1785 Add oozie email action xsd to OozieCli.java (jagatsingh via rohini)
OOZIE-1527 Fix scalability issues with coordinator materialization (puru via rohini)
OOZIE-1797 Workflow rerun command should use existing workflow properties (puru via rohini)
OOZIE-1769 An option to update coord properties/definition (puru via rohini)
OOZIE-1796 Job status should not transition from KILLED (puru via rohini)
OOZIE-1781 UI - Last Modified time is not displayed for coord action in coord job info grid (puru via mona)
OOZIE-1792 Ability to kill bundle stuck in RUNNING due to inconsistent pending states (rohini)
OOZIE-1703 User should be able to set coord end-time before start time (puru via rohini)
OOZIE-1719 v1/jobs api returns null for parentId even when it exists (ryota)
OOZIE-1773 bulk API returns total = 0 when it's not (ryota)
OOZIE-1774 Expected/Actual Duration on UI SLA Tab doesn't show correct information (ryota)
OOZIE-1754 add order(sort) option and exclude filter for coord job Info (ryota)
OOZIE-1761 Improve sharelib purging logic (puru via rohini)
OOZIE-1725 add coord EL functions to be used in SLA tag (ryota)
OOZIE-1765 JMS Notifications for Workflows not always on the correct topic (rkanter)
OOZIE-1732 Sharelib instrumentation fails if sharelib.system.libpath is not created (ryota)
OOZIE-1692 modify log message when checking completion of child job in Map-Reduce action (ryota)
OOZIE-1734 Oozie returned 500 Internal Server error when user passes invalid request (checha via rkanter)
OOZIE-1593 Oozie HCatCredential provider needs to include hadoop rpc protection to work with encrypted secure clusters (bzhang)
OOZIE-1735 Support resuming of failed coordinator job and rerun of a failed coordinator action (puru via rohini)
OOZIE-1746 New API to fetch workflows corresponding to coordinator action reruns (mona)
OOZIE-1713 Avoid creating dummy input file for each launcher job (puru via rohini)
OOZIE-1701 TestXTestCase#testWaitFor and TestXTestCase#testBaseDir have the errors (omaliuvanchuk via rohini)
OOZIE-1751 Default authentication type using env variable for oozie CLI (puru via rohini)
OOZIE-1753 Update create-release-artifact script for git (rkanter)
OOZIE-1704 Add ability to use Bulk API with bundle ID (mona)
OOZIE-1718 Coord Job Query UPDATE_COORD_JOB_CHANGE does not update last modified time (mona)
OOZIE-1693 UI timeout while loading job table (puru via rohini)
OOZIE-1698 Action sharelib configuration document lacks the "oozie." prefix (qwertymaniac via rohini)
OOZIE-1712 Oozie page does not render in Internet Explorer 9 on Windows (omaliuvanchuk via rohini)
OOZIE-1720 Oozie Hive action doesn't honour mapred.job.name (mithun via rohini)
OOZIE-1543 Minor typo in Hive Action documentation (anbu78 via rkanter)
OOZIE-1650 Whitelisting docs are incorrect (anbu78 via rkanter)
OOZIE-1733 Fix test failures caused by OOZIE-1722 (rkanter)
OOZIE-1223 too many extjs cookies can cause the web UI to stop responding (puru via rkanter)
OOZIE-1722 When an ApplicationMaster restarts, it restarts the launcher job (rkanter)
OOZIE-1727 Upgrade hadoop-minikdc (puru via rkanter)
OOZIE-1711 TestLiteWorkflowAppParser fails against Hadoop 2 (rkanter)
OOZIE-1714 Update Derby driver version to latest (rkanter)
OOZIE-1680 Add a check for a maximum frequency of 5 min on Coord jobs (rkanter)
OOZIE-1699 Some of the commands submitted to Oozie internal queue are never executed (sriksun via virag)
OOZIE-1671 add an option to limit # of coordinator actions for log retrieval (ryota)
OOZIE-1629 EL function in <timeout> is not evaluated properly (ryota)
OOZIE-1618 dryrun should check variable substitution in workflow.xml (bowenzhangusa via rkanter)
OOZIE-1681 Sqoop sharelib has no hsqldb jar version (Ostap via rkanter)
OOZIE-1691 StackOverflowError in TimestampedMessageParser.parseNextLine() (puru via rkanter)
OOZIE-1552 Bring Windows shell script functionality and structure in line with trunk (omaliuvanchuk via rkanter)
OOZIE-1608 Update Curator to 2.4.0 when its available to fix security hole (rkanter)
OOZIE-1687 Bundle can still be in RUNNINGWITHERROR status after bundle kill (rohini)
OOZIE-1684 DB upgrade from 3.3.0 to trunk fails on Oracle (rkanter)
OOZIE-1675 Adding absolute URI of local cluster to dist cache not working with hadoop version 0.20.2 and before (satish via ryota)
OOZIE-1683 UserGroupInformationService should close any filesystems opened by it (rkanter)
OOZIE-1646 HBase Table Copy between two HBase servers doesn't work with Kerberos (rkanter)
OOZIE-1609 HA support for share lib. (puru via rkanter)
OOZIE-1622 Multiple CoordSubmit for same bundle (shwethags via virag)
OOZIE-1644 Default config from config-default.xml is not propagated to actions (mona)
OOZIE-1645 Oozie upgrade DB command fails due to missing dependencies for mssql (omaliuvanchuk via rkanter)
OOZIE-1668 Coord log streaming start and end time should be of action list start and end time (puru via rohini)
OOZIE-1674 DB upgrade from 3.3.0 to trunk fails on postgres (rkanter)
OOZIE-1581 Workflow performance optimizations (mona)
OOZIE-1663 Queuedump to display command type (shwethags via virag)
OOZIE-1672 UI info fetch fails for bundle having large number of coordinators (puru via rohini)
OOZIE-1666 Child job link not working in safari and chrome (puru via ryota)
OOZIE-1658 Add bundle, coord, wf and action related information to launched M/R jobs (puru via rohini)
OOZIE-1664 PollablePriorityDelayQueue.poll() returns elements with +ve delay (shwethags via rohini)
OOZIE-1661 Stream logs in oozie UI (puru via rohini)
OOZIE-1610 UnitTests fail on Windows because of wrong paths (omaliuvanchuk via rohini)
OOZIE-1660 DB connection misconfig causes all or most unit tests to fail (rkanter)
OOZIE-1651 Oozie should mask the signature secret in the configuration output (rkanter)
OOZIE-1655 Change oozie.service.JPAService.validate.db.connection to true (rkanter)
OOZIE-1643 Oozie doesn't parse Hadoop Job Id from the Hive action (rkanter)
OOZIE-1632 Coordinators that undergo change endtime but are doneMaterialization, not getting picked for StatusTransit (mona)
OOZIE-1548 OozieDBCLI changes to convert clob to blob and remove the discriminator column (virag)
OOZIE-1504 Allow specifying a fixed instance as the start instance of a data-in (puru via rohini)
OOZIE-1576 Add documentation for Oozie Sqoop CLI (bowenzhangusa via rkanter)
OOZIE-1616 Add sharelib and launcherlib locations to the instrumentation info (rkanter)
OOZIE-1647 oozie-setup.sh doesn't check exit code of java executions (alazarev via rkanter)
OOZIE-1642 writeUTF 64k limit for counters (puru via rohini)
OOZIE-1641 oozie-audit.log - add remote IP (puru via rohini)
OOZIE-1635 verifySlaElement in submitXCommand.java should get sla info from action child as well (bowenzhangusa via rohini)
OOZIE-1575 Add functionality to submit sqoop jobs through http on oozie server side (bowenzhangusa via rkanter)
OOZIE-1634 TestJavaActionExecutor#testUpdateConfForUberMode fails against Hadoop 2 (rkanter)
OOZIE-1633 Test failures related to sharelib when running against Hadoop 2 (rkanter)
OOZIE-1598 enable html email in email action (puru via ryota)
OOZIE-1631 Tools module should have a direct dependency on mockito (rkanter)
OOZIE-1491 Make sure HA works with a secure ZooKeeper (rkanter)
OOZIE-1615 shell action cannot find script file and fails in uber mode (ryota)
OOZIE-1605 Add common custom filter applied to Wf/Coord/Bundle jobs on oozie UI (ryota)
OOZIE-1474 Fix logging issues - latency, accurate job ids, coord Job UI to show job logs (mona)
OOZIE-1623 JPAService doesn't need to do reads in a transaction (rkanter)
OOZIE-1612 When printing Dates to log messages, we should make sure they are in oozie.processing.timezone (gwenshap via rkanter)
OOZIE-1519 Admin command to update the sharelib (puru via ryota)
OOZIE-1604 <java-opts> and <java-opt> not added to Application Master property in uber mode (ryota)
OOZIE-1584 Setup sharelib using script and pickup latest(honor ship.launcher) and remove DFS dependency at startup (puru via ryota)
OOZIE-1550 Create a safeguard to kill errant recursive workflows before they bring down oozie (rkanter)
OOZIE-1314 IllegalArgumentException: wfId cannot be empty (shwethags via virag)
OOZIE-1606 Update Curator to 2.3.0 and fix some misc minor ZK related things (rkanter)
OOZIE-1544 Support variables for coord data-in/data-out dataset (puru via rohini)
OOZIE-1603 cannot submit job to oozie on mysql (virag)
OOZIE-1600 map-reduce actions without configuration section in workflow.xml throws "IllegalArgumentException: element cannot be null" (bowenzhangusa via rkanter)
OOZIE-1580 EL variables don't get resolved in configurations imported from a <job-xml> (bowenzhangusa via rkanter)
OOZIE-1562 Allow re-run of actions of killed coordinator (shwethags via virag)
OOZIE-1597 Cleanup database before every test (rkanter)
OOZIE-1589 TestZKLocksService is flakey (rkanter)
OOZIE-1541 Typo in Oozie HA admin -servers command in documentation (rkanter)
OOZIE-1596 TestOozieMySqlDBCLI.testCreateMysql fails when tests are executed in a different order (rkanter)
OOZIE-1592 El Expression Reference should point to the exact chapter in java 6 (bowenzhangusa via rkanter)
OOZIE-1578 Coordinator jobs with cron frequency should be invalidated upon submission if nothing would be materialized during run time (bowenzhangusa via rkanter)
OOZIE-1577 Oozie coordinator job with identical start and end time remains "RUNNING" forever (bowenzhangusa via rkanter)
OOZIE-1559 Fix missing fields from new SELECT queries and Recovery Service picking up killed control nodes (ryota,mona via mona)
OOZIE-1569 Maintain backward incompatibility for running jobs before upgrade (mona)
OOZIE-1568 TestWorkflowClient.testSla is flakey (rkanter)
OOZIE-1517 Support using MS SQL Server as a metastore (dwann via rkanter)
OOZIE-1460 Implement and Document security for HA (rkanter)
OOZIE-1570 Make openjpa connection properties configurable (rohini)
OOZIE-1560 Log messages should have a way of identifying which server they came from when using HA (rkanter)
OOZIE-1566 Add reference to Quartz module in cron documentation (bowenzhangusa via rkanter)
OOZIE-1454 Documentation for cron syntax scheduling of coordinator job (bowenzhangusa via rkanter)
OOZIE-1306 add flexibility to oozie coordinator job scheduling (bowenzhangusa via rohini)
OOZIE-1526 Oozie does not work with a secure HA JobTracker or ResourceManager (rkanter)
OOZIE-1500 Fix many OS-specific issues on Windows (dwann via rohini)
OOZIE-1556 Change Bundle SELECT query to fetch only necessary columns and consolidate JPA Executors (ryota)
OOZIE-1523 Create Windows versions of the shell scripts (dwann via rkanter)
OOZIE-1558 RAT Warning from BundleActionsGetJPAExecutor.java (rkanter)
OOZIE-1557 TestFsActionExecutor.testChmodWithGlob fails against Hadoop 2.1.x-beta (rkanter)
OOZIE-1503 [DB optimization] revisit eagerLoadState at places (mona)
OOZIE-1555 LauncherMapper to check for sys properties before opening files for action data (mona)
OOZIE-1546 TestMapReduceActionExecutorUberJar.testMapReduceWithUberJarEnabled fails (rkanter)
OOZIE-1545 RecoveryService keeps repeatedly queueing SuspendXCommand (rohini)
OOZIE-1547 Change Coordinator SELECT query to fetch only necessary columns and consolidate JPA Executors (ryota)
OOZIE-1529 Disable job DAG display for workflow having huge actions (puru via rohini)
OOZIE-1468 Add created time column in WF_ACTIONS and SLA tables (rohini)
OOZIE-1524 Change Workflow SELECT query to fetch only necessary columns and consolidate JPA Executors (ryota)
OOZIE-1515 Passing superset of action id range should be allowed (mona)
OOZIE-1530 Fork-join mismatch makes workflow Failed but some actions stay Running (mona)
OOZIE-1539 Load more coordinator jobs eligible to be materialized in MaterializeTriggerService (mona)
OOZIE-1528 CoordRerunX and ActionEndX not updating some of the modified beans. (virag)
OOZIE-1540 When oozie.zookeeper.oozie.id is not specified, its using a space instead of the hostname (rkanter)
OOZIE-1509 Do not preload all tabs in Oozie UI and make Active Jobs default (mona)
OOZIE-1496 Oozie demo and streaming examples fails to run on Windows (eshevchuk via rkanter)
OOZIE-1462 Compress lob columns before storing in database (virag)
OOZIE-1499 Update only necessary columns and consolidate JPA Executors (ryota)
OOZIE-1522 SignalX may try to insert transition for a forked node twice (virag)
OOZIE-1461 provide an option to auto-deploy launcher jar onto HDFS system libpath (ryota,virag via virag)
OOZIE-1520 Sequencefile Reader fails to use doas for reading action data file (rohini,mona via mona)
OOZIE-1513 Workflow stays in running if Fork/join validation or loop detection fails (mona)
OOZIE-1490 Remove unix OS enforcement from build (dwann via tucu)
OOZIE-1372 When using uber mode, Oozie should also make the AM container size larger (ryota)
OOZIE-615 Support high availability for the Oozie service (rkanter)
OOZIE-1486 Cut down on number of small files created to track a running action (mona)
OOZIE-1476 Add ability to issue kill on Coordinator Action directly with id and nominal daterange (mona)
OOZIE-1495 inconsistent behavior of chmod/chgrp when path doesn't exist after glob support (ryota)
OOZIE-1463 Remove discriminator column (virag)
OOZIE-1448 A CoordActionUpdateXCommand gets queued for all workflows even if they were not launched by a coordinator (rkanter)
OOZIE-1443 forkjoin validation should not allow a fork to go to the same node multiple times (rkanter)
OOZIE-1471 Support glob in FS action and prepare blocks (ryota)
OOZIE-1403 forkjoin validation blocks some valid cases involving decision nodes (rkanter)
OOZIE-1449 Coordinator Workflow parent relationship is broken for purge service (rkanter)
OOZIE-1458 If a Credentials type is not defined, Oozie should say something (rkanter)
OOZIE-1425 param checker should validate cron syntax (bowenzhangusa via rkanter)
OOZIE-1453 Change "frequency" to string in SyncCoordAction.java (bowenzhangusa via rkanter)
OOZIE-1447 Sqoop actions that don't launch a map reduce job fail with an IllegalArgumentException (jarcec via rkanter)
OOZIE-1440 Build fails in certain environments due to xerces OpenJPA issue (mackrorysd via rkanter)

-- Oozie 4.0.1 release (unreleased)

OOZIE-1756 hadoop-auth version is wrong if profile isn't selected (rkanter)
OOZIE-1736 Switch to Hadoop 2.3.0 for the hadoop-2 profile (rkanter)
OOZIE-1670 Workflow kill command doesn't kill child job for map-reduce action (puru via rohini)
OOZIE-1630 <prepare> operations fail when path doesn't have scheme (ryota)
OOZIE-1627 Rerun doesn't resolve workflow app name (puru via rohini)
OOZIE-1626 pig action pop-up is not working properly in UI (ryota, puru via rohini)
OOZIE-1607 [Doc]Update workflow specification for chgrp command (puru via rohini)
OOZIE-1542 When extjs isn't installed, the web UI is unhelpfully blank (rkanter)
OOZIE-1565 OOZIE-1481 should only affect v2 of the API, not v1 (rkanter)
OOZIE-1551 Change hadoop-2 profile to use 2.2.0 (rkanter,rohini,mona via rkanter)
OOZIE-1573 coord:tzOffset() gives incorrect offset for daylight saving timezones (rohini)
OOZIE-1582 Bump up Tomcat version to 6.0.37 (rkanter)
OOZIE-1563 colt jar includes GPL licence (rkanter)
OOZIE-1284 oozie.service.SchemaService.wf.ext.schemas in oozie-site is missing some newer xsd files (rkanter)
OOZIE-1549 Update hcat documentation to mention hcatalog-pig-adapter jar (bowenzhangusa via rohini)

-- Oozie 4.0.0 release

OOZIE-1514 Rerunning a coordinator with no input dependencies puts actions in WAITING instead of READY and proceeding (bowenzhangusa via mona)
OOZIE-1507 Command queue filling up with duplicate commands from RecoveryService (rohini)
OOZIE-1502 Coordinator Job not going to Failed if a bad HCat-uri is specified (mona)
OOZIE-1501 Mapreduce action counters are picked up from launcher job instead of mapreduce job (rohini)
OOZIE-1405 Fix flakey SLA tests (mona)
OOZIE-1480 Web-console Workflow Job Info popup should display parent-id field and no empty Nominal time field (mona)
OOZIE-1481 Getting a coordinator job info with len=0 should return 0 actions (rohini)
OOZIE-1484 Error in DB upgrade when error message exceeds 4K characters (ryota)
OOZIE-1482 4.0 client does not work with 3.x server for coord jobs (rohini)
OOZIE-1479 Duplicate end_miss events introduced by OOZIE-1472 (rohini)
OOZIE-1472 Confirm against database before generating start and duration miss events (rohini)
OOZIE-1473 getKey() not overridden in some commands causing duplicates in queue (virag)
OOZIE-1470 BundleStatusUpdateXCommand should get lock for bundle job (virag)
OOZIE-1469 loadState() and/or verifyPrecondition() are blank in some commands (virag)
OOZIE-1467 Bundle not killed if coordinator fails due to db exception (rohini,virag via virag)
OOZIE-1466 current EL should not check for less than or equal to zero (rohini)
OOZIE-1465 Making constants in CoordELFunctions public for el extensions (shwethags via rohini)
OOZIE-1450 Duplicate Coord_Action events on Waiting -> Timeout, and Coord Materialize not removing actions on Failure (mona)
OOZIE-1451 CoordActionInputCheckX does a redundant eagerLoadState (rohini)
OOZIE-1446 SLACalcStatus not updating the last modified time correctly and duplicate DURATION_* event (virag,mona via mona)
OOZIE-1249 SLA Documentation (mona,virag,rohini via rohini)
OOZIE-1441 Fix bugs related to coordchange and parentId in events (mona,virag via virag)
OOZIE-1444 Job DAG causes OOM. Remove refresh option (rohini)
OOZIE-1379 Generate SLA end_miss event only after confirming against persistent store (mona)
OOZIE-1439 Job materialization happening even after coordinator is supposed to be killed (virag)
OOZIE-1438 parentID is null in job event message of subworkflow action (ryota)
OOZIE-1435 StatusTransitService unnecessarily updates the lastModifiedTime of jobs which causes MaterializationService to bring same jobs in memory (virag)
OOZIE-1433 ActionCheckX should override XCommand.getKey() to prevent duplicates (virag)
OOZIE-1436 Revert SLA_XML and few other varchar columns back to clob (virag)
OOZIE-1427 Update CredentialsModule docs to mention Hive (rkanter)
OOZIE-1429 Fix bugs in SLA UI (rohini)
OOZIE-1423 Coordinator job change command not removing SLA Registration bean (mona)
OOZIE-1424 Improve SLA reliability on restart, fix bugs related to SLA and event generation (virag)
OOZIE-1417 Exlude **/oozie/store/* **/oozie/examples/* from clover reports (dennisyv via virag)
OOZIE-1426 Fix bugs in SLA UI (rohini)
OOZIE-1421 UI for SLA (virag, rohini)
OOZIE-1422 fix bug in SLARegistrationBean and CoordActionsCountForJobIdJPAExecutor (ryota)
OOZIE-1408 Change column type of "frequency" from int to varchar for coordinators (rkanter)
OOZIE-1420 OOZIE-1365 breaks the action popup in the Web UI (michalisk via rkanter)
OOZIE-1418 Fix bugs around ActionKillX not setting end time, V2SLAServlet and exception handling for event threads (mona)
OOZIE-1365 The hive action popup in the web UI is broken when externalChildIDs is empty string (michalisk via rkanter)
OOZIE-1412 Webapp contains all sharedlib dependencies after launcher refactor (rohini)
OOZIE-1414 Configuring Oozie for HTTPS still allows HTTP connections to all resources (rkanter)
OOZIE-1410 V2 servlets are missing from ssl-web.xml (rkanter, rohini via rkanter)
OOZIE-1349 oozieCLI -Doozie.auth.token.cache doesn't work (bowenzhangusa via tucu)
OOZIE-1398 Reduce the number of CLOB columns used (ryota)
OOZIE-1374 Make all unit tests run with Hadoop 2 (rohini)
OOZIE-1394 Fix Bugs in Job and SLA Events (mona)
OOZIE-1315 Refactor classes from launcher jar into Oozie sharelib (rkanter)
OOZIE-1377 OpenJPA runtime enhancement should be disabled and update OpenJPA to 2.2.2 (tucu)
OOZIE-1339 Implement SLA Bootstrap Service and fix bugs in SLACalculator (virag)
OOZIE-1400 REST API to fetch SLA (rohini)
OOZIE-1375 Generate Job notification events for Workflow Actions (mona)
OOZIE-1357 Can't view more than 1000 actions of a coordinator and paging does not work (ryota)
OOZIE-1381 Oozie does not support access to the distributed cache file under different name node (ryota)
OOZIE-1298 TestPartitionDependencyManagerEhcache.testEvictionOnTimeToIdle is flakey (rohini)
OOZIE-1397 failure in running test cases (aklochkov via rohini)
OOZIE-1294 SLA Email Notification (ryota via virag)
OOZIE-1395 Using Yarn's CapacityScheduler causes some tests to time out (rkanter)
OOZIE-1373 Oozie compilation fails with jdk7 (tucu, rohini via rohini)
OOZIE-1296 SLA JMS Event Listener for publishing notifications related to SLA information (ryota via mona)
OOZIE-1361 Remove SLACalculatorBean and add columns to SummaryBean indicating events processed and sla processed (mona)
OOZIE-674 resolveInstanceRange doesn't work for EL extensions (shwethags via mona)
OOZIE-1384 Make Uber Mode not the default (rkanter via virag)
OOZIE-1386 NPE in XOozieClient if fs.default.name is not defined but fs.defaultFS is (wypoon via rkanter)
OOZIE-1387 Proxysubmission from the Oozie client doesn't allow the mapreduce API (rkanter)
OOZIE-1244 SLA Support in Oozie (mona)
OOZIE-1371 oozie.coord.action.notification.url has no documentation (rkanter)
OOZIE-1328 Cover package org.apache.oozie.cli with unit tests (vbondarev via virag)
OOZIE-1327 enhance unit-test coverage of package org.apache.oozie (iveselovsky via rkanter)
OOZIE-1356 Bundle job in PAUSEWITHERROR state does not goto SUSPENDEDWITHERROR state on suspending it (bowenzhangusa via virag)
OOZIE-1313 coverage fix for org.apache.oozie.client (aleksgor via virag)
OOZIE-1360 Oozie CLI shows created time of workflow as started time (ryota via virag)
OOZIE-1359 mention default value of throttle in doc (ryota via virag)
OOZIE-1370 oozie create db script throws classNotFound exception (bowenzhangusa via virag)
OOZIE-1183 Update WebServices API documentation (rkanter)
OOZIE-1368 Error message when using an incorrect oozie url with kerberos is misleading (rkanter)
OOZIE-1352 Write documentation for OOzie Hive CLI (rkanter)
OOZIE-1353 hive CLI fails with -X argument (rkanter)
OOZIE-611 distcp action does not have documentation (rkanter)
OOZIE-1318 Action Main classes should be overridable via action configuration settings (rkanter)
OOZIE-1347 Additions to JMS topic API (virag)
OOZIE-1231 Provide access to launcher job URL from web console when using Map Reduce action (ryota via virag)
OOZIE-1335 The launcher job should use uber mode in Hadoop 2 by default (rkanter)
OOZIE-1297 Add chgrp in FS action (ryota via virag)
OOZIE-1329 fix coverage org.apache.oozie.tools (agorshkov via virag)
OOZIE-1351 Oozie jobs with state PAUSEDWITHERROR should change to SUSPENDEDWITHERROR state when suspended (bowenzhangusa via virag)
OOZIE-1346 Modularize hbase credentials to separate the populating of jobconf and obtaining token for job (virag)
OOZIE-1341 Have Action Main classes in Oozie webapp (virag)
OOZIE-1337 HadoopAccessorService has two static methods so you can't override them with another implementation (rkanter)
OOZIE-1333 Some testcases related to EventHandlerService are failing in a transient way (virag)
OOZIE-1316 fix coverage org.apache.oozie.action.hadoop (aleksgor via rkanter)
OOZIE-1224 web console user interface improvements (matthew ropp via mona)
OOZIE-1083 WFGEN Help -> About dialog box (jaoki via tucu)
OOZIE-670 Merge addtowar and oozie-setup scripts into one (bowenzhangusa via tucu)
OOZIE-1326 sharelib tests failing saying error on fork after OOZIE-1311 refactor (rohini via rkanter)
OOZIE-1235 Client API for retrieving topic and jms connection related details (virag)
OOZIE-1234 JMS Event Listeners for publishing notifications related to workflow and coordinator (virag)
OOZIE-1281  Hiveaction should populate externalChildIDs (rohini via virag)
OOZIE-1322 show child job URL tab selectively for pig action (ryota via mona)
OOZIE-1307 Cover package org.apache.oozie.action.ssh with unit tests (vbondarev via rkanter)
OOZIE-1317 TestEventGeneration.testCoordinatorActionEvent fails (mona)
OOZIE-1292 Add Hadoop 0.23 Poms in hadooplibs to enable a build/tests against branch 0.23 (mona)
OOZIE-1320 Tests for sharelib actions fail with ClassNotFoundException against Hadoop 2 (rkanter)
OOZIE-1311 Refactor action Main classes into sharelibs (rkanter)
OOZIE-897 remove special build handling for sqoop testcase (rkanter)
OOZIE-1209 Event generation and handling for workflow and coordinator (mona)
OOZIE-1118 improve logic of purge service (rkanter)
OOZIE-1205 If the JobTracker is restarted during a Fork, Oozie doesn't fail all of the currently running actions (rkanter)
OOZIE-1286 SSH Action does not properly handle arguments that have spaces (rkanter)
OOZIE-1300 [Doc] Error in the the email action XML schema (harsh)
OOZIE-1288 Improve docs around -D arguments support in the Oozie CLI's pig subcommand (harsh)
OOZIE-1291 TestHadoopAccessorService.testGetMRDelegationTokenRenewer fails against Yarn (rkanter)
OOZIE-1278 oozie example datelist-java-main has job property typo and has no lib directory for examples.jar (bowenzhangusa via rkanter)
OOZIE-1264 The "parent" property of a subworkflow should be the ID of the parent workflow (rkanter)
OOZIE-1245 Add ability to automatically suspend workflow at specified actions (rkanter)
OOZIE-894 support for hive in Oozie CLI (bowenzhangusa via tucu)
OOZIE-1239 Bump up trunk to 4.1.0-SNAPSHOT (virag)
OOZIE-1392 Add commons-io-*.jar to addtowar for hadoop-2.0 (virag)
OOZIE-1303 CLI API for Bulk Monitoring (mona)
OOZIE-1350 Improve client debug output information (rkanter)
OOZIE-1343 Sqoop sharelib should have hsqldb jar (rkanter)
OOZIE-1344 We should use Sqoop 1.4.3 instead of 1.5.0-incubating-SNAPSHOT (rkanter)
OOZIE-1146 FileSystem used by prepare sections should use the configuration of the action (rohini via virag)
OOZIE-1215 add note of using escape for oozie jobs filters in doc (egashira via rkanter)
OOZIE-1331 URIHandlerService not allowing relative path for URI's (virag)
OOZIE-1332 Flakey test TestActionCheckXCommand.testActionCheckTransientDuringMRAction (rkanter)
OOZIE-1150 DB upgrade scripts for hcat changes (ryota via virag)
OOZIE-1323 HTTPS docs lists the same step twice for creating a self-signed certificate (rkanter)
OOZIE-1280 CoordPushDependencyCheck queued by Recovery Services doesn't remove dependencies from cache (rohini via virag)
OOZIE-1277 CoordActionInputCheck requeues itself even if only push missing dependencies exist (virag)
OOZIE-1272 Two workflow jobs mapped to a single coordinator action (ryota via virag)
OOZIE-1274 change recovery service interval to make it consistent with oozie-default.xml (ryota via virag)
OOZIE-1246 appname need to be persisted on SLA event table by SLA status event (ryota via virag)
OOZIE-1270 Querying job directly does not pop correct information for coordinator and bundle (rohini via virag)
OOZIE-1269 Exception in push dependency check when there is also a pull dependency leaves it in waiting till timeout (rohini via virag)
OOZIE-1267 Dryrun option for push missing deps (virag)
OOZIE-1263 Fix few HCat dependency check issues (rohini via virag)
OOZIE-1261 Registered push dependencies are not removed on Coord Kill command (virag)
OOZIE-1191 add examples of coordinator with SLA tag inserted (ryota via mona)
OOZIE-1204 Illustrate correct use of parameters inside SLA tags (jun aoki via mona)
OOZIE-1255 latest/future check for hcat can cause shutdown to hang (rohini via virag)
OOZIE-1253 latest() gets resolved before all push dependencies are resolved (rohini via virag)
OOZIE-1251 Log messages for DependencyChecker class show wrong jobid and actionid (rohini via mona)
OOZIE-1218 Create a HCatalog Integration Guide (rohini via virag)
OOZIE-1250 Coord action timeout not happening when there is a exception (rohini via mona)
OOZIE-1207 Optimize current EL resolution in case of start-instance and end-instance (rohini via mona)
OOZIE-1247 CoordActionInputCheck shouldn't queue CoordPushInputCheck (rohini via virag)
OOZIE-1238 CoordPushCheck doesn't evaluate the configuration section which is propogated to workflow (virag)
OOZIE-1203 Oozie web-console to display Bundle job definition, configuration and log tabs (mona)
OOZIE-1237 Bump up trunk to 4.0.0-SNAPSHOT (virag)
OOZIE-561 Integrate Oozie with HCatalog
OOZIE-1181 Dependency cache with configurations for eviction, ttl and max elements in memory (rohini via virag)
OOZIE-1217 Address review comments in OOZIE-1210 (rohini via virag)
OOZIE-1197 Create a hcat sharelib which can be included in pig, hive and java actions (mona,rohini via virag)
OOZIE-1196 HCat EL functions for database and table should be modified (mona)
OOZIE-1210 Rework uri handling for Prepare actions and jms server mapping (rohini via virag)
OOZIE-1179 coord action in WAITING when no definition of dataset in coord job xml (mona)
OOZIE-1185 Retry jms connections on failure (rohini via virag)
OOZIE-1158 Add hcataloglib sub-module (mona)
OOZIE-1180 Separate the connection context details from JMS Accessor service (virag)
OOZIE-1097 Revert OOZIE-1095 once dependent HCat jar mavenized (mona)
OOZIE-1157 EL function hcat:exists for decision making (rohini via mona)
OOZIE-1167 Fix and rework PartitionDependency Management (rohini via virag)
OOZIE-1156 Make all the latest/future instances as pull dependences (virag)
OOZIE-1145 Modify Recovery Service to handle push missing dependencies (virag)
OOZIE-1135 Display missing partition dependencies via job -info command on CLI (mona)
OOZIE-1125 Prepare actions for hcat (rohini via virag)
OOZIE-1123 EL Functions for hcatalog (mona)
OOZIE-1138 Provide rule based mechanism to allow multiple hcatalog servers to connect to JMS server (virag)
OOZIE-1111 change HCatURI to specify partitions in path instead of query parameter (rohini,ryota via virag)
OOZIE-1108 Fix JMS message consumer to maintain single session per topic registration (mona)
OOZIE-1075 Create general scheme handler (rohini via virag)
OOZIE-1107 Change default done-flag from _SUCCESS to empty for Hcat (mohammad)
OOZIE-1095 Add HCatalog jar as resource for building (mona)
OOZIE-1105 Resolve issues found during integration(mohammad)
OOZIE-1086 Command to check the missing partitions directly against HCatalog server (mohammad)
OOZIE-1050 Implement logic to update dependencies via push JMS message(mona via mohammad)
OOZIE-1068 Metadata Accessor service for HCatalog(mohammad)
OOZIE-1069 Update dataIn and dataOut EL functions to support partitions (mohammad)
OOZIE-1043 Add logic to register to Missing Dependency Structure in coord action materialization (ryota via mohammad)
OOZIE-1061 Add new EL functions to retrieve HCatalog server, DB and table name(mohammad)
OOZIE-1056 Command to update push-based dependency (mohammad)
OOZIE-1059 Add static method to create URI String in HCatURI(ryota via mohammad)
OOZIE-1039 Implement the Missing Dependency structure for HCat partitions (mona via mohammad)
OOZIE-1042 Coordinator action table schema change. (Mohammad)
OOZIE-1036 Utility class to parse HCat URI (Ryota via Mohammad)
OOZIE-1033 Generic utility class to register/unregister a JMS message handler(Mohammad)
OOZIE-1032 Create JMSService used for any JMS compliant product (Mohammad)
OOZIE-1045 Parameterize <unresolved-instances> tag currently hardcoded (egashira via mona)
OOZIE-1096 Update wfgen README.txt to have the TLP mailing list (jun aoki via rkanter)
OOZIE-1078 Help -> Documentation and Help -> Online Help should link to oozie.apache.org/ (jun via mohammad)
OOZIE-809 MySQL TEXT columns should be MEDIUMTEXT (rkanter via tucu)
OOZIE-979 bump up trunk version to 3.4.0-SNAPSHOT (tucu)
OOZIE-1007 Add license headers to all files don't have them  (egashira via tucu)
OOZIE-976 add workflowgenerator into distro tarball (egashira via tucu)
OOZIE-944 Implement Workflow Generator UI Tool (egashira via virag)

-- Oozie 3.3.2 (unreleased)

OOZIE-1132 update quick start docs with build instructions (rkanter)
OOZIE-1268 Configuring Oozie to use SSL doesn't work if addtowar.sh is invoked directly (rkanter)
OOZIE-1208 Oozie web-console when displaying Coord Job Log for an action gives Format Error (rohini via mona)
OOZIE-1233 Add ability to configure Oozie to use HTTPS (SSL) (rkanter)
OOZIE-1242 Dryrun option for workflows mentions version 3.4 when it should be 3.3.2 (rkanter)
OOZIE-1189 add filter option to specify JobID and AppName in SLA CLI command (egashira via mona)
OOZIE-1054 Create script to properly upload sharelib to HDFS (bowenzhangusa via tucu)
OOZIE-1015 HadoopAccessorService jobtracker validation should not have hardcoded conf key (mona)
OOZIE-669 Deprecate oozie-start.sh, oozie-stop.sh & oozie-run.sh scripts (rkanter via tucu)
OOZIE-1219 The timezone cookie should never expire (rkanter)
OOZIE-1220 Make the login example cookie expire (rkanter)
OOZIE-1227 In a coordinator, specifying the <app-path> without a namenode causes it to fail (rkanter)
OOZIE-1226 Workflow lib path not found in classpath for a subworkflow (rkanter)
OOZIE-1184 Demo example job.properties has an unused parameter (udai via rkanter)
OOZIE-1211 oozie does not support duplicated dataset (jaoki via virag)
OOZIE-1187 reduce memory usage of SLA query (invoked by CLI command) to avoid OOM (egashira via virag)
OOZIE-1221 mvn install failing in Oozie-Mini module (jaoki via virag)
OOZIE-1170 Update minitest module (MiniOozie) to use main pom as its parent (jaoki via rkanter)
OOZIE-1188 Typo in documentation for using login server example (rkanter)
OOZIE-1113 The cookies used in the AltKerberosAuthenticationHandler examples aren't read properly if quoted (rkanter)
OOZIE-1103 Create example using AltKerberosAuthenticationHandler (rkanter)
OOZIE-1179 coord action in WAITING when no definition of dataset in coord job xml (mona)
OOZIE-1194 test-patch shouldn't run the testHive profile because it not longer exists (rkanter)
OOZIE-1193 upgrade jython to 2.5.3 for Pig in Oozie due to jython 2.5.0 legal issues (bowenzhangusa via rkanter)
OOZIE-1172 Add documentation on how to get Java actions to authenticate properly on Kerberos-enabled clusters (rkanter)
OOZIE-87 GH-47: Feature to supply a comma separated list of jars in an 'archive tag' of workflow (jaoki via rkanter)
OOZIE-1160 Oozie web-console to display all job URLs spawned by Pig (mona)
OOZIE-1177 HostnameFilter should only catch UnknownHostException, not Exception (rkanter)
OOZIE-945 BundleSubmitXCommand.submit() doesn't properly remove comments (jaoki via rkanter)
OOZIE-1171 HostnameFilter should handle hostname resolution failures and continue processing (tucu via rkanter)
OOZIE-1053 Oozie Web-console clicking on Bundle's coord jobs does not open them up (ryota via mona)
OOZIE-1166 Print a more helpful message when ProxyUserService is configured wrong (rkanter)
OOZIE-1136 Fix MiniOozie (rkanter)
OOZIE-1051 Repeating Errors for workflows that were allreday Killed (rkanter)
OOZIE-1140 TestLogStreamer.testStreamLog fails when its started within the first 4 seconds after the hour (rkanter)
OOZIE-1153 comma separated list in <archive> and <file> for JavaActionExecutor. (jaoki via tucu)
OOZIE-1161 Remove unnecessary db updates for some of the blobs like missing_dependencies' of Coordinator Action (virag)
OOZIE-1164 typo in toString() method for org.apache.oozie.client.rest.JsonCoordinatorJob.java (bowenzhangusa via rkanter)
OOZIE-1152 Unit test for JavaActionExecutor has a wrong action XML (jaoki via harsh)
OOZIE-1144 OOZIE-1137 breaks the sharelib (rkanter)
OOZIE-1035 Improve forkjoin validation to allow same errorTo transitions (rkanter)
OOZIE-1137 In light of federation use actionLibPath instead of appPath (vaidya via rkanter)
OOZIE-1126 see if checkstyle works for oozie development. (jaoki via rkanter)
OOZIE-1124 Split pig unit tests to a separate module (rohini via virag)
OOZIE-1087 Remove requirement of hive-default.xml from Hive action (rkanter)
OOZIE-1129 Add documentation for configurable filesystem support (rkanter)
OOZIE-1084 When use IBM jdk , UT TestCallbackServlet and TestHadoopELFunctions fail (zhujinwei via rkanter)
OOZIE-1127 Missed one services.destroy() in OOZIE-1114 (rkanter)
OOZIE-1071 latest EL function is based on action materialization time (rohini via virag)
OOZIE-1114 Some tests don't use the Services singleton properly (rkanter)
OOZIE-1101 Fix log messages that contain {0} or similar (rkanter)
OOZIE-1073 Optimize latest and future EL resolution in case of start-instance and end-instance (rohini via virag)
OOZIE-816 Add Support for Hadoop 1.1.1 (zhujinwei and harsh via harsh)
OOZIE-1106 latest and future function do not work correctly when oozie processing timezone is non UTC (rohini via tucu)
OOZIE-1102 Update Oozie README.txt to have the TLP mailing list and links (jaoki via rkanter)
OOZIE-1057 Log message for retrying to connect to the JT always says 60,000 milliseconds (jiezhou via rkanter)
OOZIE-1080 Add a dryrun option for workflows (rkanter)
OOZIE-1062 Create a shell example
OOZIE-1034 Allow disabling forkjoin validation just for a specific workflow
OOZIE-1072 Oozie Coordinator Doc error in Synchronous datasets
OOZIE-1028 Add EL function to allow date ranges to be used for dataset ranges (rkanter via tucu)
OOZIE-1048 Enable propagation of native libraries as a VM argument using java.library.path (venkatesh via tucu)
OOZIE-1014 Coordinator action failure error not propagated (mona)
OOZIE-1029 MiniMRCluster fails to start when used against YARN (rkanter via tucu)
OOZIE-1011 Tests from OOZIE-994 fail when run against Hadoop trunk (rkanter via tucu)
OOZIE-1037 XTestCase.delete() can cause tests to fail if it runs into a dangling symlink (rkanter via tucu)
OOZIE-1027 Command line mr does not support NN/JT parameters properly (Mona via Mohammad)
OOZIE-1020 BulkJPAExecutor handling date-time value incorrectly.(Mona via Mohammad)
OOZIE-967 Coordinator action window in web UI never finishes refreshing (kinley via tucu)
OOZIE-1024 ooziedb.sh script should keep OOZIE_CONFIG, OOZIE_LOG, and OOZIE_DATA if previously set (rkanter via tucu)
OOZIE-1023 Docs list OOZIE_CONF instead of OOZIE_CONFIG env var (rkanter via tucu)
OOZIE-1012 Sqoop jobs are unable to utilize Hadoop Counters (jarcec via virag)
OOZIE-986 Oozie client shell script should use consistent naming for java options (stevenwillis via tucu)
OOZIE-1018 Display coord job start time, end time, pause time, concurrency in job -info (mona via tucu)
OOZIE-1016 Tests that use junit assert or fail in a new thread report success when they are actually failing (rkanter via tucu)
OOZIE-1017 Add test to make sure old version of Xerces isn't being used (rkanter via tucu)
OOZIE-949 Allow the user to set 'mapred.job.name' (jrkinley via tucu)
OOZIE-1009 Documentation pages should use default ports for Oozie/JT/NN (tucu)
OOZIE-992 Add overall status to test-patch messages and add some color-coding for negative results (tucu)
OOZIE-1003 TestOozieCLI.testSubmitDoAs() should disable anonymous request (tucu)
OOZIE-1004 Oozie client needs to bundle slf4j JARs (tucu)
OOZIE-1000 Remove Yahoo branding from docs, tests, etc (rkanter via virag)
OOZIE-999 XLogStreamer requires log4j.appender.oozie.layout.ConversionPattern to contain a "-" (dash) or streaming logs to web UI and CLI don't work (rkanter via virag)
OOZIE-998 test-patch doesn't allow lines that are exactly 132 characters (rkanter via tucu)
OOZIE-739 a coord action fails because the uri points to a namenode that is not in whitelist. the E0901 error shows in the oozie.log, but not written to the database (mona,mbattisha via virag)
OOZIE-987 Fix minor bug in one of the uber jar tests (rkanter via tucu)
OOZIE-988 Improve verification of TestJavaActionExecutor.testLibFileArchives (rkanter via tucu)
OOZIE-973 Allow Oozie to run against Hadoop trunk branch (rkanter via tucu)
OOZIE-984 Allow EL Functions in Coordinator timeout (rkanter via tucu)
OOZIE-972 Provide  EL function to append a string in each substring of another string separated by delimiter (Mohammad via virag)
OOZIE-977 NotificationXCommand (job.notification queue entry) should set a timeout in the HTTP connections it makes (tucu)
OOZIE-654 Provide a way to use 'uber' jars with Oozie MR actions (rkanter via tucu)
OOZIE-1186 Image load for Job DAG visualization should handle resources better (mona)

-- Oozie 3.3.1 release

OOZIE-1175 Update POM version to 3.3.1 for 3.3 branch (virag)
OOZIE-1159 Set the RM token renewer as the full service principal instead of short name (rohini via virag)
OOZIE-1151 HbaseCredentials doesn't use properties from the credentials module (virag)
OOZIE-1148 Set the renewer correctly for JT/RM delegation tokens (rohini via virag)
OOZIE-1147 HCatCredentialHelper uses the wrong API for getDelegationToken (rohini via virag)
OOZIE-1149 Update 3.3 branch POM's to 3.3.1-SNAPSHOT (virag)
OOZIE-1139 bump up Tomcat version to 6.0.36 (tucu via rkanter)
OOZIE-1110 log Error that happens in XCommand to make debug easy (rohini via virag)
OOZIE-1133 Remove hadoop-auth dependency from oozie-core (virag)
OOZIE-1130 Upgrade from 3.2 to 3.3 failing due to change in WorkflowInstance structure (virag)
OOZIE-1128 When a user submitting a job is not UNDEF in the request, it should use that user as the submitter (tucu)
OOZIE-1091 workflow functional spec, fs action related issues (virag)
OOZIE-1116 Create hbaselibs module (virag)
OOZIE-1093 recursive fs chmod does not change the leaf directory (virag)
OOZIE-1094 credential cannot resolve variable (virag)
OOZIE-1099 Pig launcher log does not show the pig job url for H23 (rohini via mona)
OOZIE-1100 HFTP coordinator input check fails due to missing commons-httpclient.jar (ryota via virag)
OOZIE-1065 bundle status does not transit after rerun (virag)
OOZIE-1064 Status value of coordinator job not reflected in bundle action and invalid transition of coordinator job (virag)

-- Oozie 3.3.0 release

OOZIE-959  Use API from OOZIE-906 in console (Ashish via Mohammad)
OOZIE-1089 DistributedCache workaround for Hadoop 2.0.2-alpha (tucu)
OOZIE-1005 Tests from OOZIE-994 use wrong condition in waitFor (rkanter via virag)
OOZIE-994 ActionCheckXCommand does not handle failures properly (rkanter via virag)
OOZIE-1058 ACL modify-job should not be hardcoded to group name(mona via mohammad)
OOZIE-1052 HadoopAccessorService.createFileSystem throws exception in map-reduce action, failing workflow (egashira via mohammad)
OOZIE-1060 bump hadoop 2.X version to 2.0.2-alpha (rvs via tucu)
OOZIE-993 Hadoop 23 doesn't accept user defined jobtracker (virag)
OOZIE-1013 Build failing as the license header comment is appearing before xml declaration in some files (virag)
OOZIE-1006 Oozie fails to add required dependency for Hadoop 3.0.2 (venkatesh via virag)
OOZIE-975 Test cases should not load all the services classes (virag)
OOZIE-989 Testcases failing intermittently where coordinator jobs are in catchup mode (virag)
OOZIE-990 TestLogStreamer.testStreamLog fails in very rare cases (rkanter via tucu)
OOZIE-997 Add schema def. for distcp to work with global section and add missing xsd's for client xml validation (virag)
OOZIE-991 action prepare executions work only with HDFS filesystems (tucu)
OOZIE-981 Subworkflow lib not found in classpath when parent workflow lib overwrites it (mona via virag)
OOZIE-978 Bundle status doesn't transit to KILLED after a coordinator job fails submission (virag)
OOZIE-971 TestRecoveryService failing very often in pre-commit builds (mona via virag)
OOZIE-966 Fix formatting in CLI output when GMT-#### and GMT-##:## formatted timezones are used (rkanter via tucu)
OOZIE-960 TestStatusTransitService failing intermittently (virag)
OOZIE-968 source oozie environment from conf in oozie db setup script (svenkat via virag)
OOZIE-961 Load Hbase credentials in Oozie (virag)
OOZIE-963 Add new EL function to replace all instances of a sub-string with another one (Mohammad via virag)
OOZIE-969 Unit tests in TestStatusTransitService failing due to change in CoordKillX (mona via virag)
OOZIE-965 Allow the timezone attribute in coordinator jobs to use a format like GMT-#### (rkanter via tucu)
OOZIE-848 Bulk Monitoring API - Consolidated view of jobs (mona via virag)
OOZIE-934 Exception reporting during Services startup is inadequate (mona via virag)
OOZIE-914 Make sure all commands do their JPA writes within a single JPA executor (mona via virag)
OOZIE-918 Changing log level from DEBUG to TRACE for trivial log statements (mona via virag)
OOZIE-957 TestStatusTransitService and TestCoordKillXCommand are failing randomly; replace Thread.sleep() (rkanter via tucu)
OOZIE-477 Adding configurable filesystem support instead of hardcoded "hdfs" (mayank, mona via tucu)
OOZIE-906 Show runtime job DAG visually in Oozie console/dashboard (vaidya via virag)
OOZIE-958 typo in error message of E0736 (egashira via virag)
OOZIE-923 Improve error message when a user tries to start a coordinator job (sms via virag)
OOZIE-947 Forward porting OOZIE-733 to 3.2 and trunk (mona via virag)
OOZIE-889 Adding HCat credentials class for job conf (mona via virag)
OOZIE-940 Junk messages appear in tomcat log (egashira via virag)
OOZIE-955 TestCoordELFunctions and TestELConstantFunctions failing (bcry via tucu)
OOZIE-954 Global section xsd should allow job-xml elements and update documentation (rkanter via tucu)
OOZIE-951 Global section should make JT and NN optional (bcry via tucu)
OOZIE-948 Add support for Oozie coordinator to work in an UTC offset (tucu)
OOZIE-926 handling of global configuration is not correct (bcyr via tucu)
OOZIE-921 Changes in global section for the Name Node in FS action (bcyr via virag)
OOZIE-942 Add formal Parameters to bundle XML (rkanter via virag)
OOZIE-239 Add formal parameters to WF & COORD XML (rkanter via tucu)
OOZIE-938 Remove some duplicated code in FsActionExecutor (rkanter via tucu)
OOZIE-939 JT_PRINCIPAL and NN_PRINCIPAL must be added back to XOozieClient (rkanter via tucu)
OOZIE-930 Bundle not pass SUSPEND command to PAUSED coord job (virag)
OOZIE-933 Modify the Oozie CLI help to escape the semi-colon when multiple filters are specified (virag)
OOZIE-936 TestActionFailover failing (virag)
OOZIE-931 inconsistency on timestamp format between CLI command and web UI (egashira via virag)
OOZIE-708 Update the parent entity status dynamically (virag)
OOZIE-243 Workflow nodes START/END/KILL/FORK/JOIN should create rows in the action DB table (tucu)
OOZIE-913 Add Name Node, job-xml, and configuration Elements to FS action (rkanter via tucu)
OOZIE-937 Mention how to use the sharelib in the Quick Start page of the docs (rkanter via tucu)
OOZIE-886 Display request header info when trace is enabled (jay7306 via tucu)
OOZIE-932 space needed between "Created" and "Nominal time" in oozieCLI output (egashira via virag)
OOZIE-903 Workflow action status 'Ok' but the workflow job remains in 'RUNNING' (virag)
OOZIE-928 Clarify the documentation for submitting coordinator jobs using web services API (rkanter via virag)
OOZIE-920 Incorrect error message for multiple start instances in coordinator xml (bcyr via tucu)
OOZIE-925 Change default logging level for oozie to INFO (rkanter via tucu)
OOZIE-924 CATALINA_OPTS should include $CATALINA_OPTS in oozie-env.sh (rkanter via tucu)
OOZIE-922 Global section code doesn't properly handle extension actions (rkanter via tucu)
OOZIE-915 Obsolete NN/JT kerberos principal property names not removed from some places (mona via virag)
OOZIE-707 Suspending a paused coordinator job suspends the children but the status of job remains unchanged (virag)
OOZIE-917 Coordinator Job from 'KILLED' or 'FAILED' doesn't move to 'DONEWITHERROR' if the job materialization is not done(virag)
OOZIE-916 aggregator example uses hardcoded 'examples' value instead of parameterized (examplesRoot) value in path (wypoon via virag)
OOZIE-904 TestBundleStartX Failing (virag)
OOZIE-907 Default ACL settings for Oozie launcher (mona via virag)
OOZIE-908 Oozie docs build instructions for hadoop versions (mona via virag)
OOZIE-874 Eliminate redundancies in xml (britt via virag)
OOZIE-900 Indicate that the exception thrown from the db-cli during an error is for debug purposes (harsh)
OOZIE-865 ForkJoin validator checks total lengths of forks vs. joins instead of actual paths (rkanter via tucu)
OOZIE-905 Clarify and improve Oozie logging configuration and streaming (rkanter via tucu)
OOZIE-890 Support for map-reduce in OozieCLI (britt via virag)
OOZIE-887 Support for choosing timezone in Oozie UI (rkanter via tucu)
OOZIE-902 XLogService doesn't properly disable WS log streaming if log4j.appender.oozie.File is missing (rkanter via tucu)
OOZIE-885 A race condition can cause the workflow/coordinator to run even after the bundle job is killed (virag)
OOZIE-901 When Submitting a job without an app path, Oozie doesn't properly handle multiple paths from oozie.libpath (rkanter via virag)
OOZIE-748 Add support for oozie.libpath to be set on a per-action basis in workflow.xml (rkanter via virag)
OOZIE-899 NullPointerException on string check - Missing input dependency (mona via virag)
OOZIE-898 Oozie help [subcommand] should only print help for that subcommand (rkanter via tucu)
OOZIE-895 Oozie Hive-action should use Hive var replacement (rkanter via tucu)
OOZIE-888 Change default logging levels for oozieops and hadoop.security.authentication.server to INFO from DEBUG (rkanter via tucu)
OOZIE-896 TestFsActionExecutor.java failing (britt via virag)
OOZIE-881 Support for recursive chmod (britt via virag)
OOZIE-872 Support touchz in fs node of oozie worklfow (britt via virag)
OOZIE-769 Adding "-debug" option to Oozie CLI for debug statements to stdout (mona via virag)
OOZIE-795 update the oozie commit build profile (virag)
OOZIE-860 start-instance and end-instance should limit 1 (britt via virag)
OOZIE-882 CoordELEvaluator.createDataEvaluator doesn't set timezone for coord action (shwethags via tucu)
OOZIE-892 increase default JVM max memory to 1GB to avoid OOM (rkanter via tucu)
OOZIE-861 allow for use of multiple <java-opts> (britt via virag)
OOZIE_870 Parameterize Credentials(britt via virag)
OOZIE_846 OozieClient iterates over Properties using Hashtable method (lars_francke via tucu)
OOZIE-875 Support for multiple job-xml elements in extension action nodes (rkanter via tucu)
OOZIE-880 oozie.job.acl is not working (virag)
OOZIE-12  Support for multiple job-xml elements in action nodes (rkanter via tucu)
OOZIE-563 Missing dependency showing feeds that are already present (mona via tucu)
OOZIE-879 streaming sharelib brings in lots of unwanted dependencies (rkanter via tucu)
OOZIE-876 distcp packaging with Hadoop 1 brings in lots of unwanted dependencies (rkanter via tucu)
OOZIE-559 Create DistCp WF example (rkanter via tucu)
OOZIE-34  connProps should mask DB password when logging != DEBUG (rkanter via tucu)
OOZIE-877 update hadooplib POMs to use hadoop-2.0.0-alpha release (tucu)
OOZIE-766 Verify distcp action works with Hadoop 0.23 (rkanter via tucu)
OOZIE-801 Accepts coordinator with start time > end time (svenkat via tucu)
OOZIE-867 Unit test to account for log retrieval from multiple gzipped oozie.log files (mona via tucu)
OOZIE-649 Fail fast when a date doesn't parse correctly (rkanter via tucu)
OOZIE-871 actions from subworkflows that use oozie.libpath have duplicate classpath (tucu)
OOZIE-764 remove log warnings when credentials are null (rkanter via tucu)
OOZIE-637 parametrization of 'name' attribute in workflow/coordinator/bundle (tucu)
OOZIE-603 Invalid regex expression for IDENTIFIER type in xsd files (navis via tucu)
OOZIE-842 Update trunk POMs version to 3.3.0-SNAPSHOT (tucu)
OOZIE-818 CoordChangeXCommand deletes past coordinator actions (shwethags via tucu)
OOZIE-829 Increase the wait time for testcases failing intermittently (virag via tucu)
OOZIE-839 materialization of action does not take into account the lookupInterval for the calculations (tucu)
OOZIE-835 XTestCase Minicluster hangs when shutting down with an exception using Hadoop 2 (tucu)
OOZIE-834 Testcases for MapReduceMain, StreamingMain, PigMain, HiveMain fail with Hadoop 2 (tucu)
OOZIE-831 POMs cleanup/fixing of hadoop version and to be able to publish oozie JARs to maven repo (tucu)
OOZIE-830 add support for multiple/configurable sharelibs for each action type (tucu)
OOZIE-773 AuthorizationService should be able to use a group to identify superusers (tucu)
OOZIE-783 Upgrade to Junit4 (virag via tucu)
OOZIE-812 ooziedb tool does not create VALIDATE_CONN table (tucu)
OOZIE-824 ooziedb tool creates derby.log in current directory (tucu)
OOZIE-823 datelist-java-main example has namenode harcoded in app path the job.properties (tucu)
OOZIE-817 Fix the unreasonable definition of the schema to fs action (yians via tucu)

-- Oozie 3.2.0 release

OOZIE-852 remove pipes binaries from the source (tucu)
OOZIE-851 demo workflow example does not enable sharelib for pig and streaming (tucu)
OOZIE-850 apache-rat report should be a single global report file (tucu)
OOZIE-847 Example directory has few files without license text(Mohammad)
OOZIE-845 Delete 0 size files from repository(Mohammad)
OOZIE-833 Add Hadoop proxyuser related settings to quick start guide.(Virag via Mohammad)
OOZIE-832 Rename readme.txt file to README.txt and update contents(Mohammad)
OOZIE-827 StatusTransitService fails to run if a stale reference to coord job is present (virag via tucu)
OOZIE-815 Remove select * from queries related to coord action (Virag via Mohammad)
OOZIE-826 TestCoordKillXCommand's testCoordKillXCommandUniqueness testcase is failing after interrupt changes(virag via Mohammad)
OOZIE-819 Interrupt map doesn't have unique set of commands for a given jobid(virag via Mohammad)
OOZIE-810 Modify Oozie POM to pickup doxia 9.2y from a repo where it is avail(tucu via Mohammad)
OOZIE-241 EL function(s) to expose action output data as a (XML/JSON/PROP) blob (tucu)
OOZIE-825 Update oozie-sharelib-hive to use Hive 0.9.0 (virag via tucu)
OOZIE-820 OOZIE-820 Shell action to support env-var value with = sign (mona via tucu)
OOZIE-813 Sub-workflow child job does not get group name even if parent carries.(Mona via Mohammad)
OOZIE-791 coord job status not updated to done_with_error after kill(Virag via Mohammad)
OOZIE-804 TestDecisionActionExecutor failing due to uninitialized conf.(Virag via Mohammad)
OOZIE-805 TestCoordSubmitX failing(Virag via Mohamamd).
OOZIE-803 UP Remove HadoopAccessorService createFileSystem() method that takes config only (tucu)
OOZIE-802 Add minicluster config as hadoop-site.xml for testcases (tucu)
OOZIE-796 Making the maximum number of job retrials configurable (Mohamed via Mohammad)
OOZIE-741 the size of the workflow definition file (Mohamed via Mohammad)
OOZIE-797 Action retry not reading default error code.(Mona via Mohammad)
OOZIE-780 XConfiguration parser can't parse XML file with <include> element (Virag via Mohammad)
OOZIE-794 oozie job -info -filter should error out on bundle job and workflow job (virag via Mohammad)
OOZIE-799 Testcases failing due to missing action-conf dir. (Virag via Mohammad)
OOZIE-798 it would be nice to keep action specific configs in action-conf instead of hadoop-conf (rvs via tucu)
OOZIE-790 default concurrency value is inconsistent between doc and implementation.(Mohammad)
OOZIE-793 remove HiveMain check for HADOOP_HOME (tucu)
OOZIE-792 add default action configs per cluster (tucu)
OOZIE-624 client side improvement of authentication for user defined options
OOZIE-789 a few testcases using waitFor are timing out with YARN MiniCluster (tucu)
OOZIE-781 Xerces validator used by Java gets stuck during pattern matching (Virag via Mohammad)
OOZIE-788 JavaActionExecutor should not set yarn.resourcemanager.address (tucu)
OOZIE-785 No JsonToBean mapping for coord pausetime(shwetha via Mohammad)
OOZIE-786 tomcat should stop if oozie does not start correctly (tucu)
OOZIE-779 Oozie cannot submit jobs to hadoop 0.23 if running in non-default host:port (tucu)
OOZIE-774 Implement a coord:conf EL function to access configuration properties from Oozie coordinator XML files (Maxime via Mohammad)
OOZIE-777 Hadoop 0.23 removed org.apache.hadoop.mapred.Task$Counter group name breaking EL counters() (tucu)
OOZIE-776 custom-main example job.properties is missing the activation of sharelib (tucu)
OOZIE-775 sharelibs assembly does not include deps with compile scope (tucu)
OOZIE-758 Oozie logs should record job-id for when job is submitted (Mona via Mohammad)
OOZIE-772 enable Hive and Email actions by default (rvs via tucu)
OOZIE-771 oozied.sh should exec catalina.sh instead of forking it off (rvs via tucu)
OOZIE-767 TestCoordRerun and Testrerun shoudl be deleted.(virag via Mohammad)
OOZIE-768 latest Hadoop 0.23.3 minicluster is not creating /tmp in HDFS (tucu)
OOZIE-763 Add findbugs and clover plugin for CI (virag via tucu)
OOZIE-646 Doc changes: Drilldown and PigStats (params via tucu)
OOZIE-4   Configuration of Maximum output len for each action (harsh via tucu)
OOZIE-759 Fix config defaults in EmailActionExecutor (harsh via tucu)
OOZIE-675 checkMultipleTimeInstances doesn't work for EL extensions. EX: ${coord:formatTime(coord:current(0),'yyyy-MM-dd')} (sriksun via tucu)
OOZIE-749 oozie tests doesn't delete the files in tmp directories (virag via tucu)
OOZIE-761 Fixes in CoordELFunctions and testcases for Hadoop 0.23 (tucu)
OOZIE-760 oozied.sh needs to be able to pick up CATALINA_HOME (rvs via tucu)
OOZIE-757 hive-contrib version should use ${hive.version} (abayer via tucu)
OOZIE-274 move callback HTTP endpoint outside of the versioned WS endpoints (tucu)
OOZIE-755 remove hadoop.job.ugi and kerberos principal hardcoded injections (tucu)
OOZIE-754 remove use of group from HadoopAccessor (tucu)
OOZIE-752 if group.name/oozie.job.acl is not defined in job.properties job submission fails (tucu)
OOZIE-753 default hadoop config file does not endup in the distro and hadoop config doc typo (tucu)
OOZIE-747 HadoopAccessorService hadoop-configs should be loaded from Hadoop -site.xml files (tucu)
OOZIE-746 JobConf/Configuration creation is inconsistent and makes things fail in odd ways (tucu)
OOZIE-744 HadoopAccessorService hadoop-configs loading logic is not 100% correct (tucu)
OOZIE-743 HadoopAccessorService hadoop configurations should not use VARs from properties defined oozie-site.xml (tucu)
OOZIE-742 getJobInfo for workflows should return workflow external id (Shwetha via Mohammad)
OOZIE-750 enhance ooziedb tool not to require manual upgrade steps and not to require the -sqlfile option (tucu)
OOZIE-684 CoordChangeXCommand already used is thrown while executing interrupt commands (Mohamed via Mohammad)
OOZIE-723 Getting rid of the unused Commands classes (mohamed via tucu)
OOZIE-719 Missing java docs for several methods on ActionXCommand.java (Mohamed via Mohammad)
OOZIE-738 HadoopAccessorService configs typo/missed value (tucu)
OOZIE-737 ooziedb tool does not register SLAEventBean resulting in an incorrect DB creation (tucu)
OOZIE-736 Add support for configurations per JT/NN (tucu)
OOZIE-734 Simplify Kerberos/HadoopAccessorService code and remove Kerberos/DoAs code (tucu)
OOZIE-631 Oozie DB create/upgrade tool (tucu)
OOZIE-729 SubmitMRCommand & SubmitMRXCommant testcases fail with Hadoop 0.23 (tucu)
OOZIE-726 Removing switch from default runtime scope to compile scope for hadooplib.xml assembly due to it pulling in JDK tools.jar with compile scope. (abayer via tucu)
OOZIE-228 For authorization we should use the ACL model (tucu)
OOZIE-715 Fix TestLocalOozieExample (angeloh via tucu)
OOZIE-701 Oozie notification URLs don't get replaced with the taken transition (tucu)
OOZIE-724 TestClassUtils fails as looks for hadoop-core (tucu)
OOZIE-725 Increase JVM MaxPermSize value for the testcases (tucu)
OOZIE-727 make test timeout value configurable via -D (tucu)
OOZIE-677 Add Filter API for status on coordinator actions (Virag Kothari via Angelo)
OOZIE-721 remove obsolete/not-used JobServlet and JobsServlet code (tucu)
OOZIE-626 Roll the oozie log file in GZ format (Kiran Nagasubramanian via Angelo)
OOZIE-693 Fork-join validation doesn't check for the 'error to' transition of nodes (Virag Kothari via Angelo)
OOZIE-616 Moving action prepare FS execution to LauncherMapper ( Kiran Nagasubramanian via Angelo)
OOZIE-687 The start time of the action is set after the job is already submitted to hadoop (Mohamed Battisha vis Angelo)
OOZIE-712 Hive testcases fail with 0.23 (tucu)
OOZIE-710 add a timeout to the surefire configuration (tucu)
OOZIE-704 Sharelib action JARs for testcases should be collected leveraging Maven dependency information (tucu)
OOZIE-703 Improve/Consolidate Hadoop job ID log harvesting logic (tucu)
OOZIE-702 XTestCase minicluster fails with Hadoop 1.x (tucu)
OOZIE-700 update hadooplibs versions (tucu)
OOZIE-698 Make sharelib components version dependency configurable (tucu)
OOZIE-696 scope of oozie-hadoop-test artifact is wrong (tucu)
OOZIE-691 Fix testcases using launcher using Hadoop 0.23.x (tucu)
OOZIE-690 use hadoop-client/hadoop-minicluster artifacts for Hadoop 0.23.1 & trunk (tucu)
OOZIE-689 XTestCase proxyuser settings fails with Hadoop 1.0.0/0.23.1 (tucu)
OOZIE-582 Adding new test cases for the feature - viewing log for coordinator actions in a given date range (harsh via tucu)
OOZIE-499 Broken link in maven docs to config files (harsh via tucu)
OOZIE-636 Validate fork-join (virag via tucu)
OOZIE-685 Update License file with 3rd party license information. (Mohammad)
OOZIE-678 Update NOTICE.txt to reflect the workcount binaries into oozie src(Mohammad)
OOZIE-667 Change the way Oozie brings in Hadoop JARs into the build (tucu)
OOZIE-673 Offset and len option not working as expected.(Virag via Mohammad)
OOZIE-668 Adding license header into minitest/pom.xml.(Mohammad)
OOZIE-665 Shell action doesn't capture multiple key-value pairs.(Mohammad)
OOZIE-666 Oozie's Tomcat admin port is hardcoded. (tucu)
OOZIE-662 Unit test failing: TestHostnameFilter. (tucu)
OOZIE-651 Coordinator rerun fails due to NPE in some cases.(Virag via Mohammad)
OOZIE-655 Information added to Oozie help.(Virag via Mohammad)
OOZIE-642 Year support in dateOffset() El function.(Virag via Mohammad)
OOZIE-652 Add proxyuser capabilities to Oozie HTTP API. (tucu)
OOZIE-591 Oozie continues to materialize new actions after end date modification (Mohamed Battisha vis Angelo)
OOZIE-639 Hive sharelib POM must exclude hadoop-core. (tucu)
OOZIE-635 ShellMain closes the STD/ERR stream while shell is processing. (tucu)
OOZIE-629 Oozie server to prevent usage of dataset initial-instance earlier than the system-defined default value.(Mona via Mohammad)
OOZIE-621 Option to add timeunit for frequency for coordinator jobs filtering.(Kiran via Mohammad)
OOZIE-627 Handle GZ log retrieval failures gracefully.(Kiran via Mohammad)
OOZIE-8   Variable not getting replaced with value in workflow rerun.(Mona via Mohammad)
OOZIE-15  Coordinator input/output event instance should limit 1 instance. (Mona via Mohammad)
OOZIE-633 Create sharelib directory for oozie.(Mohammad)
OOZIE-625 Oozie server not starting due to missing sl4j library for Authenticationfilter. (tucu)
OOZIE-617 Add back Ssh action as extension. (tucu)
OOZIE-578 Support shell action in Oozie WF (Mohammad)
OOZIE-620 POMs clean/tune up before 3.2 release. (tucu)
OOZIE-613 Update documentation for execution order.(Mohammad)
OOZIE-589 Make the command requeue interval configurable.(Mohammad)
OOZIE-156 Add support for a SQOOP action. (tucu)
OOZIE-77  Oozie should support Kerberos authentication on its HTTP REST API. (tucu)
OOZIE-622 Remove system sharelib tests from TestLiteWorkflowAppService. (tucu)
OOZIE-588 Oozie to allow drill down to hadoop job's details (virag/params via Mohammad)
OOZIE-68  Add Hive action. (tucu)
OOZIE-608 Fix test failure for testCoordChangeXCommand, testCoordChangeEndTime Unit
OOZIE-610 Oozie system share lib should have jars per action type. (tucu)
OOZIE-565 Make Oozie compile against Hadoop 0.23. (tucu)
OOZIE-609 Oozie services fail to start with log enabled. (tucu)
OOZIE-607 Pig POM brings in several unneeded dependencies. (tucu)
OOZIE-601 Oozie's POMs should use org.apache.oozie as group. (tucu)
OOZIE-480 In Oozie-site.xml, if we specify oozie.services.ext property is not overriding the services. (tucu)
OOZIE-602 Update the Hadoop version to be an Apache Hadoop version. (tucu)
OOZIE-557 Simplify/normalize testing configuration when using different databases. (tucu via mohammad)
OOZIE-590 Log Retrieval from multiple .gz archive files. (kiran via angeloh)
OOZIE-587 Out of memory issues due to current query design. (virag via angeloh)
OOZIE-600 Bump-up the version to 3.2.0-SNAPSHOT. (mohammad via angeloh)

-- Oozie 3.1.3 release

OOZIE-683 Add DISCLAIMER file in the root.(Mohammad)
OOZIE-681 Update the contents of readme.txt.(Mohammad)
OOZIE-680 oozie's assembly creates an extra level of empty subdirectory for docs. (rvs via tucu)

-- Oozie 3.1.2 release

OOZIE-38 LocalOozie example and improvement
OOZIE-580 use xml element to handle string escape when configure evaluator
OOZIE-585 Coordinator job fail to retrieve log with date range and action range.
OOZIE-553 Ability to view log for coordinator actions that ran in a date range.
OOZIE-581 Fix unit test failure in TestStatusTransitService.java.
OOZIE-579 POM file changes for oozie version 3.1.2.
OOZIE-26 Ability to get the log content from Archived file(.gz format)
OOZIE-554 New filters for all kinds of jobs
OOZIE-556 Sort on Web Console for non-string data type
OOZIE-41 Usability improvement (Additional options) for coordinator job analysis on Web Console
OOZIE-568 distcp action return error code -1
OOZIE-573 error message about misconfig in starting time of coordinator and initial-instance of dataset
OOZIE-571 Oozie validate command doesnt work for schema 0.2
OOZIE-570 Oozie bundle is running but not materializing new actions
OOZIE-25 Removing confusing exception trace during wf suspend/kill/resume
OOZIE-567 Is sub-workflow lib directory not used? Libraries of both parent and child workflows need to be added to classpath
OOZIE-564 Embedded pig within python fails when run using oozie
OOZIE-569 Update documentation on external dataset definition
OOZIE-572 Space missing between id and status for action id >= 1000

-- Oozie 3.1.0 release
OOZIE-37 Documentation related modifications for "log -action" option
OOZIE-35 add auto-rerun for error codes JA008 and JA009 in action executor
OOZIE-21 Fixed bug forked subwf not returning status to the parent wf job
OOZIE-28 update coordinator name to coord job at loadstate of coord-submit to avoid exception of bundle-status-update
OOZIE-22 (Apache) Add support PostgreSQL
OOZIE-10 add user-retry in workflow action
OOZIE-540 CoordKillXCommand command uniqueness and increase priority
OOZIE-552 support multiple shared lib path in oozie
OOZIE-18 Option to view Workflow job details from Coordinator job detail popup
OOZIE-17 Group column for coordinator jobs in Oozie Web Console
OOZIE-11  Adding Distcp Action.
OOZIE-6 Custom filters option and User information column added to Coordinator jobs section of Oozie Web Console
OOZIE-5 Log retrieval for a Coordinator job with large number or actions
OOZIE-7 Ability to view the log information corresponding to particular coordinator actions
OOZIE-541: Update documentation for job-type in WS API
OOZIE-498: Add an email action to Oozie
OOZIE-518: merge changes for OOZIE-101 to ActionEndXCommand
OOZIE-529: workflow kill node message is not resolved and set it to action error message
OOZIE-528: adjust configuration for DBCP data source
OOZIE-522: migrate jpa service changes to master branch from integration branch
OOZIE-520: upgrade openjpa jar to 2.1.0
OOZIE-527: add coordinator 0.3 schema for app name parametrization
OOZIE-518: ${wf:lastErrorNode()} is not set when an action ends in error
OOZIE-516 action errorMessage is not being set
OOZIE-524 add test case to test uniqueness of CoordActionInputCheckXCommand
OOZIE-517 escape characters for xml when create dag evaluator
OOZIE-515 parametrization of 'name' attribute in workflow/coordinator/bundle
OOZIE-523 add new queue class to iterate next callable when current callable type has reached max concorrency
OOZIE-525 Upgrade pom version to 3.1.0.
OOZIE-550 Fs 'move' action made consistent and able to have existing target dir
OOZIE-417 oozie-stop.sh is oblivious to 'catalina.sh stop' failing


-- Oozie 3.0.2 release

OOZIE-118 fix pipes program accept relative path
OOZIE-120 coordinator resolve config default variable
OOZIE-119 relative path in coord dataset include should throw exception if given
OOZIE-115 oozie should check if app path is directory and read the app xml under it

-- Oozie 3.0.1 release

OOZIE-93 coordinator start and end instances doesn't work with float number.
OOZIE-80 Make coordinator backward compatible
OOZIE-58 Add date/time formatting function to coord.
OOZIE-75 fix coord el function actualTime()
OOZIE-73 increase executionPath of wf_actions to 1k.
GH-0566 If Java Main exit code !=0, LauncherMapper should the exit code as the error code
OOZIE-34 LauncherMapper security manager fails when a permission with context is check

-- Oozie 3.0.0 release

GH-0069 Create a coordinator bundle.
GH-0070 Start a coordinator bundle.
GH-0071 Pause a coordinator bundle.
GH-0073 Suspend a coordinator bundle.
GH-0072 Resume a coordinator bundle.
GH-0065 Kill a coordinator bundle.
GH-0074 Variable definition at coordinator bundle level.
GH-0098 XCommand Code refactoring.
GH-0099 JPA command refactor.
GH-0077 Reprocessing of coordinator jobs.
GH-0078 Option to rerun from failed node.
GH-0075 Provide access to date list.
GH-0077 Reprocess a complete coordinator bundle.
GH-0110 Redesign Coordinator Job's status.
GH-0111 Enforce precondition checking when executing coordinator commands.
GH-0066 Oozie should not queue the same command more than once.
GH-0067 Input data check should have a timeout for catch-up mode too.
GH-0084 Reduce Oozie DB issues related to update SQL commands and excessive logging.
GH-0079 Oozie command line documentation for Ops.
GH-0086 Clean up temporary files in the user HDFS directory upon completion.
GH-0141 Oozie uses excessive memory when doing purging.
GH-0166 Modify the logic of adding .so and .so.1 files into cache.
GH-0362 getting the job configuration through oozie command line.
GH-0361 Throttle coordinator action/workflow creation per coordinator job .
GH-0480 Support new Pig API to submit pig job
GH-0461 Mapping the workflow ID to coordinator ID
GH-0588 Adding Bundle to recovery service.
OOZIE-23 Update oozie examples with new namespace version for workflow and coordinator.

-- Oozie 2.3.0 release

GH-0236 add support for -Dname=value to oozie CLI and make -config optional
GH-0108 Add support for Derby as Oozie DB
GH-0189 make ENV setting flexible to allow Unix standard layout for conf/logs/data/tmp
GH-0149 create sharelib module with Pig/Streaming JARs
GH-0119 support for user() EL function in coord apps
GH-0131 add an embedded tomcat in Oozie distribution
GH-0026 add support for multiple workflow XMLs in a single directory
GH-0027 support for a share lib directory in HDFS for workflow action binaries
GH-0106 support for a system share lib directory in HDFS for workflow action binaries
GH-0034 update/simplify examples
GH-0050 Oozie jobs configuration properties with variables should be resolved to concrete values.

-- Oozie 2.2.5 release

GH-0372 Change logs output for missing dependencies
GH-0332 Adding Credentials Module
GH-0066 Add Uniqueness functionality to queue
GH-0141 Oozie uses excessive memory when doing purging

-- Oozie 2.2.3 release

GH-0055 Oozie should not materialize a coordinator job right after its submission if the job will only run in far future
GH-0046 Add support the coordiator job submitted to run in far future

-- Oozie 2.2.2 release

GH-0040 coordinator rerun doesn't consider empty output-event
GH-0041 update ojdbc version
GH-0001 references SVN in bin/mkdistro.sh

-- Oozie 2.2.1 release

GH-0010 POM cleanup, remove unneeded repositories, remove/exclude commons-cli 2.0

-- Oozie 2.2.0 release

- adding Pig version number to pig execution log in launcher log
- simplify Oozie build
- oozie documentation is not included in oozie.war and standalone as docs.zip
- simplify Oozie config/logs loading
- fixing location of RowExpander.js for web console in index.html
- jpa configuration refactoring
- Fix oozie UI
- Stop checking input directories if unable to find anyone directory
- Read default timeout from config file.
- Change update query to only modify required fields.
- Simplify client utility methods
- Http Submission of single MR/PIG job without corresponding workflow.xml
- oozie launcher failed when pig log not found.
- client API addArchive does not link file to a directory
- oozie.libpath needs to start with hdfs://namenode when submit pig job to certain versions of hadoop clusters

-- Oozie 2.1.0 release

- compositecommand uses hardcoded type, this limits concurrency by command type
- testcases time doubled, lot of exceptions on command queue on shutdown
- Set default coordinator action timeout to 2 hours.
- build/assembly changes
- oozie mistakes namenode as the jobtracker at white list validation
- single distribution should work both with Hadoop 20 and 20S
- use comma as separator for datasets
- Oozie should not package the Hadoop JARs
- Whitelist of valid Jobtracker & Namenode URIs
- blank whitelist should allow any namenode/jobtracker
- EL function in oozie coordinator to check data dependencies on the closest future data date
- EL function to generate a UTC date based on another UTC date
- instrumentation for commands in the queue.
- Queue Refactor
- instrumentation for commands in the queue
- Coordinator action rerun
- Change end_time and concurrency for a running coordinator job
- Change pause_time for a running coordinator job
- Annotate error message with jobID
- Set pending in SuspendCommand and reset pending in ResumeCommand
- Set time in super class bean
- Remove unnecessary command and service from the code.
- CoordRecoveryCommand update the job status unconditionally
- Fix admin -version
- Need to revisit prioritization of coordinator commands
- coordinator job takes long time (>10mins) to create new actions when released from being paused
- Set NN and JT Principal in JavaActionExecutor
- Adding support for hadoop 0.20.200
- Update document with two new EL functions in 2.1

-- Oozie 2.0.2 release

-- Oozie coordinator
