<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<!--
  Licensed to the Apache Software Foundation (ASF) under one
  or more contributor license agreements.  See the NOTICE file
  distributed with this work for additional information
  regarding copyright ownership.  The ASF licenses this file
  to you under the Apache License, Version 2.0 (the
  "License"); you may not use this file except in compliance
  with the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<configuration>

    <!-- ************************** VERY IMPORTANT  ************************** -->
    <!-- This file is in the Oozie configuration directory only for reference. -->
    <!-- It is not loaded by Oozie, Oozie uses its own privatecopy.            -->
    <!-- ************************** VERY IMPORTANT  ************************** -->

    <property>
        <name>oozie.output.compression.codec</name>
        <value>gz</value>
        <description>
            The name of the compression codec to use.
            The implementation class for the codec needs to be specified through another property oozie.compression.codecs.
            You can specify a comma separated list of 'Codec_name'='Codec_class' for oozie.compression.codecs
            where codec class implements the interface org.apache.oozie.compression.CompressionCodec.
            If oozie.compression.codecs is not specified, gz codec implementation is used by default.
        </description>
    </property>

    <property>
        <name>oozie.action.mapreduce.uber.jar.enable</name>
        <value>false</value>
        <description>
            If true, enables the oozie.mapreduce.uber.jar mapreduce workflow configuration property, which is used to specify an
            uber jar in HDFS.  Submitting a workflow with an uber jar requires at least Hadoop 2.2.0 or 1.2.0.  If false, workflows
            which specify the oozie.mapreduce.uber.jar configuration property will fail.
        </description>
    </property>

    <property>
        <name>oozie.processing.timezone</name>
        <value>UTC</value>
        <description>
            Oozie server timezone. Valid values are UTC and GMT(+/-)####, for example 'GMT+0530' would be India
            timezone. All dates parsed and genered dates by Oozie Coordinator/Bundle will be done in the specified
            timezone. The default value of 'UTC' should not be changed under normal circumtances. If for any reason
            is changed, note that GMT(+/-)#### timezones do not observe DST changes.
        </description>
    </property>

    <!-- Base Oozie URL: <SCHEME>://<HOST>:<PORT>/<CONTEXT> -->

    <property>
        <name>oozie.base.url</name>
        <value>http://localhost:8080/oozie</value>
        <description>
             Base Oozie URL.
        </description>
    </property>

    <!-- Services -->

    <property>
        <name>oozie.system.id</name>
        <value>oozie-${user.name}</value>
        <description>
            The Oozie system ID.
        </description>
    </property>

    <property>
        <name>oozie.systemmode</name>
        <value>NORMAL</value>
        <description>
            System mode for  Oozie at startup.
        </description>
    </property>

    <property>
        <name>oozie.delete.runtime.dir.on.shutdown</name>
        <value>true</value>
        <description>
            If the runtime directory should be kept after Oozie shutdowns down.
        </description>
    </property>

    <property>
        <name>oozie.services</name>
        <value>
            org.apache.oozie.service.SchedulerService,
            org.apache.oozie.service.InstrumentationService,
            org.apache.oozie.service.MemoryLocksService,
            org.apache.oozie.service.CallableQueueService,
            org.apache.oozie.service.UUIDService,
            org.apache.oozie.service.ELService,
            org.apache.oozie.service.AuthorizationService,
            org.apache.oozie.service.UserGroupInformationService,
            org.apache.oozie.service.HadoopAccessorService,
            org.apache.oozie.service.JobsConcurrencyService,
            org.apache.oozie.service.URIHandlerService,
            org.apache.oozie.service.DagXLogInfoService,
            org.apache.oozie.service.SchemaService,
            org.apache.oozie.service.LiteWorkflowAppService,
            org.apache.oozie.service.JPAService,
            org.apache.oozie.service.StoreService,
            org.apache.oozie.service.CoordinatorStoreService,
            org.apache.oozie.service.SLAStoreService,
            org.apache.oozie.service.DBLiteWorkflowStoreService,
            org.apache.oozie.service.CallbackService,
            org.apache.oozie.service.ActionService,
            org.apache.oozie.service.ShareLibService,
            org.apache.oozie.service.ActionCheckerService,
            org.apache.oozie.service.RecoveryService,
            org.apache.oozie.service.PurgeService,
            org.apache.oozie.service.CoordinatorEngineService,
            org.apache.oozie.service.BundleEngineService,
            org.apache.oozie.service.DagEngineService,
            org.apache.oozie.service.CoordMaterializeTriggerService,
            org.apache.oozie.service.StatusTransitService,
            org.apache.oozie.service.PauseTransitService,
            org.apache.oozie.service.GroupsService,
            org.apache.oozie.service.ProxyUserService,
            org.apache.oozie.service.XLogStreamingService,
            org.apache.oozie.service.JvmPauseMonitorService
        </value>
        <description>
            All services to be created and managed by Oozie Services singleton.
            Class names must be separated by commas.
        </description>
    </property>

    <property>
        <name>oozie.services.ext</name>
        <value> </value>
        <description>
            To add/replace services defined in 'oozie.services' with custom implementations.
            Class names must be separated by commas.
        </description>
    </property>

    <property>
        <name>oozie.service.XLogStreamingService.buffer.len</name>
        <value>4096</value>
        <description>4K buffer for streaming the logs progressively</description>
    </property>

 <!-- HCatAccessorService -->
   <property>
        <name>oozie.service.HCatAccessorService.jmsconnections</name>
        <value>
        default=java.naming.factory.initial#org.apache.activemq.jndi.ActiveMQInitialContextFactory;java.naming.provider.url#tcp://localhost:61616;connectionFactoryNames#ConnectionFactory
        </value>
        <description>
        Specify the map  of endpoints to JMS configuration properties. In general, endpoint
        identifies the HCatalog server URL. "default" is used if no endpoint is mentioned
        in the query. If some JMS property is not defined, the system will use the property
        defined jndi.properties. jndi.properties files is retrieved from the application classpath.
        Mapping rules can also be provided for mapping Hcatalog servers to corresponding JMS providers.
        hcat://${1}.${2}.server.com:8020=java.naming.factory.initial#Dummy.Factory;java.naming.provider.url#tcp://broker.${2}:61616
        </description>
   </property>

    <!-- TopicService -->

   <property>
        <name>oozie.service.JMSTopicService.topic.name</name>
        <value>
        default=${username}
        </value>
        <description>
        Topic options are ${username} or ${jobId} or a fixed string which can be specified as default or for a
        particular job type.
        For e.g To have a fixed string topic for workflows, coordinators and bundles,
        specify in the following comma-separated format: {jobtype1}={some_string1}, {jobtype2}={some_string2}
        where job type can be WORKFLOW, COORDINATOR or BUNDLE.
        e.g. Following defines topic for workflow job, workflow action, coordinator job, coordinator action,
        bundle job and bundle action
        WORKFLOW=workflow,
        COORDINATOR=coordinator,
        BUNDLE=bundle
        For jobs with no defined topic, default topic will be ${username}
        </description>
    </property>

    <!-- JMS Producer connection -->
    <property>
        <name>oozie.jms.producer.connection.properties</name>
        <value>java.naming.factory.initial#org.apache.activemq.jndi.ActiveMQInitialContextFactory;java.naming.provider.url#tcp://localhost:61616;connectionFactoryNames#ConnectionFactory</value>
    </property>

 <!-- JMSAccessorService -->
    <property>
        <name>oozie.service.JMSAccessorService.connectioncontext.impl</name>
        <value>
        org.apache.oozie.jms.DefaultConnectionContext
        </value>
        <description>
        Specifies the Connection Context implementation
        </description>
    </property>


    <!-- ConfigurationService -->

    <property>
        <name>oozie.service.ConfigurationService.ignore.system.properties</name>
        <value>
            oozie.service.AuthorizationService.security.enabled
        </value>
        <description>
            Specifies "oozie.*" properties to cannot be overriden via Java system properties.
            Property names must be separted by commas.
        </description>
    </property>

    <!-- SchedulerService -->

    <property>
        <name>oozie.service.SchedulerService.threads</name>
        <value>10</value>
        <description>
            The number of threads to be used by the SchedulerService to run deamon tasks.
            If maxed out, scheduled daemon tasks will be queued up and delayed until threads become available.
        </description>
    </property>

    <!--  AuthorizationService -->
    
    <property>
        <name>oozie.service.AuthorizationService.authorization.enabled</name>
        <value>false</value>
        <description>
            Specifies whether security (user name/admin role) is enabled or not.
            If disabled any user can manage Oozie system and manage any job.
        </description>
    </property>

    <property>
        <name>oozie.service.AuthorizationService.default.group.as.acl</name>
        <value>false</value>
        <description>
            Enables old behavior where the User's default group is the job's ACL.
        </description>
    </property>

    <!-- InstrumentationService -->

    <property>
        <name>oozie.service.InstrumentationService.logging.interval</name>
        <value>60</value>
        <description>
            Interval, in seconds, at which instrumentation should be logged by the InstrumentationService.
            If set to 0 it will not log instrumentation data.
        </description>
    </property>

    <!-- PurgeService -->
    <property>
        <name>oozie.service.PurgeService.older.than</name>
        <value>30</value>
        <description>
            Completed workflow jobs older than this value, in days, will be purged by the PurgeService.
        </description>
    </property>
    
    <property>
        <name>oozie.service.PurgeService.coord.older.than</name>
        <value>7</value>
        <description>
            Completed coordinator jobs older than this value, in days, will be purged by the PurgeService.
        </description>
    </property>
    
    <property>
        <name>oozie.service.PurgeService.bundle.older.than</name>
        <value>7</value>
        <description>
            Completed bundle jobs older than this value, in days, will be purged by the PurgeService.
        </description>
    </property>

    <property>
        <name>oozie.service.PurgeService.purge.old.coord.action</name>
        <value>false</value>
        <description>
            Whether to purge completed workflows and their corresponding coordinator actions
            of long running coordinator jobs if the completed workflow jobs are older than the value
            specified in oozie.service.PurgeService.older.than.
        </description>
    </property>
    
    <property>
		<name>oozie.service.PurgeService.purge.limit</name>
		<value>100</value>
		<description>
			Completed Actions purge - limit each purge to this value
        </description>
	</property>
	
    <property>
        <name>oozie.service.PurgeService.purge.interval</name>
        <value>3600</value>
        <description>
            Interval at which the purge service will run, in seconds.
        </description>
    </property>
    
    <!-- RecoveryService -->

    <property>
        <name>oozie.service.RecoveryService.wf.actions.older.than</name>
        <value>120</value>
        <description>
            Age of the actions which are eligible to be queued for recovery, in seconds.
        </description>
    </property>

    <property>
        <name>oozie.service.RecoveryService.callable.batch.size</name>
        <value>10</value>
        <description>
            This value determines the number of callable which will be batched together
            to be executed by a single thread.
        </description>
    </property>

    <property>
        <name>oozie.service.RecoveryService.push.dependency.interval</name>
        <value>200</value>
        <description>
            This value determines the delay for push missing dependency command queueing
            in Recovery Service
        </description>
    </property>

    <property>
        <name>oozie.service.RecoveryService.interval</name>
        <value>60</value>
        <description>
            Interval at which the RecoverService will run, in seconds.
        </description>
    </property>

    <property>
        <name>oozie.service.RecoveryService.coord.older.than</name>
        <value>600</value>
        <description>
            Age of the Coordinator jobs or actions which are eligible to be queued for recovery, in seconds.
        </description>
    </property>

	<property>
        <name>oozie.service.RecoveryService.bundle.older.than</name>
        <value>600</value>
        <description>
            Age of the Bundle jobs which are eligible to be queued for recovery, in seconds.
        </description>
    </property>

    <!-- CallableQueueService -->

    <property>
        <name>oozie.service.CallableQueueService.queue.size</name>
        <value>10000</value>
        <description>Max callable queue size</description>
    </property>

    <property>
        <name>oozie.service.CallableQueueService.threads</name>
        <value>10</value>
        <description>Number of threads used for executing callables</description>
    </property>

    <property>
        <name>oozie.service.CallableQueueService.callable.concurrency</name>
        <value>3</value>
        <description>
            Maximum concurrency for a given callable type.
            Each command is a callable type (submit, start, run, signal, job, jobs, suspend,resume, etc).
            Each action type is a callable type (Map-Reduce, Pig, SSH, FS, sub-workflow, etc).
            All commands that use action executors (action-start, action-end, action-kill and action-check) use
            the action type as the callable type.
        </description>
    </property>
    
    <property>
        <name>oozie.service.CallableQueueService.callable.next.eligible</name>
        <value>true</value>
        <description>
            If true, when a callable in the queue has already reached max concurrency,
            Oozie continuously find next one which has not yet reach max concurrency.
        </description>
    </property>

    <property>
        <name>oozie.service.CallableQueueService.InterruptMapMaxSize</name>
        <value>500</value>
        <description>
            Maximum Size of the Interrupt Map, the interrupt element will not be inserted in the map if exceeded the size.
        </description>
    </property>

    <property>
        <name>oozie.service.CallableQueueService.InterruptTypes</name>
        <value>kill,resume,suspend,bundle_kill,bundle_resume,bundle_suspend,coord_kill,coord_change,coord_resume,coord_suspend</value>
        <description>
            Getting the types of XCommands that are considered to be of Interrupt type
        </description>
    </property>

    <!--  CoordMaterializeTriggerService -->

    <property>
        <name>oozie.service.CoordMaterializeTriggerService.lookup.interval
        </name>
        <value>300</value>
        <description> Coordinator Job Lookup interval.(in seconds).
        </description>
    </property>

    <!-- Enable this if you want different scheduling interval for CoordMaterializeTriggerService.
    By default it will use lookup interval as scheduling interval
    <property>
        <name>oozie.service.CoordMaterializeTriggerService.scheduling.interval
        </name>
        <value>300</value>
        <description> The frequency at which the CoordMaterializeTriggerService will run.</description>
    </property>
    -->

    <property>
        <name>oozie.service.CoordMaterializeTriggerService.materialization.window
        </name>
        <value>3600</value>
        <description> Coordinator Job Lookup command materialized each
            job for this next "window" duration
        </description>
    </property>

    <property>
        <name>oozie.service.CoordMaterializeTriggerService.callable.batch.size</name>
        <value>10</value>
        <description>
            This value determines the number of callable which will be batched together
            to be executed by a single thread.
        </description>
    </property>

    <property>
        <name>oozie.service.CoordMaterializeTriggerService.materialization.system.limit</name>
        <value>50</value>
        <description>
            This value determines the number of coordinator jobs to be materialized at a given time.
        </description>
    </property>

    <property>
		<name>oozie.service.coord.normal.default.timeout
		</name>
		<value>10080</value>
		<description>Default timeout for a coordinator action input check (in minutes) for normal job.
            </description>
	</property>

	<property>
		<name>oozie.service.coord.default.max.timeout
		</name>
		<value>86400</value>
		<description>Default maximum timeout for a coordinator action input check (in minutes). 86400= 60days
        </description>
	</property>

	<property>
		<name>oozie.service.coord.input.check.requeue.interval
		</name>
		<value>60000</value>
		<description>Command re-queue interval for coordinator data input check (in millisecond).
        </description>
	</property>

    <property>
        <name>oozie.service.coord.push.check.requeue.interval
        </name>
        <value>600000</value>
        <description>Command re-queue interval for push dependencies (in millisecond).
        </description>
    </property>

    <property>
		<name>oozie.service.coord.default.concurrency
		</name>
		<value>1</value>
		<description>Default concurrency for a coordinator job to determine how many maximum action should
		be executed at the same time. -1 means infinite concurrency.</description>
	</property>

    <property>
		<name>oozie.service.coord.default.throttle
		</name>
		<value>12</value>
		<description>Default throttle for a coordinator job to determine how many maximum action should 
		be in WAITING state at the same time.</description>
	</property>

	<property>
		<name>oozie.service.coord.materialization.throttling.factor
		</name>
		<value>0.05</value>
		<description>Determine how many maximum actions should be in WAITING state for a single job at any time. The value is calculated by 
		this factor X the total queue size.</description>
	</property>

    <property>
        <name>oozie.service.coord.check.maximum.frequency</name>
        <value>true</value>
        <description>
            When true, Oozie will reject any coordinators with a frequency faster than 5 minutes.  It is not recommended to disable
            this check or submit coordinators with frequencies faster than 5 minutes: doing so can cause unintended behavior and
            additional system stress.
        </description>
    </property>

	<!-- ELService -->
    <!--  List of supported groups for ELService -->
	<property>
        <name>oozie.service.ELService.groups</name>
        <value>job-submit,workflow,wf-sla-submit,coord-job-submit-freq,coord-job-submit-nofuncs,coord-job-submit-data,coord-job-submit-instances,coord-sla-submit,coord-action-create,coord-action-create-inst,coord-sla-create,coord-action-start,coord-job-wait-timeout</value>
        <description>List of groups for different ELServices</description>
    </property>

    <property>
        <name>oozie.service.ELService.constants.job-submit</name>
        <value>
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.job-submit</name>
        <value>
        </value>
        <description>
          EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

<!-- Workflow specifics -->
    <property>
        <name>oozie.service.ELService.constants.workflow</name>
        <value>
            KB=org.apache.oozie.util.ELConstantsFunctions#KB,
            MB=org.apache.oozie.util.ELConstantsFunctions#MB,
            GB=org.apache.oozie.util.ELConstantsFunctions#GB,
            TB=org.apache.oozie.util.ELConstantsFunctions#TB,
            PB=org.apache.oozie.util.ELConstantsFunctions#PB,
            RECORDS=org.apache.oozie.action.hadoop.HadoopELFunctions#RECORDS,
            MAP_IN=org.apache.oozie.action.hadoop.HadoopELFunctions#MAP_IN,
            MAP_OUT=org.apache.oozie.action.hadoop.HadoopELFunctions#MAP_OUT,
            REDUCE_IN=org.apache.oozie.action.hadoop.HadoopELFunctions#REDUCE_IN,
            REDUCE_OUT=org.apache.oozie.action.hadoop.HadoopELFunctions#REDUCE_OUT,
            GROUPS=org.apache.oozie.action.hadoop.HadoopELFunctions#GROUPS
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.workflow</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.workflow</name>
        <value>
            firstNotNull=org.apache.oozie.util.ELConstantsFunctions#firstNotNull,
            concat=org.apache.oozie.util.ELConstantsFunctions#concat,
            replaceAll=org.apache.oozie.util.ELConstantsFunctions#replaceAll,
            appendAll=org.apache.oozie.util.ELConstantsFunctions#appendAll,
            trim=org.apache.oozie.util.ELConstantsFunctions#trim,
            timestamp=org.apache.oozie.util.ELConstantsFunctions#timestamp,
            urlEncode=org.apache.oozie.util.ELConstantsFunctions#urlEncode,
            toJsonStr=org.apache.oozie.util.ELConstantsFunctions#toJsonStr,
            toPropertiesStr=org.apache.oozie.util.ELConstantsFunctions#toPropertiesStr,
            toConfigurationStr=org.apache.oozie.util.ELConstantsFunctions#toConfigurationStr,
            wf:id=org.apache.oozie.DagELFunctions#wf_id,
            wf:name=org.apache.oozie.DagELFunctions#wf_name,
            wf:appPath=org.apache.oozie.DagELFunctions#wf_appPath,
            wf:conf=org.apache.oozie.DagELFunctions#wf_conf,
            wf:user=org.apache.oozie.DagELFunctions#wf_user,
            wf:group=org.apache.oozie.DagELFunctions#wf_group,
            wf:callback=org.apache.oozie.DagELFunctions#wf_callback,
            wf:transition=org.apache.oozie.DagELFunctions#wf_transition,
            wf:lastErrorNode=org.apache.oozie.DagELFunctions#wf_lastErrorNode,
            wf:errorCode=org.apache.oozie.DagELFunctions#wf_errorCode,
            wf:errorMessage=org.apache.oozie.DagELFunctions#wf_errorMessage,
            wf:run=org.apache.oozie.DagELFunctions#wf_run,
            wf:actionData=org.apache.oozie.DagELFunctions#wf_actionData,
            wf:actionExternalId=org.apache.oozie.DagELFunctions#wf_actionExternalId,
            wf:actionTrackerUri=org.apache.oozie.DagELFunctions#wf_actionTrackerUri,
            wf:actionExternalStatus=org.apache.oozie.DagELFunctions#wf_actionExternalStatus,
            hadoop:counters=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_counters,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf,
            fs:exists=org.apache.oozie.action.hadoop.FsELFunctions#fs_exists,
            fs:isDir=org.apache.oozie.action.hadoop.FsELFunctions#fs_isDir,
            fs:dirSize=org.apache.oozie.action.hadoop.FsELFunctions#fs_dirSize,
            fs:fileSize=org.apache.oozie.action.hadoop.FsELFunctions#fs_fileSize,
            fs:blockSize=org.apache.oozie.action.hadoop.FsELFunctions#fs_blockSize,
            hcat:exists=org.apache.oozie.coord.HCatELFunctions#hcat_exists
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.WorkflowAppService.WorkflowDefinitionMaxLength</name>
        <value>100000</value>
        <description>
            The maximum length of the workflow definition in bytes
            An error will be reported if the length exceeds the given maximum
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.workflow</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <!-- Resolve SLA information during Workflow job submission -->
	<property>
        <name>oozie.service.ELService.constants.wf-sla-submit</name>
        <value>
            MINUTES=org.apache.oozie.util.ELConstantsFunctions#SUBMIT_MINUTES,
            HOURS=org.apache.oozie.util.ELConstantsFunctions#SUBMIT_HOURS,
            DAYS=org.apache.oozie.util.ELConstantsFunctions#SUBMIT_DAYS
            </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.wf-sla-submit</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.wf-sla-submit</name>
        <value> </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>
    <property>
        <name>oozie.service.ELService.ext.functions.wf-sla-submit</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

<!-- Coordinator specifics -->l
<!-- Phase 1 resolution during job submission -->
<!-- EL Evalautor setup to resolve mainly frequency tags -->
    <property>
        <name>oozie.service.ELService.constants.coord-job-submit-freq</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-job-submit-freq</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-job-submit-freq</name>
        <value>
            coord:days=org.apache.oozie.coord.CoordELFunctions#ph1_coord_days,
            coord:months=org.apache.oozie.coord.CoordELFunctions#ph1_coord_months,
            coord:hours=org.apache.oozie.coord.CoordELFunctions#ph1_coord_hours,
            coord:minutes=org.apache.oozie.coord.CoordELFunctions#ph1_coord_minutes,
            coord:endOfDays=org.apache.oozie.coord.CoordELFunctions#ph1_coord_endOfDays,
            coord:endOfMonths=org.apache.oozie.coord.CoordELFunctions#ph1_coord_endOfMonths,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-job-wait-timeout</name>
        <value>
            coord:days=org.apache.oozie.coord.CoordELFunctions#ph1_coord_days,
            coord:months=org.apache.oozie.coord.CoordELFunctions#ph1_coord_months,
            coord:hours=org.apache.oozie.coord.CoordELFunctions#ph1_coord_hours,
            coord:minutes=org.apache.oozie.coord.CoordELFunctions#ph1_coord_minutes,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-job-submit-freq</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

<!-- EL Evalautor setup to resolve mainly all constants/variables - no EL functions is resolved -->
    <property>
        <name>oozie.service.ELService.constants.coord-job-submit-nofuncs</name>
        <value>
            MINUTE=org.apache.oozie.coord.CoordELConstants#SUBMIT_MINUTE,
            HOUR=org.apache.oozie.coord.CoordELConstants#SUBMIT_HOUR,
            DAY=org.apache.oozie.coord.CoordELConstants#SUBMIT_DAY,
            MONTH=org.apache.oozie.coord.CoordELConstants#SUBMIT_MONTH,
            YEAR=org.apache.oozie.coord.CoordELConstants#SUBMIT_YEAR
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-job-submit-nofuncs</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-job-submit-nofuncs</name>
        <value>
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-job-submit-nofuncs</name>
        <value> </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

<!-- EL Evalautor setup to **check** whether instances/start-instance/end-instances are valid
 no EL functions will be resolved -->
    <property>
        <name>oozie.service.ELService.constants.coord-job-submit-instances</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-job-submit-instances</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-job-submit-instances</name>
        <value>
            coord:hoursInDay=org.apache.oozie.coord.CoordELFunctions#ph1_coord_hoursInDay_echo,
            coord:daysInMonth=org.apache.oozie.coord.CoordELFunctions#ph1_coord_daysInMonth_echo,
            coord:tzOffset=org.apache.oozie.coord.CoordELFunctions#ph1_coord_tzOffset_echo,
            coord:current=org.apache.oozie.coord.CoordELFunctions#ph1_coord_current_echo,
            coord:currentRange=org.apache.oozie.coord.CoordELFunctions#ph1_coord_currentRange_echo,
            coord:offset=org.apache.oozie.coord.CoordELFunctions#ph1_coord_offset_echo,
            coord:latest=org.apache.oozie.coord.CoordELFunctions#ph1_coord_latest_echo,
            coord:latestRange=org.apache.oozie.coord.CoordELFunctions#ph1_coord_latestRange_echo,
            coord:future=org.apache.oozie.coord.CoordELFunctions#ph1_coord_future_echo,
            coord:futureRange=org.apache.oozie.coord.CoordELFunctions#ph1_coord_futureRange_echo,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_formatTime_echo,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:absolute=org.apache.oozie.coord.CoordELFunctions#ph1_coord_absolute_echo,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-job-submit-instances</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

<!-- EL Evalautor setup to **check** whether dataIn and dataOut are valid
 no EL functions will be resolved -->

    <property>
        <name>oozie.service.ELService.constants.coord-job-submit-data</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-job-submit-data</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-job-submit-data</name>
        <value>
            coord:dataIn=org.apache.oozie.coord.CoordELFunctions#ph1_coord_dataIn_echo,
            coord:dataOut=org.apache.oozie.coord.CoordELFunctions#ph1_coord_dataOut_echo,
            coord:nominalTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_nominalTime_echo_wrap,
            coord:actualTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_actualTime_echo_wrap,
            coord:dateOffset=org.apache.oozie.coord.CoordELFunctions#ph1_coord_dateOffset_echo,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_formatTime_echo,
            coord:actionId=org.apache.oozie.coord.CoordELFunctions#ph1_coord_actionId_echo,
            coord:name=org.apache.oozie.coord.CoordELFunctions#ph1_coord_name_echo,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:databaseIn=org.apache.oozie.coord.HCatELFunctions#ph1_coord_databaseIn_echo,
            coord:databaseOut=org.apache.oozie.coord.HCatELFunctions#ph1_coord_databaseOut_echo,
            coord:tableIn=org.apache.oozie.coord.HCatELFunctions#ph1_coord_tableIn_echo,
            coord:tableOut=org.apache.oozie.coord.HCatELFunctions#ph1_coord_tableOut_echo,
            coord:dataInPartitionFilter=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataInPartitionFilter_echo,
            coord:dataInPartitionMin=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataInPartitionMin_echo,
            coord:dataInPartitionMax=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataInPartitionMax_echo,
            coord:dataInPartitions=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataInPartitions_echo,
            coord:dataOutPartitions=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataOutPartitions_echo,
            coord:dataOutPartitionValue=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataOutPartitionValue_echo,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-job-submit-data</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <!-- Resolve SLA information during Coordinator job submission -->
	<property>
        <name>oozie.service.ELService.constants.coord-sla-submit</name>
        <value>
            MINUTES=org.apache.oozie.coord.CoordELConstants#SUBMIT_MINUTES,
            HOURS=org.apache.oozie.coord.CoordELConstants#SUBMIT_HOURS,
            DAYS=org.apache.oozie.coord.CoordELConstants#SUBMIT_DAYS
            </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-sla-submit</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-sla-submit</name>
        <value>
            coord:dataOut=org.apache.oozie.coord.CoordELFunctions#ph1_coord_dataOut_echo,
            coord:nominalTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_nominalTime_echo_fixed,
            coord:actualTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_actualTime_echo_wrap,
            coord:dateOffset=org.apache.oozie.coord.CoordELFunctions#ph1_coord_dateOffset_echo,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph1_coord_formatTime_echo,
            coord:actionId=org.apache.oozie.coord.CoordELFunctions#ph1_coord_actionId_echo,
            coord:name=org.apache.oozie.coord.CoordELFunctions#ph1_coord_name_echo,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:databaseOut=org.apache.oozie.coord.HCatELFunctions#ph1_coord_databaseOut_echo,
            coord:tableOut=org.apache.oozie.coord.HCatELFunctions#ph1_coord_tableOut_echo,
            coord:dataOutPartitions=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataOutPartitions_echo,
            coord:dataOutPartitionValue=org.apache.oozie.coord.HCatELFunctions#ph1_coord_dataOutPartitionValue_echo,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>
    <property>
        <name>oozie.service.ELService.ext.functions.coord-sla-submit</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

 <!--  Action creation for coordinator -->
<property>
        <name>oozie.service.ELService.constants.coord-action-create</name>
        <value>
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-action-create</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-action-create</name>
        <value>
            coord:hoursInDay=org.apache.oozie.coord.CoordELFunctions#ph2_coord_hoursInDay,
            coord:daysInMonth=org.apache.oozie.coord.CoordELFunctions#ph2_coord_daysInMonth,
            coord:tzOffset=org.apache.oozie.coord.CoordELFunctions#ph2_coord_tzOffset,
            coord:current=org.apache.oozie.coord.CoordELFunctions#ph2_coord_current,
            coord:currentRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_currentRange,
            coord:offset=org.apache.oozie.coord.CoordELFunctions#ph2_coord_offset,
            coord:latest=org.apache.oozie.coord.CoordELFunctions#ph2_coord_latest_echo,
            coord:latestRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_latestRange_echo,
            coord:future=org.apache.oozie.coord.CoordELFunctions#ph2_coord_future_echo,
            coord:futureRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_futureRange_echo,
            coord:actionId=org.apache.oozie.coord.CoordELFunctions#ph2_coord_actionId,
            coord:name=org.apache.oozie.coord.CoordELFunctions#ph2_coord_name,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph2_coord_formatTime,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:absolute=org.apache.oozie.coord.CoordELFunctions#ph2_coord_absolute_echo,
            coord:absoluteRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_absolute_range,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-action-create</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>


 <!--  Action creation for coordinator used to only evaluate instance number like ${current (daysInMonth())}. current will be echo-ed -->
<property>
        <name>oozie.service.ELService.constants.coord-action-create-inst</name>
        <value>
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-action-create-inst</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-action-create-inst</name>
        <value>
            coord:hoursInDay=org.apache.oozie.coord.CoordELFunctions#ph2_coord_hoursInDay,
            coord:daysInMonth=org.apache.oozie.coord.CoordELFunctions#ph2_coord_daysInMonth,
            coord:tzOffset=org.apache.oozie.coord.CoordELFunctions#ph2_coord_tzOffset,
            coord:current=org.apache.oozie.coord.CoordELFunctions#ph2_coord_current_echo,
            coord:currentRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_currentRange_echo,
            coord:offset=org.apache.oozie.coord.CoordELFunctions#ph2_coord_offset_echo,
            coord:latest=org.apache.oozie.coord.CoordELFunctions#ph2_coord_latest_echo,
            coord:latestRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_latestRange_echo,
            coord:future=org.apache.oozie.coord.CoordELFunctions#ph2_coord_future_echo,
            coord:futureRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_futureRange_echo,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph2_coord_formatTime,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:absolute=org.apache.oozie.coord.CoordELFunctions#ph2_coord_absolute_echo,
            coord:absoluteRange=org.apache.oozie.coord.CoordELFunctions#ph2_coord_absolute_range,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-action-create-inst</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>
    
        <!-- Resolve SLA information during Action creation/materialization -->
	<property>
        <name>oozie.service.ELService.constants.coord-sla-create</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-sla-create</name>
        <value>
            MINUTES=org.apache.oozie.coord.CoordELConstants#SUBMIT_MINUTES,
            HOURS=org.apache.oozie.coord.CoordELConstants#SUBMIT_HOURS,
            DAYS=org.apache.oozie.coord.CoordELConstants#SUBMIT_DAYS</value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-sla-create</name>
        <value>
            coord:dataOut=org.apache.oozie.coord.CoordELFunctions#ph3_coord_dataOut,
            coord:nominalTime=org.apache.oozie.coord.CoordELFunctions#ph2_coord_nominalTime,
            coord:actualTime=org.apache.oozie.coord.CoordELFunctions#ph2_coord_actualTime,
            coord:dateOffset=org.apache.oozie.coord.CoordELFunctions#ph2_coord_dateOffset,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph2_coord_formatTime,
            coord:actionId=org.apache.oozie.coord.CoordELFunctions#ph2_coord_actionId,
            coord:name=org.apache.oozie.coord.CoordELFunctions#ph2_coord_name,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:databaseOut=org.apache.oozie.coord.HCatELFunctions#ph3_coord_databaseOut,
            coord:tableOut=org.apache.oozie.coord.HCatELFunctions#ph3_coord_tableOut,
            coord:dataOutPartitions=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataOutPartitions,
            coord:dataOutPartitionValue=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataOutPartitionValue,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>
    <property>
        <name>oozie.service.ELService.ext.functions.coord-sla-create</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

<!--  Action start for coordinator -->
<property>
        <name>oozie.service.ELService.constants.coord-action-start</name>
        <value>
        </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.constants.coord-action-start</name>
        <value> </value>
        <description>
            EL constant declarations, separated by commas, format is [PREFIX:]NAME=CLASS#CONSTANT.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.functions.coord-action-start</name>
        <value>
            coord:hoursInDay=org.apache.oozie.coord.CoordELFunctions#ph3_coord_hoursInDay,
            coord:daysInMonth=org.apache.oozie.coord.CoordELFunctions#ph3_coord_daysInMonth,
            coord:tzOffset=org.apache.oozie.coord.CoordELFunctions#ph3_coord_tzOffset,
            coord:latest=org.apache.oozie.coord.CoordELFunctions#ph3_coord_latest,
            coord:latestRange=org.apache.oozie.coord.CoordELFunctions#ph3_coord_latestRange,
            coord:future=org.apache.oozie.coord.CoordELFunctions#ph3_coord_future,
            coord:futureRange=org.apache.oozie.coord.CoordELFunctions#ph3_coord_futureRange,
            coord:dataIn=org.apache.oozie.coord.CoordELFunctions#ph3_coord_dataIn,
            coord:dataOut=org.apache.oozie.coord.CoordELFunctions#ph3_coord_dataOut,
            coord:nominalTime=org.apache.oozie.coord.CoordELFunctions#ph3_coord_nominalTime,
            coord:actualTime=org.apache.oozie.coord.CoordELFunctions#ph3_coord_actualTime,
            coord:dateOffset=org.apache.oozie.coord.CoordELFunctions#ph3_coord_dateOffset,
            coord:formatTime=org.apache.oozie.coord.CoordELFunctions#ph3_coord_formatTime,
            coord:actionId=org.apache.oozie.coord.CoordELFunctions#ph3_coord_actionId,
            coord:name=org.apache.oozie.coord.CoordELFunctions#ph3_coord_name,
            coord:conf=org.apache.oozie.coord.CoordELFunctions#coord_conf,
            coord:user=org.apache.oozie.coord.CoordELFunctions#coord_user,
            coord:databaseIn=org.apache.oozie.coord.HCatELFunctions#ph3_coord_databaseIn,
            coord:databaseOut=org.apache.oozie.coord.HCatELFunctions#ph3_coord_databaseOut,
            coord:tableIn=org.apache.oozie.coord.HCatELFunctions#ph3_coord_tableIn,
            coord:tableOut=org.apache.oozie.coord.HCatELFunctions#ph3_coord_tableOut,
            coord:dataInPartitionFilter=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataInPartitionFilter,
            coord:dataInPartitionMin=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataInPartitionMin,
            coord:dataInPartitionMax=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataInPartitionMax,
            coord:dataInPartitions=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataInPartitions,
            coord:dataOutPartitions=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataOutPartitions,
            coord:dataOutPartitionValue=org.apache.oozie.coord.HCatELFunctions#ph3_coord_dataOutPartitionValue,
            hadoop:conf=org.apache.oozie.action.hadoop.HadoopELFunctions#hadoop_conf
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.ext.functions.coord-action-start</name>
        <value>
        </value>
        <description>
            EL functions declarations, separated by commas, format is [PREFIX:]NAME=CLASS#METHOD.
            This property is a convenience property to add extensions to the built in executors without having to
            include all the built in ones.
        </description>
    </property>

    <property>
        <name>oozie.service.ELService.latest-el.use-current-time</name>
        <value>false</value>
        <description>
            Determine whether to use the current time to determine the latest dependency or the action creation time.
            This is for backward compatibility with older oozie behaviour.
        </description>
    </property>

    <!-- UUIDService -->

    <property>
        <name>oozie.service.UUIDService.generator</name>
        <value>counter</value>
        <description>
            random : generated UUIDs will be random strings.
            counter: generated UUIDs generated will be a counter postfixed with the system startup time.
        </description>
    </property>

    <!-- DBLiteWorkflowStoreService -->

    <property>
        <name>oozie.service.DBLiteWorkflowStoreService.status.metrics.collection.interval</name>
        <value>5</value>
        <description> Workflow Status metrics collection interval in minutes.</description>
    </property>

    <property>
        <name>oozie.service.DBLiteWorkflowStoreService.status.metrics.window</name>
        <value>3600</value>
        <description>
            Workflow Status metrics collection window in seconds. Workflow status will be instrumented for the window.
        </description>
    </property>

    <!-- DB Schema Info, used by DBLiteWorkflowStoreService -->

    <property>
        <name>oozie.db.schema.name</name>
        <value>oozie</value>
        <description>
            Oozie DataBase Name
        </description>
    </property>

   <!-- StoreService -->

    <property>
        <name>oozie.service.JPAService.create.db.schema</name>
        <value>false</value>
        <description>
            Creates Oozie DB.

            If set to true, it creates the DB schema if it does not exist. If the DB schema exists is a NOP.
            If set to false, it does not create the DB schema. If the DB schema does not exist it fails start up.
        </description>
    </property>

    <property>
        <name>oozie.service.JPAService.validate.db.connection</name>
        <value>true</value>
        <description>
            Validates DB connections from the DB connection pool.
            If the 'oozie.service.JPAService.create.db.schema' property is set to true, this property is ignored.
        </description>
    </property>
    
    <property>
        <name>oozie.service.JPAService.validate.db.connection.eviction.interval</name>
        <value>300000</value>
        <description>
            Validates DB connections from the DB connection pool.
            When validate db connection 'TestWhileIdle' is true, the number of milliseconds to sleep 
            between runs of the idle object evictor thread.
        </description>
    </property>
    
    <property>
        <name>oozie.service.JPAService.validate.db.connection.eviction.num</name>
        <value>10</value>
        <description>
            Validates DB connections from the DB connection pool.
            When validate db connection 'TestWhileIdle' is true, the number of objects to examine during
            each run of the idle object evictor thread.
        </description>
    </property>


    <property>
        <name>oozie.service.JPAService.connection.data.source</name>
        <value>org.apache.commons.dbcp.BasicDataSource</value>
        <description>
            DataSource to be used for connection pooling.
        </description>
    </property>
    
    <property>
        <name>oozie.service.JPAService.jdbc.driver</name>
        <value>org.apache.derby.jdbc.EmbeddedDriver</value>
        <description>
            JDBC driver class.
        </description>
    </property>

    <property>
        <name>oozie.service.JPAService.jdbc.url</name>
        <value>jdbc:derby:${oozie.data.dir}/${oozie.db.schema.name}-db;create=true</value>
        <description>
            JDBC URL.
        </description>
    </property>

    <property>
        <name>oozie.service.JPAService.jdbc.username</name>
        <value>sa</value>
        <description>
            DB user name.
        </description>
    </property>

    <property>
        <name>oozie.service.JPAService.jdbc.password</name>
        <value> </value>
        <description>
            DB user password.

            IMPORTANT: if password is emtpy leave a 1 space string, the service trims the value,
                       if empty Configuration assumes it is NULL.

            IMPORTANT: if the StoreServicePasswordService is active, it will reset this value with the value given in
                       the console.
        </description>
    </property>

    <property>
        <name>oozie.service.JPAService.pool.max.active.conn</name>
        <value>10</value>
        <description>
             Max number of connections.
        </description>
    </property>

   <!-- SchemaService -->

    <property>
        <name>oozie.service.SchemaService.wf.ext.schemas</name>
        <value>oozie-sla-0.1.xsd,oozie-sla-0.2.xsd</value>
        <description>
            Schemas for additional actions types.

            IMPORTANT: if there are no schemas leave a 1 space string, the service trims the value,
                       if empty Configuration assumes it is NULL.
        </description>
    </property>
    
    <property>
        <name>oozie.service.SchemaService.coord.ext.schemas</name>
        <value>oozie-sla-0.1.xsd,oozie-sla-0.2.xsd</value>
        <description>
            Schemas for additional actions types.

            IMPORTANT: if there are no schemas leave a 1 space string, the service trims the value,
                       if empty Configuration assumes it is NULL.
        </description>
    </property>

    <property>
        <name>oozie.service.SchemaService.sla.ext.schemas</name>
        <value> </value>
        <description>
            Schemas for semantic validation for GMS SLA.

            IMPORTANT: if there are no schemas leave a 1 space string, the service trims the value,
                       if empty Configuration assumes it is NULL.
        </description>
    </property>
    <!-- CallbackService -->

    <property>
        <name>oozie.service.CallbackService.base.url</name>
        <value>${oozie.base.url}/callback</value>
        <description>
             Base callback URL used by ActionExecutors.
        </description>
    </property>

    <!-- CallbackServlet -->

    <property>
        <name>oozie.servlet.CallbackServlet.max.data.len</name>
        <value>2048</value>
        <description>
            Max size in characters for the action completion data output.
        </description>
    </property>

    <!-- External stats-->

    <property>
        <name>oozie.external.stats.max.size</name>
        <value>-1</value>
        <description>
            Max size in bytes for action stats. -1 means infinite value.
        </description>
    </property>

    <!-- JobCommand -->

    <property>
        <name>oozie.JobCommand.job.console.url</name>
        <value>${oozie.base.url}?job=</value>
        <description>
             Base console URL for a workflow job.
        </description>
    </property>


    <!-- ActionService -->

    <property>
        <name>oozie.service.ActionService.executor.classes</name>
        <value>
            org.apache.oozie.action.decision.DecisionActionExecutor,
            org.apache.oozie.action.hadoop.JavaActionExecutor,
            org.apache.oozie.action.hadoop.FsActionExecutor,
            org.apache.oozie.action.hadoop.MapReduceActionExecutor,
            org.apache.oozie.action.hadoop.PigActionExecutor,
            org.apache.oozie.action.ssh.SshActionExecutor,
            org.apache.oozie.action.oozie.SubWorkflowActionExecutor
        </value>
        <description>
            List of ActionExecutors classes (separated by commas).
            Only action types with associated executors can be used in workflows.
        </description>
    </property>

    <property>
        <name>oozie.service.ActionService.executor.ext.classes</name>
        <value> </value>
        <description>
            List of ActionExecutors extension classes (separated by commas). Only action types with associated
            executors can be used in workflows. This property is a convenience property to add extensions to the built
            in executors without having to include all the built in ones.
        </description>
    </property>

    <!-- ActionCheckerService -->

    <property>
        <name>oozie.service.ActionCheckerService.action.check.interval</name>
        <value>60</value>
        <description>
            The frequency at which the ActionCheckService will run.
        </description>
    </property>

     <property>
        <name>oozie.service.ActionCheckerService.action.check.delay</name>
        <value>600</value>
        <description>
            The time, in seconds, between an ActionCheck for the same action.
        </description>
    </property>

    <property>
        <name>oozie.service.ActionCheckerService.callable.batch.size</name>
        <value>10</value>
        <description>
            This value determines the number of actions which will be batched together
            to be executed by a single thread.
        </description>
    </property>

    <!-- StatusTransitService -->
    <property>
        <name>oozie.service.StatusTransitService.statusTransit.interval</name>
        <value>60</value>
        <description>
            The frequency in seconds at which the StatusTransitService will run.
        </description>
    </property>
    
    <property>
        <name>oozie.service.StatusTransitService.backward.support.for.coord.status</name>
        <value>false</value>
        <description>
            true, if coordinator job submits using 'uri:oozie:coordinator:0.1' and wants to keep Oozie 2.x status transit.
            if set true,
            1. SUCCEEDED state in coordinator job means materialization done.
            2. No DONEWITHERROR state in coordinator job
            3. No PAUSED or PREPPAUSED state in coordinator job
            4. PREPSUSPENDED becomes SUSPENDED in coordinator job
        </description>
    </property>
    
    <property>
        <name>oozie.service.StatusTransitService.backward.support.for.states.without.error</name>
        <value>true</value>
        <description>
            true, if you want to keep Oozie 3.2 status transit.
            Change it to false for Oozie 4.x releases.
            if set true,
            No states like RUNNINGWITHERROR, SUSPENDEDWITHERROR and PAUSEDWITHERROR
            for coordinator and bundle
        </description>
    </property>

    <!-- PauseTransitService -->
    <property>
        <name>oozie.service.PauseTransitService.PauseTransit.interval</name>
        <value>60</value>
        <description>
            The frequency in seconds at which the PauseTransitService will run.
        </description>
    </property>

    <!-- JavaActionExecutor -->
    <!-- This is common to the subclasses of action executors for Java (e.g. map-reduce, pig, hive, java, etc) -->

    <property>
        <name>oozie.action.launcher.mapreduce.job.ubertask.enable</name>
        <value>false</value>
        <description>
            Enables Uber Mode for the launcher job in YARN/Hadoop 2 (no effect in Hadoop 1).
            Setting oozie.launcher.mapreduce.job.ubertask.enable in a an action's configuration section overrides this for that
            action.
        </description>
    </property>
    
    <!-- HadoopActionExecutor -->
    <!-- This is common to the subclasses action executors for map-reduce and pig -->

    <property>
        <name>oozie.action.retries.max</name>
        <value>3</value>
        <description>
           The number of retries for executing an action in case of failure
        </description>
    </property>

    <property>
        <name>oozie.action.hadoop.delete.hdfs.tmp.dir</name>
        <value>false</value>
        <description>
            If set to true, it will delete temporary directory at the end of execution of map reduce action.
        </description>
    </property>

    <!-- PigActionExecutor -->

    <property>
        <name>oozie.action.pig.delete.hdfs.tmp.dir</name>
        <value>false</value>
        <description>
            If set to true, it will delete temporary directory at the end of execution of pig action.
        </description>
    </property>

    <!-- SshActionExecutor -->

    <property>
        <name>oozie.action.ssh.delete.remote.tmp.dir</name>
        <value>false</value>
        <description>
            If set to true, it will delete temporary directory at the end of execution of ssh action.
        </description>
    </property>

    <property>
        <name>oozie.action.ssh.http.command</name>
        <value>curl</value>
        <description>
            Command to use for callback to oozie, normally is 'curl' or 'wget'.
            The command must available in PATH environment variable of the USER@HOST box shell.
        </description>
    </property>

    <property>
        <name>oozie.action.ssh.http.command.post.options</name>
        <value>--data-binary @#stdout --request POST --header "content-type:text/plain"</value>
        <description>
            The callback command POST options.
            Used when the ouptut of the ssh action is captured.
        </description>
    </property>
    
    <property>
        <name>oozie.action.ssh.allow.user.at.host</name>
        <value>true</value>
        <description>
            Specifies whether the user specified by the ssh action is allowed or is to be replaced
            by the Job user
        </description>
    </property>

    <!-- SubworkflowActionExecutor -->

    <property>
        <name>oozie.action.subworkflow.max.depth</name>
        <value>50</value>
        <description>
            The maximum depth for subworkflows.  For example, if set to 3, then a workflow can start subwf1, which can start subwf2,
            which can start subwf3; but if subwf3 tries to start subwf4, then the action will fail.  This is helpful in preventing
            errant workflows from starting infintely recursive subworkflows.
        </description>
    </property>

    <!-- HadoopAccessorService -->

    <property>
        <name>oozie.service.HadoopAccessorService.kerberos.enabled</name>
        <value>false</value>
        <description>
            Indicates if Oozie is configured to use Kerberos.
        </description>
    </property>

    <property>
        <name>local.realm</name>
        <value>LOCALHOST</value>
        <description>
            Kerberos Realm used by Oozie and Hadoop. Using 'local.realm' to be aligned with Hadoop configuration
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.keytab.file</name>
        <value>${user.home}/oozie.keytab</value>
        <description>
            Location of the Oozie user keytab file.
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.kerberos.principal</name>
        <value>${user.name}/localhost@${local.realm}</value>
        <description>
            Kerberos principal for Oozie service.
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.jobTracker.whitelist</name>
        <value> </value>
        <description>
            Whitelisted job tracker for Oozie service.
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.nameNode.whitelist</name>
        <value> </value>
        <description>
            Whitelisted job tracker for Oozie service.
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.hadoop.configurations</name>
        <value>*=hadoop-conf</value>
        <description>
            Comma separated AUTHORITY=HADOOP_CONF_DIR, where AUTHORITY is the HOST:PORT of
            the Hadoop service (JobTracker, YARN, HDFS). The wildcard '*' configuration is
            used when there is no exact match for an authority. The HADOOP_CONF_DIR contains
            the relevant Hadoop *-site.xml files. If the path is relative is looked within
            the Oozie configuration directory; though the path can be absolute (i.e. to point
            to Hadoop client conf/ directories in the local filesystem.
        </description>
    </property>


    <property>
        <name>oozie.service.HadoopAccessorService.action.configurations</name>
        <value>*=action-conf</value>
        <description>
            Comma separated AUTHORITY=ACTION_CONF_DIR, where AUTHORITY is the HOST:PORT of
            the Hadoop MapReduce service (JobTracker, YARN). The wildcard '*' configuration is
            used when there is no exact match for an authority. The ACTION_CONF_DIR may contain
            ACTION.xml files where ACTION is the action type ('java', 'map-reduce', 'pig',
            'hive', 'sqoop', etc.). If the ACTION.xml file exists, its properties will be used
            as defaults properties for the action. If the path is relative is looked within
            the Oozie configuration directory; though the path can be absolute (i.e. to point
            to Hadoop client conf/ directories in the local filesystem.
        </description>
    </property>

    <!-- Credentials -->
    <property>
        <name>oozie.credentials.credentialclasses</name>
        <value> </value>
        <description>
            A list of credential class mapping for CredentialsProvider
        </description>
    </property>

	<property>
        <name>oozie.actions.main.classnames</name>
        <value>distcp=org.apache.hadoop.tools.DistCp</value>
        <description>
            A list of class name mapping for Action classes
        </description>
    </property>

    <property>
        <name>oozie.service.WorkflowAppService.system.libpath</name>
        <value>hdfs:///user/${user.name}/share/lib</value>
        <description>
            System library path to use for workflow applications.
            This path is added to workflow application if their job properties sets
            the property 'oozie.use.system.libpath' to true.
        </description>
    </property>

    <property>
        <name>use.system.libpath.for.mapreduce.and.pig.jobs</name>
        <value>false</value>
        <description>
            If set to true, submissions of MapReduce and Pig jobs will include
            automatically the system library path, thus not requiring users to
            specify where the Pig JAR files are. Instead, the ones from the system
            library path are used.
        </description>
    </property>

    <property>
        <name>oozie.command.default.lock.timeout</name>
        <value>5000</value>
        <description>
            Default timeout (in milliseconds) for commands for acquiring an exclusive lock on an entity.
        </description>
    </property>

    <property>
        <name>oozie.command.default.requeue.delay</name>
        <value>10000</value>
        <description>
            Default time (in milliseconds) for commands that are requeued for delayed execution.
        </description>
    </property>

   <!-- LiteWorkflowStoreService, Workflow Action Automatic Retry -->

    <property>
        <name>oozie.service.LiteWorkflowStoreService.user.retry.max</name>
        <value>3</value>
        <description>
            Automatic retry max count for workflow action is 3 in default.
        </description>
    </property>

    <property>
        <name>oozie.service.LiteWorkflowStoreService.user.retry.inteval</name>
        <value>10</value>
        <description>
            Automatic retry interval for workflow action is in minutes and the default value is 10 minutes.
        </description>
    </property>

    <property>
        <name>oozie.service.LiteWorkflowStoreService.user.retry.error.code</name>
        <value>JA008,JA009,JA017,JA018,JA019,FS009,FS008</value>
        <description>
            Automatic retry interval for workflow action is handled for these specified error code:
            FS009, FS008 is file exists error when using chmod in fs action.
            JA018 is output directory exists error in workflow map-reduce action.
            JA019 is error while executing distcp action.
            JA017 is job not exists error in action executor.
            JA008 is FileNotFoundException in action executor.
            JA009 is IOException in action executor.
            ALL is the any kind of error in action executor.
        </description>
    </property>
    
    <property>
        <name>oozie.service.LiteWorkflowStoreService.user.retry.error.code.ext</name>
        <value> </value>
        <description>
            Automatic retry interval for workflow action is handled for these specified extra error code:
            ALL is the any kind of error in action executor.
        </description>
    </property>
    
    <property>
        <name>oozie.service.LiteWorkflowStoreService.node.def.version</name>
        <value>_oozie_inst_v_1</value>
        <description>
            NodeDef default version, _oozie_inst_v_0 or _oozie_inst_v_1
        </description>
    </property>

    <!-- Oozie Authentication -->

    <property>
        <name>oozie.authentication.type</name>
        <value>simple</value>
        <description>
            Defines authentication used for Oozie HTTP endpoint.
            Supported values are: simple | kerberos | #AUTHENTICATION_HANDLER_CLASSNAME#
        </description>
    </property>

    <property>
        <name>oozie.authentication.token.validity</name>
        <value>36000</value>
        <description>
            Indicates how long (in seconds) an authentication token is valid before it has
            to be renewed.
        </description>
    </property>

    <property>
        <name>oozie.authentication.signature.secret</name>
        <value>oozie</value>
        <description>
            The signature secret for signing the authentication tokens.
            If not set a random secret is generated at startup time.
            In order to authentiation to work correctly across multiple hosts
            the secret must be the same across al the hosts.
        </description>
    </property>

    <property>
      <name>oozie.authentication.cookie.domain</name>
      <value></value>
      <description>
        The domain to use for the HTTP cookie that stores the authentication token.
        In order to authentiation to work correctly across multiple hosts
        the domain must be correctly set.
      </description>
    </property>

    <property>
        <name>oozie.authentication.simple.anonymous.allowed</name>
        <value>true</value>
        <description>
            Indicates if anonymous requests are allowed when using 'simple' authentication.
        </description>
    </property>

    <property>
        <name>oozie.authentication.kerberos.principal</name>
        <value>HTTP/localhost@${local.realm}</value>
        <description>
            Indicates the Kerberos principal to be used for HTTP endpoint.
            The principal MUST start with 'HTTP/' as per Kerberos HTTP SPNEGO specification.
        </description>
    </property>

    <property>
        <name>oozie.authentication.kerberos.keytab</name>
        <value>${oozie.service.HadoopAccessorService.keytab.file}</value>
        <description>
            Location of the keytab file with the credentials for the principal.
            Referring to the same keytab file Oozie uses for its Kerberos credentials for Hadoop.
        </description>
    </property>

    <property>
        <name>oozie.authentication.kerberos.name.rules</name>
        <value>DEFAULT</value>
        <description>
            The kerberos names rules is to resolve kerberos principal names, refer to Hadoop's
            KerberosName for more details.
        </description>
    </property>

    <!-- Coordinator "NONE" execution order default time tolerance -->
    <property>
        <name>oozie.coord.execution.none.tolerance</name>
        <value>1</value>
        <description>
            Default time tolerance in minutes after action nominal time for an action to be skipped
            when execution order is "NONE"
        </description>
    </property>

    <!-- Coordinator Actions default length -->
	<property>
		<name>oozie.coord.actions.default.length</name>
		<value>1000</value>
		<description>
			Default number of coordinator actions to be retrieved by the info command
		</description>
	</property>

	<!-- ForkJoin validation -->
	<property>
		<name>oozie.validate.ForkJoin</name>
		<value>true</value>
		<description>
			If true, fork and join should be validated at wf submission time.
		</description>
	</property>

	<property>
		<name>oozie.coord.action.get.all.attributes</name>
		<value>false</value>
		<description>
			Setting to true is not recommended as coord job/action info will bring all columns of the action in memory.
			Set it true only if backward compatibility for action/job info is required.
		</description>
	</property>

	<property>
		<name>oozie.service.HadoopAccessorService.supported.filesystems</name>
		<value>hdfs,hftp,webhdfs</value>
		<description>
			Enlist the different filesystems supported for federation. If wildcard "*" is specified,
			then ALL file schemes will be allowed.
		</description>
	</property>

        <property>
                <name>oozie.service.URIHandlerService.uri.handlers</name>
                <value>org.apache.oozie.dependency.FSURIHandler</value>
                <description>
                        Enlist the different uri handlers supported for data availability checks.
                </description>
        </property>
    <!-- Oozie HTTP Notifications -->

    <property>
        <name>oozie.notification.url.connection.timeout</name>
        <value>10000</value>
        <description>
            Defines the timeout, in milliseconds, for Oozie HTTP notification callbacks. Oozie does
            HTTP notifications for workflow jobs which set the 'oozie.wf.action.notification.url',
            'oozie.wf.worklfow.notification.url' and/or 'oozie.coord.action.notification.url'
            properties in their job.properties. Refer to section '5 Oozie Notifications' in the
            Workflow specification for details.
        </description>
    </property>


    <!-- Enable Distributed Cache workaround for Hadoop 2.0.2-alpha (MAPREDUCE-4820) -->
    <property>
        <name>oozie.hadoop-2.0.2-alpha.workaround.for.distributed.cache</name>
        <value>false</value>
        <description>
            Due to a bug in Hadoop 2.0.2-alpha, MAPREDUCE-4820, launcher jobs fail to set
            the distributed cache for the action job because the local JARs are implicitly
            included triggering a duplicate check.
            This flag removes the distributed cache files for the action as they'll be
            included from the local JARs of the JobClient (MRApps) submitting the action
            job from the launcher.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.filter.app.types</name>
        <value>workflow_job, coordinator_action</value>
        <description>
            The app-types among workflow/coordinator/bundle job/action for which
            for which events system is enabled.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.event.queue</name>
        <value>org.apache.oozie.event.MemoryEventQueue</value>
        <description>
            The implementation for EventQueue in use by the EventHandlerService.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.event.listeners</name>
        <value>org.apache.oozie.jms.JMSJobEventListener</value>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.queue.size</name>
        <value>10000</value>
        <description>
            Maximum number of events to be contained in the event queue.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.worker.interval</name>
        <value>30</value>
        <description>
            The default interval (seconds) at which the worker threads will be scheduled to run
            and process events.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.batch.size</name>
        <value>10</value>
        <description>
            The batch size for batched draining per thread from the event queue.
        </description>
    </property>

    <property>
        <name>oozie.service.EventHandlerService.worker.threads</name>
        <value>3</value>
        <description>
            Number of worker threads to be scheduled to run and process events.
        </description>
    </property>

    <property>
        <name>oozie.sla.service.SLAService.capacity</name>
        <value>5000</value>
        <description>
             Maximum number of sla records to be contained in the memory structure.
        </description>
    </property>

    <property>
        <name>oozie.sla.service.SLAService.alert.events</name>
        <value>END_MISS</value>
        <description>
             Default types of SLA events for being alerted of.
        </description>
    </property>

    <property>
        <name>oozie.sla.service.SLAService.calculator.impl</name>
        <value>org.apache.oozie.sla.SLACalculatorMemory</value>
        <description>
             The implementation for SLACalculator in use by the SLAService.
        </description>
    </property>

    <property>
        <name>oozie.sla.service.SLAService.job.event.latency</name>
        <value>90000</value>
        <description>
             Time in milliseconds to account of latency of getting the job status event
             to compare against and decide sla miss/met
        </description>
    </property>

    <property>
        <name>oozie.sla.service.SLAService.check.interval</name>
        <value>30</value>
        <description>
             Time interval, in seconds, at which SLA Worker will be scheduled to run
        </description>
    </property>

    <!-- ZooKeeper configuration -->
    <property>
        <name>oozie.zookeeper.connection.string</name>
        <value>localhost:2181</value>
        <description>
            Comma-separated values of host:port pairs of the ZooKeeper servers.
        </description>
    </property>

    <property>
        <name>oozie.zookeeper.namespace</name>
        <value>oozie</value>
        <description>
            The namespace to use.  All of the Oozie Servers that are planning on talking to each other should have the same
            namespace.
        </description>
    </property>

<!--
    <property>
        <name>oozie.instance.id</name>
        <value>${OOZIE_HTTP_HOSTNAME}</value>
        <description>
        Each Oozie server should have its own unique instance id. The default is system property
        =${OOZIE_HTTP_HOSTNAME}= (i.e. the hostname).
        </description>
    </property>
-->


    <!-- Sharelib Configuration -->
    <property>
        <name>oozie.service.ShareLibService.mapping.file</name>
        <value></value>
        <description>
            Sharelib mapping files contains list of key=value,
            where key will be the sharelib name for the action and value is a comma separated list of
            DFS directories or jar files.
            Example.
            oozie.pig_10=hdfs:///share/lib/pig/pig-0.10.1/lib/
            oozie.pig=hdfs:///share/lib/pig/pig-0.11.1/lib/
            oozie.distcp=hdfs:///share/lib/hadoop-2.2.0/share/hadoop/tools/lib/hadoop-distcp-2.2.0.jar
        </description>

    </property>
        <property>
        <name>oozie.service.ShareLibService.fail.fast.on.startup</name>
        <value>false</value>
        <description>
            Fails server starup if sharelib initilzation fails.
        </description>
    </property>

    <property>
        <name>oozie.service.ShareLibService.purge.interval</name>
        <value>1</value>
        <description>
            How often, in days, Oozie should check for old ShareLibs and LauncherLibs to purge from HDFS.
        </description>
    </property>

    <property>
        <name>oozie.action.jobinfo.enable</name>
        <value>false</value>
        <description>
        JobInfo will contain information of bundle, coordinator, workflow and actions. If enabled, hadoop job will have
        property(oozie.job.info) which value is multiple key/value pair separated by ",". This information can be used for
        analytics like how many oozie jobs are submitted for a particular period, what is the total number of failed pig jobs,
        etc from mapreduce job history logs and configuration.
        User can also add custom workflow property to jobinfo by adding property which prefix with "oozie.job.info."
        Eg.
        oozie.job.info="bundle.id=,bundle.name=,coord.name=,coord.nominal.time=,coord.name=,wf.id=,
        wf.name=,action.name=,action.type=,launcher=true"
        </description>
    </property>

    <property>
        <name>oozie.service.XLogStreamingService.max.log.scan.duration</name>
        <value>-1</value>
        <description>
        Max log scan duration in hours. If log scan request end_date - start_date > value,
        then exception is thrown to reduce the scan duration. -1 indicate no limit.
        </description>
    </property>

    <property>
        <name>oozie.service.XLogStreamingService.max.actionlist.log.scan.duration</name>
        <value>-1</value>
        <description>
        Max log scan duration in hours for coordinator job when list of actions are specified.
        If log streaming request end_date - start_date > value, then exception is thrown to reduce the scan duration.
        -1 indicate no limit.
        This setting is separate from max.log.scan.duration as we want to allow higher durations when actions are specified.
        </description>
    </property>

    <!-- JvmPauseMonitorService Configuration -->
    <property>
        <name>oozie.service.JvmPauseMonitorService.warn-threshold.ms</name>
        <value>10000</value>
        <description>
            The JvmPauseMonitorService runs a thread that repeatedly tries to detect when the JVM pauses, which could indicate
            that the JVM or host machine is overloaded or other problems.  This thread sleeps for 500ms; if it sleeps for
            significantly longer, then there is likely a problem.  This property specifies the threadshold for when Oozie should log
            a WARN level message; there is also a counter named "jvm.pause.warn-threshold".
        </description>
    </property>

    <property>
        <name>oozie.service.JvmPauseMonitorService.info-threshold.ms</name>
        <value>1000</value>
        <description>
            The JvmPauseMonitorService runs a thread that repeatedly tries to detect when the JVM pauses, which could indicate
            that the JVM or host machine is overloaded or other problems.  This thread sleeps for 500ms; if it sleeps for
            significantly longer, then there is likely a problem.  This property specifies the threadshold for when Oozie should log
            an INFO level message; there is also a counter named "jvm.pause.info-threshold".
        </description>
    </property>

    <property>
        <name>oozie.service.ZKLocksService.locks.reaper.threshold</name>
        <value>300</value>
        <description>
            The frequency at which the ChildReaper will run.
            Duration should be in sec. Default is 5 min.
        </description>
    </property>

    <property>
        <name>oozie.service.ZKLocksService.locks.reaper.threads</name>
        <value>2</value>
        <description>
            Number of fixed threads used by ChildReaper to
            delete empty locks.
        </description>
    </property>

</configuration>
