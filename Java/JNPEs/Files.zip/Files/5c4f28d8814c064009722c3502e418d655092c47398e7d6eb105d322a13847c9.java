Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: Plantuml Plug-in test
Bundle-SymbolicName: net.sourceforge.plantuml.eclipse.tests
Bundle-Version: 1.1.20
Bundle-Vendor: PlantUML Team
Require-Bundle: org.eclipse.core.runtime;bundle-version="3.3.1",
 org.eclipse.core.resources;bundle-version="3.3.1",
 net.sourceforge.plantuml.eclipse.imagecontrol;bundle-version="1.1.20",
 net.sourceforge.plantuml.eclipse;bundle-version="1.1.20",
 org.junit,
 org.eclipse.ui;bundle-version="3.106.1",
 org.eclipse.ui.editors;bundle-version="3.8.200",
 org.eclipse.ui.ide;bundle-version="3.10.2"
Bundle-ClassPath: .
Bundle-RequiredExecutionEnvironment: JavaSE-1.6
Export-Package: net.sourceforge.plantuml.eclipse.test.util
