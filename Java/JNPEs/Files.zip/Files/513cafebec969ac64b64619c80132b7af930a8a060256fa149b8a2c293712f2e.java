<?xml version="1.0" encoding="UTF-8"?>
<site>
   <feature url="features/net.sourceforge.plantuml.ecore.feature_1.1.20.jar" id="net.sourceforge.plantuml.ecore.feature" version="1.1.20">
      <category name="net.sourceforge.plantuml.feature"/>
   </feature>
   <feature url="features/net.sourceforge.plantuml.feature_1.1.20.jar" id="net.sourceforge.plantuml.feature" version="1.1.20">
      <category name="net.sourceforge.plantuml.feature"/>
   </feature>
   <category-def name="net.sourceforge.plantuml.feature" label="PlantUML Eclipse support"/>
</site>
