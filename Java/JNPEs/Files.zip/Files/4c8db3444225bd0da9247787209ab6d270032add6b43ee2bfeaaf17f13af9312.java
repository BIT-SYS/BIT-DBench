name: BungeeOnlineTime
main: lu.r3flexi0n.bungeeonlinetime.BungeeOnlineTime
version: 5.9
author: R3fleXi0n