
(object Petal
    version    	50
    _written   	"Rose 8.3.0407.2800"
    charSet    	0)

(object Class_Category "dataaccess"
    is_unit    	TRUE
    is_loaded  	TRUE
    quid       	"453E0CD8006C"
    stereotype 	"metamodel"
    exportControl 	"Public"
    logical_models 	(list unit_reference_list
	(object Class_Category "expressions"
	    quid       	"45191D730367"
	    documentation 	"Specifies an expression language that allows its users for form expressions over objects and values, producing other objects and values."
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Expression"
		    quid       	"450E63AB03A2"
		    documentation 	"An expression that evaluates to an object."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4717B87503E5"
			    label      	"l"
			    supplier   	"Logical View::data::classes::TypedElement"
			    quidu      	"4717B7BC031A")
			(object Inheritance_Relationship
			    quid       	"4B85517B009C"
			    supplier   	"Logical View::data::classes::InScope"
			    quidu      	"4B85514B0119"))
		    operations 	(list Operations
			(object Operation "isSideEffectFree"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::isSideEffectFree():Boolean
|body:
|  let parametersAndSignatureAreSideEffectFree:Boolean =
|    self.oclIsKindOf(SignatureCallExpression) implies
|      (self.oclAsType(SignatureCallExpression).parameters->forAll(p|p.isSideEffectFree())
|       and self.oclAsType(SignatureCallExpression).getSignature().sideEffectFree)
|  in
|  if self.oclIsKindOf(ObjectBasedExpression) then
|    self.oclAsType(ObjectBasedExpression).object.isSideEffectFree() and
|    if self.oclIsKindOf(SignatureCallExpression) then
|      parametersAndSignatureAreSideEffectFree
|    else
|      if self.oclIsKindOf(Replace) then
|        self.oclAsType(Replace).with.isSideEffectFree()
|      else
|        if self.oclIsKindOf(ExpressionWithArgument) and self.oclAsType(ExpressionWithArgument).argument->notEmpty() then
|          self.oclAsType(ExpressionWithArgument).argument.isSideEffectFree()
|        else
|          true
|        endif
|      endif
|    endif
|  else if self.oclIsKindOf(FunctionCallExpression) then
|    parametersAndSignatureAreSideEffectFree and self.oclAsType(FunctionCallExpression).calledBlock.isSideEffectFree()
|  else if self.oclIsKindOf(Equals) then
|    self.oclAsType(Equals).left.isSideEffectFree() and self.oclAsType(Equals).right.isSideEffectFree()
|  else if self.oclIsKindOf(ObjectCreationExpression) then
|    self.oclAsType(ObjectCreationExpression).classToInstantiate.valueType
|  else if self.oclIsKindOf(dataaccess::analytics::DimensionExpression) then
|    self.oclAsType(dataaccess::analytics::DimensionExpression).dimensionParameter.ownerSignature.sideEffectFree
|  else if self.oclIsKindOf(Ternary) then
|    self.oclAsType(Ternary).condition.isSideEffectFree() and
|    self.oclAsType(Ternary).trueExpr.isSideEffectFree() and
|    self.oclAsType(Ternary).falseExpr.isSideEffectFree()
|  else if self.oclIsKindOf(dataaccess::expressions::collectionexpressions::CollectionExpression) then
|    self.oclAsType(dataaccess::expressions::collectionexpressions::CollectionExpression).source.isSideEffectFree() and
|    if self.oclIsKindOf(dataaccess::expressions::collectionexpressions::Iterate) then
|      (self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).accumulator.initExpression->notEmpty() implies
|         self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).accumulator.initExpression.isSideEffectFree()) and
|      self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).iteratorExpression.isSideEffectFree()
|    else
|      true
|    endif
|  else if self.oclIsKindOf(dataaccess::expressions::literals::ObjectLiteral) then
|    self.oclAsType(dataaccess::expressions::literals::ObjectLiteral).propertyValues.value->forAll(v|v.isSideEffectFree())
|  else if self.oclIsKindOf(persistence::expressions::All) or self.oclIsKindOf(Replace) or self.oclIsKindOf(This) or self.oclIsKindOf(VariableExpression) or
|  self.oclIsKindOf(dataaccess::expressions::literals::Literal) or self.oclIsKindOf(dataaccess::expressions::fp::AnonymousFunctionExpr) then
|    true
|  else if self.oclIsKindOf(dataaccess::query::Selection) then
|    self.oclAsType(dataaccess::query::Selection).object.isSideEffectFree()
|  else
|    false
|  endif
|  endif
|  endif
|  endif
|  endif
|  endif
|  endif
|  endif
|  endif
|  endif
				    )))
			    quid       	"489D64AF0399"
			    documentation 	"Tells if this expression is side effect-free. An expression has a side effect if it invokes a method or a function that is not described as side effect-free. It is important to note that this has to be checked recursively for nested expressions."
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392")
			(object Operation "evaluatesToEqualAs"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::evaluatesToEqualAs(e:Expression):Boolean
|body:
|  if self=e then
|    true
|  else
|  if self.oclIsKindOf(dataaccess::expressions::literals::NumberLiteral) and e.oclIsKindOf(dataaccess::expressions::literals::NumberLiteral) then
|    self.oclAsType(dataaccess::expressions::literals::NumberLiteral).literal=e.oclAsType(dataaccess::expressions::literals::NumberLiteral).literal
|  else
|    if self.oclIsKindOf(dataaccess::expressions::literals::StringLiteral) and e.oclIsKindOf(dataaccess::expressions::literals::StringLiteral) then
|      self.oclAsType(dataaccess::expressions::literals::StringLiteral).literal=e.oclAsType(dataaccess::expressions::literals::StringLiteral).literal
|    else
|      if self.oclIsKindOf(dataaccess::expressions::literals::ObjectLiteral) and e.oclIsKindOf(dataaccess::expressions::literals::ObjectLiteral) then
|        self.oclAsType(dataaccess::expressions::literals::ObjectLiteral).isEqualTo(e.oclAsType(dataaccess::expressions::literals::ObjectLiteral))
|      else
|        if self.oclIsKindOf(VariableExpression) and e.oclIsKindOf(VariableExpression) then
|          self.oclAsType(VariableExpression).variable = e.oclAsType(VariableExpression).variable
|        else
|          false
|        endif
|      endif
|    endif
|  endif
|  endif
				    )))
			    quid       	"49C0CF0601F4"
			    documentation 	"A conservative estimation that returns true if provably this and the passed expression will evaluate to equal objects. false means that the two expressions may evaluate to different results, not excluding that they can still have equal results; it's just not (yet) provable here."
			    parameters 	(list Parameters
				(object Parameter "e"
				    quid       	"49C0CF0E0167"
				    type       	"Expression"
				    quidu      	"450E63AB03A2"))
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392")
			(object Operation "getUsedAliases"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "*"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.isUnique"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::getUsedAliases():Set(behavioral::actions::Iterator)
|body:
|  if self.oclIsKindOf(VariableExpression) then
|    if self.oclAsType(VariableExpression).variable.oclIsKindOf(behavioral::actions::Iterator) then
|      self.oclAsType(VariableExpression).variable.oclAsType(behavioral::actions::Iterator)->select(i | i.fromClause->notEmpty())->asSet()
|    else
|      Set{}
|    endif
|  else
|    if self.oclIsKindOf(Replace) then
|      self.oclAsType(Replace).object.getUsedAliases()->union(
|      self.oclAsType(Replace).steps.filterFunction.getUsedAliases()->flatten()->asSet())->union(
|      self.oclAsType(Replace).with.getUsedAliases())
|    else
|      if self.oclIsKindOf(dataaccess::query::Selection) then
|        self.oclAsType(dataaccess::query::Selection).object.getUsedAliases()->union(
|        self.oclAsType(dataaccess::query::Selection).selectionExpr.getUsedAliases())
|      else
|        if self.oclIsKindOf(ObjectBasedExpression) then
|          let objectAliases:Set(behavioral::actions::Iterator) = self.oclAsType(ObjectBasedExpression).object.getUsedAliases() in
|          if self.oclIsKindOf(MethodCallExpression) then
|            objectAliases->union(self.oclAsType(MethodCallExpression).parameters.getUsedAliases()->flatten()->asSet())
|          else
|            objectAliases
|          endif
|        else
|          if self.oclIsKindOf(Equals) then
|            self.oclAsType(Equals).left.getUsedAliases()->union(self.oclAsType(Equals).right.getUsedAliases())
|          else
|            if self.oclIsKindOf(FunctionCallExpression) then
|              self.oclAsType(FunctionCallExpression).calledBlock.getUsedAliases()->union(
|                           self.oclAsType(FunctionCallExpression).parameters.getUsedAliases()->flatten()->asSet())
|            else
|              if self.oclIsKindOf(Ternary) then
|                let sat:Ternary = self.oclAsType(Ternary) in
|                sat.condition.getUsedAliases()->union(sat.trueExpr.getUsedAliases())->union(sat.falseExpr.getUsedAliases())
|             else
|                 if self.oclIsKindOf(dataaccess::expressions::collectionexpressions::CollectionExpressionWithArgument) then
|                  self.oclAsType(dataaccess::expressions::collectionexpressions::CollectionExpressionWithArgument).argument.getUsedAliases()->union(
|                  self.oclAsType(dataaccess::expressions::collectionexpressions::CollectionExpressionWithArgument).source.getUsedAliases())
|                else
|                  if self.oclIsKindOf(dataaccess::expressions::collectionexpressions::Iterate) then
|                    self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).iteratorExpression.getUsedAliases()->union(
|                    self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).accumulator.initExpression.getUsedAliases())->union(
|                    self.oclAsType(dataaccess::expressions::collectionexpressions::Iterate).source.getUsedAliases())
|                  else
|                    if self.oclIsKindOf(dataaccess::query::OqlQuery) then
|                      self.oclAsType(dataaccess::query::OqlQuery).fromClauses.fromExpression.getUsedAliases()->flatten()->asSet()->union(
|                      self.oclAsType(dataaccess::query::OqlQuery).condition.getUsedAliases())
|                    else
|                      Set{}
|                    endif
|                  endif
|                endif
|              endif
|            endif
|          endif
|        endif
|      endif
|    endif
|  endif
				    )))
			    quid       	"4B277D73000F"
			    documentation 	"Computes the Iterator objects that are defined by a FromClause of an OqlQuery and that are used in a VariableExpression somewhere inside this expression. Needs to handle all side effect-free expression types. By the current definition, this excludes, e.g., ObjectCreationExpression and therefore its initializers method call expressions."
			    result     	"Iterator"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"47A719D200EA")
			(object Operation "getNamedValuesInScope"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "*"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.isUnique"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::getNamedValuesInScope():Set(NamedValue)
|body:
|  self.addNamedValuesWithNewNames(
|
|  -- First, collect those NamedValues defined immediately for this expression:
|  -- an iterate's body expression sees the iterators and the accumulator
|  let accumulator:Set(data::classes::NamedValue)=self.inIterator.accumulator->asSet() in
|  let iterators:Set(data::classes::NamedValue)=self.inIterator.iterators->asSet() in
|  -- an OQL "from" clause sees all aliases left of it
|  let oqlAliases:Set(data::classes::NamedValue)=(if self.fromClause->notEmpty() then
|    let fromClauses:OrderedSet(dataaccess::query::FromClause) = self.fromClause.fromClauseOfOqlQuery.fromClauses in
|    let fcIndex:Integer = fromClauses->indexOf(self.fromClause) in
|      Sequence{1..-1+fcIndex}->collect(i | fromClauses->at(i).alias)->asSet()
|  else
|    Set{}
|  endif)->union(
|  -- an OQL "where" clause sees all aliases defined by any of the OQL expression's "from" entries
|  self.conditionOfOqlQuery.fromClauses.alias->asSet()) in
|  -- a Selection defines an implicit iterator for its filter expression
|  let selectionIterator:Set(data::classes::NamedValue)=self.selection.iterator->asSet() in
|  -- a GroupBy's mapExpression sees all dimension iterators and the groupedFacts iterator
|  let groupByMapExpressionIterators:Set(data::classes::NamedValue)=self.mapExpressionOfGroupBy.groupedFacts->asSet()->union(
|                                                    self.mapExpressionOfGroupBy.dimensions.iterator->asSet()) in
|  -- a GroupBy's dimension expression sees the facts iterator
|  let groupByDimensionFactIterator:Set(data::classes::NamedValue)=self.dimension.groupBy.fact->asSet() in
|
|  accumulator->union(iterators)->union(oqlAliases)->union(selectionIterator)->union(groupByMapExpressionIterators)->
|  union(groupByDimensionFactIterator),
|
|  -- Then, add those defined by owning structures such as owning statements or owning expressions
|  -- an expression that is used by an ExpressionStatement or as condition in a Conditional sees all named values that the statement sees
|  if self.actualObjectParameter.owningClassTypeDefinition->notEmpty() then
|    self.actualObjectParameter.owningClassTypeDefinition.getNamedValuesInScope()
|  else
|    if self.initExpressionFor.namedValueDeclaration->notEmpty() then
|      self.initExpressionFor.namedValueDeclaration.getNamedValuesInScope()
|    else
|      if self.expressionStatement->notEmpty() then
|        self.expressionStatement.getNamedValuesInScope()
|      else
|        if self.conditional->notEmpty() then
|          if self.conditional.oclIsKindOf(behavioral::actions::ConditionalStatement) then
|            self.conditional.oclAsType(behavioral::actions::ConditionalStatement).getNamedValuesInScope()
|          else
|            self.conditional.oclAsType(ConditionalExpression).getNamedValuesInScope()
|          endif
|        else
|          if self.argumentOf->notEmpty() and self.argumentOf.oclIsKindOf(behavioral::actions::StatementWithArgument) then
|            self.argumentOf.oclAsType(behavioral::actions::StatementWithArgument).getNamedValuesInScope()
|          else
|            -- add all variables in scope for owning expressions
|            let oe:Expression = self.getOwningExpression() in
|              if oe->isEmpty() then
|                Set{}
|              else
|                oe.getNamedValuesInScope()
|              endif
|          endif
|        endif
|      endif
|    endif
|  endif
|  )
				    )))
			    quid       	"4B83E38F033C"
			    result     	"NamedValue"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4522A56F0149")
			(object Operation "getOwningExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "0..1"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::getOwningExpression():Expression
|body:
|  let objectBasedExpressions:Set(Expression)=self.objectBasedExpression->asSet() in
|  let argumentsOf:Set(Expression)=self.argumentOf->select(ao | ao.oclIsKindOf(Expression)).oclAsType(ExpressionWithArgument)->asSet() in
|  let equals:Set(Expression)=self.leftOfEquals->asSet()->union(self.rightOfEquals->asSet()) in
|  let blocksOfFunctionCallExpression:Set(Expression)=self.blockOfFunctionCallExpression->asSet() in
|  let signatureCalls:Set(Expression)=self.usedAsArgumentInSignatureCall->asSet() in
|  let creationExpression:Set(Expression)=if self.oclIsKindOf(MethodCallExpression) then
|    self.oclAsType(MethodCallExpression).creationExpression->asSet()
|  else
|    Set{}
|  endif in
|  let ternary:Set(Expression)=self.trueOfTernary->asSet()->union(self.falseOfTernary->asSet()) in
|  let conditional:Set(Expression)=if self.conditional->notEmpty() and self.conditional.oclIsKindOf(ConditionalExpression) then
|    self.conditional.oclAsType(ConditionalExpression)->asSet()
|  else
|    Set{}
|  endif in
|  let replace:Set(Expression)=self.withOfReplace->asSet()->union(self.navigationStep.replace->asSet()) in
|  let oqlQuery:Set(Expression)=self.conditionOfOqlQuery->asSet()->union(self.fromClause.fromClauseOfOqlQuery->asSet()) in
|  let selection:Set(Expression)=self.selection->asSet() in
|  let objectLiteral:Set(Expression)=self.valueInit.objectLiteral->asSet() in
|  let iterator:Set(Expression)=self.inIterator->asSet() in
|  let collectionExpression:Set(Expression)=self.collectionExpression->asSet() in
|  let all:Set(Expression)=self.all->asSet() in
|  let valueInitInObjectLiteral:Set(Expression)=self.valueInit.objectLiteral->asSet() in
|  let dimensionExpression:Set(Expression)=self.cellSetOfDimensionExpression->asSet()->union(
|                                                                   self.factsOfDimensionExpression->asSet()) in
|  let groupByExpression:Set(Expression)=self.dimension.groupBy->asSet()->union(
|                                                                   self.mapExpressionOfGroupBy->asSet()) in
|
|  objectBasedExpressions->union(argumentsOf)->union(equals)->union(blocksOfFunctionCallExpression)->union(
|  signatureCalls)->union(creationExpression)->union(ternary)->union(conditional)->union(replace)->union(
|  oqlQuery)->union(selection)->union(objectLiteral)->union(iterator)->union(collectionExpression)->union(
|  all)->union(valueInitInObjectLiteral)->union(dimensionExpression)->union(groupByExpression)->any(true)
				    )))
			    quid       	"4B83F58702BF"
			    documentation 	
|If this expression is composed by another expression, determines the composing expression. Otherwise, an empty result is returned.
|
|The issue with this operation is that each time a new inbound composite relatioship is added to Expression, this operation needs to be extended accordingly.
			    
			    result     	"Expression"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"450E63AB03A2")
			(object Operation "getOwningClass"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "0..1"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Expression::getOwningClass():SapClass
|body:
|  let oe:Expression = self.getOwningExpression() in
|  if oe->notEmpty() then
|    oe.getOwningClass()
|  else
|    if self.expressionStatement->notEmpty() then
|      self.expressionStatement.getOwningClass()
|    else
|      if self.conditional->notEmpty() and self.conditional.oclIsKindOf(behavioral::actions::Statement) then
|        self.conditional.oclAsType(behavioral::actions::ConditionalStatement).getOwningClass()
|      else
|        if self.argumentOf->notEmpty() and self.argumentOf.oclIsKindOf(behavioral::actions::StatementWithArgument) then
|          self.argumentOf.oclAsType(behavioral::actions::StatementWithArgument).getOwningClass()
|        else
|          if self.initExpressionFor.namedValueDeclaration->notEmpty() then
|            self.initExpressionFor.namedValueDeclaration.getOwningClass()
|          else
|            null
|          endif
|        endif
|      endif
|    endif
|  endif
				    )))
			    quid       	"4B84EE28030D"
			    result     	"SapClass"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4432171B031E"))
		    abstract   	TRUE)
		(object Class "VariableExpression"
		    quid       	"4522AC6A022F"
		    documentation 	
|The variable referenced by this type of expression must be visible within the scope where this expression occurs.
|
|TODO: How to determine the block containing this VariableExpression? This will be important to determine if the variable is visible.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4545FDBE01AE"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    nestedClasses 	(list nestedClasses
			(object Class "VariableExpressionType"
			    quid       	"4522AE490300"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4522AE420101"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context VariableExpression
|inv:
|    self.getType().conformsTo(self.variable.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "MethodCallExpression"
		    quid       	"4522E05D00A8"
		    documentation 	
|The MethodCallExpression executes an implementation of the signature using the "parameters" expressions as arguments on the object evaluated by the "object" expression. For that, first the "object" expression is evaluated. the parameter expressions (if provided) are evaluated and then passed to the implementation.
|
|The object expression must evaluate to a single value, i.e., a TypeDefinition with upperMultiplicity = 1.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"47BC30F40203"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335")
			(object Inheritance_Relationship
			    quid       	"47F3B83200B9"
			    supplier   	"Logical View::dataaccess::expressions::SignatureCallExpression"
			    quidu      	"47F3B80500BD"))
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "asynchronous"
			    quid       	"4549FF6500B0"
			    documentation 	"An operation may be invoked asynchronously. If the operation returns a value, it is ignored, as are any exceptions raised by the operation. An OperationExpression with this attribute set to true has itself no type and therefore cannot reasonably be used in a side effect-free expression but only as a statement."
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public"))
		    nestedClasses 	(list nestedClasses
			(object Class "ObjectMustSupportOperation"
			    quid       	"4548A9B600A7"
			    documentation 	"TODO: What does applying a signature call expression to a value with multiplicity >1 mean? Invoke on all elements within?"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4548A9C503C0"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context MethodCallExpression
|inv:
|  self.object.getType().getInnermost().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.object.getType().getInnermost().oclAsType(data::classes::ClassTypeDefinition).clazz.conformsTo(self.methodSignature.owner.oclAsType(data::classes::SapClass))
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "OutputMultiplicities"
			    quid       	"48A9EB710138"
			    documentation 	
|Requires an upper multiplicity on the expression's type at least as great as the product of the upper multiplicities of the "this" (multi-)object and the signature output.
|
|Similarly, for the lower multiplicities the minimum multiplicity must allow for the product of the respective two lower multiplicities or fewer.
|
|Make sure that a MethodCallExpression's type is always non-unique in case the object expression has upper multiplicity >1. Rationale: the method implementation may be non-injective, mapping two different objects to equal/same results. In this case the results would get messed up and could probably not be associated appropriately anymore with the source objects.
			    
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48A9EB820222"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context MethodCallExpression
|inv:
|  (self.object.getType().isMany() implies (self.getType().isMany() and not self.getType().unique)) and
|  (self.object.getType().lowerMultiplicity = 0 implies (self.getType()->isEmpty() or self.getType().lowerMultiplicity = 0))
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ObjectBasedExpression"
		    quid       	"453E0FC80335"
		    documentation 	
|A specific type of expression that is evaluated in the context of a specific object. Another expression is used to determine this object. An example for such an expression would be association navigation, where the object where the navigation starts has to be specified by the "object" expression.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"453E0FF30001"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    abstract   	TRUE)
		(object Class "ObjectCreationExpression"
		    quid       	"454BA26C0254"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"454BA274017C"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    nestedClasses 	(list nestedClasses
			(object Class "CannotInstantiateAbstractClass"
			    quid       	"454BA2AC006C"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"454BA2B70224"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCreationExpression
|inv:
|    not self.classToInstantiate.isAbstract()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ExpressionType"
			    quid       	"4759551601E4"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4759552102CE"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCreationExpression
|inv:
|  self.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.getType().oclAsType(data::classes::ClassTypeDefinition).clazz = self.classToInstantiate and
|  self.getType().lowerMultiplicity = 1 and
|  self.getType().upperMultiplicity = 1
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "HasToOwnTypeDefinition"
			    quid       	"47862616005D"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47862623004E"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCreationExpression
|inv:
|  self.ownedTypeDefinition->notEmpty()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "CannotInstantiateValueClass"
			    quid       	"4A08420603CA"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4A084218022C"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCreationExpression
|inv:
|    not self.classToInstantiate.valueType
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "NoDuplicateInitializers"
			    quid       	"4B1CF9F603B4"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B1CFA1102B9"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCreationExpression
|inv:
|    self.initializers->forAll( a, b | a <> b implies a.methodSignature <> b.methodSignature )
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "FunctionCallExpression"
		    quid       	"45473F620076"
		    documentation 	
|An expression that is computed by first evaluating "calledBlock" and invoking the resulting block passing the "argument" expression. The value returned by the block constitutes the value of this expression. If the block terminates with a fault, the evaluation of this expression terminates with this fault.
|
|The type of the object computed by the "parameters" expression must conform to the input parameter types of the signature called.
|
|If the calledBock evaluates to more than one callable function, all functions will be called. Invocation ordering depends on the side effect-freeness of the signatures called.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"47F3B84601D1"
			    supplier   	"Logical View::dataaccess::expressions::SignatureCallExpression"
			    quidu      	"47F3B80500BD"))
		    nestedClasses 	(list nestedClasses
			(object Class "ResultType"
			    quid       	"4786256B0109"
			    documentation 	
|Invoking a object whose type is defined by a FunctionSignatureTypeDefinition produces an object whose type definition at its core has the type definition of the signature's output, but probably with a different multiplicity, perhaps nested, according to the following rules.
|
|If the FunctionSignatureTypeDefinition has an upper multiplicity of 1, all resulting multiplicity properties are equal to those of the signature's output type definition except for the lower multiplicity which is forced to 0 if that of the FunctionSignatureTypeDefinition is 0.
|
|If the FunctionSignatureTypeDefinition has an upper multiplicity greater than 1, the resulting type definition is a NestedTypeDefinition with exactly the multiplicity properties of the FunctionSignatureTypeDefinition, where the inner type is exactly that of the signature's output.
			    
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47862574000F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context FunctionCallExpression
|inv:
|  let fstd:data::classes::FunctionSignatureTypeDefinition = self.calledBlock.getType().getInnermost().oclAsType(data::classes::FunctionSignatureTypeDefinition) in
|
|  if fstd.isMany() then
|    -- calling multiple functions; test is somewhat fuzzy because it doesn't test condormance of nesting structure exactly
|    self.getType().isMany() and not self.getType().unique and
|    fstd.signature.output.getInnermost().conformsTo(self.getType().getInnermost()) and
|    (fstd.lowerMultiplicity = 0 implies (self.getType()->isEmpty() or self.getType().lowerMultiplicity = 0))
|  else
|    -- calling a single function
|    fstd.signature.output.conformsTo(self.getType()) and 
|    (fstd.lowerMultiplicity = 0 implies (self.getType()->isEmpty() or self.getType().lowerMultiplicity = 0))
|  endif
|
|
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "CalledBlockMustBeFunction"
			    quid       	"4AD977480271"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4AD9775401D4"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context FunctionCallExpression
|inv:
|  self.calledBlock.getType().getInnermost().oclIsKindOf(data::classes::FunctionSignatureTypeDefinition)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "WithArgument"
		    quid       	"4577E587019C"
		    abstract   	TRUE)
		(object Class "This"
		    quid       	"45A9433E03D2"
		    documentation 	
|Statically, the This expression has the type that owns its occurrence. This means, in order to determine this, the getType implementation needs to ascend the composition hierarchy until it finds a Class somewhere. The problem, again, is that an OCL expression cannot manufacture the result required becauce currently TypeDefinition is still an "entity type," meaning a MOF class whose instances have ID and an explicit life cycle.
|
|Therefore, currently This has to own its type definition, unfortunately.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"45A94345036E"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2")))
		(object Class "Equals"
		    quid       	"475958230399"
		    documentation 	
|compares two or more values/objects. Entity type instances are compared based on their identity. Value type instances are compared by their value. The type of an Equals expression is Boolean.
|
|The getType() implementation can only infer the type once TypeDefinition is a value type, values of which can be constructed in an OCL expression.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4759582D007D"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    nestedClasses 	(list nestedClasses
			(object Class "ConformaceOneWayOrAnother"
			    quid       	"4B06B6950157"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B06B69E0203"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Equals
|inv:
|  self.left.getType().conformsTo(self.right.getType()) or
|  self.right.getType().conformsTo(self.left.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "AssociationEndNavigationExpression"
		    quid       	"478620130157"
		    documentation 	
|Navigates from the "object" across the "toEnd"'s association to the "toEnd". The expression evaluates to the objects at the "toEnd" that are associated with the "object" based on the end's association.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4786201B036B"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "ObjectTypeMustMatch"
			    quid       	"478620BF032C"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"478620D90271"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context AssociationEndNavigationExpression
|inv:
|  self.object.getType().conformsToIgnoringMultiplicity(self.toEnd.otherEnd().type)
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ResultType"
			    quid       	"478621470399"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4786214F036B"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context AssociationEndNavigationExpression
|inv:
|  self.getType() = self.toEnd.type
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "EndMustBeNavigable"
			    quid       	"4873524B034B"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"487352570290"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context AssociationEndNavigationExpression
|inv:
|  self.toEnd.navigable
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "SignatureCallExpression"
		    quid       	"47F3B80500BD"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"47F3B890000D"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    operations 	(list Operations
			(object Operation "getSignature"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context SignatureCallExpression::getSignature():Signature
|body:
|  if self.oclIsKindOf(FunctionCallExpression) then
|    self.oclAsType(FunctionCallExpression).calledBlock->collect(getType().getInnermost().oclAsType(data::classes::FunctionSignatureTypeDefinition).signature)
|  else
|    self.oclAsType(MethodCallExpression).methodSignature
|  endif
				    )))
			    quid       	"4939043400CB"
			    documentation 	"For FunctionCallExpression, this retrieves the signature from the type of the calledBlock expression which is required to be a FunctionSignatureTypeDefinition. For MethodCallExpression, it obtains the signature by navigating to the methodSignature role."
			    result     	"Signature"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4432198602CB")
			(object Operation "getMultiplicityOfCallTarget"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context SignatureCallExpression::getMultiplicityOfCallTarget():Multiplicity
|body:
|  if self.oclIsKindOf(FunctionCallExpression) then
|      self.oclAsType(FunctionCallExpression).calledBlock.getType()
|  else
|      self.oclAsType(MethodCallExpression).object.getType()
|  endif
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"4AD4791F02AF"
			    result     	"Multiplicity"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"47554DA003A9"))
		    abstract   	TRUE
		    nestedClasses 	(list nestedClasses
			(object Class "ParametersTypesMustMatchSignatureParametersTypes"
			    quid       	"47F3BCCA0255"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47F3BCFB017B"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context SignatureCallExpression
|inv:
|  let numberOfMandatoryParameters:Integer =
|    self.getSignature().input->select(p|p.defaultValue->isEmpty())->size()
|  in
|  self.parameters->size() >= numberOfMandatoryParameters and
|  self.parameters->size() <= self.getSignature().input->size() and
|  self.parameters->forAll(parameter |
|    parameter.getType().conformsTo(self.getSignature().input->at(self.parameters->indexOf(parameter)).getType()) )
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "CallTypeMustMatchSignatureOutput"
			    quid       	"48A9EA3E0213"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48A9EA540128"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context SignatureCallExpression
|inv:
|    if self.getSignature().output.oclIsUndefined() then
|        self.getType().oclIsUndefined()
|    else 
|        if self.getMultiplicityOfCallTarget().isMany() and self.getSignature().output.isMany() then
|            let ntd:data::classes::NestedTypeDefinition = self.getType().oclAsType(data::classes::NestedTypeDefinition) in
|                self.getType().oclIsKindOf(data::classes::NestedTypeDefinition) and 
|                ntd.unique = false and
|                ntd.ordered = self.getMultiplicityOfCallTarget().ordered and
|                ntd.lowerMultiplicity = self.getMultiplicityOfCallTarget().lowerMultiplicity and
|                ntd.upperMultiplicity = self.getMultiplicityOfCallTarget().upperMultiplicity and
|                self.getSignature().output.conformsTo(ntd.type)
|        else
|            let target:data::classes::Multiplicity = self.getMultiplicityOfCallTarget() in
|            let output:data::classes::TypeDefinition = self.getSignature().output in 
|                ( output.isMany() implies self.getType().unique = output.unique ) and
|                ( ( output.isMany() or target.isMany() ) implies ( self.getType().ordered = (output.ordered or target.ordered) ) ) and
|                ( self.getType().lowerMultiplicity = (output.lowerMultiplicity * target.lowerMultiplicity)) and
|                ( self.getType().upperMultiplicity = (if output.isMany() or target.isMany() then 
|                                                        -1 
|                                                    else 
|                                                        output.upperMultiplicity * target.upperMultiplicity 
|                                                    endif)) and
|                self.getType().conformsToIgnoringMultiplicity(output)
|        endif
|    endif
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ObjectCount"
		    quid       	"48E9DE8C030D"
		    documentation 	
|Computes the Number 1 for single objects, and the number of objects in a multi-valued object otherwise.
|
|Type inference in getType() can be done once TypeDefinition is a value type that can be constructed in OCL.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"48E9DEC500AB"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "TypeIsNumber"
			    quid       	"48E9DFA5007D"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48E9DFC0038A"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCount
|inv:
|  self.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.name = 'Number'
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "MultiplicityIsOne"
			    quid       	"48E9DFB5035B"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48E9DFC5000F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ObjectCount
|inv:
|  self.getType().upperMultiplicity = 1 and
|  self.getType().lowerMultiplicity = 1
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Replace"
		    quid       	"499C2988038A"
		    documentation 	
|An abstract-syntactical convenience to construct a value from an existing one, replacing a component somewhere in the possibly deep structure that the value has.
|
|The replacement always produces a value of the same type as the source value. It can provide a navigation path, following associations, staying withing values, with the last path component being allowed to end at an entity or a value class. Each path segment may add a constraint which makes sense specifically for multiplicities greater than one.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"499C2A7A004E"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "SourceObjectIsOfValueType"
			    quid       	"499C2A90033C"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"499C2A9C02DE"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Replace
|inv:
|  self.object.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.object.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.valueType
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "WithTypeConformsToLastStepsType"
			    quid       	"499D6B0F0399"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"499D6B2901B5"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Replace
|inv:
|  self.with.getType().conformsTo(self.steps->at(self.steps->size()).to.type)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "NavigationStep"
		    quid       	"499D4031000F"
		    nestedClasses 	(list nestedClasses
			(object Class "FromEndAttachesToOutputOfPreviousStep"
			    quid       	"499D5D4403B9"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"499D5D900109"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context NavigationStep
|inv:
|  let i:Integer = self.replace.steps->indexOf(self) in
|  let t:data::classes::ClassTypeDefinition = if i=1 then
|      self.replace.object.getType().oclAsType(data::classes::ClassTypeDefinition)
|    else
|      self.replace.steps->at(-1 + i).to.type
|    endif
|  in
|
|  self.to.otherEnd().type.clazz.conformsTo(t.clazz)
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "FilterFunctionExpressionHasFunctionType"
			    quid       	"499D8ECA002E"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"499D8EDC0128"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context NavigationStep
|inv:
|  self.filterFunction->notEmpty() implies self.filterFunction.getType().oclIsKindOf(data::classes::FunctionSignatureTypeDefinition)
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "FromEndMustBeEqualityRelevant"
			    quid       	"499E87D601C5"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"499E87E3008C"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context NavigationStep
|inv:
|  to.otherEnd().contributesToEquality
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Head"
		    quid       	"49BFCF80001E"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49BFCFE2021E"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "IsOrdered"
			    quid       	"49BFD86F023A"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"49BFD8850380"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Head
|inv:
|  self.object.getType().ordered
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Tail"
		    quid       	"49BFCF9E020B"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49BFCFDF0087"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "IsOrdered"
			    quid       	"49BFD8380366"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"49BFD85002D8"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Tail
|inv:
|  self.object.getType().ordered
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "AsList"
		    quid       	"49BFD73E033E"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49BFD7480223"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335")))
		(object Class "Conditional"
		    quid       	"45471B4401F7"
		    documentation 	"Some statement depending on a Boolean expression"
		    abstract   	TRUE
		    nestedClasses 	(list nestedClasses
			(object Class "ConditionMustBeBoolean"
			    quid       	"45471BB2005B"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"45471BBF0303"
				    documentation 	"TODO: Check upper multiplicity of condition expression to be 1?"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Conditional
|inv:
|  self.condition.getType().upperMultiplicity = 1 and
|  self.condition.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.condition.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.name = 'Boolean'
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Ternary"
		    quid       	"4A389707002E"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4A38971503A9"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2")
			(object Inheritance_Relationship
			    quid       	"4B8523D403B9"
			    supplier   	"Logical View::dataaccess::expressions::ConditionalExpression"
			    quidu      	"4B8523C90167"))
		    nestedClasses 	(list nestedClasses
			(object Class "TrueAndFalseExprsConformToResultType"
			    quid       	"4A38997702EE"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4A3899A9029F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Ternary
|inv:
|  self.trueExpr.getType().conformsTo(self.getType()) or
|  self.falseExpr.getType().conformsTo(self.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ContentEquals"
		    quid       	"4B06A82B0109"
		    documentation 	"Compares two entity objects by the content of those associations marked as equality relevant for the entity."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B06A83500CB"
			    supplier   	"Logical View::dataaccess::expressions::Equals"
			    quidu      	"475958230399"))
		    nestedClasses 	(list nestedClasses
			(object Class "ContentEqualsOnlyForEntities"
			    quid       	"4B06A8560213"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B06A861036B"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context ContentEquals
|inv:
|  self.left.getType().getInnermost().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.right.getType().getInnermost().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  not self.left.getType().getInnermost().oclAsType(data::classes::ClassTypeDefinition).clazz.valueType and
|  not self.right.getType().getInnermost().oclAsType(data::classes::ClassTypeDefinition).clazz.valueType
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ExpressionWithArgument"
		    quid       	"4B8504AE03C8"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B8504B6036B"
			    supplier   	"Logical View::dataaccess::expressions::WithArgument"
			    quidu      	"4577E587019C")
			(object Inheritance_Relationship
			    quid       	"4B8520070109"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    abstract   	TRUE)
		(object Class "ConditionalExpression"
		    quid       	"4B8523C90167"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B8523D800BB"
			    supplier   	"Logical View::dataaccess::expressions::Conditional"
			    quidu      	"45471B4401F7")
			(object Inheritance_Relationship
			    quid       	"4B8523FD005D"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    abstract   	TRUE)
		(object Class "Map"
		    quid       	"4B8D1E5103B9"
		    documentation 	"A map expression operates on a (multi-)object (therefore it is an ObjectBaseExpression) and subjects each element of this (multi-)object as argument to the function expected as argument (therefore, it is an ExpressionWithArgument). The single multiplicity of the object expression must conform to the single input argument of the function signature of the FunctionSignatureTypeDefinition defining the type of the argument."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B8D1E60034B"
			    supplier   	"Logical View::dataaccess::expressions::ExpressionWithArgument"
			    quidu      	"4B8504AE03C8")
			(object Inheritance_Relationship
			    quid       	"4B8D1E61032C"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "ObjectTypeMustConformToFunctionArgument"
			    quid       	"4B8D1F31002E"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8D23C000CB"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Map
|inv:
|  let fstd:data::classes::TypeDefinition = self.argument.getType() in
|  let sig:data::classes::Signature = fstd.oclAsType(data::classes::FunctionSignatureTypeDefinition).signature in
|  let t:data::classes::TypeDefinition = self.object.getType() in
|  let argT:data::classes::TypeDefinition = sig.input->at(1).getType() in
|  -- if multiplicities match including multiplicities, that's ok
|  t.conformsTo(argT) or
|  -- otherwise, pick single multiplicity from object and try again
|  t.conformsToIgnoringMultiplicity(argT) or
|  (t.oclIsKindOf(data::classes::NestedTypeDefinition) and t.oclAsType(data::classes::NestedTypeDefinition).type.conformsTo(argT))
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ArgumentMustBeSingleArgumentFunctionWithNonVoidOutput"
			    quid       	"4B8D1F720222"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8D1F8700AB"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Map
|inv:
|  let fstd:data::classes::TypeDefinition = self.argument.getType() in
|  fstd.oclIsKindOf(data::classes::FunctionSignatureTypeDefinition) and
|  (let sig:data::classes::Signature = fstd.oclAsType(data::classes::FunctionSignatureTypeDefinition).signature in
|  (sig.output->notEmpty() and
|  sig.input->size() = 1))
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "MapFunctionMustBeSideEffectFree"
			    quid       	"4B8D38680222"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8D387402DE"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Map
|inv:
|  self.argument.getType().oclAsType(data::classes::FunctionSignatureTypeDefinition).signature.sideEffectFree
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Association "$UNNAMED$0"
		    quid       	"4522AE0D02E6"
		    roles      	(list role_list
			(object Role "variable"
			    quid       	"4522AE0E00C0"
			    label      	"variable"
			    supplier   	"Logical View::data::classes::NamedValue"
			    quidu      	"4522A56F0149"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$1"
			    quid       	"4522AE0E00CB"
			    supplier   	"Logical View::dataaccess::expressions::VariableExpression"
			    quidu      	"4522AC6A022F")))
		(object Association "$UNNAMED$2"
		    quid       	"453649650215"
		    roles      	(list role_list
			(object Role "object"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4536496701B4"
			    label      	"object"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "objectBasedExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4536496701C8"
			    label      	"objectBasedExpression"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$3"
		    quid       	"454BA28B0154"
		    roles      	(list role_list
			(object Role "classToInstantiate"
			    quid       	"454BA28C00A2"
			    label      	"classToInstantiate"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$4"
			    quid       	"454BA28C0156"
			    supplier   	"Logical View::dataaccess::expressions::ObjectCreationExpression"
			    quidu      	"454BA26C0254")))
		(object Association "$UNNAMED$5"
		    quid       	"4577E58D0258"
		    roles      	(list role_list
			(object Role "argumentOf"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4577E58D0259"
			    label      	"argumentOf"
			    supplier   	"Logical View::dataaccess::expressions::WithArgument"
			    quidu      	"4577E587019C"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)
			(object Role "argument"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4577E58D025A"
			    label      	"argument"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)))
		(object Association "$UNNAMED$6"
		    quid       	"45473F690329"
		    roles      	(list role_list
			(object Role "calledBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"45473F6A0302"
			    label      	"calledBlock"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "blockOfFunctionCallExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"45473F6A0316"
			    label      	"blockOfFunctionCallExpression"
			    supplier   	"Logical View::dataaccess::expressions::FunctionCallExpression"
			    quidu      	"45473F620076"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$7"
		    quid       	"4759584301D4"
		    roles      	(list role_list
			(object Role "left"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4759584402DE"
			    label      	"left"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "leftOfEquals"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4759584402FD"
			    label      	"leftOfEquals"
			    supplier   	"Logical View::dataaccess::expressions::Equals"
			    quidu      	"475958230399"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$8"
		    quid       	"4786205D0261"
		    roles      	(list role_list
			(object Role "toEnd"
			    quid       	"4786205E00AB"
			    label      	"toEnd"
			    supplier   	"Logical View::data::classes::AssociationEnd"
			    quidu      	"44EC55FB03B8"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$9"
			    quid       	"4786205E00BB"
			    supplier   	"Logical View::dataaccess::expressions::AssociationEndNavigationExpression"
			    quidu      	"478620130157"
			    client_cardinality 	(value cardinality "0..*"))))
		(object Association "SignatureCallParameters"
		    quid       	"47F3B8AB019D"
		    roles      	(list role_list
			(object Role "parameters"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"47F3B8AC0339"
			    label      	"parameters"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..n")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "usedAsArgumentInSignatureCall"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"47F3B8AC036B"
			    label      	"usedAsArgumentInSignatureCall"
			    supplier   	"Logical View::dataaccess::expressions::SignatureCallExpression"
			    quidu      	"47F3B80500BD"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SignatureCallToSignature"
		    quid       	"4939041D0109"
		    roles      	(list role_list
			(object Role "$UNNAMED$10"
			    quid       	"4939041D010A"
			    supplier   	"Logical View::dataaccess::expressions::MethodCallExpression"
			    quidu      	"4522E05D00A8"
			    client_cardinality 	(value cardinality "0..n"))
			(object Role "methodSignature"
			    quid       	"4939041D010B"
			    label      	"methodSignature"
			    supplier   	"Logical View::data::classes::MethodSignature"
			    quidu      	"47D67D15030D"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)))
		(object Association "$UNNAMED$11"
		    quid       	"497656FD0205"
		    roles      	(list role_list
			(object Role "right"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"49765700006E"
			    label      	"right"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "rightOfEquals"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"49765700009D"
			    label      	"rightOfEquals"
			    supplier   	"Logical View::dataaccess::expressions::Equals"
			    quidu      	"475958230399"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$12"
		    quid       	"499D40450261"
		    roles      	(list role_list
			(object Role "steps"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"499D404600CB"
			    label      	"steps"
			    supplier   	"Logical View::dataaccess::expressions::NavigationStep"
			    quidu      	"499D4031000F"
			    client_cardinality 	(value cardinality "1..*")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "replace"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"499D404600CD"
			    label      	"replace"
			    supplier   	"Logical View::dataaccess::expressions::Replace"
			    quidu      	"499C2988038A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$13"
		    quid       	"499D416E03A9"
		    documentation 	
|If the opposite assoication end to which the step navigates connects only to a class *conforming* to the output of the previous step, this implicitly means a type filtering: only those instances will pass whose type conforms to the class to which *to*'s other end connects.
|
|For example, if an Address value class has a property of type Province, and there are classes ProvinceWithLanguage that conforms to Province and has a property *language*, a navigation step to the "language" end will eliminate all provinces whose type does not conform to ProvinceWithLanguage.
		    
		    roles      	(list role_list
			(object Role "to"
			    quid       	"499D416F01F4"
			    label      	"to"
			    supplier   	"Logical View::data::classes::AssociationEnd"
			    quidu      	"44EC55FB03B8"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$14"
			    quid       	"499D416F0213"
			    supplier   	"Logical View::dataaccess::expressions::NavigationStep"
			    quidu      	"499D4031000F"
			    client_cardinality 	(value cardinality "0..*"))))
		(object Association "$UNNAMED$15"
		    quid       	"499D5BB500FA"
		    documentation 	"If specified, the expression must evaluate to a function such that the association end's (to) type definition conforms to the function's single input argument's type definition and the output is a single Boolean object."
		    roles      	(list role_list
			(object Role "filterFunction"
			    quid       	"499D5BB701A5"
			    label      	"filterFunction"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "navigationStep"
			    quid       	"499D5BB70203"
			    label      	"navigationStep"
			    supplier   	"Logical View::dataaccess::expressions::NavigationStep"
			    quidu      	"499D4031000F"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$16"
		    quid       	"499D69C401C5"
		    roles      	(list role_list
			(object Role "with"
			    quid       	"499D69C7029F"
			    label      	"with"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "withOfReplace"
			    quid       	"499D69C702DE"
			    label      	"withOfReplace"
			    supplier   	"Logical View::dataaccess::expressions::Replace"
			    quidu      	"499C2988038A"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$17"
		    quid       	"4A3897E603B9"
		    roles      	(list role_list
			(object Role "falseExpr"
			    quid       	"4A3897E7030D"
			    label      	"falseExpr"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "falseOfTernary"
			    quid       	"4A3897E7035B"
			    label      	"falseOfTernary"
			    supplier   	"Logical View::dataaccess::expressions::Ternary"
			    quidu      	"4A389707002E"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$18"
		    quid       	"4A3897E80280"
		    roles      	(list role_list
			(object Role "trueExpr"
			    quid       	"4A3897EA02EE"
			    label      	"trueExpr"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "trueOfTernary"
			    quid       	"4A3897EA034B"
			    label      	"trueOfTernary"
			    supplier   	"Logical View::dataaccess::expressions::Ternary"
			    quidu      	"4A389707002E"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$19"
		    quid       	"45471B920394"
		    roles      	(list role_list
			(object Role "condition"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"45471B930205"
			    label      	"condition"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "conditional"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"45471B93020F"
			    label      	"conditional"
			    supplier   	"Logical View::dataaccess::expressions::Conditional"
			    quidu      	"45471B4401F7"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$20"
		    quid       	"4B1CF92F02A0"
		    roles      	(list role_list
			(object Role "initializers"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B1CF930036B"
			    label      	"initializers"
			    supplier   	"Logical View::dataaccess::expressions::MethodCallExpression"
			    quidu      	"4522E05D00A8"
			    client_cardinality 	(value cardinality "0..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "creationExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B1CF930036D"
			    label      	"creationExpression"
			    supplier   	"Logical View::dataaccess::expressions::ObjectCreationExpression"
			    quidu      	"454BA26C0254"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Class_Category "literals"
		    quid       	"4717D1DA0359"
		    exportControl 	"Public"
		    logical_models 	(list unit_reference_list
			(object Class "Literal"
			    quid       	"454746D10018"
			    documentation 	
|A literal of any primitive type, such as "This is a string" or 123 or an enumeration literal or a literal denoting a value of an implicit anonymous class, or a block, or a literal that denotes a (potentially anonymous) class.
|
|The exact type of a literal may not always be possible to decide completely, particularly when it comes to constrained types over primitive types. This can only come in through "post types" and type inference, e.g., in an assignment statement where the type of the lvalue is known.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"454746F00167"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"))
			    class_attributes 	(list class_attribute_list
				(object ClassAttribute "literal"
				    quid       	"45D9808702F7"
				    documentation 	"Represents the value of this literal as a string. Final interpretation has to happen by the type of the literal expression. For string literals this is particularly straightforward. For numbers and dates, specific formats as defined by the respective types may apply."
				    type       	"String"
				    quidu      	"39A2BDA60394"
				    exportControl 	"Public")))
			(object Class "BinaryLiteral"
			    quid       	"4717D1FE0387"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4717D2310193"
				    supplier   	"Logical View::dataaccess::expressions::literals::Literal"
				    quidu      	"454746D10018")))
			(object Class "StringLiteral"
			    quid       	"4717D20103C6"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4717D2330126"
				    supplier   	"Logical View::dataaccess::expressions::literals::Literal"
				    quidu      	"454746D10018")))
			(object Class "NumberLiteral"
			    quid       	"4717D202026E"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4717D2340378"
				    supplier   	"Logical View::dataaccess::expressions::literals::Literal"
				    quidu      	"454746D10018")))
			(object Class "TimePointLiteral"
			    quid       	"4717D2030107"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4717D23602FB"
				    supplier   	"Logical View::dataaccess::expressions::literals::Literal"
				    quidu      	"454746D10018")))
			(object Class "BooleanLiteral"
			    quid       	"4717D204001C"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4717D2380397"
				    supplier   	"Logical View::dataaccess::expressions::literals::Literal"
				    quidu      	"454746D10018")))
			(object Class "ObjectLiteral"
			    quid       	"4717D20502BC"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4974A3CE030D"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"))
			    operations 	(list Operations
				(object Operation "isEqualTo"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.OperationCodeOcl"
					    value      	(value Text 
|context ObjectLiteral::isEqualTo(o:ObjectLiteral):Boolean
|body:
|  self.valueClass = o.valueClass and
|  self.propertyValues->size() = o.propertyValues->size() and
|  self.propertyValues->forAll(pv | o.propertyValues->exists(opv | opv.forEnd = pv.forEnd and opv.value.evaluatesToEqualAs(pv.value)))
					    )))
				    quid       	"4A0D2FFB01C5"
				    parameters 	(list Parameters
					(object Parameter "o"
					    quid       	"4A0D30030280"
					    type       	"ObjectLiteral"
					    quidu      	"4717D20502BC"))
				    result     	"Boolean"
				    concurrency 	"Sequential"
				    opExportControl 	"Public"
				    uid        	0
				    quidu      	"39A2BDA60392"))
			    nestedClasses 	(list nestedClasses
				(object Class "ObjectLiteralsForValueClassesOnly"
				    quid       	"4974924900EA"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4974926102BF"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context ObjectLiteral
|inv:
|  self.valueClass.valueType
						)
					    opExportControl 	"Public"
					    uid        	0)))
				(object Class "ObjectLiteralPropertiesOnRightClass"
				    quid       	"4974927802DE"
				    documentation 	
|The "for" association end of all "propertyValues" ValueInit elements must with their opposite ends connect to the class provided as "valueClass" for this ObjectLiteral.
				    
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"497492DF0203"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context ObjectLiteral
|inv:
|  self.propertyValues->forAll(vi|vi.forEnd.otherEnd().type.clazz = self.valueClass)
						)
					    opExportControl 	"Public"
					    uid        	0)))
				(object Class "ValuesMustBeProvidedForAllMandatoryProperties"
				    quid       	"4A0E960C0028"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4A0E962702F5"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context ObjectLiteral
|inv:
|  self.valueClass.getEqualityRelevantAssociationEnds()->select(ae | ae.otherEnd().type.lowerMultiplicity > 0)->forAll(ae |
|      self.propertyValues->exists(pv | pv.forEnd.otherEnd() = ae))
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Class "ValueInit"
			    quid       	"4974918A0232"
			    documentation 	"Provides an initialization value for an association end whose other end is attached to a value class. The expression's type must conform to the association end's type."
			    nestedClasses 	(list nestedClasses
				(object Class "ValueInitTypeConforms"
				    quid       	"4B26673A01D4"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4B26674403B9"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context ValueInit
|inv:
|  self.value.getType().conformsTo(self.forEnd.type)
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Association "$UNNAMED$21"
			    quid       	"497490F800AB"
			    roles      	(list role_list
				(object Role "valueClass"
				    quid       	"497490F90222"
				    label      	"valueClass"
				    supplier   	"Logical View::data::classes::SapClass"
				    quidu      	"4432171B031E"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "objectLiteral"
				    quid       	"497490F903D8"
				    label      	"objectLiteral"
				    supplier   	"Logical View::dataaccess::expressions::literals::ObjectLiteral"
				    quidu      	"4717D20502BC"
				    client_cardinality 	(value cardinality "0..*"))))
			(object Association "$UNNAMED$22"
			    quid       	"497491CD01B5"
			    roles      	(list role_list
				(object Role "propertyValues"
				    quid       	"497491CE0157"
				    label      	"propertyValues"
				    supplier   	"Logical View::dataaccess::expressions::literals::ValueInit"
				    quidu      	"4974918A0232"
				    client_cardinality 	(value cardinality "0..*")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "objectLiteral"
				    quid       	"497491CE0159"
				    label      	"objectLiteral"
				    supplier   	"Logical View::dataaccess::expressions::literals::ObjectLiteral"
				    quidu      	"4717D20502BC"
				    client_cardinality 	(value cardinality "0..1")
				    is_aggregate 	TRUE)))
			(object Association "$UNNAMED$23"
			    quid       	"497491EE003E"
			    roles      	(list role_list
				(object Role "forEnd"
				    quid       	"497491EE0251"
				    label      	"forEnd"
				    supplier   	"Logical View::data::classes::AssociationEnd"
				    quidu      	"44EC55FB03B8"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "valueInit"
				    quid       	"497491EE0290"
				    label      	"valueInit"
				    supplier   	"Logical View::dataaccess::expressions::literals::ValueInit"
				    quidu      	"4974918A0232"
				    client_cardinality 	(value cardinality "0..*"))))
			(object Association "$UNNAMED$24"
			    quid       	"497492170138"
			    roles      	(list role_list
				(object Role "value"
				    quid       	"49749219005D"
				    label      	"value"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"
				    client_cardinality 	(value cardinality "1")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "valueInit"
				    quid       	"4974921900FA"
				    label      	"valueInit"
				    supplier   	"Logical View::dataaccess::expressions::literals::ValueInit"
				    quidu      	"4974918A0232"
				    client_cardinality 	(value cardinality "0..1")
				    is_aggregate 	TRUE))))
		    logical_presentations 	(list unit_reference_list
			(object ClassDiagram "Literals"
			    quid       	"45D9805A01B2"
			    title      	"Literals"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	0
			    origin_y   	0
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::Literal" @1
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(884, 695)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@1
					location   	(737, 614)
					fill_color 	13434879
					nlines     	1
					max_width  	294
					justify    	0
					label      	"Literal")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"454746D10018"
				    width      	312
				    height     	186
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::BinaryLiteral" @2
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(189, 1151)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@2
					location   	(59, 1100)
					fill_color 	13434879
					nlines     	1
					max_width  	260
					justify    	0
					label      	"BinaryLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D1FE0387"
				    width      	278
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::StringLiteral" @3
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(487, 1151)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@3
					location   	(362, 1100)
					fill_color 	13434879
					nlines     	1
					max_width  	250
					justify    	0
					label      	"StringLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D20103C6"
				    width      	268
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::NumberLiteral" @4
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(800, 1151)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@4
					location   	(656, 1100)
					fill_color 	13434879
					nlines     	1
					max_width  	288
					justify    	0
					label      	"NumberLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D202026E"
				    width      	306
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::TimePointLiteral" @5
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1136, 1150)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@5
					location   	(977, 1099)
					fill_color 	13434879
					nlines     	1
					max_width  	318
					justify    	0
					label      	"TimePointLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D2030107"
				    width      	336
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::BooleanLiteral" @6
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1478, 1154)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@6
					location   	(1331, 1103)
					fill_color 	13434879
					nlines     	1
					max_width  	294
					justify    	0
					label      	"BooleanLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D204001C"
				    width      	312
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritTreeView "" @7
				    location   	(884, 944)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@1
				    vertices   	(list Points
					(884, 944)
					(884, 788)))
				(object InheritView "" @8
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D2330126"
				    client     	@3
				    supplier   	@1
				    vertices   	(list Points
					(488, 1088)
					(488, 944))
				    line_style 	3
				    origin_attachment 	(488, 1088)
				    terminal_attachment 	(488, 944)
				    drawSupplier 	@7)
				(object InheritView "" @9
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D2340378"
				    client     	@4
				    supplier   	@1
				    vertices   	(list Points
					(800, 1088)
					(800, 944))
				    line_style 	3
				    origin_attachment 	(800, 1088)
				    terminal_attachment 	(800, 944)
				    drawSupplier 	@7)
				(object InheritView "" @10
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D23602FB"
				    client     	@5
				    supplier   	@1
				    vertices   	(list Points
					(1134, 1087)
					(1134, 944))
				    line_style 	3
				    origin_attachment 	(1134, 1087)
				    terminal_attachment 	(1134, 944)
				    drawSupplier 	@7)
				(object InheritView "" @11
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D2380397"
				    client     	@6
				    supplier   	@1
				    vertices   	(list Points
					(1478, 1091)
					(1478, 944))
				    line_style 	3
				    origin_attachment 	(1478, 1091)
				    terminal_attachment 	(1478, 944)
				    drawSupplier 	@7)
				(object InheritView "" @12
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D2310193"
				    client     	@2
				    supplier   	@1
				    vertices   	(list Points
					(294, 1087)
					(294, 944))
				    line_style 	3
				    origin_attachment 	(294, 1087)
				    terminal_attachment 	(294, 944)
				    drawSupplier 	@7)
				(object NoteView @13
				    location   	(676, 1935)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@13
					location   	(314, 1869)
					fill_color 	13434879
					nlines     	2
					max_width  	689
					label      	
|TODO: What about a "null" literal? What should its semantics be?
					)
				    line_color 	3342489
				    fill_color 	13434879
				    width      	749
				    height     	144)
				(object NoteView @14
				    location   	(713, 1592)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@14
					location   	(125, 1398)
					fill_color 	13434879
					nlines     	7
					max_width  	1140
					label      	"TODO: What about a multi-value literal? Something like [] (list) and {} (set) perhaps? Since literals have to be written in some order, unordered literals are not necessary. Unordered types could also be made conform to ordered types and therefore be assignment-compatible. The type could be derived from the common type (or common adapter chain end) of the literals contained.")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	1200
				    height     	400)
				(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @15
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(938, 241)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@15
					location   	(671, 12)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Expression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"450E63AB03A2"
				    width      	552
				    height     	482
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritTreeView "" @16
				    location   	(938, 572)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@15
				    vertices   	(list Points
					(938, 572)
					(938, 482)))
				(object InheritView "" @17
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454746F00167"
				    client     	@1
				    supplier   	@15
				    vertices   	(list Points
					(884, 602)
					(884, 572))
				    line_style 	3
				    origin_attachment 	(884, 602)
				    terminal_attachment 	(884, 572)
				    drawSupplier 	@16)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::ObjectLiteral" @18
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1800, 1154)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@18
					location   	(1666, 1073)
					fill_color 	13434879
					nlines     	1
					max_width  	268
					justify    	0
					label      	"ObjectLiteral")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717D20502BC"
				    width      	286
				    height     	186
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @19
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4974A3CE030D"
				    client     	@18
				    supplier   	@15
				    vertices   	(list Points
					(1781, 1060)
					(1781, 572))
				    line_style 	3
				    origin_attachment 	(1781, 1060)
				    terminal_attachment 	(1781, 572)
				    drawSupplier 	@16)
				(object ClassView "Class" "Logical View::dataaccess::expressions::literals::ValueInit" @20
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2485, 1168)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@20
					location   	(2386, 1117)
					fill_color 	13434879
					nlines     	1
					max_width  	198
					justify    	0
					label      	"ValueInit")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4974918A0232"
				    width      	216
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "$UNNAMED$22" @21
				    location   	(2160, 1169)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"497491CD01B5"
				    roleview_list 	(list RoleViews
					(object RoleView "propertyValues" @22
					    Parent_View 	@21
					    location   	(382, 213)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @23
						Parent_View 	@22
						location   	(2203, 1130)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	302
						justify    	0
						label      	"+propertyValues"
						pctDist    	0.198020
						height     	40
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497491CE0157"
					    client     	@21
					    supplier   	@20
					    vertices   	(list Points
						(2160, 1169)
						(2377, 1169))
					    line_style 	3
					    origin_attachment 	(2160, 1169)
					    terminal_attachment 	(2377, 1169)
					    label      	(object SegLabel @24
						Parent_View 	@22
						location   	(2315, 1217)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.720524
						height     	48
						orientation 	1))
					(object RoleView "objectLiteral" @25
					    Parent_View 	@21
					    location   	(382, 213)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @26
						Parent_View 	@25
						location   	(2091, 1214)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	249
						justify    	0
						label      	"+objectLiteral"
						pctDist    	0.322751
						height     	45
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497491CE0159"
					    client     	@21
					    supplier   	@18
					    vertices   	(list Points
						(2160, 1169)
						(1943, 1169))
					    line_style 	3
					    origin_attachment 	(2160, 1169)
					    terminal_attachment 	(1943, 1169)
					    label      	(object SegLabel @27
						Parent_View 	@25
						location   	(1985, 1131)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.805970
						height     	39
						orientation 	1))))
				(object AssociationViewNew "$UNNAMED$24" @28
				    location   	(2302, 175)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"497492170138"
				    roleview_list 	(list RoleViews
					(object RoleView "value" @29
					    Parent_View 	@28
					    location   	(-85, -790)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @30
						Parent_View 	@29
						location   	(1301, 137)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	132
						justify    	0
						label      	"+value"
						pctDist    	0.919598
						height     	39
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"49749219005D"
					    client     	@28
					    supplier   	@15
					    vertices   	(list Points
						(2302, 175)
						(1214, 175))
					    line_style 	3
					    origin_attachment 	(2302, 175)
					    terminal_attachment 	(1214, 175)
					    label      	(object SegLabel @31
						Parent_View 	@29
						location   	(1250, 229)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.966834
						height     	54
						orientation 	0))
					(object RoleView "valueInit" @32
					    Parent_View 	@28
					    location   	(-85, -790)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @33
						Parent_View 	@32
						location   	(2357, 944)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	180
						justify    	0
						label      	"+valueInit"
						pctDist    	0.852941
						height     	103
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4974921900FA"
					    client     	@28
					    supplier   	@20
					    vertices   	(list Points
						(2302, 175)
						(2459, 175)
						(2459, 1105))
					    line_style 	3
					    origin_attachment 	(2302, 175)
					    terminal_attachment 	(2459, 1105)
					    label      	(object SegLabel @34
						Parent_View 	@32
						location   	(2394, 1031)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.931985
						height     	66
						orientation 	1))))
				(object ClassView "Class" "Logical View::data::classes::SapClass" @35
				    ShowCompartmentStereotypes 	TRUE
				    SuppressAttribute 	TRUE
				    SuppressOperation 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1798, 1560)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@35
					location   	(1687, 1510)
					fill_color 	13434879
					nlines     	1
					max_width  	222
					justify    	0
					label      	"SapClass")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432171B031E"
				    width      	240
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "$UNNAMED$21" @36
				    location   	(1797, 1372)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"497490F800AB"
				    roleview_list 	(list RoleViews
					(object RoleView "valueClass" @37
					    Parent_View 	@36
					    location   	(19, 416)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @38
						Parent_View 	@37
						location   	(1937, 1462)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	230
						justify    	0
						label      	"+valueClass"
						pctDist    	0.723404
						height     	140
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497490F90222"
					    client     	@36
					    supplier   	@35
					    vertices   	(list Points
						(1797, 1372)
						(1797, 1498))
					    line_style 	3
					    origin_attachment 	(1797, 1372)
					    terminal_attachment 	(1797, 1498)
					    label      	(object SegLabel @39
						Parent_View 	@37
						location   	(1753, 1466)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.744681
						height     	45
						orientation 	1))
					(object RoleView "objectLiteral" @40
					    Parent_View 	@36
					    location   	(19, 416)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @41
						Parent_View 	@40
						location   	(1647, 1281)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	249
						justify    	0
						label      	"+objectLiteral"
						pctDist    	0.728000
						height     	150
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497490F903D8"
					    client     	@36
					    supplier   	@18
					    vertices   	(list Points
						(1797, 1372)
						(1797, 1247))
					    line_style 	3
					    origin_attachment 	(1797, 1372)
					    terminal_attachment 	(1797, 1247)
					    label      	(object SegLabel @42
						Parent_View 	@40
						location   	(1851, 1275)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.778571
						height     	54
						orientation 	1))))
				(object ClassView "Class" "Logical View::data::classes::AssociationEnd" @43
				    ShowCompartmentStereotypes 	TRUE
				    SuppressAttribute 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2618, 1562)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@43
					location   	(2224, 1481)
					fill_color 	13434879
					nlines     	1
					max_width  	789
					justify    	0
					label      	"AssociationEnd")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"44EC55FB03B8"
				    width      	807
				    height     	187
				    annotation 	8)
				(object AssociationViewNew "$UNNAMED$23" @44
				    location   	(2487, 1350)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"497491EE003E"
				    roleview_list 	(list RoleViews
					(object RoleView "forEnd" @45
					    Parent_View 	@44
					    location   	(0, 385)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @46
						Parent_View 	@45
						location   	(2575, 1439)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	142
						justify    	0
						label      	"+forEnd"
						pctDist    	0.743802
						height     	88
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497491EE0251"
					    client     	@44
					    supplier   	@43
					    vertices   	(list Points
						(2487, 1350)
						(2487, 1469))
					    line_style 	3
					    origin_attachment 	(2487, 1350)
					    terminal_attachment 	(2487, 1469)
					    label      	(object SegLabel @47
						Parent_View 	@45
						location   	(2440, 1439)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.743802
						height     	48
						orientation 	1))
					(object RoleView "valueInit" @48
					    Parent_View 	@44
					    location   	(0, 385)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @49
						Parent_View 	@48
						location   	(2383, 1267)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	180
						justify    	0
						label      	"+valueInit"
						pctDist    	0.697479
						height     	104
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"497491EE0290"
					    client     	@44
					    supplier   	@20
					    vertices   	(list Points
						(2487, 1350)
						(2487, 1231))
					    line_style 	3
					    origin_attachment 	(2487, 1350)
					    terminal_attachment 	(2487, 1231)
					    label      	(object SegLabel @50
						Parent_View 	@48
						location   	(2535, 1262)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.735537
						height     	48
						orientation 	1))))
				(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @51
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2084, 2176)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@51
					location   	(1789, 2047)
					fill_color 	13434879
					nlines     	1
					max_width  	590
					justify    	0
					label      	"ClassTypeDefinition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4784F7E800AB"
				    width      	608
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "" @52
				    location   	(1849, 1828)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005D"
				    roleview_list 	(list RoleViews
					(object RoleView "clazz" @53
					    Parent_View 	@52
					    location   	(-213, -150)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @54
						Parent_View 	@53
						location   	(1746, 1667)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	136
						justify    	0
						label      	"+clazz"
						pctDist    	0.781553
						height     	104
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4784F7F5005F"
					    client     	@52
					    supplier   	@35
					    vertices   	(list Points
						(1849, 1828)
						(1849, 1621))
					    line_style 	3
					    origin_attachment 	(1849, 1828)
					    terminal_attachment 	(1849, 1621)
					    label      	(object SegLabel @55
						Parent_View 	@53
						location   	(1889, 1673)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.747573
						height     	40
						orientation 	1))
					(object RoleView "elementsOfType" @56
					    Parent_View 	@52
					    location   	(-213, -150)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @57
						Parent_View 	@56
						location   	(1658, 1992)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	320
						justify    	0
						label      	"+elementsOfType"
						pctDist    	0.796117
						height     	192
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4784F7F5005E"
					    client     	@52
					    supplier   	@51
					    vertices   	(list Points
						(1849, 1828)
						(1849, 2035))
					    line_style 	3
					    origin_attachment 	(1849, 1828)
					    terminal_attachment 	(1849, 2035)
					    label      	(object SegLabel @58
						Parent_View 	@56
						location   	(1909, 1990)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.786408
						height     	60
						orientation 	0))))
				(object AssociationViewNew "" @59
				    location   	(2302, 1845)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9ABAE00AB"
				    roleview_list 	(list RoleViews
					(object RoleView "associationEnd" @60
					    Parent_View 	@59
					    location   	(240, -133)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @61
						Parent_View 	@60
						location   	(2474, 1753)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	304
						justify    	0
						label      	"+associationEnd"
						pctDist    	0.489583
						height     	172
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47B9ABAF02BF"
					    client     	@59
					    supplier   	@43
					    vertices   	(list Points
						(2302, 1845)
						(2302, 1655))
					    line_style 	3
					    origin_attachment 	(2302, 1845)
					    terminal_attachment 	(2302, 1655)
					    label      	(object SegLabel @62
						Parent_View 	@60
						location   	(2368, 1701)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.760417
						height     	66
						orientation 	1))
					(object RoleView "type" @63
					    Parent_View 	@59
					    location   	(240, -133)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @64
						Parent_View 	@63
						location   	(2388, 1948)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	108
						justify    	0
						label      	"+type"
						pctDist    	0.549223
						height     	86
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47B9ABAF02AF"
					    client     	@59
					    supplier   	@51
					    vertices   	(list Points
						(2302, 1845)
						(2302, 2035))
					    line_style 	3
					    origin_attachment 	(2302, 1845)
					    terminal_attachment 	(2302, 2035)
					    label      	(object SegLabel @65
						Parent_View 	@63
						location   	(2345, 2000)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.818653
						height     	43
						orientation 	0))))))))
		(object Class_Category "collectionExpressions"
		    quid       	"4759564F00AB"
		    exportControl 	"Public"
		    logical_models 	(list unit_reference_list
			(object Class "Including"
			    quid       	"475956720213"
			    documentation 	
|Produces a new value which includes the *argument* object. If the *argument* object was already included in the *source* and the multiplicity of the *source* has the *unique* attribute set to *true*, the *what* object will not be added a second time and the resulting expression will be equal to the *source* expression's value.
|
|If the *source* expression had multiplicity 1, the resulting expression's multiplicity is *, regardless of whether an object actually gets added.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4ADF36F5002E"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::CollectionExpressionWithArgument"
				    quidu      	"4ADF36A4001F")))
			(object Class "Excluding"
			    quid       	"47595673001F"
			    documentation 	
|Produces a new value which includes one less occurrence of the *argument* object than *source* or no occurrence if *source* did not contain an occurrence.
|
|If the *source* expression had multiplicity a..b, the resulting expression's multiplicity is Max(a-1, 0)..b, regardless of whether an object actually gets removed.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4ADF36FA0119"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::CollectionExpressionWithArgument"
				    quidu      	"4ADF36A4001F")))
			(object Class "IncludingAt"
			    quid       	"475956750280"
			    documentation 	"Like Including, produced a new value based on the *source* value that includes the *argument* object. In addition, *IncludingAt* specifies the position where to include the *argument* object. The multiplicity of source and resulting value have ordered=true. If *source* already includes an object equal to *argument* and the *source* multiplicity has unique=true, that element will afterwards be at the requested position or at the end of the resulting value if the *at* position is greater or equal the *source*'s cardinality."
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47B5ABF60203"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::WithPosition"
				    quidu      	"47B5ABDC038A")
				(object Inheritance_Relationship
				    quid       	"47B9FCA403D8"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::Including"
				    quidu      	"475956720213")))
			(object Class "Iterate"
			    quid       	"47595676008C"
			    documentation 	
|Given the number of iterators variables, assigns all possible tuples of values from the source expression to the iterators (combinatorial product). In particular, if only only one iterator variable is provided, this variable will "loop" through the values in the source expression. If the source expression has an ordered multiplicity, the iteration order corresponds with that order. Otherwise, iteration order is arbitrary and undefined.
|
|For each combination of iterator variable values, the iteratorExpression will be evaluated. The result of each evaluation is assigned to the accumulator variable.
|
|The iteratorExpression can use all iterators variables as well as the accumulator if one is declared, and of course all other variables in scope as well (block variables, etc.). If an accumulator is declared, an initial value must be provided for it.
|
|The result of the Iterate expression is the value that the accumulator has when the iteration terminates or the value of the last iteratorExpression evaluation if no accumulator has been provided. By this rationale, the type of the Iterate expression equals the type of the iteratorExpression.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47595F5801A5"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::CollectionExpression"
				    quidu      	"47595F60033C"))
			    nestedClasses 	(list nestedClasses
				(object Class "AccumulatorTypeEqualsExpressionType"
				    quid       	"47B5BE680167"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"47B5BE7C01C5"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context Iterate
|inv:
|  self.accumulator->notEmpty() implies
|  (self.accumulator.ownedTypeDefinition->notEmpty() implies
|     self.accumulator.ownedTypeDefinition.conformsTo(self.iteratorExpression.getType()))
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Class "CollectionExpression"
			    quid       	"47595F60033C"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47595F6A036B"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"))
			    abstract   	TRUE)
			(object Class "ExcludingAt"
			    quid       	"47B5ABAC0232"
			    documentation 	
|Like Excluding, but useful if multiple occurrences of the *argument* value exist. This expression removes the occurrence at the position specified by *at*. For this purpose, the argument value must have ordered=true, and so will the resulting value. If at position *at* there is no object that equals *argument* or the *at* position is outside the valid bounds, the resulting expression equals the *source* expression.
|
|If the argument is a multi-object (cardinality > 1), it needs to be ordered, and the argument's object sequence needs to exist at the position specified by *at*. If only a subsequence prefix is matched at position *at*, only that subsequence prefix will be excluded.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47B5ABF800DA"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::WithPosition"
				    quidu      	"47B5ABDC038A")
				(object Inheritance_Relationship
				    quid       	"47B5AC13007D"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::Excluding"
				    quidu      	"47595673001F")))
			(object Class "WithPosition"
			    quid       	"47B5ABDC038A"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"493E4C4F03C8"
				    supplier   	"Logical View::dataaccess::expressions::ExpressionWithArgument"
				    quidu      	"4B8504AE03C8"))
			    class_attributes 	(list class_attribute_list
				(object ClassAttribute "at"
				    quid       	"47595959002E"
				    documentation 	"a position in an object with upper multiplicity >1 and ordered=true."
				    type       	"Integer"
				    quidu      	"3B538AB300B3"
				    exportControl 	"Public"))
			    abstract   	TRUE
			    nestedClasses 	(list nestedClasses
				(object Class "SourceMustBeOrdered"
				    quid       	"493E4C61031C"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"493E4C7A034B"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context WithPosition
|inv:
|  self.argument.getType().ordered
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Class "CollectionExpressionWithArgument"
			    quid       	"4ADF36A4001F"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4ADF36D201A5"
				    supplier   	"Logical View::dataaccess::expressions::ExpressionWithArgument"
				    quidu      	"4B8504AE03C8")
				(object Inheritance_Relationship
				    quid       	"4ADF36E80271"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::CollectionExpression"
				    quidu      	"47595F60033C"))
			    abstract   	TRUE
			    nestedClasses 	(list nestedClasses
				(object Class "ArgumentTypeMustConformToCollectionExpressionType"
				    quid       	"4ADF362100EA"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4ADF364A002E"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context CollectionExpressionWithArgument
|inv:
|  let snl : Integer = source.getType().getNestingLevel() in let anl : Integer = argument.getType().getNestingLevel() in
|    if snl = anl then
|      source.getType().conformsToIgnoringMultiplicity(argument.getType())
|    else
|      if snl = (anl + 1) then
|        source.getType().oclAsType(data::classes::NestedTypeDefinition).type.conformsToIgnoringMultiplicity(argument.getType())
|      else
|        if (snl + 1) = anl then
|          source.getType().conformsToIgnoringMultiplicity(argument.getType().oclAsType(data::classes::NestedTypeDefinition).type)
|        else
|          false
|        endif
|      endif
|    endif
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Association "SourceOfCollectionExpression"
			    quid       	"47595F91004E"
			    roles      	(list role_list
				(object Role "source"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.store"
					    value      	("RoleStoreKindSet" 203)))
				    quid       	"47595F930196"
				    label      	"source"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"
				    client_cardinality 	(value cardinality "1")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "collectionExpression"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.store"
					    value      	("RoleStoreKindSet" 202)))
				    quid       	"47595F9301C5"
				    label      	"collectionExpression"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::CollectionExpression"
				    quidu      	"47595F60033C"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE
				    is_aggregate 	TRUE)))
			(object Association "IterateIterator"
			    quid       	"4759625301D4"
			    roles      	(list role_list
				(object Role "iterators"
				    quid       	"4759625303C8"
				    label      	"iterators"
				    supplier   	"Logical View::behavioral::actions::Iterator"
				    quidu      	"47A719D200EA"
				    client_cardinality 	(value cardinality "1..*")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "iterate"
				    quid       	"4759625303D8"
				    label      	"iterate"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::Iterate"
				    quidu      	"47595676008C"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE
				    is_aggregate 	TRUE)))
			(object Association "IterateAccumulator"
			    quid       	"47596322030D"
			    documentation 	"Conceptually, the accumulator is not a constant in the usual sense. It changes its value with each iteration. However, syntactically, it shares all properties with a constant such as requiring an initialization expression and not being assignable otherwise."
			    roles      	(list role_list
				(object Role "accumulator"
				    quid       	"475963230109"
				    label      	"accumulator"
				    supplier   	"Logical View::behavioral::actions::Constant"
				    quidu      	"47A717EE033C"
				    client_cardinality 	(value cardinality "0..1")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "iterate"
				    quid       	"475963230119"
				    label      	"iterate"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::Iterate"
				    quidu      	"47595676008C"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE
				    is_aggregate 	TRUE)))
			(object Association "$UNNAMED$25"
			    quid       	"47596342006D"
			    roles      	(list role_list
				(object Role "iteratorExpression"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.store"
					    value      	("RoleStoreKindSet" 203)))
				    quid       	"475963450186"
				    label      	"iteratorExpression"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"
				    client_cardinality 	(value cardinality "1")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "inIterator"
				    quid       	"475963450196"
				    label      	"inIterator"
				    supplier   	"Logical View::dataaccess::expressions::collectionExpressions::Iterate"
				    quidu      	"47595676008C"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE
				    is_aggregate 	TRUE))))
		    logical_presentations 	(list unit_reference_list
			(object ClassDiagram "Collection Expressions"
			    quid       	"475956590232"
			    title      	"Collection Expressions"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	38
			    origin_y   	0
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::Including" @66
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1011, 1819)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@66
					location   	(916, 1768)
					fill_color 	13434879
					nlines     	1
					max_width  	190
					justify    	0
					label      	"Including")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"475956720213"
				    width      	208
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::Excluding" @67
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1414, 1813)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@67
					location   	(1309, 1762)
					fill_color 	13434879
					nlines     	1
					max_width  	210
					justify    	0
					label      	"Excluding")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47595673001F"
				    width      	228
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::IncludingAt" @68
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(923, 2071)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@68
					location   	(806, 2020)
					fill_color 	13434879
					nlines     	1
					max_width  	234
					justify    	0
					label      	"IncludingAt")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"475956750280"
				    width      	252
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::NamedValue" @69
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2882, 958)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@69
					location   	(2615, 854)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"NamedValue")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4522A56F0149"
				    width      	552
				    height     	232
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @70
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2881, 1266)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@70
					location   	(2769, 1188)
					fill_color 	13434879
					nlines     	1
					max_width  	224
					justify    	0
					label      	"Iterator")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47A719D200EA"
				    width      	242
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::actions::Constant" @71
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2507, 1585)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@71
					location   	(2395, 1507)
					fill_color 	13434879
					nlines     	1
					max_width  	224
					justify    	0
					label      	"Constant")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47A717EE033C"
				    width      	242
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::CollectionExpression" @72
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1364, 1255)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@72
					location   	(1155, 1204)
					fill_color 	13434879
					nlines     	1
					max_width  	418
					justify    	0
					label      	"CollectionExpression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47595F60033C"
				    width      	436
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::Iterate" @73
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1766, 1556)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@73
					location   	(1685, 1505)
					fill_color 	13434879
					nlines     	1
					max_width  	162
					justify    	0
					label      	"Iterate")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47595676008C"
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "IterateIterator" @74
				    location   	(2465, 1838)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @75
					Parent_View 	@74
					location   	(2465, 1779)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	249
					justify    	0
					label      	"IterateIterator"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4759625301D4"
				    roleview_list 	(list RoleViews
					(object RoleView "iterators" @76
					    Parent_View 	@74
					    location   	(300, 357)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @77
						Parent_View 	@76
						location   	(2787, 1454)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	183
						justify    	0
						label      	"+iterators"
						pctDist    	0.891803
						height     	101
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4759625303C8"
					    client     	@74
					    supplier   	@70
					    vertices   	(list Points
						(2465, 1838)
						(2887, 1838)
						(2887, 1356))
					    line_style 	3
					    origin_attachment 	(2465, 1838)
					    terminal_attachment 	(2887, 1356)
					    label      	(object SegLabel @78
						Parent_View 	@76
						location   	(2818, 1404)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1..*"
						pctDist    	0.946448
						height     	70
						orientation 	0))
					(object RoleView "iterate" @79
					    Parent_View 	@74
					    location   	(300, 357)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @80
						Parent_View 	@79
						location   	(1681, 1731)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	145
						justify    	0
						label      	"+iterate"
						pctDist    	0.877348
						height     	99
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4759625303D8"
					    client     	@74
					    supplier   	@73
					    vertices   	(list Points
						(2465, 1838)
						(1779, 1838)
						(1779, 1619))
					    line_style 	3
					    origin_attachment 	(2465, 1838)
					    terminal_attachment 	(1779, 1619)
					    label      	(object SegLabel @81
						Parent_View 	@79
						location   	(1709, 1685)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.926746
						height     	71
						orientation 	0))))
				(object AssociationViewNew "IterateAccumulator" @82
				    location   	(2121, 1582)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @83
					Parent_View 	@82
					location   	(2125, 1516)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"IterateAccumulator"
					pctDist    	0.566667
					height     	66
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47596322030D"
				    roleview_list 	(list RoleViews
					(object RoleView "accumulator" @84
					    Parent_View 	@82
					    location   	(201, 101)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @85
						Parent_View 	@84
						location   	(2221, 1553)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	260
						justify    	0
						label      	"+accumulator"
						pctDist    	0.376384
						height     	30
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475963230109"
					    client     	@82
					    supplier   	@71
					    vertices   	(list Points
						(2121, 1582)
						(2386, 1582))
					    line_style 	3
					    origin_attachment 	(2121, 1582)
					    terminal_attachment 	(2386, 1582)
					    label      	(object SegLabel @86
						Parent_View 	@84
						location   	(2332, 1624)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.797048
						height     	42
						orientation 	1))
					(object RoleView "iterate" @87
					    Parent_View 	@82
					    location   	(201, 101)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @88
						Parent_View 	@87
						location   	(1948, 1545)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	145
						justify    	0
						label      	"+iterate"
						pctDist    	0.656604
						height     	38
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475963230119"
					    client     	@82
					    supplier   	@73
					    vertices   	(list Points
						(2121, 1582)
						(1856, 1582))
					    line_style 	3
					    origin_attachment 	(2121, 1582)
					    terminal_attachment 	(1856, 1582)
					    label      	(object SegLabel @89
						Parent_View 	@87
						location   	(1916, 1636)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.776824
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @90
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1301, 797)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@90
					location   	(1034, 568)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Expression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"450E63AB03A2"
				    width      	552
				    height     	482
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "SourceOfCollectionExpression" @91
				    location   	(550, 1068)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @92
					Parent_View 	@91
					location   	(627, 1061)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	554
					justify    	0
					label      	"SourceOfCollectionExpression"
					pctDist    	1.800000
					height     	8
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47595F91004E"
				    roleview_list 	(list RoleViews
					(object RoleView "source" @93
					    Parent_View 	@91
					    location   	(-668, 647)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @94
						Parent_View 	@93
						location   	(844, 839)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	147
						justify    	0
						label      	"+source"
						pctDist    	0.756716
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47595F930196"
					    client     	@91
					    supplier   	@90
					    vertices   	(list Points
						(550, 1068)
						(550, 797)
						(1025, 797))
					    line_style 	3
					    origin_attachment 	(550, 1068)
					    terminal_attachment 	(1025, 797)
					    label      	(object SegLabel @95
						Parent_View 	@93
						location   	(983, 845)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.943284
						height     	48
						orientation 	1))
					(object RoleView "collectionExpression" @96
					    Parent_View 	@91
					    location   	(-668, 647)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @97
						Parent_View 	@96
						location   	(837, 1260)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	402
						justify    	0
						label      	"+collectionExpression"
						pctDist    	0.586158
						height     	41
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47595F9301C5"
					    client     	@91
					    supplier   	@72
					    vertices   	(list Points
						(550, 1068)
						(550, 1219)
						(1146, 1219))
					    line_style 	3
					    origin_attachment 	(550, 1068)
					    terminal_attachment 	(1146, 1219)
					    label      	(object SegLabel @98
						Parent_View 	@96
						location   	(1095, 1267)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.932203
						height     	48
						orientation 	1))))
				(object AssociationViewNew "$UNNAMED$25" @99
				    location   	(1772, 1071)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47596342006D"
				    roleview_list 	(list RoleViews
					(object RoleView "iteratorExpression" @100
					    Parent_View 	@99
					    location   	(-148, -410)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @101
						Parent_View 	@100
						location   	(1864, 808)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	358
						justify    	0
						label      	"+iteratorExpression"
						pctDist    	1.163717
						height     	92
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475963450186"
					    client     	@99
					    supplier   	@90
					    vertices   	(list Points
						(1772, 1071)
						(1772, 845)
						(1577, 845))
					    line_style 	3
					    origin_attachment 	(1772, 1071)
					    terminal_attachment 	(1577, 845)
					    label      	(object SegLabel @102
						Parent_View 	@100
						location   	(1612, 819)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.917808
						height     	27
						orientation 	1))
					(object RoleView "inIterator" @103
					    Parent_View 	@99
					    location   	(-148, -410)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @104
						Parent_View 	@103
						location   	(1894, 1465)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	184
						justify    	0
						label      	"+inIterator"
						pctDist    	0.934783
						height     	122
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475963450196"
					    client     	@99
					    supplier   	@73
					    vertices   	(list Points
						(1772, 1071)
						(1772, 1493))
					    line_style 	3
					    origin_attachment 	(1772, 1071)
					    terminal_attachment 	(1772, 1493)
					    label      	(object SegLabel @105
						Parent_View 	@103
						location   	(1844, 1376)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.722826
						height     	72
						orientation 	0))))
				(object ClassView "Class" "Logical View::dataaccess::expressions::WithArgument" @106
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(267, 985)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@106
					location   	(116, 907)
					fill_color 	13434879
					nlines     	1
					max_width  	302
					justify    	0
					label      	"WithArgument")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4577E587019C"
				    width      	320
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "$UNNAMED$5" @107
				    location   	(573, 722)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D0258"
				    roleview_list 	(list RoleViews
					(object RoleView "argument" @108
					    Parent_View 	@107
					    location   	(-11, -669)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @109
						Parent_View 	@108
						location   	(788, 675)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	196
						justify    	0
						label      	"+argument"
						pctDist    	0.478697
						height     	48
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4577E58D025A"
					    client     	@107
					    supplier   	@90
					    vertices   	(list Points
						(573, 722)
						(1025, 722))
					    line_style 	3
					    origin_attachment 	(573, 722)
					    terminal_attachment 	(1025, 722)
					    label      	(object SegLabel @110
						Parent_View 	@108
						location   	(985, 677)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.913956
						height     	46
						orientation 	0))
					(object RoleView "argumentOf" @111
					    Parent_View 	@107
					    location   	(-11, -669)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @112
						Parent_View 	@111
						location   	(243, 804)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+argumentOf"
						pctDist    	0.800000
						height     	52
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4577E58D0259"
					    client     	@107
					    supplier   	@106
					    vertices   	(list Points
						(573, 722)
						(294, 722)
						(294, 895))
					    line_style 	3
					    origin_attachment 	(573, 722)
					    terminal_attachment 	(294, 895)
					    label      	(object SegLabel @113
						Parent_View 	@111
						location   	(229, 868)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.939668
						height     	66
						orientation 	1))))
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::ExcludingAt" @114
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1406, 2068)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@114
					location   	(1281, 2017)
					fill_color 	13434879
					nlines     	1
					max_width  	250
					justify    	0
					label      	"ExcludingAt")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B5ABAC0232"
				    width      	268
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::WithPosition" @115
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(279, 1781)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@115
					location   	(146, 1700)
					fill_color 	13434879
					nlines     	1
					max_width  	266
					justify    	0
					label      	"WithPosition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B5ABDC038A"
				    width      	284
				    height     	186
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @116
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B5AC13007D"
				    client     	@114
				    supplier   	@67
				    vertices   	(list Points
					(1413, 2005)
					(1413, 1876))
				    line_style 	3
				    origin_attachment 	(1413, 2005)
				    terminal_attachment 	(1413, 1876))
				(object NoteView @117
				    location   	(2046, 2590)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@117
					location   	(1196, 2346)
					fill_color 	13434879
					nlines     	9
					max_width  	1665
					label      	
|A statement of the form
|  foreach i in c {
|    some block;
|  }
|could be parsed into an Iterate expression whose iteratorExpression is a BlockCallExpression for the Block specified (some block) and an Iterator i and c being the source of the Iterate expression. No accumulator would be defined in this case. Therefore, the result will be the value last produced by evaluating the block. The Block will take one input argument which happens to be the Iterator (i).
					)
				    line_color 	3342489
				    fill_color 	13434879
				    width      	1725
				    height     	500)
				(object InheritTreeView "" @118
				    location   	(279, 1964)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@115
				    vertices   	(list Points
					(279, 1964)
					(279, 1874)))
				(object InheritView "" @119
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B5ABF800DA"
				    client     	@114
				    supplier   	@115
				    vertices   	(list Points
					(1354, 2005)
					(1354, 1964))
				    line_style 	3
				    origin_attachment 	(1354, 2005)
				    terminal_attachment 	(1354, 1964)
				    drawSupplier 	@118)
				(object InheritView "" @120
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B5ABF60203"
				    client     	@68
				    supplier   	@115
				    vertices   	(list Points
					(929, 2008)
					(929, 1964))
				    line_style 	3
				    origin_attachment 	(929, 2008)
				    terminal_attachment 	(929, 1964)
				    drawSupplier 	@118)
				(object InheritView "" @121
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9FCA403D8"
				    client     	@68
				    supplier   	@66
				    vertices   	(list Points
					(963, 2007)
					(963, 1882))
				    line_style 	3
				    origin_attachment 	(963, 2007)
				    terminal_attachment 	(963, 1882))
				(object NoteView @122
				    location   	(595, 2560)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@122
					location   	(295, 2425)
					fill_color 	13434879
					nlines     	5
					max_width  	565
					label      	"TODO add a WithElementAtMovedTo expression")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	625
				    height     	282)
				(object ClassView "Class" "Logical View::data::classes::TypedElement" @123
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1928, 215)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@123
					location   	(1780, 86)
					fill_color 	13434879
					nlines     	1
					max_width  	296
					justify    	0
					label      	"TypedElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717B7BC031A"
				    width      	314
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object NoteView @124
				    location   	(494, 239)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@124
					location   	(103, 76)
					fill_color 	13434879
					nlines     	6
					max_width  	746
					label      	"TODO constrain multiplicities of Including and Excluding as specified in their doc-string. Unfortunately, this can't be inferred due to limitations around defining Multiplicity as StructureType")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	806
				    height     	338)
				(object InheritView "" @125
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47A719D70280"
				    client     	@70
				    supplier   	@69
				    vertices   	(list Points
					(2881, 1176)
					(2881, 1074))
				    line_style 	3
				    origin_attachment 	(2881, 1176)
				    terminal_attachment 	(2881, 1074))
				(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::CollectionExpressionWithArgument" @126
				    ShowCompartmentStereotypes 	TRUE
				    location   	(1234, 1579)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@126
					location   	(897, 1528)
					fill_color 	13434879
					nlines     	1
					max_width  	674
					justify    	0
					label      	"CollectionExpressionWithArgument")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4ADF36A4001F"
				    width      	692
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritTreeView "" @127
				    location   	(1234, 1732)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@126
				    vertices   	(list Points
					(1234, 1732)
					(1234, 1642)))
				(object InheritView "" @128
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ADF36F5002E"
				    client     	@66
				    supplier   	@126
				    vertices   	(list Points
					(1009, 1756)
					(1009, 1732))
				    line_style 	3
				    origin_attachment 	(1009, 1756)
				    terminal_attachment 	(1009, 1732)
				    drawSupplier 	@127)
				(object InheritView "" @129
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ADF36FA0119"
				    client     	@67
				    supplier   	@126
				    vertices   	(list Points
					(1413, 1750)
					(1413, 1732))
				    line_style 	3
				    origin_attachment 	(1413, 1750)
				    terminal_attachment 	(1413, 1732)
				    drawSupplier 	@127)
				(object InheritTreeView "" @130
				    location   	(1364, 1410)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@72
				    vertices   	(list Points
					(1364, 1410)
					(1364, 1318)))
				(object InheritView "" @131
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47595F5801A5"
				    client     	@73
				    supplier   	@72
				    vertices   	(list Points
					(1728, 1493)
					(1728, 1410))
				    line_style 	3
				    origin_attachment 	(1728, 1493)
				    terminal_attachment 	(1728, 1410)
				    drawSupplier 	@130)
				(object InheritView "" @132
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ADF36E80271"
				    client     	@126
				    supplier   	@72
				    vertices   	(list Points
					(1294, 1516)
					(1294, 1410))
				    line_style 	3
				    origin_attachment 	(1294, 1516)
				    terminal_attachment 	(1294, 1410)
				    drawSupplier 	@130)
				(object InheritTreeView "" @133
				    location   	(1928, 460)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@123
				    vertices   	(list Points
					(1928, 460)
					(1928, 356)))
				(object InheritView "" @134
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717B85102FB"
				    client     	@69
				    supplier   	@123
				    vertices   	(list Points
					(2893, 842)
					(2893, 460))
				    line_style 	3
				    origin_attachment 	(2893, 842)
				    terminal_attachment 	(2893, 460)
				    drawSupplier 	@133)
				(object InheritView "l" @135
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@135
					location   	(1310, 508)
					anchor_loc 	1
					nlines     	1
					max_width  	60
					justify    	0
					label      	"l")
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717B87503E5"
				    client     	@90
				    supplier   	@123
				    vertices   	(list Points
					(1310, 556)
					(1310, 460))
				    line_style 	3
				    origin_attachment 	(1310, 556)
				    terminal_attachment 	(1310, 460)
				    drawSupplier 	@133)
				(object ClassView "Class" "Logical View::dataaccess::expressions::ExpressionWithArgument" @136
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(375, 1324)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@136
					location   	(129, 1250)
					fill_color 	13434879
					nlines     	1
					max_width  	492
					justify    	0
					label      	"ExpressionWithArgument")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4B8504AE03C8"
				    width      	510
				    height     	172
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritTreeView "" @137
				    location   	(375, 1501)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@136
				    vertices   	(list Points
					(375, 1501)
					(375, 1410)))
				(object InheritView "" @138
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"493E4C4F03C8"
				    client     	@115
				    supplier   	@136
				    vertices   	(list Points
					(244, 1688)
					(244, 1501))
				    line_style 	3
				    origin_attachment 	(244, 1688)
				    terminal_attachment 	(244, 1501)
				    drawSupplier 	@137)
				(object InheritView "" @139
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ADF36D201A5"
				    client     	@126
				    supplier   	@136
				    vertices   	(list Points
					(1169, 1516)
					(1169, 1501))
				    line_style 	3
				    origin_attachment 	(1169, 1516)
				    terminal_attachment 	(1169, 1501)
				    drawSupplier 	@137)
				(object InheritView "" @140
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8504B6036B"
				    client     	@136
				    supplier   	@106
				    vertices   	(list Points
					(306, 1237)
					(306, 1075))
				    line_style 	3
				    origin_attachment 	(306, 1237)
				    terminal_attachment 	(306, 1075))
				(object InheritTreeView "" @141
				    location   	(1301, 1154)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@90
				    vertices   	(list Points
					(1301, 1154)
					(1301, 1038)))
				(object InheritView "" @142
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47595F6A036B"
				    client     	@72
				    supplier   	@90
				    vertices   	(list Points
					(1353, 1192)
					(1353, 1154))
				    line_style 	3
				    origin_attachment 	(1353, 1192)
				    terminal_attachment 	(1353, 1154)
				    drawSupplier 	@141)
				(object InheritView "" @143
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8520070109"
				    client     	@136
				    supplier   	@90
				    vertices   	(list Points
					(403, 1238)
					(403, 1154))
				    line_style 	3
				    origin_attachment 	(403, 1238)
				    terminal_attachment 	(403, 1154)
				    drawSupplier 	@141)))))
		(object Class_Category "fp"
		    quid       	"47A0755F0195"
		    exportControl 	"Public"
		    logical_models 	(list unit_reference_list
			(object Class "AnonymousFunctionExpr"
			    quid       	"47A0757E02EC"
			    documentation 	
|The type of expression of this type is a FunctionSignatureTypeDefinition. The value of this expression can be invoked which results in an invocation of the assoicated block.
|
|The expression must own a FunctionSignatureTypeDefinition in the role ownedTypeDefinition that has a valid implementation for its FunctionSignature.
|
|Note that there can be other expressions that evaluate to a function, such as an access to a variable that has a FunctionSignatureTypeDefinition as its type. AnonymousFunctionExpr really is the constructor for a function with implementation. This expression may then, e.g., be bound to variables or passed as parameter or returned by a method or function.
			    
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47A0773A011C"
				    supplier   	"Logical View::dataaccess::expressions::Expression"
				    quidu      	"450E63AB03A2"))
			    operations 	(list Operations
				(object Operation "getImplementation"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.OperationCodeOcl"
					    value      	(value Text 
|context AnonymousFunctionExpr::getImplementation():FunctionSignatureImplementation
|body:
|  self.ownedTypeDefinition.oclAsType(data::classes::FunctionSignatureTypeDefinition).signature.oclAsType(data::classes::FunctionSignature).implementation
					    ))
					(object Attribute
					    tool       	"MOF"
					    name       	"rose2mof.isQuery"
					    value      	(value Text "true")))
				    quid       	"47FF305F00CB"
				    documentation 	"Determines the Block implementing the function to which this expression evaluates by navigating to the FunctionSignatureTypeDefinition that tells this expression's type, and from there obtaining the signature's implementation."
				    result     	"FunctionSignatureImplementation"
				    concurrency 	"Sequential"
				    opExportControl 	"Public"
				    uid        	0
				    quidu      	"4974995A0069"))
			    nestedClasses 	(list nestedClasses
				(object Class "TypeMustBeSignatureTypeDefinitionWithImplementation"
				    quid       	"47D67B7D03C2"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"47D67B940226"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context AnonymousFunctionExpr
|inv:
|  self.getType().oclIsKindOf(data::classes::FunctionSignatureTypeDefinition) and
|  self.getType().oclAsType(data::classes::FunctionSignatureTypeDefinition).signature.oclAsType(data::classes::FunctionSignature).implementation->notEmpty()
						)
					    opExportControl 	"Public"
					    uid        	0)))
				(object Class "HasToOwnSignatureTypeDefinition"
				    quid       	"47D68B1D0094"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"47D68B5700B4"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context AnonymousFunctionExpr
|inv:
|  self.ownedTypeDefinition->notEmpty()
						)
					    opExportControl 	"Public"
					    uid        	0)))
				(object Class "SignatureMustBeFunctionSignature"
				    quid       	"48A038A2002E"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"48A038B3030D"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context AnonymousFunctionExpr
|inv:
|  self.ownedTypeDefinition.oclAsType(data::classes::FunctionSignatureTypeDefinition).signature.oclIsKindOf(data::classes::FunctionSignature)
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Class "FunctionFromMethodExpr"
			    quid       	"487F6B6D0177"
			    documentation 	"The getType() implementation for this expression type could infer the function type definition from the method signature. However, this would require constructing such a value from within OCL."
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"487F6B76036B"
				    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
				    quidu      	"453E0FC80335"))
			    nestedClasses 	(list nestedClasses
				(object Class "SignatureAvailableOnObjectsClass"
				    quid       	"4880917802CE"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4880864E00FA"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context FunctionFromMethodExpr
|inv:
|  self.object.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|  self.object.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.conformsTo(self.method.owner.oclAsType(data::classes::SapClass))
						)
					    opExportControl 	"Public"
					    uid        	0)))
				(object Class "MethodSignatureConformsToFunctionSignature"
				    quid       	"4880946302CE"
				    stereotype 	"constraint"
				    operations 	(list Operations
					(object Operation "OCL"
					    quid       	"4880949001F4"
					    concurrency 	"Sequential"
					    semantics  	(object Semantic_Info
						PDL        	
|context FunctionFromMethodExpr
|inv:
|    self.getType().oclIsKindOf(data::classes::FunctionSignatureTypeDefinition) and
|    self.method.conformsTo(self.getType().oclAsType(data::classes::FunctionSignatureTypeDefinition).signature)
						)
					    opExportControl 	"Public"
					    uid        	0)))))
			(object Association "$UNNAMED$26"
			    quid       	"488086DC003E"
			    roles      	(list role_list
				(object Role "method"
				    quid       	"488086DD0167"
				    label      	"method"
				    supplier   	"Logical View::data::classes::MethodSignature"
				    quidu      	"47D67D15030D"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "$UNNAMED$27"
				    quid       	"488086DD0186"
				    supplier   	"Logical View::dataaccess::expressions::fp::FunctionFromMethodExpr"
				    quidu      	"487F6B6D0177"
				    client_cardinality 	(value cardinality "0..*")))))
		    logical_presentations 	(list unit_reference_list
			(object ClassDiagram "Anonymous Function Expression"
			    quid       	"47A075B40358"
			    title      	"Anonymous Function Expression"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	306
			    origin_y   	0
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::data::classes::SignatureImplementation" @144
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1650, 1296)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@144
					location   	(1381, 1192)
					fill_color 	13434879
					nlines     	1
					max_width  	538
					justify    	0
					label      	"SignatureImplementation")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47836ECF037A"
				    width      	556
				    height     	232
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::TypedElement" @145
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(568, 428)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@145
					location   	(420, 299)
					fill_color 	13434879
					nlines     	1
					max_width  	296
					justify    	0
					label      	"TypedElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717B7BC031A"
				    width      	314
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @146
				    ShowCompartmentStereotypes 	TRUE
				    SuppressOperation 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1685, 493)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@146
					location   	(1540, 418)
					fill_color 	13434879
					nlines     	1
					max_width  	290
					justify    	0
					label      	"TypeDefinition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B9A97A00CB"
				    width      	308
				    height     	174
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "" @147
				    location   	(1128, 459)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF4180109"
				    roleview_list 	(list RoleViews
					(object RoleView "ownerTypedElement" @148
					    Parent_View 	@147
					    location   	(336, 266)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @149
						Parent_View 	@148
						location   	(947, 418)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	393
						justify    	0
						label      	"+ownerTypedElement"
						pctDist    	0.449198
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47CBF418010B"
					    client     	@147
					    supplier   	@145
					    vertices   	(list Points
						(1128, 459)
						(725, 459))
					    line_style 	3
					    origin_attachment 	(1128, 459)
					    terminal_attachment 	(725, 459)
					    label      	(object SegLabel @150
						Parent_View 	@148
						location   	(811, 507)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.788732
						height     	48
						orientation 	0))
					(object RoleView "ownedTypeDefinition" @151
					    Parent_View 	@147
					    location   	(336, 266)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @152
						Parent_View 	@151
						location   	(1309, 492)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	396
						justify    	0
						label      	"+ownedTypeDefinition"
						pctDist    	0.452632
						height     	33
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47CBF418010A"
					    client     	@147
					    supplier   	@146
					    vertices   	(list Points
						(1128, 459)
						(1531, 459))
					    line_style 	3
					    origin_attachment 	(1128, 459)
					    terminal_attachment 	(1531, 459)
					    label      	(object SegLabel @153
						Parent_View 	@151
						location   	(1476, 436)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.862676
						height     	24
						orientation 	0))))
				(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @154
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(635, 991)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@154
					location   	(368, 762)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Expression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"450E63AB03A2"
				    width      	552
				    height     	482
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "l" @155
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@155
					location   	(578, 659)
					anchor_loc 	1
					nlines     	1
					max_width  	60
					justify    	0
					label      	"l")
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717B87503E5"
				    client     	@154
				    supplier   	@145
				    vertices   	(list Points
					(578, 750)
					(578, 568))
				    line_style 	3
				    origin_attachment 	(578, 750)
				    terminal_attachment 	(578, 568))
				(object ClassView "Class" "Logical View::behavioral::actions::Block" @156
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1654, 2186)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@156
					location   	(1387, 2007)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Block")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"454606CB020A"
				    width      	552
				    height     	382
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::fp::AnonymousFunctionExpr" @157
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(582, 1414)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@157
					location   	(335, 1333)
					fill_color 	13434879
					nlines     	1
					max_width  	494
					justify    	0
					label      	"AnonymousFunctionExpr")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47A0757E02EC"
				    width      	512
				    height     	186
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @158
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47A0773A011C"
				    client     	@157
				    supplier   	@154
				    vertices   	(list Points
					(572, 1321)
					(572, 1231))
				    line_style 	3
				    origin_attachment 	(572, 1321)
				    terminal_attachment 	(572, 1231))
				(object ClassView "Class" "Logical View::data::classes::FunctionSignatureTypeDefinition" @159
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1698, 959)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@159
					location   	(1384, 881)
					fill_color 	13434879
					nlines     	1
					max_width  	628
					justify    	0
					label      	"FunctionSignatureTypeDefinition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B9A9AD03B9"
				    width      	646
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @160
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9A9C20109"
				    client     	@159
				    supplier   	@146
				    vertices   	(list Points
					(1703, 869)
					(1703, 579))
				    line_style 	3
				    origin_attachment 	(1703, 869)
				    terminal_attachment 	(1703, 579))
				(object ClassView "Class" "Logical View::data::classes::Signature" @161
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2769, 935)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@161
					location   	(2502, 731)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Signature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432198602CB"
				    width      	552
				    height     	432
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "" @162
				    location   	(2257, 959)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6000F"
				    roleview_list 	(list RoleViews
					(object RoleView "typeDefinition" @163
					    Parent_View 	@162
					    location   	(150, 369)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @164
						Parent_View 	@163
						location   	(2156, 923)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	269
						justify    	0
						label      	"+typeDefinition"
						pctDist    	0.432653
						height     	37
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"48A02BD6007D"
					    client     	@162
					    supplier   	@159
					    vertices   	(list Points
						(2257, 959)
						(2021, 959))
					    line_style 	3
					    origin_attachment 	(2257, 959)
					    terminal_attachment 	(2021, 959)
					    label      	(object SegLabel @165
						Parent_View 	@163
						location   	(2087, 1016)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.722449
						height     	57
						orientation 	0))
					(object RoleView "signature" @166
					    Parent_View 	@162
					    location   	(150, 369)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @167
						Parent_View 	@166
						location   	(2326, 1032)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	206
						justify    	0
						label      	"+signature"
						pctDist    	0.292683
						height     	73
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"48A02BD6002E"
					    client     	@162
					    supplier   	@161
					    vertices   	(list Points
						(2257, 959)
						(2493, 959))
					    line_style 	3
					    origin_attachment 	(2257, 959)
					    terminal_attachment 	(2493, 959)
					    label      	(object SegLabel @168
						Parent_View 	@166
						location   	(2446, 914)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.800813
						height     	46
						orientation 	0))))
				(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @169
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2876, 1747)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@169
					location   	(2406, 1618)
					fill_color 	13434879
					nlines     	1
					max_width  	940
					justify    	0
					label      	"FunctionSignature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47D67D190077"
				    width      	958
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::FunctionSignatureImplementation" @170
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1616, 1741)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@170
					location   	(1299, 1637)
					fill_color 	13434879
					nlines     	1
					max_width  	634
					justify    	0
					label      	"FunctionSignatureImplementation")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4974995A0069"
				    width      	652
				    height     	232
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @171
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB74030D"
				    client     	@156
				    supplier   	@170
				    vertices   	(list Points
					(1632, 1995)
					(1632, 1857))
				    line_style 	3
				    origin_attachment 	(1632, 1995)
				    terminal_attachment 	(1632, 1857))
				(object AssociationViewNew "" @172
				    location   	(2169, 1751)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F4"
				    roleview_list 	(list RoleViews
					(object RoleView "functionSignature" @173
					    Parent_View 	@172
					    location   	(-865, 738)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @174
						Parent_View 	@173
						location   	(2216, 1794)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	346
						justify    	0
						label      	"+functionSignature"
						pctDist    	0.206140
						height     	43
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4975FB7F01F6"
					    client     	@172
					    supplier   	@169
					    vertices   	(list Points
						(2169, 1751)
						(2397, 1751))
					    line_style 	3
					    origin_attachment 	(2169, 1751)
					    terminal_attachment 	(2397, 1751)
					    label      	(object SegLabel @175
						Parent_View 	@173
						location   	(2357, 1708)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.824742
						height     	44
						orientation 	0))
					(object RoleView "implementation" @176
					    Parent_View 	@172
					    location   	(-865, 738)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @177
						Parent_View 	@176
						location   	(2103, 1705)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	304
						justify    	0
						label      	"+implementation"
						pctDist    	0.290749
						height     	46
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4975FB7F01F5"
					    client     	@172
					    supplier   	@170
					    vertices   	(list Points
						(2169, 1751)
						(1942, 1751))
					    line_style 	3
					    origin_attachment 	(2169, 1751)
					    terminal_attachment 	(1942, 1751)
					    label      	(object SegLabel @178
						Parent_View 	@176
						location   	(1983, 1792)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.820690
						height     	41
						orientation 	0))))
				(object InheritView "" @179
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4974996A0390"
				    client     	@170
				    supplier   	@144
				    vertices   	(list Points
					(1629, 1624)
					(1629, 1412))
				    line_style 	3
				    origin_attachment 	(1629, 1624)
				    terminal_attachment 	(1629, 1412))
				(object NoteView @180
				    location   	(575, 1899)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@180
					location   	(131, 1577)
					fill_color 	13434879
					nlines     	12
					max_width  	853
					label      	
|Question: Would it have been possible to use Block as Expression and hence just omit AnonymousFunctionExpr? Because a Block without "function ..." would not be an expression? But that could be disambiguated in the mapping, e.g., by using a specific mode for expressions (#expression) and a different mode (or no mode) for blocks that represent the implementation of a method signature (or vice versa).
					)
				    line_color 	3342489
				    fill_color 	13434879
				    width      	913
				    height     	656)
				(object InheritView "" @181
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47D67D2001B3"
				    client     	@169
				    supplier   	@161
				    vertices   	(list Points
					(2904, 1605)
					(2904, 1150))
				    line_style 	3
				    origin_attachment 	(2904, 1605)
				    terminal_attachment 	(2904, 1150))))
			(object ClassDiagram "Function from Method"
			    quid       	"487F6B5E031C"
			    title      	"Function from Method"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	0
			    origin_y   	0
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::data::classes::TypedElement" @182
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(456, 190)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@182
					location   	(308, 61)
					fill_color 	13434879
					nlines     	1
					max_width  	296
					justify    	0
					label      	"TypedElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4717B7BC031A"
				    width      	314
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @183
				    ShowCompartmentStereotypes 	TRUE
				    SuppressOperation 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1595, 291)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@183
					location   	(1450, 216)
					fill_color 	13434879
					nlines     	1
					max_width  	290
					justify    	0
					label      	"TypeDefinition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B9A97A00CB"
				    width      	308
				    height     	174
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "" @184
				    location   	(1027, 247)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF4180109"
				    roleview_list 	(list RoleViews
					(object RoleView "ownerTypedElement" @185
					    Parent_View 	@184
					    location   	(235, 54)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @186
						Parent_View 	@185
						location   	(841, 206)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	393
						justify    	0
						label      	"+ownerTypedElement"
						pctDist    	0.449198
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47CBF418010B"
					    client     	@184
					    supplier   	@182
					    vertices   	(list Points
						(1027, 247)
						(613, 247))
					    line_style 	3
					    origin_attachment 	(1027, 247)
					    terminal_attachment 	(613, 247)
					    label      	(object SegLabel @187
						Parent_View 	@185
						location   	(701, 295)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.788732
						height     	48
						orientation 	0))
					(object RoleView "ownedTypeDefinition" @188
					    Parent_View 	@184
					    location   	(235, 54)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @189
						Parent_View 	@188
						location   	(1148, 277)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	396
						justify    	0
						label      	"+ownedTypeDefinition"
						pctDist    	0.295775
						height     	30
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47CBF418010A"
					    client     	@184
					    supplier   	@183
					    vertices   	(list Points
						(1027, 247)
						(1441, 247))
					    line_style 	3
					    origin_attachment 	(1027, 247)
					    terminal_attachment 	(1441, 247)
					    label      	(object SegLabel @190
						Parent_View 	@188
						location   	(1383, 224)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.862676
						height     	24
						orientation 	0))))
				(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @191
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1994, 1127)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@191
					location   	(1524, 998)
					fill_color 	13434879
					nlines     	1
					max_width  	940
					justify    	0
					label      	"FunctionSignature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47D67D190077"
				    width      	958
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @192
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(495, 1120)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@192
					location   	(262, 1042)
					fill_color 	13434879
					nlines     	1
					max_width  	466
					justify    	0
					label      	"ObjectBasedExpression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"453E0FC80335"
				    width      	484
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @193
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(473, 704)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@193
					location   	(206, 475)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Expression")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"450E63AB03A2"
				    width      	552
				    height     	482
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "$UNNAMED$2" @194
				    location   	(1035, 912)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"453649650215"
				    roleview_list 	(list RoleViews
					(object RoleView "objectBasedExpression" @195
					    Parent_View 	@194
					    location   	(742, 276)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @196
						Parent_View 	@195
						location   	(1084, 1099)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+objectBasedExpression"
						pctDist    	0.380220
						height     	49
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4536496701C8"
					    client     	@194
					    supplier   	@192
					    vertices   	(list Points
						(1035, 912)
						(1035, 1107)
						(737, 1107))
					    line_style 	3
					    origin_attachment 	(1035, 912)
					    terminal_attachment 	(737, 1107)
					    label      	(object SegLabel @197
						Parent_View 	@195
						location   	(803, 1056)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	131
						justify    	0
						label      	"0..1"
						pctDist    	0.868132
						height     	52
						orientation 	1))
					(object RoleView "object" @198
					    Parent_View 	@194
					    location   	(742, 276)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @199
						Parent_View 	@198
						location   	(829, 756)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	139
						justify    	0
						label      	"+object"
						pctDist    	0.839161
						height     	51
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4536496701B4"
					    client     	@194
					    supplier   	@193
					    vertices   	(list Points
						(1035, 912)
						(1035, 705)
						(749, 705))
					    line_style 	3
					    origin_attachment 	(1035, 912)
					    terminal_attachment 	(749, 705)
					    label      	(object SegLabel @200
						Parent_View 	@198
						location   	(785, 656)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.926573
						height     	50
						orientation 	1))))
				(object ClassView "Class" "Logical View::data::classes::SapClass" @201
				    ShowCompartmentStereotypes 	TRUE
				    SuppressAttribute 	TRUE
				    SuppressOperation 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2317, 1927)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@201
					location   	(2206, 1877)
					fill_color 	13434879
					nlines     	1
					max_width  	222
					justify    	0
					label      	"SapClass")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432171B031E"
				    width      	240
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::data::classes::MethodSignature" @202
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2624, 1553)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@202
					location   	(2448, 1449)
					fill_color 	13434879
					nlines     	1
					max_width  	352
					justify    	0
					label      	"MethodSignature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47D67D15030D"
				    width      	370
				    height     	232
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::dataaccess::expressions::fp::FunctionFromMethodExpr" @203
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(500, 1559)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@203
					location   	(251, 1508)
					fill_color 	13434879
					nlines     	1
					max_width  	498
					justify    	0
					label      	"FunctionFromMethodExpr")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"487F6B6D0177"
				    width      	516
				    height     	126
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @204
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"487F6B76036B"
				    client     	@203
				    supplier   	@192
				    vertices   	(list Points
					(472, 1496)
					(472, 1210))
				    line_style 	3
				    origin_attachment 	(472, 1496)
				    terminal_attachment 	(472, 1210))
				(object AssociationViewNew "$UNNAMED$26" @205
				    location   	(1598, 1537)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"488086DC003E"
				    roleview_list 	(list RoleViews
					(object RoleView "method" @206
					    Parent_View 	@205
					    location   	(1268, 28)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @207
						Parent_View 	@206
						location   	(2302, 1489)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	176
						justify    	0
						label      	"+method"
						pctDist    	0.837004
						height     	49
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"488086DD0167"
					    client     	@205
					    supplier   	@202
					    vertices   	(list Points
						(1598, 1537)
						(2439, 1537))
					    line_style 	3
					    origin_attachment 	(1598, 1537)
					    terminal_attachment 	(2439, 1537)
					    label      	(object SegLabel @208
						Parent_View 	@206
						location   	(2376, 1575)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.926579
						height     	38
						orientation 	1))
					(object RoleView "$UNNAMED$27" @209
					    Parent_View 	@205
					    location   	(1268, 28)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"488086DD0186"
					    client     	@205
					    supplier   	@203
					    vertices   	(list Points
						(1598, 1537)
						(758, 1537))
					    line_style 	3
					    origin_attachment 	(1598, 1537)
					    terminal_attachment 	(758, 1537)
					    label      	(object SegLabel @210
						Parent_View 	@209
						location   	(875, 1587)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.861968
						height     	50
						orientation 	0))))
				(object NoteView @211
				    location   	(1426, 1790)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@211
					location   	(1119, 1675)
					fill_color 	13434879
					nlines     	4
					max_width  	578
					label      	"The class owning the method signature must be the same as the object's static type")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	638
				    height     	243)
				(object AttachView "" @212
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@211
				    supplier   	@194
				    vertices   	(list Points
					(1370, 1668)
					(1035, 912))
				    line_style 	0)
				(object AttachView "" @213
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@211
				    supplier   	@201
				    vertices   	(list Points
					(1745, 1838)
					(2196, 1906))
				    line_style 	0)
				(object ClassView "Class" "Logical View::data::classes::FunctionSignatureTypeDefinition" @214
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1396, 665)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@214
					location   	(1082, 587)
					fill_color 	13434879
					nlines     	1
					max_width  	628
					justify    	0
					label      	"FunctionSignatureTypeDefinition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47B9A9AD03B9"
				    width      	646
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @215
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9A9C20109"
				    client     	@214
				    supplier   	@183
				    vertices   	(list Points
					(1565, 574)
					(1565, 377))
				    line_style 	3
				    origin_attachment 	(1565, 574)
				    terminal_attachment 	(1565, 377))
				(object ClassView "Class" "Logical View::data::classes::Signature" @216
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2469, 637)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@216
					location   	(2202, 433)
					fill_color 	13434879
					nlines     	1
					max_width  	534
					justify    	0
					label      	"Signature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432198602CB"
				    width      	552
				    height     	432
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "" @217
				    location   	(1956, 662)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6000F"
				    roleview_list 	(list RoleViews
					(object RoleView "typeDefinition" @218
					    Parent_View 	@217
					    location   	(-151, 72)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @219
						Parent_View 	@218
						location   	(1871, 701)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+typeDefinition"
						pctDist    	0.358650
						height     	39
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"48A02BD6007D"
					    client     	@217
					    supplier   	@214
					    vertices   	(list Points
						(1956, 662)
						(1719, 662))
					    line_style 	3
					    origin_attachment 	(1956, 662)
					    terminal_attachment 	(1719, 662)
					    label      	(object SegLabel @220
						Parent_View 	@218
						location   	(1777, 623)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.755274
						height     	39
						orientation 	1))
					(object RoleView "signature" @221
					    Parent_View 	@217
					    location   	(-151, 72)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @222
						Parent_View 	@221
						location   	(2084, 622)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	206
						justify    	0
						label      	"+signature"
						pctDist    	0.540084
						height     	40
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"48A02BD6002E"
					    client     	@217
					    supplier   	@216
					    vertices   	(list Points
						(1956, 662)
						(2193, 662))
					    line_style 	3
					    origin_attachment 	(1956, 662)
					    terminal_attachment 	(2193, 662)
					    label      	(object SegLabel @223
						Parent_View 	@221
						location   	(2168, 716)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object InheritView "" @224
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"453E0FF30001"
				    client     	@192
				    supplier   	@193
				    vertices   	(list Points
					(497, 1030)
					(497, 944))
				    line_style 	3
				    origin_attachment 	(497, 1030)
				    terminal_attachment 	(497, 944))
				(object InheritView "l" @225
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@225
					location   	(450, 397)
					anchor_loc 	1
					nlines     	1
					max_width  	60
					justify    	0
					label      	"l")
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717B87503E5"
				    client     	@193
				    supplier   	@182
				    vertices   	(list Points
					(450, 462)
					(450, 331))
				    line_style 	3
				    origin_attachment 	(450, 462)
				    terminal_attachment 	(450, 331))
				(object InheritTreeView "" @226
				    location   	(2469, 947)
				    line_color 	3342489
				    fill_color 	13434879
				    supplier   	@216
				    vertices   	(list Points
					(2469, 947)
					(2469, 853)))
				(object InheritView "" @227
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47D67D2001B3"
				    client     	@191
				    supplier   	@216
				    vertices   	(list Points
					(2022, 985)
					(2022, 947))
				    line_style 	3
				    origin_attachment 	(2022, 985)
				    terminal_attachment 	(2022, 947)
				    drawSupplier 	@226)
				(object InheritView "" @228
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47D67D1D035D"
				    client     	@202
				    supplier   	@216
				    vertices   	(list Points
					(2696, 1436)
					(2696, 947))
				    line_style 	3
				    origin_attachment 	(2696, 1436)
				    terminal_attachment 	(2696, 947)
				    drawSupplier 	@226))))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Expressions"
		    quid       	"4522AC3B0173"
		    title      	"Expressions"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	800
		    origin_y   	9
		    items      	(list diagram_item_list
			(object NoteView @229
			    location   	(2164, 2453)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@229
				location   	(1539, 2290)
				fill_color 	13434879
				nlines     	6
				max_width  	1214
				label      	
|An expression can implicitly define its type. For example, if a "query expression" (FromEntry) uses a projection clause with multiple elements, the result is a collection of objects whose type is a class with the respective association ends attached. This implies that expression results may be structured deeply.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	1274
			    height     	338)
			(object ClassView "Class" "Logical View::dataaccess::expressions::literals::Literal" @230
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2109, 1728)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@230
				location   	(1962, 1624)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"Literal")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454746D10018"
			    width      	312
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::This" @231
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1353, 1924)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@231
				location   	(1272, 1873)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"This")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45A9433E03D2"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @232
			    location   	(597, 785)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@232
				location   	(325, 638)
				fill_color 	13434879
				nlines     	5
				max_width  	508
				label      	"Expression shouldn't inherit from TypedElement but should associate a TypedElement.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	568
			    height     	306)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @233
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1750, 597)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@233
				location   	(1602, 468)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SapClass" @234
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2816, 283)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@234
				location   	(2608, 204)
				fill_color 	13434879
				nlines     	1
				max_width  	416
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	434
			    height     	182
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @235
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1763, 266)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@235
				location   	(1468, 137)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"ClassTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4784F7E800AB"
			    width      	608
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @236
			    location   	(2333, 255)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4784F7F5005D"
			    roleview_list 	(list RoleViews
				(object RoleView "clazz" @237
				    Parent_View 	@236
				    location   	(677, 99)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @238
					Parent_View 	@237
					location   	(2499, 297)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	136
					justify    	0
					label      	"+clazz"
					pctDist    	0.625616
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005F"
				    client     	@236
				    supplier   	@234
				    vertices   	(list Points
					(2333, 255)
					(2599, 255))
				    line_style 	3
				    origin_attachment 	(2333, 255)
				    terminal_attachment 	(2599, 255)
				    label      	(object SegLabel @239
					Parent_View 	@237
					location   	(2573, 214)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.901478
					height     	42
					orientation 	0))
				(object RoleView "elementsOfType" @240
				    Parent_View 	@236
				    location   	(677, 99)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @241
					Parent_View 	@240
					location   	(2263, 216)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	320
					justify    	0
					label      	"+elementsOfType"
					pctDist    	0.265000
					height     	40
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005E"
				    client     	@236
				    supplier   	@235
				    vertices   	(list Points
					(2333, 255)
					(2067, 255))
				    line_style 	3
				    origin_attachment 	(2333, 255)
				    terminal_attachment 	(2067, 255)
				    label      	(object SegLabel @242
					Parent_View 	@240
					location   	(2129, 297)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.770000
					height     	42
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::Multiplicity" @243
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1046, 353)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@243
				location   	(793, 149)
				fill_color 	13434879
				nlines     	1
				max_width  	506
				justify    	0
				label      	"Multiplicity")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47554DA003A9"
			    width      	524
			    height     	432
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::VariableExpression" @244
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2398, 2147)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@244
				location   	(2202, 2095)
				fill_color 	13434879
				nlines     	1
				max_width  	392
				justify    	0
				label      	"VariableExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522AC6A022F"
			    width      	410
			    height     	128
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @245
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3051, 1619)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@245
				location   	(2784, 1515)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    width      	552
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$0" @246
			    location   	(3004, 2129)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4522AE0D02E6"
			    roleview_list 	(list RoleViews
				(object RoleView "$UNNAMED$1" @247
				    Parent_View 	@246
				    location   	(693, 763)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @248
					Parent_View 	@247
					location   	(2684, 2088)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					hidden     	TRUE
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	""
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4522AE0E00CB"
				    client     	@246
				    supplier   	@244
				    vertices   	(list Points
					(3004, 2129)
					(2603, 2129))
				    line_style 	3
				    origin_attachment 	(3004, 2129)
				    terminal_attachment 	(2603, 2129))
				(object RoleView "variable" @249
				    Parent_View 	@246
				    location   	(693, 763)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @250
					Parent_View 	@249
					location   	(2954, 1802)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	173
					justify    	0
					label      	"+variable"
					pctDist    	0.852632
					height     	111
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4522AE0E00C0"
				    client     	@246
				    supplier   	@245
				    vertices   	(list Points
					(3004, 2129)
					(3064, 2129)
					(3064, 1735))
				    line_style 	3
				    origin_attachment 	(3004, 2129)
				    terminal_attachment 	(3064, 1735)
				    label      	(object SegLabel @251
					Parent_View 	@249
					location   	(3109, 1811)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.831579
					height     	45
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectCount" @252
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(818, 1927)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@252
				location   	(690, 1876)
				fill_color 	13434879
				nlines     	1
				max_width  	256
				justify    	0
				label      	"ObjectCount")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"48E9DE8C030D"
			    width      	274
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @253
			    location   	(1975, 2792)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@253
				location   	(1687, 2707)
				fill_color 	13434879
				nlines     	3
				max_width  	540
				label      	"TODO: We most definitely need coercion expressions")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	600
			    height     	182)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Head" @254
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(567, 1927)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@254
				location   	(486, 1876)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Head")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49BFCF80001E"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Tail" @255
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(351, 1927)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@255
				location   	(270, 1876)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Tail")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49BFCF9E020B"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::AsList" @256
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(147, 1925)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@256
				location   	(66, 1874)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"AsList")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49BFD73E033E"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Ternary" @257
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1089, 1926)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@257
				location   	(1000, 1875)
				fill_color 	13434879
				nlines     	1
				max_width  	178
				justify    	0
				label      	"Ternary")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4A389707002E"
			    width      	196
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @258
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(617, 1661)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@258
				location   	(381, 1610)
				fill_color 	13434879
				nlines     	1
				max_width  	472
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	490
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @259
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49BFCFE2021E"
			    client     	@254
			    supplier   	@258
			    vertices   	(list Points
				(569, 1864)
				(569, 1724))
			    line_style 	3
			    origin_attachment 	(569, 1864)
			    terminal_attachment 	(569, 1724))
			(object InheritView "" @260
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49BFCFDF0087"
			    client     	@255
			    supplier   	@258
			    vertices   	(list Points
				(350, 1864)
				(350, 1813)
				(569, 1813)
				(569, 1724))
			    line_style 	3
			    origin_attachment 	(350, 1864)
			    terminal_attachment 	(569, 1724))
			(object InheritView "" @261
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48E9DEC500AB"
			    client     	@252
			    supplier   	@258
			    vertices   	(list Points
				(822, 1864)
				(822, 1813)
				(569, 1813)
				(569, 1724))
			    line_style 	3
			    origin_attachment 	(822, 1864)
			    terminal_attachment 	(569, 1724))
			(object InheritView "" @262
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49BFD7480223"
			    client     	@256
			    supplier   	@258
			    vertices   	(list Points
				(159, 1862)
				(159, 1813)
				(569, 1813)
				(569, 1724))
			    line_style 	3
			    origin_attachment 	(159, 1862)
			    terminal_attachment 	(569, 1724))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @263
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1307, 1137)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@263
				location   	(1040, 931)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$2" @264
			    location   	(675, 1163)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "object" @265
				    Parent_View 	@264
				    location   	(444, 562)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @266
					Parent_View 	@265
					location   	(928, 1054)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.762836
					height     	31
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@264
				    supplier   	@263
				    vertices   	(list Points
					(675, 1163)
					(675, 1084)
					(1031, 1084))
				    line_style 	3
				    origin_attachment 	(675, 1163)
				    terminal_attachment 	(1031, 1084)
				    label      	(object SegLabel @267
					Parent_View 	@265
					location   	(996, 1134)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.919315
					height     	50
					orientation 	1))
				(object RoleView "objectBasedExpression" @268
				    Parent_View 	@264
				    location   	(444, 562)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @269
					Parent_View 	@268
					location   	(428, 1470)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	455
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.709091
					height     	248
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@264
				    supplier   	@258
				    vertices   	(list Points
					(675, 1163)
					(675, 1598))
				    line_style 	3
				    origin_attachment 	(675, 1163)
				    terminal_attachment 	(675, 1598)
				    label      	(object SegLabel @270
					Parent_View 	@268
					location   	(611, 1553)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.896104
					height     	65
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Equals" @271
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2599, 1702)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@271
				location   	(2514, 1651)
				fill_color 	13434879
				nlines     	1
				max_width  	170
				justify    	0
				label      	"Equals")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"475958230399"
			    width      	188
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$7" @272
			    location   	(2325, 1188)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4759584301D4"
			    roleview_list 	(list RoleViews
				(object RoleView "left" @273
				    Parent_View 	@272
				    location   	(-470, 386)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @274
					Parent_View 	@273
					location   	(1752, 1153)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	80
					justify    	0
					label      	"+left"
					pctDist    	0.773788
					height     	36
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4759584402DE"
				    client     	@272
				    supplier   	@263
				    vertices   	(list Points
					(2325, 1188)
					(1583, 1188))
				    line_style 	3
				    origin_attachment 	(2325, 1188)
				    terminal_attachment 	(1583, 1188)
				    label      	(object SegLabel @275
					Parent_View 	@273
					location   	(1627, 1153)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.940754
					height     	36
					orientation 	1))
				(object RoleView "leftOfEquals" @276
				    Parent_View 	@272
				    location   	(-470, 386)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @277
					Parent_View 	@276
					location   	(2576, 1473)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	246
					justify    	0
					label      	"+leftOfEquals"
					pctDist    	0.777299
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4759584402FD"
				    client     	@272
				    supplier   	@271
				    vertices   	(list Points
					(2325, 1188)
					(2616, 1188)
					(2616, 1639))
				    line_style 	3
				    origin_attachment 	(2325, 1188)
				    terminal_attachment 	(2616, 1639)
				    label      	(object SegLabel @278
					Parent_View 	@276
					location   	(2574, 1555)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.888124
					height     	43
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$11" @279
			    location   	(2403, 1090)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"497656FD0205"
			    roleview_list 	(list RoleViews
				(object RoleView "right" @280
				    Parent_View 	@279
				    location   	(273, -303)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @281
					Parent_View 	@280
					location   	(1747, 1049)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	108
					justify    	0
					label      	"+right"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49765700006E"
				    client     	@279
				    supplier   	@263
				    vertices   	(list Points
					(2403, 1090)
					(1583, 1090))
				    line_style 	3
				    origin_attachment 	(2403, 1090)
				    terminal_attachment 	(1583, 1090)
				    label      	(object SegLabel @282
					Parent_View 	@280
					location   	(1634, 1053)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.938567
					height     	38
					orientation 	1))
				(object RoleView "rightOfEquals" @283
				    Parent_View 	@279
				    location   	(273, -303)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @284
					Parent_View 	@283
					location   	(2720, 1426)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	282
					justify    	0
					label      	"+rightOfEquals"
					pctDist    	0.740310
					height     	46
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49765700009D"
				    client     	@279
				    supplier   	@271
				    vertices   	(list Points
					(2403, 1090)
					(2674, 1090)
					(2674, 1639))
				    line_style 	3
				    origin_attachment 	(2403, 1090)
				    terminal_attachment 	(2674, 1639)
				    label      	(object SegLabel @285
					Parent_View 	@283
					location   	(2722, 1559)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.904110
					height     	48
					orientation 	0))))
			(object InheritTreeView "" @286
			    location   	(1307, 1472)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@263
			    vertices   	(list Points
				(1307, 1472)
				(1307, 1355)))
			(object InheritView "" @287
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@258
			    supplier   	@263
			    vertices   	(list Points
				(750, 1597)
				(750, 1472))
			    line_style 	3
			    origin_attachment 	(750, 1597)
			    terminal_attachment 	(750, 1472)
			    drawSupplier 	@286)
			(object InheritView "" @288
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"454746F00167"
			    client     	@230
			    supplier   	@263
			    vertices   	(list Points
				(2097, 1612)
				(2097, 1472))
			    line_style 	3
			    origin_attachment 	(2097, 1612)
			    terminal_attachment 	(2097, 1472)
			    drawSupplier 	@286)
			(object InheritView "" @289
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4545FDBE01AE"
			    client     	@244
			    supplier   	@263
			    vertices   	(list Points
				(2400, 2083)
				(2400, 1472))
			    line_style 	3
			    origin_attachment 	(2400, 2083)
			    terminal_attachment 	(2400, 1472)
			    drawSupplier 	@286)
			(object InheritView "" @290
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45A94345036E"
			    client     	@231
			    supplier   	@263
			    vertices   	(list Points
				(1343, 1860)
				(1343, 1472))
			    line_style 	3
			    origin_attachment 	(1343, 1860)
			    terminal_attachment 	(1343, 1472)
			    drawSupplier 	@286)
			(object InheritView "" @291
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4759582D007D"
			    client     	@271
			    supplier   	@263
			    vertices   	(list Points
				(2518, 1638)
				(2518, 1472))
			    line_style 	3
			    origin_attachment 	(2518, 1638)
			    terminal_attachment 	(2518, 1472)
			    drawSupplier 	@286)
			(object InheritView "" @292
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A38971503A9"
			    client     	@257
			    supplier   	@263
			    vertices   	(list Points
				(1087, 1863)
				(1087, 1472))
			    line_style 	3
			    origin_attachment 	(1087, 1863)
			    terminal_attachment 	(1087, 1472)
			    drawSupplier 	@286)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ContentEquals" @293
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2600, 1940)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@293
				location   	(2453, 1889)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"ContentEquals")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B06A82B0109"
			    width      	312
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @294
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B06A83500CB"
			    client     	@293
			    supplier   	@271
			    vertices   	(list Points
				(2599, 1877)
				(2599, 1765))
			    line_style 	3
			    origin_attachment 	(2599, 1877)
			    terminal_attachment 	(2599, 1765))
			(object InheritTreeView "" @295
			    location   	(1750, 853)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@233
			    vertices   	(list Points
				(1750, 853)
				(1750, 738)))
			(object AttachView "" @296
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@232
			    supplier   	@295
			    vertices   	(list Points
				(881, 787)
				(1750, 795))
			    line_style 	0)
			(object InheritView "l" @297
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@297
				location   	(1309, 886)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@263
			    supplier   	@233
			    vertices   	(list Points
				(1309, 919)
				(1309, 853))
			    line_style 	3
			    origin_attachment 	(1309, 919)
			    terminal_attachment 	(1309, 853)
			    drawSupplier 	@295)
			(object InheritView "" @298
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B85102FB"
			    client     	@245
			    supplier   	@233
			    vertices   	(list Points
				(3048, 1503)
				(3048, 853))
			    line_style 	3
			    origin_attachment 	(3048, 1503)
			    terminal_attachment 	(3048, 853)
			    drawSupplier 	@295)))
		(object ClassDiagram "Method Call Expression"
		    quid       	"453627180132"
		    title      	"Method Call Expression"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	606
		    origin_y   	319
		    items      	(list diagram_item_list
			(object NoteView @299
			    location   	(1425, 543)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@299
				location   	(1137, 462)
				fill_color 	13434879
				nlines     	3
				max_width  	540
				label      	"Should the arguments of the QueryExpression be required to be ReadOnlyExpressions?")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	600
			    height     	175)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @300
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(753, 271)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@300
				location   	(605, 142)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::Signature" @301
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2062, 1344)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@301
				location   	(1814, 1190)
				fill_color 	13434879
				nlines     	1
				max_width  	496
				justify    	0
				label      	"Signature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432198602CB"
			    width      	514
			    height     	332
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @302
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(326, 1355)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@302
				location   	(92, 1304)
				fill_color 	13434879
				nlines     	1
				max_width  	468
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	486
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::SignatureCallExpression" @303
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(951, 1352)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@303
				location   	(676, 1246)
				fill_color 	13434879
				nlines     	1
				max_width  	550
				justify    	0
				label      	"SignatureCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F3B80500BD"
			    compartment 	(object Compartment
				Parent_View 	@303
				location   	(676, 1307)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	0)
			    width      	568
			    height     	236
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @304
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(745, 840)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@304
				location   	(401, 634)
				fill_color 	13434879
				nlines     	1
				max_width  	688
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	706
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$2" @305
			    location   	(249, 1009)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @306
				    Parent_View 	@305
				    location   	(-495, 682)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @307
					Parent_View 	@306
					location   	(298, 1178)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.597173
					height     	49
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@305
				    supplier   	@302
				    vertices   	(list Points
					(249, 1009)
					(249, 1292))
				    line_style 	3
				    origin_attachment 	(249, 1009)
				    terminal_attachment 	(249, 1292)
				    label      	(object SegLabel @308
					Parent_View 	@306
					location   	(193, 1243)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.830688
					height     	57
					orientation 	1))
				(object RoleView "object" @309
				    Parent_View 	@305
				    location   	(-495, 682)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @310
					Parent_View 	@309
					location   	(311, 831)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.713781
					height     	38
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@305
				    supplier   	@304
				    vertices   	(list Points
					(249, 1009)
					(249, 869)
					(392, 869))
				    line_style 	3
				    origin_attachment 	(249, 1009)
				    terminal_attachment 	(392, 869)
				    label      	(object SegLabel @311
					Parent_View 	@309
					location   	(347, 907)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.840426
					height     	38
					orientation 	1))))
			(object InheritView "l" @312
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@312
				location   	(741, 517)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@304
			    supplier   	@300
			    vertices   	(list Points
				(741, 622)
				(741, 412))
			    line_style 	3
			    origin_attachment 	(741, 622)
			    terminal_attachment 	(741, 412))
			(object AssociationViewNew "SignatureCallParameters" @313
			    location   	(1197, 997)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @314
				Parent_View 	@313
				location   	(1453, 1044)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"SignatureCallParameters"
				pctDist    	4.766667
				height     	47
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B8AB019D"
			    roleview_list 	(list RoleViews
				(object RoleView "usedAsArgumentInSignatureCall" @315
				    Parent_View 	@313
				    location   	(452, 157)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @316
					Parent_View 	@315
					location   	(1259, 1145)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	613
					justify    	0
					label      	"+usedAsArgumentInSignatureCall"
					pctDist    	0.624473
					height     	62
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC036B"
				    client     	@313
				    supplier   	@303
				    vertices   	(list Points
					(1197, 997)
					(1197, 1233))
				    line_style 	3
				    origin_attachment 	(1197, 997)
				    terminal_attachment 	(1197, 1233)
				    label      	(object SegLabel @317
					Parent_View 	@315
					location   	(1251, 1209)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	119
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "parameters" @318
				    Parent_View 	@313
				    location   	(452, 157)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @319
					Parent_View 	@318
					location   	(1245, 823)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	235
					justify    	0
					label      	"+parameters"
					pctDist    	1.260870
					height     	48
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC0339"
				    client     	@313
				    supplier   	@304
				    vertices   	(list Points
					(1197, 997)
					(1197, 859)
					(1098, 859))
				    line_style 	3
				    origin_attachment 	(1197, 997)
				    terminal_attachment 	(1098, 859)
				    label      	(object SegLabel @320
					Parent_View 	@318
					location   	(1153, 895)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	194
					justify    	0
					label      	"0..n"
					pctDist    	0.767677
					height     	36
					orientation 	0)
				    label      	(object SegLabel @321
					Parent_View 	@318
					location   	(1170, 951)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.700337
					height     	92
					orientation 	0))))
			(object InheritTreeView "" @322
			    location   	(745, 1148)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@304
			    vertices   	(list Points
				(745, 1148)
				(745, 1058)))
			(object InheritView "" @323
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@302
			    supplier   	@304
			    vertices   	(list Points
				(300, 1292)
				(300, 1148))
			    line_style 	3
			    origin_attachment 	(300, 1292)
			    terminal_attachment 	(300, 1148)
			    drawSupplier 	@322)
			(object InheritView "" @324
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B890000D"
			    client     	@303
			    supplier   	@304
			    vertices   	(list Points
				(781, 1234)
				(781, 1148))
			    line_style 	3
			    origin_attachment 	(781, 1234)
			    terminal_attachment 	(781, 1148)
			    drawSupplier 	@322)
			(object ClassView "Class" "Logical View::data::classes::MethodSignature" @325
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2069, 1799)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@325
				location   	(1893, 1695)
				fill_color 	13434879
				nlines     	1
				max_width  	352
				justify    	0
				label      	"MethodSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D15030D"
			    width      	370
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @326
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47D67D1D035D"
			    client     	@325
			    supplier   	@301
			    vertices   	(list Points
				(2041, 1683)
				(2041, 1510))
			    line_style 	3
			    origin_attachment 	(2041, 1683)
			    terminal_attachment 	(2041, 1510))
			(object ClassView "Class" "Logical View::dataaccess::expressions::MethodCallExpression" @327
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(596, 1827)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@327
				location   	(351, 1746)
				fill_color 	13434879
				nlines     	1
				max_width  	490
				justify    	0
				label      	"MethodCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522E05D00A8"
			    width      	508
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @328
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47BC30F40203"
			    client     	@327
			    supplier   	@302
			    vertices   	(list Points
				(422, 1734)
				(422, 1418))
			    line_style 	3
			    origin_attachment 	(422, 1734)
			    terminal_attachment 	(422, 1418))
			(object InheritView "" @329
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B83200B9"
			    client     	@327
			    supplier   	@303
			    vertices   	(list Points
				(772, 1733)
				(772, 1470))
			    line_style 	3
			    origin_attachment 	(772, 1733)
			    terminal_attachment 	(772, 1470))
			(object AssociationViewNew "SignatureCallToSignature" @330
			    location   	(1367, 1800)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @331
				Parent_View 	@330
				location   	(1337, 1768)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	465
				justify    	0
				label      	"SignatureCallToSignature"
				pctDist    	0.000000
				height     	33
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4939041D0109"
			    roleview_list 	(list RoleViews
				(object RoleView "methodSignature" @332
				    Parent_View 	@330
				    location   	(416, 448)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @333
					Parent_View 	@332
					location   	(1687, 1831)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	329
					justify    	0
					label      	"+methodSignature"
					pctDist    	0.620493
					height     	31
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4939041D010B"
				    client     	@330
				    supplier   	@325
				    vertices   	(list Points
					(1367, 1800)
					(1884, 1800))
				    line_style 	3
				    origin_attachment 	(1367, 1800)
				    terminal_attachment 	(1884, 1800)
				    label      	(object SegLabel @334
					Parent_View 	@332
					location   	(1820, 1736)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.878205
					height     	65
					orientation 	0))
				(object RoleView "$UNNAMED$10" @335
				    Parent_View 	@330
				    location   	(416, 448)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4939041D010A"
				    client     	@330
				    supplier   	@327
				    vertices   	(list Points
					(1367, 1800)
					(850, 1800))
				    line_style 	3
				    origin_attachment 	(1367, 1800)
				    terminal_attachment 	(850, 1800)
				    label      	(object SegLabel @336
					Parent_View 	@335
					location   	(975, 1837)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.759615
					height     	37
					orientation 	0))))))
		(object ClassDiagram "Object Creation Expression"
		    quid       	"454BA25D0095"
		    title      	"Object Creation Expression"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @337
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(978, 781)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@337
				location   	(635, 575)
				fill_color 	13434879
				nlines     	1
				max_width  	686
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	704
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @338
			    location   	(834, 2199)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@338
				location   	(403, 2071)
				fill_color 	13434879
				nlines     	5
				max_width  	827
				label      	"TODO: For now we offer simple initialization in ObjectCreationExpressions. If later full-blown constructors are allowed, initializers must be revistited.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	887
			    height     	268)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @339
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(971, 240)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@339
				location   	(823, 111)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "l" @340
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@340
				location   	(975, 472)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@337
			    supplier   	@339
			    vertices   	(list Points
				(975, 563)
				(975, 381))
			    line_style 	3
			    origin_attachment 	(975, 563)
			    terminal_attachment 	(975, 381))
			(object ClassView "Class" "Logical View::data::classes::Multiplicity" @341
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2427, 446)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@341
				location   	(2174, 242)
				fill_color 	13434879
				nlines     	1
				max_width  	506
				justify    	0
				label      	"Multiplicity")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47554DA003A9"
			    width      	524
			    height     	432
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @342
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1603, 395)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@342
				location   	(1308, 266)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"ClassTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4784F7E800AB"
			    width      	608
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SapClass" @343
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2566, 1696)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@343
				location   	(2082, 1092)
				fill_color 	13434879
				nlines     	1
				max_width  	968
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	986
			    height     	1232
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @344
			    location   	(1609, 1257)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4784F7F5005D"
			    roleview_list 	(list RoleViews
				(object RoleView "clazz" @345
				    Parent_View 	@344
				    location   	(75, 791)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @346
					Parent_View 	@345
					location   	(1856, 1467)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	136
					justify    	0
					label      	"+clazz"
					pctDist    	0.699612
					height     	48
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005F"
				    client     	@344
				    supplier   	@343
				    vertices   	(list Points
					(1609, 1257)
					(1609, 1514)
					(2073, 1514))
				    line_style 	3
				    origin_attachment 	(1609, 1257)
				    terminal_attachment 	(2073, 1514)
				    label      	(object SegLabel @347
					Parent_View 	@345
					location   	(2012, 1464)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.916667
					height     	51
					orientation 	0))
				(object RoleView "elementsOfType" @348
				    Parent_View 	@344
				    location   	(75, 791)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @349
					Parent_View 	@348
					location   	(1812, 648)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	320
					justify    	0
					label      	"+elementsOfType"
					pctDist    	0.844660
					height     	203
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005E"
				    client     	@344
				    supplier   	@342
				    vertices   	(list Points
					(1609, 1257)
					(1609, 536))
				    line_style 	3
				    origin_attachment 	(1609, 1257)
				    terminal_attachment 	(1609, 536)
				    label      	(object SegLabel @350
					Parent_View 	@348
					location   	(1680, 591)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.925602
					height     	71
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::MethodCallExpression" @351
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(335, 680)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@351
				location   	(90, 599)
				fill_color 	13434879
				nlines     	1
				max_width  	490
				justify    	0
				label      	"MethodCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522E05D00A8"
			    width      	508
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectCreationExpression" @352
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(971, 1206)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@352
				location   	(721, 1155)
				fill_color 	13434879
				nlines     	1
				max_width  	500
				justify    	0
				label      	"ObjectCreationExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454BA26C0254"
			    width      	518
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @353
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"454BA274017C"
			    client     	@352
			    supplier   	@337
			    vertices   	(list Points
				(978, 1143)
				(978, 999))
			    line_style 	3
			    origin_attachment 	(978, 1143)
			    terminal_attachment 	(978, 999))
			(object AssociationViewNew "$UNNAMED$3" @354
			    location   	(1440, 1624)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"454BA28B0154"
			    roleview_list 	(list RoleViews
				(object RoleView "classToInstantiate" @355
				    Parent_View 	@354
				    location   	(762, 996)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @356
					Parent_View 	@355
					location   	(1780, 1674)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	360
					justify    	0
					label      	"+classToInstantiate"
					pctDist    	0.539192
					height     	50
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454BA28C00A2"
				    client     	@354
				    supplier   	@343
				    vertices   	(list Points
					(1440, 1624)
					(2073, 1624))
				    line_style 	3
				    origin_attachment 	(1440, 1624)
				    terminal_attachment 	(2073, 1624)
				    label      	(object SegLabel @357
					Parent_View 	@355
					location   	(1986, 1580)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.862069
					height     	45
					orientation 	0))
				(object RoleView "$UNNAMED$4" @358
				    Parent_View 	@354
				    location   	(762, 996)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454BA28C0156"
				    client     	@354
				    supplier   	@352
				    vertices   	(list Points
					(1440, 1624)
					(1162, 1624)
					(1162, 1269))
				    line_style 	3
				    origin_attachment 	(1440, 1624)
				    terminal_attachment 	(1162, 1269))))
			(object AttachView "" @359
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@338
			    supplier   	@352
			    vertices   	(list Points
				(1103, 2064)
				(1103, 1268))
			    line_style 	3
			    origin_attachment 	(1103, 2064)
			    terminal_attachment 	(1103, 1268))
			(object AssociationViewNew "$UNNAMED$20" @360
			    location   	(319, 1139)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B1CF92F02A0"
			    roleview_list 	(list RoleViews
				(object RoleView "initializers" @361
				    Parent_View 	@360
				    location   	(-646, 39)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @362
					Parent_View 	@361
					location   	(453, 830)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	206
					justify    	0
					label      	"+initializers"
					pctDist    	0.845679
					height     	134
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B1CF930036B"
				    client     	@360
				    supplier   	@351
				    vertices   	(list Points
					(319, 1139)
					(319, 773))
				    line_style 	3
				    origin_attachment 	(319, 1139)
				    terminal_attachment 	(319, 773)
				    label      	(object SegLabel @363
					Parent_View 	@361
					location   	(269, 843)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.808642
					height     	51
					orientation 	0))
				(object RoleView "creationExpression" @364
				    Parent_View 	@360
				    location   	(-646, 39)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @365
					Parent_View 	@364
					location   	(424, 1245)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	375
					justify    	0
					label      	"+creationExpression"
					pctDist    	0.363914
					height     	46
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B1CF930036D"
				    client     	@360
				    supplier   	@352
				    vertices   	(list Points
					(319, 1139)
					(319, 1195)
					(712, 1195))
				    line_style 	3
				    origin_attachment 	(319, 1139)
				    terminal_attachment 	(712, 1195)
				    label      	(object SegLabel @366
					Parent_View 	@364
					location   	(651, 1157)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.865979
					height     	43
					orientation 	0))))))
		(object ClassDiagram "Function Call Expression"
		    quid       	"45473F5C0190"
		    title      	"Function Call Expression"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	862
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @367
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2325, 168)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@367
				location   	(2177, 39)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @368
			    location   	(2657, 2156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@368
				location   	(2251, 1940)
				fill_color 	13434879
				nlines     	8
				max_width  	777
				label      	
|The calledBlock expression must evaluate to something whose type is a FunctionSignatureTypeDefinition.
|The Signature of the FunctionCallExpression has then to be the same that is defined through this FunctionSignatureTypeDefinition
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	837
			    height     	444)
			(object ClassView "Class" "Logical View::dataaccess::expressions::FunctionCallExpression" @369
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2330, 1630)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@369
				location   	(2102, 1579)
				fill_color 	13434879
				nlines     	1
				max_width  	456
				justify    	0
				label      	"FunctionCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45473F620076"
			    width      	474
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::SignatureCallExpression" @370
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2314, 1260)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@370
				location   	(2039, 1154)
				fill_color 	13434879
				nlines     	1
				max_width  	550
				justify    	0
				label      	"SignatureCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F3B80500BD"
			    compartment 	(object Compartment
				Parent_View 	@370
				location   	(2039, 1215)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	547)
			    width      	568
			    height     	236
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @371
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2328, 691)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@371
				location   	(2061, 485)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$6" @372
			    location   	(2766, 1186)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45473F690329"
			    roleview_list 	(list RoleViews
				(object RoleView "calledBlock" @373
				    Parent_View 	@372
				    location   	(1926, 821)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @374
					Parent_View 	@373
					location   	(2763, 638)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	239
					justify    	0
					label      	"+calledBlock"
					pctDist    	0.758261
					height     	54
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45473F6A0302"
				    client     	@372
				    supplier   	@371
				    vertices   	(list Points
					(2766, 1186)
					(2766, 691)
					(2604, 691))
				    line_style 	3
				    origin_attachment 	(2766, 1186)
				    terminal_attachment 	(2604, 691)
				    label      	(object SegLabel @375
					Parent_View 	@373
					location   	(2652, 650)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.929155
					height     	42
					orientation 	1))
				(object RoleView "blockOfFunctionCallExpression" @376
				    Parent_View 	@372
				    location   	(1926, 821)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @377
					Parent_View 	@376
					location   	(2479, 1762)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	591
					justify    	0
					label      	"+blockOfFunctionCallExpression"
					pctDist    	1.135714
					height     	118
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45473F6A0316"
				    client     	@372
				    supplier   	@369
				    vertices   	(list Points
					(2766, 1186)
					(2766, 1644)
					(2567, 1644))
				    line_style 	3
				    origin_attachment 	(2766, 1186)
				    terminal_attachment 	(2567, 1644)
				    label      	(object SegLabel @378
					Parent_View 	@376
					location   	(2623, 1592)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.916376
					height     	53
					orientation 	1))))
			(object AttachView "" @379
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@368
			    supplier   	@372
			    vertices   	(list Points
				(2681, 1933)
				(2766, 1186))
			    line_style 	0)
			(object InheritView "l" @380
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@380
				location   	(2344, 391)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@371
			    supplier   	@367
			    vertices   	(list Points
				(2344, 473)
				(2344, 308))
			    line_style 	3
			    origin_attachment 	(2344, 473)
			    terminal_attachment 	(2344, 308))
			(object AssociationViewNew "SignatureCallParameters" @381
			    location   	(2194, 1025)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @382
				Parent_View 	@381
				location   	(2082, 1019)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"SignatureCallParameters"
				pctDist    	-1.383333
				height     	7
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B8AB019D"
			    roleview_list 	(list RoleViews
				(object RoleView "usedAsArgumentInSignatureCall" @383
				    Parent_View 	@381
				    location   	(335, -78)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @384
					Parent_View 	@383
					location   	(1876, 1077)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	613
					justify    	0
					label      	"+usedAsArgumentInSignatureCall"
					pctDist    	0.441441
					height     	319
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC036B"
				    client     	@381
				    supplier   	@370
				    vertices   	(list Points
					(2194, 1025)
					(2194, 1142))
				    line_style 	3
				    origin_attachment 	(2194, 1025)
				    terminal_attachment 	(2194, 1142)
				    label      	(object SegLabel @385
					Parent_View 	@383
					location   	(2123, 1120)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	138
					justify    	0
					label      	"0..1"
					pctDist    	0.814570
					height     	72
					orientation 	1))
				(object RoleView "parameters" @386
				    Parent_View 	@381
				    location   	(335, -78)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @387
					Parent_View 	@386
					location   	(2062, 926)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	235
					justify    	0
					label      	"+parameters"
					pctDist    	0.863636
					height     	133
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC0339"
				    client     	@381
				    supplier   	@371
				    vertices   	(list Points
					(2194, 1025)
					(2194, 909))
				    line_style 	3
				    origin_attachment 	(2194, 1025)
				    terminal_attachment 	(2194, 909)
				    label      	(object SegLabel @388
					Parent_View 	@386
					location   	(2271, 944)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	125
					justify    	0
					label      	"0..n"
					pctDist    	0.708609
					height     	77
					orientation 	1)
				    label      	(object SegLabel @389
					Parent_View 	@386
					location   	(2087, 967)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.496689
					height     	108
					orientation 	0))))
			(object InheritView "" @390
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B84601D1"
			    client     	@369
			    supplier   	@370
			    vertices   	(list Points
				(2325, 1567)
				(2325, 1377))
			    line_style 	3
			    origin_attachment 	(2325, 1567)
			    terminal_attachment 	(2325, 1377))
			(object ClassView "Class" "Logical View::data::classes::FunctionSignatureTypeDefinition" @391
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1345, 2312)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@391
				location   	(1031, 2234)
				fill_color 	13434879
				nlines     	1
				max_width  	628
				justify    	0
				label      	"FunctionSignatureTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A9AD03B9"
			    width      	646
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AttachView "" @392
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@368
			    supplier   	@391
			    vertices   	(list Points
				(2238, 2204)
				(1668, 2273))
			    line_style 	0)
			(object ClassView "Class" "Logical View::data::classes::Signature" @393
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1599, 1363)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@393
				location   	(1332, 1159)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Signature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432198602CB"
			    width      	552
			    height     	432
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @394
			    location   	(1666, 1900)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48A02BD6000F"
			    roleview_list 	(list RoleViews
				(object RoleView "typeDefinition" @395
				    Parent_View 	@394
				    location   	(546, 912)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @396
					Parent_View 	@395
					location   	(1625, 2157)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+typeDefinition"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6007D"
				    client     	@394
				    supplier   	@391
				    vertices   	(list Points
					(1666, 1900)
					(1666, 2221))
				    line_style 	3
				    origin_attachment 	(1666, 1900)
				    terminal_attachment 	(1666, 2221)
				    label      	(object SegLabel @397
					Parent_View 	@395
					location   	(1739, 2180)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.874576
					height     	73
					orientation 	0))
				(object RoleView "signature" @398
				    Parent_View 	@394
				    location   	(546, 912)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @399
					Parent_View 	@398
					location   	(1778, 1667)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	206
					justify    	0
					label      	"+signature"
					pctDist    	0.725424
					height     	112
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6002E"
				    client     	@394
				    supplier   	@393
				    vertices   	(list Points
					(1666, 1900)
					(1666, 1579))
				    line_style 	3
				    origin_attachment 	(1666, 1900)
				    terminal_attachment 	(1666, 1579)
				    label      	(object SegLabel @400
					Parent_View 	@398
					location   	(1720, 1611)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @401
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(485, 2125)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@401
				location   	(218, 1946)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    width      	552
			    height     	382
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SignatureImplementation" @402
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(517, 1152)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@402
				location   	(248, 1048)
				fill_color 	13434879
				nlines     	1
				max_width  	538
				justify    	0
				label      	"SignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47836ECF037A"
			    width      	556
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @403
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1376, 1877)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@403
				location   	(906, 1748)
				fill_color 	13434879
				nlines     	1
				max_width  	940
				justify    	0
				label      	"FunctionSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D190077"
			    width      	958
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @404
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47D67D2001B3"
			    client     	@403
			    supplier   	@393
			    vertices   	(list Points
				(1463, 1735)
				(1463, 1578))
			    line_style 	3
			    origin_attachment 	(1463, 1735)
			    terminal_attachment 	(1463, 1578))
			(object ClassView "Class" "Logical View::data::classes::FunctionSignatureImplementation" @405
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(517, 1589)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@405
				location   	(200, 1485)
				fill_color 	13434879
				nlines     	1
				max_width  	634
				justify    	0
				label      	"FunctionSignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4974995A0069"
			    width      	652
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @406
			    location   	(819, 1833)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4975FB7F01F4"
			    roleview_list 	(list RoleViews
				(object RoleView "functionSignature" @407
				    Parent_View 	@406
				    location   	(316, 1248)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @408
					Parent_View 	@407
					location   	(958, 1769)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	346
					justify    	0
					label      	"+functionSignature"
					pctDist    	1.783333
					height     	65
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F6"
				    client     	@406
				    supplier   	@403
				    vertices   	(list Points
					(819, 1833)
					(897, 1833))
				    line_style 	3
				    origin_attachment 	(819, 1833)
				    terminal_attachment 	(897, 1833)
				    label      	(object SegLabel @409
					Parent_View 	@407
					location   	(881, 1784)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.804795
					height     	50
					orientation 	0))
				(object RoleView "implementation" @410
				    Parent_View 	@406
				    location   	(316, 1248)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @411
					Parent_View 	@410
					location   	(573, 1807)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	304
					justify    	0
					label      	"+implementation"
					pctDist    	0.455882
					height     	187
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F5"
				    client     	@406
				    supplier   	@405
				    vertices   	(list Points
					(819, 1833)
					(759, 1833)
					(759, 1705))
				    line_style 	3
				    origin_attachment 	(819, 1833)
				    terminal_attachment 	(759, 1705)
				    label      	(object SegLabel @412
					Parent_View 	@410
					location   	(806, 1799)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.500000
					height     	47
					orientation 	1))))
			(object InheritView "" @413
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4974996A0390"
			    client     	@405
			    supplier   	@402
			    vertices   	(list Points
				(517, 1473)
				(517, 1268))
			    line_style 	3
			    origin_attachment 	(517, 1473)
			    terminal_attachment 	(517, 1268))
			(object InheritView "" @414
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B890000D"
			    client     	@370
			    supplier   	@371
			    vertices   	(list Points
				(2347, 1141)
				(2347, 909))
			    line_style 	3
			    origin_attachment 	(2347, 1141)
			    terminal_attachment 	(2347, 909))
			(object InheritView "" @415
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4975FB74030D"
			    client     	@401
			    supplier   	@405
			    vertices   	(list Points
				(341, 1934)
				(341, 1704))
			    line_style 	3
			    origin_attachment 	(341, 1934)
			    terminal_attachment 	(341, 1704))))
		(object ClassDiagram "Association Navigation"
		    quid       	"47861FFC037A"
		    title      	"Association Navigation"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	694
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @416
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(420, 1149)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@416
				location   	(183, 1098)
				fill_color 	13434879
				nlines     	1
				max_width  	474
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	492
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @417
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(420, 755)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@417
				location   	(77, 549)
				fill_color 	13434879
				nlines     	1
				max_width  	686
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	704
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$2" @418
			    location   	(1014, 1010)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @419
				    Parent_View 	@418
				    location   	(-274, 719)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @420
					Parent_View 	@419
					location   	(900, 1204)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.528226
					height     	46
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@418
				    supplier   	@416
				    vertices   	(list Points
					(1014, 1010)
					(1014, 1158)
					(666, 1158))
				    line_style 	3
				    origin_attachment 	(1014, 1010)
				    terminal_attachment 	(666, 1158)
				    label      	(object SegLabel @421
					Parent_View 	@419
					location   	(720, 1113)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.891129
					height     	45
					orientation 	1))
				(object RoleView "object" @422
				    Parent_View 	@418
				    location   	(-274, 719)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @423
					Parent_View 	@422
					location   	(872, 797)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@418
				    supplier   	@417
				    vertices   	(list Points
					(1014, 1010)
					(1014, 755)
					(772, 755))
				    line_style 	3
				    origin_attachment 	(1014, 1010)
				    terminal_attachment 	(772, 755)
				    label      	(object SegLabel @424
					Parent_View 	@422
					location   	(823, 702)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object InheritView "" @425
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@416
			    supplier   	@417
			    vertices   	(list Points
				(442, 1085)
				(442, 973))
			    line_style 	3
			    origin_attachment 	(442, 1085)
			    terminal_attachment 	(442, 973))
			(object ClassView "Class" "Logical View::dataaccess::expressions::AssociationEndNavigationExpression" @426
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(462, 1512)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@426
				location   	(110, 1461)
				fill_color 	13434879
				nlines     	1
				max_width  	704
				justify    	0
				label      	"AssociationEndNavigationExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"478620130157"
			    width      	722
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @427
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4786201B036B"
			    client     	@426
			    supplier   	@416
			    vertices   	(list Points
				(433, 1449)
				(433, 1211))
			    line_style 	3
			    origin_attachment 	(433, 1449)
			    terminal_attachment 	(433, 1211))
			(object ClassView "Class" "Logical View::data::classes::AssociationEnd" @428
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1702, 1505)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@428
				location   	(1388, 1326)
				fill_color 	13434879
				nlines     	1
				max_width  	628
				justify    	0
				label      	"AssociationEnd")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44EC55FB03B8"
			    width      	646
			    height     	382
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$8" @429
			    location   	(1101, 1512)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4786205D0261"
			    roleview_list 	(list RoleViews
				(object RoleView "toEnd" @430
				    Parent_View 	@429
				    location   	(-166, 462)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @431
					Parent_View 	@430
					location   	(1287, 1466)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	137
					justify    	0
					label      	"+toEnd"
					pctDist    	0.673981
					height     	47
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4786205E00AB"
				    client     	@429
				    supplier   	@428
				    vertices   	(list Points
					(1101, 1512)
					(1379, 1512))
				    line_style 	3
				    origin_attachment 	(1101, 1512)
				    terminal_attachment 	(1379, 1512)
				    label      	(object SegLabel @432
					Parent_View 	@430
					location   	(1350, 1566)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "$UNNAMED$9" @433
				    Parent_View 	@429
				    location   	(-166, 462)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4786205E00BB"
				    client     	@429
				    supplier   	@426
				    vertices   	(list Points
					(1101, 1512)
					(823, 1512))
				    line_style 	3
				    origin_attachment 	(1101, 1512)
				    terminal_attachment 	(823, 1512)
				    label      	(object SegLabel @434
					Parent_View 	@433
					location   	(868, 1554)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.842767
					height     	42
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @435
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1728, 855)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@435
				location   	(1433, 726)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"ClassTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4784F7E800AB"
			    width      	608
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @436
			    location   	(1722, 1155)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9ABAE00AB"
			    roleview_list 	(list RoleViews
				(object RoleView "associationEnd" @437
				    Parent_View 	@436
				    location   	(53, 296)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @438
					Parent_View 	@437
					location   	(1519, 1279)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	304
					justify    	0
					label      	"+associationEnd"
					pctDist    	0.789189
					height     	204
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9ABAF02BF"
				    client     	@436
				    supplier   	@428
				    vertices   	(list Points
					(1722, 1155)
					(1722, 1314))
				    line_style 	3
				    origin_attachment 	(1722, 1155)
				    terminal_attachment 	(1722, 1314)
				    label      	(object SegLabel @439
					Parent_View 	@437
					location   	(1814, 1278)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.778378
					height     	92
					orientation 	0))
				(object RoleView "type" @440
				    Parent_View 	@436
				    location   	(53, 296)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @441
					Parent_View 	@440
					location   	(1798, 1022)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	108
					justify    	0
					label      	"+type"
					pctDist    	0.839196
					height     	76
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9ABAF02AF"
				    client     	@436
				    supplier   	@435
				    vertices   	(list Points
					(1722, 1155)
					(1722, 996))
				    line_style 	3
				    origin_attachment 	(1722, 1155)
				    terminal_attachment 	(1722, 996)
				    label      	(object SegLabel @442
					Parent_View 	@440
					location   	(1694, 1028)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.804020
					height     	29
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @443
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(415, 256)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@443
				location   	(267, 127)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "l" @444
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@444
				location   	(425, 467)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@417
			    supplier   	@443
			    vertices   	(list Points
				(425, 537)
				(425, 397))
			    line_style 	3
			    origin_attachment 	(425, 537)
			    terminal_attachment 	(425, 397))
			(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @445
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1733, 291)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@445
				location   	(1333, 12)
				fill_color 	13434879
				nlines     	1
				max_width  	800
				justify    	0
				label      	"TypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A97A00CB"
			    width      	818
			    height     	582
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @446
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9A982030D"
			    client     	@435
			    supplier   	@445
			    vertices   	(list Points
				(1728, 714)
				(1728, 582))
			    line_style 	3
			    origin_attachment 	(1728, 714)
			    terminal_attachment 	(1728, 582))))
		(object ClassDiagram "SignatureCallExpression"
		    quid       	"47F3B7E201F2"
		    title      	"SignatureCallExpression"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	413
		    items      	(list diagram_item_list
			(object NoteView @447
			    location   	(834, 259)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@447
				location   	(596, 125)
				fill_color 	13434879
				nlines     	5
				max_width  	440
				label      	"The ordering and types of the expressions must conform to the input parameters of the Signature")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	500
			    height     	281)
			(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @448
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(228, 1843)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@448
				location   	(43, 1739)
				fill_color 	13434879
				nlines     	1
				max_width  	370
				justify    	0
				label      	"FunctionSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D190077"
			    width      	388
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @449
			    location   	(893, 2068)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@449
				location   	(580, 1921)
				fill_color 	13434879
				nlines     	5
				max_width  	590
				label      	
|MethodCallExpression.signature has to be a MethodSignature.
|Same for FunctionCallExpression and FunctionSignature
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	650
			    height     	306)
			(object AttachView "" @450
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@449
			    supplier   	@448
			    vertices   	(list Points
				(567, 1957)
				(422, 1908))
			    line_style 	0)
			(object ClassView "Class" "Logical View::data::classes::Signature" @451
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(336, 1112)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@451
				location   	(88, 958)
				fill_color 	13434879
				nlines     	1
				max_width  	496
				justify    	0
				label      	"Signature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432198602CB"
			    width      	514
			    height     	332
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::Parameter" @452
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(330, 529)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@452
				location   	(212, 451)
				fill_color 	13434879
				nlines     	1
				max_width  	236
				justify    	0
				label      	"Parameter")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F12A7E0062"
			    width      	254
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AttachView "" @453
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@447
			    supplier   	@452
			    vertices   	(list Points
				(583, 392)
				(457, 459))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @454
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(913, 1272)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@454
				location   	(679, 1221)
				fill_color 	13434879
				nlines     	1
				max_width  	468
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	486
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::FunctionCallExpression" @455
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1753, 1816)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@455
				location   	(1524, 1765)
				fill_color 	13434879
				nlines     	1
				max_width  	458
				justify    	0
				label      	"FunctionCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45473F620076"
			    width      	476
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AttachView "" @456
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@449
			    supplier   	@455
			    vertices   	(list Points
				(1218, 1972)
				(1538, 1879))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @457
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1953, 597)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@457
				location   	(1609, 391)
				fill_color 	13434879
				nlines     	1
				max_width  	688
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	706
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$6" @458
			    location   	(1916, 1284)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45473F690329"
			    roleview_list 	(list RoleViews
				(object RoleView "blockOfFunctionCallExpression" @459
				    Parent_View 	@458
				    location   	(482, 687)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @460
					Parent_View 	@459
					location   	(2226, 1641)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	590
					justify    	0
					label      	"+blockOfFunctionCallExpression"
					pctDist    	0.761411
					height     	310
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45473F6A0316"
				    client     	@458
				    supplier   	@455
				    vertices   	(list Points
					(1916, 1284)
					(1916, 1753))
				    line_style 	3
				    origin_attachment 	(1916, 1284)
				    terminal_attachment 	(1916, 1753)
				    label      	(object SegLabel @461
					Parent_View 	@459
					location   	(1970, 1705)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "calledBlock" @462
				    Parent_View 	@458
				    location   	(482, 687)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @463
					Parent_View 	@462
					location   	(2072, 913)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	239
					justify    	0
					label      	"+calledBlock"
					pctDist    	0.793419
					height     	156
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45473F6A0302"
				    client     	@458
				    supplier   	@457
				    vertices   	(list Points
					(1916, 1284)
					(1916, 815))
				    line_style 	3
				    origin_attachment 	(1916, 1284)
				    terminal_attachment 	(1916, 815)
				    label      	(object SegLabel @464
					Parent_View 	@462
					location   	(1970, 863)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object AttachView "" @465
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@447
			    supplier   	@457
			    vertices   	(list Points
				(1084, 333)
				(1599, 489))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::SignatureCallExpression" @466
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1405, 1088)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@466
				location   	(1130, 982)
				fill_color 	13434879
				nlines     	1
				max_width  	550
				justify    	0
				label      	"SignatureCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F3B80500BD"
			    compartment 	(object Compartment
				Parent_View 	@466
				location   	(1130, 1043)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	0)
			    width      	568
			    height     	236
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @467
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B890000D"
			    client     	@466
			    supplier   	@457
			    vertices   	(list Points
				(1536, 969)
				(1707, 815))
			    line_style 	0)
			(object AssociationViewNew "SignatureCallParameters" @468
			    location   	(1322, 659)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @469
				Parent_View 	@468
				location   	(1244, 614)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"SignatureCallParameters"
				pctDist    	-0.800000
				height     	46
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B8AB019D"
			    roleview_list 	(list RoleViews
				(object RoleView "parameters" @470
				    Parent_View 	@468
				    location   	(602, -172)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @471
					Parent_View 	@470
					location   	(1496, 512)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	235
					justify    	0
					label      	"+parameters"
					pctDist    	0.694087
					height     	88
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC0339"
				    client     	@468
				    supplier   	@457
				    vertices   	(list Points
					(1322, 659)
					(1322, 599)
					(1600, 599))
				    line_style 	3
				    origin_attachment 	(1322, 659)
				    terminal_attachment 	(1600, 599)
				    label      	(object SegLabel @472
					Parent_View 	@470
					location   	(1545, 566)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.838046
					height     	34
					orientation 	0)
				    label      	(object SegLabel @473
					Parent_View 	@470
					location   	(1503, 631)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	160
					justify    	0
					label      	"{ordered}"
					pctDist    	0.717224
					height     	32
					orientation 	1))
				(object RoleView "usedAsArgumentInSignatureCall" @474
				    Parent_View 	@468
				    location   	(602, -172)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @475
					Parent_View 	@474
					location   	(1303, 891)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	613
					justify    	0
					label      	"+usedAsArgumentInSignatureCall"
					pctDist    	0.749482
					height     	20
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F3B8AC036B"
				    client     	@468
				    supplier   	@466
				    vertices   	(list Points
					(1322, 659)
					(1322, 969))
				    line_style 	3
				    origin_attachment 	(1322, 659)
				    terminal_attachment 	(1322, 969)
				    label      	(object SegLabel @476
					Parent_View 	@474
					location   	(1259, 935)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.886128
					height     	64
					orientation 	1))))
			(object InheritTreeView "" @477
			    location   	(336, 1396)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@451
			    vertices   	(list Points
				(336, 1396)
				(336, 1278)))
			(object InheritView "" @478
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47D67D2001B3"
			    client     	@448
			    supplier   	@451
			    vertices   	(list Points
				(188, 1726)
				(188, 1396))
			    line_style 	3
			    origin_attachment 	(188, 1726)
			    terminal_attachment 	(188, 1396)
			    drawSupplier 	@477)
			(object ClassView "Class" "Logical View::data::classes::MethodSignature" @479
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(425, 1566)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@479
				location   	(249, 1462)
				fill_color 	13434879
				nlines     	1
				max_width  	352
				justify    	0
				label      	"MethodSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D15030D"
			    width      	370
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object AttachView "" @480
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@449
			    supplier   	@479
			    vertices   	(list Points
				(749, 1914)
				(533, 1682))
			    line_style 	0)
			(object InheritView "" @481
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47D67D1D035D"
			    client     	@479
			    supplier   	@451
			    vertices   	(list Points
				(504, 1450)
				(504, 1396))
			    line_style 	3
			    origin_attachment 	(504, 1450)
			    terminal_attachment 	(504, 1396)
			    drawSupplier 	@477)
			(object ClassView "Class" "Logical View::dataaccess::expressions::MethodCallExpression" @482
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1378, 1551)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@482
				location   	(1133, 1470)
				fill_color 	13434879
				nlines     	1
				max_width  	490
				justify    	0
				label      	"MethodCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522E05D00A8"
			    width      	508
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object AttachView "" @483
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@449
			    supplier   	@482
			    vertices   	(list Points
				(1035, 1914)
				(1288, 1644))
			    line_style 	0)
			(object AssociationViewNew "SignatureCallToSignature" @484
			    location   	(867, 1545)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @485
				Parent_View 	@484
				location   	(865, 1511)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	465
				justify    	0
				label      	"SignatureCallToSignature"
				pctDist    	0.483333
				height     	35
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4939041D0109"
			    roleview_list 	(list RoleViews
				(object RoleView "methodSignature" @486
				    Parent_View 	@484
				    location   	(-313, -37)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @487
					Parent_View 	@486
					location   	(812, 1467)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	329
					justify    	0
					label      	"+methodSignature"
					pctDist    	0.218750
					height     	79
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4939041D010B"
				    client     	@484
				    supplier   	@479
				    vertices   	(list Points
					(867, 1545)
					(610, 1545))
				    line_style 	3
				    origin_attachment 	(867, 1545)
				    terminal_attachment 	(610, 1545)
				    label      	(object SegLabel @488
					Parent_View 	@486
					location   	(653, 1611)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.834821
					height     	66
					orientation 	0))
				(object RoleView "$UNNAMED$10" @489
				    Parent_View 	@484
				    location   	(-313, -37)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @490
					Parent_View 	@489
					location   	(1072, 1504)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					hidden     	TRUE
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	""
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4939041D010A"
				    client     	@484
				    supplier   	@482
				    vertices   	(list Points
					(867, 1545)
					(1124, 1545))
				    line_style 	3
				    origin_attachment 	(867, 1545)
				    terminal_attachment 	(1124, 1545)
				    label      	(object SegLabel @491
					Parent_View 	@489
					location   	(1067, 1605)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.782222
					height     	60
					orientation 	1))))
			(object InheritTreeView "" @492
			    location   	(1405, 1296)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@466
			    vertices   	(list Points
				(1405, 1296)
				(1405, 1206)))
			(object InheritView "" @493
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B84601D1"
			    client     	@455
			    supplier   	@466
			    vertices   	(list Points
				(1753, 1753)
				(1753, 1296))
			    line_style 	3
			    origin_attachment 	(1753, 1753)
			    terminal_attachment 	(1753, 1296)
			    drawSupplier 	@492)
			(object InheritView "" @494
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F3B83200B9"
			    client     	@482
			    supplier   	@466
			    vertices   	(list Points
				(1354, 1458)
				(1354, 1296))
			    line_style 	3
			    origin_attachment 	(1354, 1458)
			    terminal_attachment 	(1354, 1296)
			    drawSupplier 	@492)
			(object InheritView "" @495
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47BC30F40203"
			    client     	@482
			    supplier   	@454
			    vertices   	(list Points
				(1135, 1458)
				(1135, 1335))
			    line_style 	3
			    origin_attachment 	(1135, 1458)
			    terminal_attachment 	(1135, 1335))))
		(object ClassDiagram "Value Replacement"
		    quid       	"492FCCF60271"
		    title      	"Value Replacement"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	6
		    items      	(list diagram_item_list
			(object NoteView @496
			    location   	(1350, 453)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@496
				location   	(237, 128)
				fill_color 	13434879
				nlines     	13
				max_width  	2190
				label      	
|Besides literals for "primitive" types, we need literals for other value classes as well. Two things should be enabled:
|
| - creating a new value object "from scratch" by recursively specifying objects for all equality-relevant association ends
| - creation a new value by changing an existing value; the changing expression would only specify the path of the components to replace and give a new value for those; watch our for components with multiplicities >1.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	2250
			    height     	662)
			(object ClassView "Class" "Logical View::data::classes::AssociationEnd" @497
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1942, 2304)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@497
				location   	(1628, 2125)
				fill_color 	13434879
				nlines     	1
				max_width  	628
				justify    	0
				label      	"AssociationEnd")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44EC55FB03B8"
			    width      	646
			    height     	382
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @498
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(959, 1589)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@498
				location   	(725, 1538)
				fill_color 	13434879
				nlines     	1
				max_width  	468
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	486
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::NavigationStep" @499
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1947, 1825)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@499
				location   	(1790, 1774)
				fill_color 	13434879
				nlines     	1
				max_width  	314
				justify    	0
				label      	"NavigationStep")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"499D4031000F"
			    width      	332
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$13" @500
			    location   	(1947, 2000)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"499D416E03A9"
			    roleview_list 	(list RoleViews
				(object RoleView "to" @501
				    Parent_View 	@500
				    location   	(185, 379)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @502
					Parent_View 	@501
					location   	(1889, 2086)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	60
					justify    	0
					label      	"+to"
					pctDist    	0.761062
					height     	59
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D416F01F4"
				    client     	@500
				    supplier   	@497
				    vertices   	(list Points
					(1947, 2000)
					(1947, 2113))
				    line_style 	3
				    origin_attachment 	(1947, 2000)
				    terminal_attachment 	(1947, 2113)
				    label      	(object SegLabel @503
					Parent_View 	@501
					location   	(1996, 2086)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.761062
					height     	49
					orientation 	0))
				(object RoleView "$UNNAMED$14" @504
				    Parent_View 	@500
				    location   	(185, 379)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D416F0213"
				    client     	@500
				    supplier   	@499
				    vertices   	(list Points
					(1947, 2000)
					(1947, 1888))
				    line_style 	3
				    origin_attachment 	(1947, 2000)
				    terminal_attachment 	(1947, 1888)
				    label      	(object SegLabel @505
					Parent_View 	@504
					location   	(1994, 1915)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.758929
					height     	47
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @506
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(935, 1151)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@506
				location   	(668, 945)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @507
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@498
			    supplier   	@506
			    vertices   	(list Points
				(938, 1526)
				(938, 1368))
			    line_style 	3
			    origin_attachment 	(938, 1526)
			    terminal_attachment 	(938, 1368))
			(object AssociationViewNew "$UNNAMED$2" @508
			    location   	(497, 1387)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @509
				    Parent_View 	@508
				    location   	(-731, 424)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @510
					Parent_View 	@509
					location   	(866, 1487)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	1.372414
					height     	85
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@508
				    supplier   	@498
				    vertices   	(list Points
					(497, 1387)
					(497, 1571)
					(716, 1571))
				    line_style 	3
				    origin_attachment 	(497, 1387)
				    terminal_attachment 	(716, 1571)
				    label      	(object SegLabel @511
					Parent_View 	@509
					location   	(675, 1518)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "object" @512
				    Parent_View 	@508
				    location   	(-731, 424)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @513
					Parent_View 	@512
					location   	(578, 1105)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@508
				    supplier   	@506
				    vertices   	(list Points
					(497, 1387)
					(497, 1146)
					(659, 1146))
				    line_style 	3
				    origin_attachment 	(497, 1387)
				    terminal_attachment 	(659, 1146)
				    label      	(object SegLabel @514
					Parent_View 	@512
					location   	(619, 1200)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$15" @515
			    location   	(1885, 1151)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"499D5BB500FA"
			    roleview_list 	(list RoleViews
				(object RoleView "filterFunction" @516
				    Parent_View 	@515
				    location   	(123, -470)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @517
					Parent_View 	@516
					location   	(1449, 1118)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	273
					justify    	0
					label      	"+filterFunction"
					pctDist    	0.648459
					height     	34
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D5BB701A5"
				    client     	@515
				    supplier   	@506
				    vertices   	(list Points
					(1885, 1151)
					(1211, 1151))
				    line_style 	3
				    origin_attachment 	(1885, 1151)
				    terminal_attachment 	(1211, 1151)
				    label      	(object SegLabel @518
					Parent_View 	@516
					location   	(1260, 1112)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.928571
					height     	40
					orientation 	1))
				(object RoleView "navigationStep" @519
				    Parent_View 	@515
				    location   	(123, -470)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @520
					Parent_View 	@519
					location   	(2122, 1666)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	290
					justify    	0
					label      	"+navigationStep"
					pctDist    	0.856930
					height     	174
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D5BB70203"
				    client     	@515
				    supplier   	@499
				    vertices   	(list Points
					(1885, 1151)
					(1948, 1151)
					(1948, 1762))
				    line_style 	3
				    origin_attachment 	(1885, 1151)
				    terminal_attachment 	(1948, 1762)
				    label      	(object SegLabel @521
					Parent_View 	@519
					location   	(2015, 1729)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.950980
					height     	67
					orientation 	0))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Replace" @522
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(935, 1819)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@522
				location   	(844, 1768)
				fill_color 	13434879
				nlines     	1
				max_width  	182
				justify    	0
				label      	"Replace")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"499C2988038A"
			    width      	200
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @523
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"499C2A7A004E"
			    client     	@522
			    supplier   	@498
			    vertices   	(list Points
				(938, 1756)
				(938, 1652))
			    line_style 	3
			    origin_attachment 	(938, 1756)
			    terminal_attachment 	(938, 1652))
			(object AssociationViewNew "$UNNAMED$12" @524
			    location   	(1408, 1861)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"499D40450261"
			    roleview_list 	(list RoleViews
				(object RoleView "steps" @525
				    Parent_View 	@524
				    location   	(658, 246)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @526
					Parent_View 	@525
					location   	(1618, 1827)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	136
					justify    	0
					label      	"+steps"
					pctDist    	0.563003
					height     	35
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D404600CB"
				    client     	@524
				    supplier   	@499
				    vertices   	(list Points
					(1408, 1861)
					(1781, 1861))
				    line_style 	3
				    origin_attachment 	(1408, 1861)
				    terminal_attachment 	(1781, 1861)
				    label      	(object SegLabel @527
					Parent_View 	@525
					location   	(1736, 1828)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.882038
					height     	34
					orientation 	0)
				    label      	(object SegLabel @528
					Parent_View 	@525
					location   	(1682, 1909)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.737265
					height     	48
					orientation 	1))
				(object RoleView "replace" @529
				    Parent_View 	@524
				    location   	(658, 246)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @530
					Parent_View 	@529
					location   	(1119, 1821)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	156
					justify    	0
					label      	"+replace"
					pctDist    	0.774799
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D404600CD"
				    client     	@524
				    supplier   	@522
				    vertices   	(list Points
					(1408, 1861)
					(1035, 1861))
				    line_style 	3
				    origin_attachment 	(1408, 1861)
				    terminal_attachment 	(1035, 1861)
				    label      	(object SegLabel @531
					Parent_View 	@529
					location   	(1073, 1915)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$16" @532
			    location   	(1522, 1580)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"499D69C401C5"
			    roleview_list 	(list RoleViews
				(object RoleView "with" @533
				    Parent_View 	@532
				    location   	(772, -35)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @534
					Parent_View 	@533
					location   	(1335, 1250)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	104
					justify    	0
					label      	"+with"
					pctDist    	0.819596
					height     	40
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D69C7029F"
				    client     	@532
				    supplier   	@506
				    vertices   	(list Points
					(1522, 1580)
					(1522, 1210)
					(1211, 1210))
				    line_style 	3
				    origin_attachment 	(1522, 1580)
				    terminal_attachment 	(1211, 1210)
				    label      	(object SegLabel @535
					Parent_View 	@533
					location   	(1249, 1248)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.943987
					height     	38
					orientation 	0))
				(object RoleView "withOfReplace" @536
				    Parent_View 	@532
				    location   	(772, -35)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @537
					Parent_View 	@536
					location   	(1291, 1733)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	300
					justify    	0
					label      	"+withOfReplace"
					pctDist    	0.624611
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"499D69C702DE"
				    client     	@532
				    supplier   	@522
				    vertices   	(list Points
					(1522, 1580)
					(1522, 1774)
					(1035, 1774))
				    line_style 	3
				    origin_attachment 	(1522, 1580)
				    terminal_attachment 	(1035, 1774)
				    label      	(object SegLabel @538
					Parent_View 	@536
					location   	(1088, 1729)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.922697
					height     	46
					orientation 	1))))))
		(object ClassDiagram "Ternary Expression"
		    quid       	"4A38977D01E4"
		    title      	"Ternary Expression"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @539
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(761, 187)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@539
				location   	(613, 58)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Conditional" @540
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(317, 1030)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@540
				location   	(203, 978)
				fill_color 	13434879
				nlines     	1
				max_width  	228
				justify    	0
				label      	"Conditional")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B4401F7"
			    width      	246
			    height     	128
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @541
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(987, 581)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@541
				location   	(412, 468)
				fill_color 	13434879
				nlines     	1
				max_width  	1151
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	1169
			    height     	250
			    annotation 	8)
			(object AssociationViewNew "$UNNAMED$19" @542
			    location   	(253, 688)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B920394"
			    roleview_list 	(list RoleViews
				(object RoleView "conditional" @543
				    Parent_View 	@542
				    location   	(-1052, -356)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @544
					Parent_View 	@543
					location   	(378, 885)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	224
					justify    	0
					label      	"+conditional"
					pctDist    	0.712644
					height     	125
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B93020F"
				    client     	@542
				    supplier   	@540
				    vertices   	(list Points
					(253, 688)
					(253, 966))
				    line_style 	3
				    origin_attachment 	(253, 688)
				    terminal_attachment 	(253, 966)
				    label      	(object SegLabel @545
					Parent_View 	@543
					location   	(322, 938)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.902367
					height     	69
					orientation 	0))
				(object RoleView "condition" @546
				    Parent_View 	@542
				    location   	(-1052, -356)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @547
					Parent_View 	@546
					location   	(285, 517)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	204
					justify    	0
					label      	"+condition"
					pctDist    	0.580769
					height     	44
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B930205"
				    client     	@542
				    supplier   	@541
				    vertices   	(list Points
					(253, 688)
					(253, 556)
					(403, 556))
				    line_style 	3
				    origin_attachment 	(253, 688)
				    terminal_attachment 	(403, 556)
				    label      	(object SegLabel @548
					Parent_View 	@546
					location   	(374, 614)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Ternary" @549
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(909, 1610)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@549
				location   	(412, 1510)
				fill_color 	13434879
				nlines     	1
				max_width  	994
				justify    	0
				label      	"Ternary")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4A389707002E"
			    width      	1012
			    height     	225
			    annotation 	8)
			(object AssociationViewNew "$UNNAMED$17" @550
			    location   	(1303, 1102)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A3897E603B9"
			    roleview_list 	(list RoleViews
				(object RoleView "falseExpr" @551
				    Parent_View 	@550
				    location   	(-34, -907)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @552
					Parent_View 	@551
					location   	(1170, 756)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	195
					justify    	0
					label      	"+falseExpr"
					pctDist    	0.877483
					height     	134
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3897E7030D"
				    client     	@550
				    supplier   	@541
				    vertices   	(list Points
					(1303, 1102)
					(1303, 706))
				    line_style 	3
				    origin_attachment 	(1303, 1102)
				    terminal_attachment 	(1303, 706)
				    label      	(object SegLabel @553
					Parent_View 	@551
					location   	(1339, 748)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.897351
					height     	36
					orientation 	1))
				(object RoleView "falseOfTernary" @554
				    Parent_View 	@550
				    location   	(-34, -907)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @555
					Parent_View 	@554
					location   	(1156, 1399)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	296
					justify    	0
					label      	"+falseOfTernary"
					pctDist    	0.749175
					height     	148
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3897E7035B"
				    client     	@550
				    supplier   	@549
				    vertices   	(list Points
					(1303, 1102)
					(1303, 1498))
				    line_style 	3
				    origin_attachment 	(1303, 1102)
				    terminal_attachment 	(1303, 1498)
				    label      	(object SegLabel @556
					Parent_View 	@554
					location   	(1357, 1458)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$18" @557
			    location   	(881, 1101)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A3897E80280"
			    roleview_list 	(list RoleViews
				(object RoleView "trueExpr" @558
				    Parent_View 	@557
				    location   	(-456, -908)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @559
					Parent_View 	@558
					location   	(764, 751)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	183
					justify    	0
					label      	"+trueExpr"
					pctDist    	0.887417
					height     	118
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3897EA02EE"
				    client     	@557
				    supplier   	@541
				    vertices   	(list Points
					(881, 1101)
					(881, 705))
				    line_style 	3
				    origin_attachment 	(881, 1101)
				    terminal_attachment 	(881, 705)
				    label      	(object SegLabel @560
					Parent_View 	@558
					location   	(923, 755)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.872549
					height     	42
					orientation 	1))
				(object RoleView "trueOfTernary" @561
				    Parent_View 	@557
				    location   	(-456, -908)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @562
					Parent_View 	@561
					location   	(1028, 1327)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	282
					justify    	0
					label      	"+trueOfTernary"
					pctDist    	0.569536
					height     	147
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3897EA034B"
				    client     	@557
				    supplier   	@549
				    vertices   	(list Points
					(881, 1101)
					(881, 1498))
				    line_style 	3
				    origin_attachment 	(881, 1101)
				    terminal_attachment 	(881, 1498)
				    label      	(object SegLabel @563
					Parent_View 	@561
					location   	(943, 1457)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.898693
					height     	62
					orientation 	0))))
			(object InheritView "l" @564
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@564
				location   	(763, 392)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@541
			    supplier   	@539
			    vertices   	(list Points
				(763, 455)
				(763, 328))
			    line_style 	3
			    origin_attachment 	(763, 455)
			    terminal_attachment 	(763, 328))
			(object ClassView "Class" "Logical View::dataaccess::expressions::ConditionalExpression" @565
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(332, 1309)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@565
				location   	(116, 1258)
				fill_color 	13434879
				nlines     	1
				max_width  	432
				justify    	0
				label      	"ConditionalExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8523C90167"
			    width      	450
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @566
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8523D800BB"
			    client     	@565
			    supplier   	@540
			    vertices   	(list Points
				(284, 1246)
				(284, 1094))
			    line_style 	3
			    origin_attachment 	(284, 1246)
			    terminal_attachment 	(284, 1094))
			(object InheritView "" @567
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8523D403B9"
			    client     	@549
			    supplier   	@565
			    vertices   	(list Points
				(438, 1498)
				(438, 1372))
			    line_style 	3
			    origin_attachment 	(438, 1498)
			    terminal_attachment 	(438, 1372))
			(object InheritTreeView "" @568
			    location   	(584, 991)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@541
			    vertices   	(list Points
				(584, 991)
				(584, 706)))
			(object InheritView "" @569
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8523FD005D"
			    client     	@565
			    supplier   	@541
			    vertices   	(list Points
				(500, 1246)
				(500, 991))
			    line_style 	3
			    origin_attachment 	(500, 1246)
			    terminal_attachment 	(500, 991)
			    drawSupplier 	@568)
			(object InheritView "" @570
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A38971503A9"
			    client     	@549
			    supplier   	@541
			    vertices   	(list Points
				(659, 1498)
				(659, 991))
			    line_style 	3
			    origin_attachment 	(659, 1498)
			    terminal_attachment 	(659, 991)
			    drawSupplier 	@568)))
		(object ClassDiagram "WithArgument"
		    quid       	"4B850503030D"
		    title      	"WithArgument"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::dataaccess::expressions::WithArgument" @571
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1488, 183)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@571
				location   	(1341, 132)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"WithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E587019C"
			    width      	312
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::StatementWithArgument" @572
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(644, 482)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@572
				location   	(404, 408)
				fill_color 	13434879
				nlines     	1
				max_width  	480
				justify    	0
				label      	"StatementWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"492573460213"
			    width      	498
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @573
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49257357038A"
			    client     	@572
			    supplier   	@571
			    vertices   	(list Points
				(883, 395)
				(1331, 236))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ExpressionWithArgument" @574
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2331, 482)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@574
				location   	(2085, 431)
				fill_color 	13434879
				nlines     	1
				max_width  	492
				justify    	0
				label      	"ExpressionWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8504AE03C8"
			    width      	510
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @575
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8504B6036B"
			    client     	@574
			    supplier   	@571
			    vertices   	(list Points
				(2154, 418)
				(1644, 237))
			    line_style 	0)
			(object ClassView "Class" "Logical View::behavioral::actions::Assignment" @576
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(194, 804)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@576
				location   	(69, 730)
				fill_color 	13434879
				nlines     	1
				max_width  	250
				justify    	0
				label      	"Assignment")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45229F090021"
			    width      	268
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @577
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925735300FA"
			    client     	@576
			    supplier   	@572
			    vertices   	(list Points
				(313, 717)
				(522, 568))
			    line_style 	0)
			(object ClassView "Class" "Logical View::behavioral::actions::Return" @578
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(644, 804)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@578
				location   	(544, 730)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Return")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E38403E0"
			    width      	218
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @579
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4577E39701D4"
			    client     	@578
			    supplier   	@572
			    vertices   	(list Points
				(644, 717)
				(644, 568))
			    line_style 	0)
			(object ClassView "Class" "Logical View::persistence::actions::StatementWithEntityArgument" @580
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1244, 804)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@580
				location   	(949, 730)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"StatementWithEntityArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"497A4BFB0037"
			    width      	608
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @581
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"497A4C1C0028"
			    client     	@580
			    supplier   	@572
			    vertices   	(list Points
				(1083, 717)
				(805, 568))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::WithPosition" @582
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1881, 1156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@582
				location   	(1675, 1052)
				fill_color 	13434879
				nlines     	1
				max_width  	412
				justify    	0
				label      	"WithPosition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B5ABDC038A"
			    width      	430
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @583
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"493E4C4F03C8"
			    client     	@582
			    supplier   	@574
			    vertices   	(list Points
				(1958, 1039)
				(2288, 545))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::CollectionExpressionWithArgument" @584
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2781, 804)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@584
				location   	(2446, 730)
				fill_color 	13434879
				nlines     	1
				max_width  	670
				justify    	0
				label      	"CollectionExpressionWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4ADF36A4001F"
			    width      	688
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @585
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ADF36D201A5"
			    client     	@584
			    supplier   	@574
			    vertices   	(list Points
				(2660, 717)
				(2420, 545))
			    line_style 	0)
			(object ClassView "Class" "Logical View::persistence::actions::Store" @586
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(831, 1156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@586
				location   	(731, 1082)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Store")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4979C056001D"
			    width      	218
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @587
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4979C07300D8"
			    client     	@586
			    supplier   	@580
			    vertices   	(list Points
				(931, 1069)
				(1141, 890))
			    line_style 	0)
			(object ClassView "Class" "Logical View::persistence::actions::Delete" @588
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1281, 1156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@588
				location   	(1181, 1082)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Delete")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"497A4BE10316"
			    width      	218
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @589
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"497A4BE703A7"
			    client     	@588
			    supplier   	@580
			    vertices   	(list Points
				(1271, 1069)
				(1252, 890))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::IncludingAt" @590
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2181, 1508)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@590
				location   	(1977, 1434)
				fill_color 	13434879
				nlines     	1
				max_width  	408
				justify    	0
				label      	"IncludingAt")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"475956750280"
			    width      	426
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @591
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B5ABF60203"
			    client     	@590
			    supplier   	@582
			    vertices   	(list Points
				(2107, 1421)
				(1979, 1272))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::ExcludingAt" @592
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2781, 1508)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@592
				location   	(2577, 1434)
				fill_color 	13434879
				nlines     	1
				max_width  	408
				justify    	0
				label      	"ExcludingAt")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B5ABAC0232"
			    width      	426
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @593
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B5ABF800DA"
			    client     	@592
			    supplier   	@582
			    vertices   	(list Points
				(2567, 1423)
				(2096, 1240))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::Including" @594
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2481, 1156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@594
				location   	(2277, 1082)
				fill_color 	13434879
				nlines     	1
				max_width  	408
				justify    	0
				label      	"Including")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"475956720213"
			    width      	426
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @595
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9FCA403D8"
			    client     	@590
			    supplier   	@594
			    vertices   	(list Points
				(2254, 1421)
				(2407, 1242))
			    line_style 	0)
			(object InheritView "" @596
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ADF36F5002E"
			    client     	@594
			    supplier   	@584
			    vertices   	(list Points
				(2554, 1069)
				(2707, 890))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::collectionExpressions::Excluding" @597
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3081, 1156)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@597
				location   	(2877, 1082)
				fill_color 	13434879
				nlines     	1
				max_width  	408
				justify    	0
				label      	"Excluding")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47595673001F"
			    width      	426
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @598
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B5AC13007D"
			    client     	@592
			    supplier   	@597
			    vertices   	(list Points
				(2854, 1421)
				(3007, 1242))
			    line_style 	0)
			(object InheritView "" @599
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ADF36FA0119"
			    client     	@597
			    supplier   	@584
			    vertices   	(list Points
				(3007, 1069)
				(2854, 890))
			    line_style 	0)))
		(object ClassDiagram "Conditional Subclasses"
		    quid       	"4B85239F0251"
		    title      	"Conditional Subclasses"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::behavioral::actions::ConditionalStatement" @600
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1501, 587)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@600
				location   	(1290, 513)
				fill_color 	13434879
				nlines     	1
				max_width  	422
				justify    	0
				label      	"ConditionalStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8518F803B9"
			    width      	440
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::WhileLoop" @601
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1201, 964)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@601
				location   	(1043, 860)
				fill_color 	13434879
				nlines     	1
				max_width  	316
				justify    	0
				label      	"WhileLoop")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B58016A"
			    width      	334
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @602
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B7E0219"
			    client     	@601
			    supplier   	@600
			    vertices   	(list Points
				(1291, 847)
				(1431, 673))
			    line_style 	0)
			(object ClassView "Class" "Logical View::behavioral::actions::IfElse" @603
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1801, 964)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@603
				location   	(1642, 835)
				fill_color 	13434879
				nlines     	1
				max_width  	318
				justify    	0
				label      	"IfElse")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B57000A"
			    width      	336
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @604
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B7D0181"
			    client     	@603
			    supplier   	@600
			    vertices   	(list Points
				(1688, 822)
				(1569, 673))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Ternary" @605
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(445, 965)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@605
				location   	(356, 914)
				fill_color 	13434879
				nlines     	1
				max_width  	178
				justify    	0
				label      	"Ternary")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4A389707002E"
			    width      	196
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Conditional" @606
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1497, 268)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@606
				location   	(1384, 217)
				fill_color 	13434879
				nlines     	1
				max_width  	226
				justify    	0
				label      	"Conditional")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B4401F7"
			    width      	244
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @607
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B85190101D4"
			    client     	@600
			    supplier   	@606
			    vertices   	(list Points
				(1499, 500)
				(1497, 331))
			    line_style 	0)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @608
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(453, 293)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@608
				location   	(186, 87)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	436
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$19" @609
			    location   	(1052, 262)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B920394"
			    roleview_list 	(list RoleViews
				(object RoleView "conditional" @610
				    Parent_View 	@609
				    location   	(558, -38)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @611
					Parent_View 	@610
					location   	(1237, 223)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	224
					justify    	0
					label      	"+conditional"
					pctDist    	0.572755
					height     	39
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B93020F"
				    client     	@609
				    supplier   	@606
				    vertices   	(list Points
					(1052, 262)
					(1375, 262))
				    line_style 	3
				    origin_attachment 	(1052, 262)
				    terminal_attachment 	(1375, 262)
				    label      	(object SegLabel @612
					Parent_View 	@610
					location   	(1343, 316)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "condition" @613
				    Parent_View 	@609
				    location   	(558, -38)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @614
					Parent_View 	@613
					location   	(841, 220)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	204
					justify    	0
					label      	"+condition"
					pctDist    	0.653251
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B930205"
				    client     	@609
				    supplier   	@608
				    vertices   	(list Points
					(1052, 262)
					(729, 262))
				    line_style 	3
				    origin_attachment 	(1052, 262)
				    terminal_attachment 	(729, 262)
				    label      	(object SegLabel @615
					Parent_View 	@613
					location   	(761, 316)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object InheritView "" @616
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A38971503A9"
			    client     	@605
			    supplier   	@608
			    vertices   	(list Points
				(445, 902)
				(445, 511))
			    line_style 	3
			    origin_attachment 	(445, 902)
			    terminal_attachment 	(445, 511))))
		(object ClassDiagram "Map"
		    quid       	"4B8D1CC003A9"
		    title      	"Map"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::dataaccess::expressions::ExpressionWithArgument" @617
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1287, 1378)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@617
				location   	(1041, 1327)
				fill_color 	13434879
				nlines     	1
				max_width  	492
				justify    	0
				label      	"ExpressionWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8504AE03C8"
			    width      	510
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::WithArgument" @618
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1153, 990)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@618
				location   	(1006, 939)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"WithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E587019C"
			    width      	312
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @619
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8504B6036B"
			    client     	@617
			    supplier   	@618
			    vertices   	(list Points
				(1163, 1314)
				(1163, 1052))
			    line_style 	3
			    origin_attachment 	(1163, 1314)
			    terminal_attachment 	(1163, 1052))
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @620
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2001, 1381)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@620
				location   	(1767, 1330)
				fill_color 	13434879
				nlines     	1
				max_width  	468
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	486
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @621
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1709, 459)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@621
				location   	(984, 240)
				fill_color 	13434879
				nlines     	1
				max_width  	1450
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	1468
			    height     	463
			    annotation 	8)
			(object InheritView "" @622
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8520070109"
			    client     	@617
			    supplier   	@621
			    vertices   	(list Points
				(1481, 1314)
				(1481, 690))
			    line_style 	3
			    origin_attachment 	(1481, 1314)
			    terminal_attachment 	(1481, 690))
			(object AssociationViewNew "$UNNAMED$5" @623
			    location   	(1150, 808)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4577E58D0258"
			    roleview_list 	(list RoleViews
				(object RoleView "argument" @624
				    Parent_View 	@623
				    location   	(284, -120)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @625
					Parent_View 	@624
					location   	(1020, 723)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	196
					justify    	0
					label      	"+argument"
					pctDist    	0.717557
					height     	131
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D025A"
				    client     	@623
				    supplier   	@621
				    vertices   	(list Points
					(1150, 808)
					(1150, 690))
				    line_style 	3
				    origin_attachment 	(1150, 808)
				    terminal_attachment 	(1150, 690)
				    label      	(object SegLabel @626
					Parent_View 	@624
					location   	(1212, 734)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.625954
					height     	62
					orientation 	1))
				(object RoleView "argumentOf" @627
				    Parent_View 	@623
				    location   	(284, -120)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @628
					Parent_View 	@627
					location   	(985, 898)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	238
					justify    	0
					label      	"+argumentOf"
					pctDist    	0.757576
					height     	166
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D0259"
				    client     	@623
				    supplier   	@618
				    vertices   	(list Points
					(1150, 808)
					(1150, 927))
				    line_style 	3
				    origin_attachment 	(1150, 808)
				    terminal_attachment 	(1150, 927)
				    label      	(object SegLabel @629
					Parent_View 	@627
					location   	(1218, 903)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.795455
					height     	68
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$2" @630
			    location   	(2199, 1004)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @631
				    Parent_View 	@630
				    location   	(949, 557)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @632
					Parent_View 	@631
					location   	(2455, 1282)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	455
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.885350
					height     	256
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@630
				    supplier   	@620
				    vertices   	(list Points
					(2199, 1004)
					(2199, 1318))
				    line_style 	3
				    origin_attachment 	(2199, 1004)
				    terminal_attachment 	(2199, 1318)
				    label      	(object SegLabel @633
					Parent_View 	@631
					location   	(2141, 1281)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.882166
					height     	58
					orientation 	1))
				(object RoleView "object" @634
				    Parent_View 	@630
				    location   	(949, 557)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @635
					Parent_View 	@634
					location   	(2294, 728)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.878981
					height     	95
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@630
				    supplier   	@621
				    vertices   	(list Points
					(2199, 1004)
					(2199, 690))
				    line_style 	3
				    origin_attachment 	(2199, 1004)
				    terminal_attachment 	(2199, 690)
				    label      	(object SegLabel @636
					Parent_View 	@634
					location   	(2151, 723)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.894904
					height     	48
					orientation 	0))))
			(object InheritView "" @637
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@620
			    supplier   	@621
			    vertices   	(list Points
				(1812, 1318)
				(1812, 689))
			    line_style 	3
			    origin_attachment 	(1812, 1318)
			    terminal_attachment 	(1812, 689))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Map" @638
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1677, 1822)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@638
				location   	(1424, 1769)
				fill_color 	13434879
				nlines     	1
				max_width  	507
				justify    	0
				label      	"Map")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8D1E5103B9"
			    width      	525
			    height     	131
			    annotation 	8)
			(object InheritView "" @639
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8D1E60034B"
			    client     	@638
			    supplier   	@617
			    vertices   	(list Points
				(1478, 1757)
				(1478, 1441))
			    line_style 	3
			    origin_attachment 	(1478, 1757)
			    terminal_attachment 	(1478, 1441))
			(object InheritView "" @640
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8D1E61032C"
			    client     	@638
			    supplier   	@620
			    vertices   	(list Points
				(1848, 1756)
				(1848, 1443))
			    line_style 	3
			    origin_attachment 	(1848, 1756)
			    terminal_attachment 	(1848, 1443))))))
	(object Class_Category "query"
	    quid       	"44D7528D0275"
	    documentation 	
|A query language (overlap with rules package?) based on the structural package (BO, BONodes, associations, attributes). The language is independent of the mapping to the persistence layer but can be mapped to efficient queries in the persistence layer for those BOs that have a declared persistence mapping. Look closely at FSI, its query and view builder and how they have structured their metadata.
|
|Should this be a subset of the expression language?
|Note the particular issues around *retrieval* (as opposed to just querying IDs) as mentioned by Maic Wintel. Modeling of aspects to retrieve by a query?
|
|What about regular expressions?
|
|TODO: Most queries by means of their projection (SELECT) clause will implicitly define a tuple type, and the value returned by the query is a multi-object of that tuple type. We need to think about what these types exactly are (currently we don't support tuple types). Are they classes that are implicitly defined by the query? Or does a class explicitly have to be defined whose associations then can assume the values of the individual columns? Can that class somehow be referenced otherwise? What happens when the result of a query is assigned to a variable that uses type inference? I would hope that the implicit result class of the query is used as the variable's type. But is there / should there also be explicit ways of referencing this type?
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Selection"
		    quid       	"4ACC4F790222"
		    documentation 	
|Filters the (multi-)object based on the "condition" predicate. The expression can assume an implicit iterator variable "self" to be in scope which holds a single element of the (multi-)object from which to select. self's basic type is the same as that of "object" but with single multiplicity.
|
|The expression's type must be Boolean. If the expression evaluates to true, the single object is part of the resulting object, otherwise not.
|
|The Selection expression's result type is the same as object's type.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4ACC4F8503E7"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "ConditionMustBeSideEffectFree"
			    quid       	"4ACC5585000F"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4ACC558F03C8"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Selection
|inv:
|  self.selectionExpr.isSideEffectFree()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ConditionMustBeBooleanOrNumeric"
			    quid       	"4ACC97CE016B"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4ACC97CE016C"
				    documentation 	"TODO: Check upper multiplicity of condition expression to be 1?"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Selection
|inv:
|  self.selectionExpr.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
| (
|    (
|      self.selectionExpr.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.name = 'Boolean' and
|      self.selectionExpr.getType().upperMultiplicity = 1
|    )
|    or
|    (
|      self.selectionExpr.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.name = 'Number' 
|      and 
|      self.object.getType().ordered
|    )
|  )
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "OqlQuery"
		    quid       	"4B2755FC01F4"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B27561D0203"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    used_nodes 	(list uses_relationship_list
			(object Uses_Relationship
			    quid       	"4B27584E00AB"
			    label      	"has value type with selected aliases' types"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"))
		    nestedClasses 	(list nestedClasses
			(object Class "ConditionMustBeBoolean"
			    quid       	"4B2758E502DE"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B2758F20280"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context OqlQuery
|inv:
|  self.condition->notEmpty() implies
|    (self.condition.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and
|     self.condition.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.name='Boolean')
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "WhereClauseMustBeSideEffectFree"
			    quid       	"4B2759490109"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B27595001E4"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context OqlQuery
|inv:
|  self.condition->forAll(c | c.isSideEffectFree())
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "HasValueType"
			    quid       	"4B2784AF030D"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B2784B7030D"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context OqlQuery
|inv:
|  self.getType().oclIsKindOf(data::classes::ClassTypeDefinition) and self.getType().oclAsType(data::classes::ClassTypeDefinition).clazz.valueType
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "SelectedIteratorsMustHaveClassTypeDefinitionAsType"
			    quid       	"4B27A2F403B9"
			    documentation 	
|This constraint is necessary because the result will be presented as a set of value objects where the "properties" are the value of an iterator at some point. Only ClassTypeDefinition types are allowed for the value type's association ends.
			    
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B27A3190138"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context OqlQuery
|inv:
|  self.selected->forAll(i | i.getType().oclIsKindOf(data::classes::ClassTypeDefinition))
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "FromClause"
		    quid       	"4B275602036B"
		    nestedClasses 	(list nestedClasses
			(object Class "FromClausesMustBeSideEffectFree"
			    quid       	"4B2758BD0186"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B2758C303B9"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context FromClause
|inv:
|  self.fromExpression.isSideEffectFree()
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Association "$UNNAMED$28"
		    quid       	"4ACC52B7004D"
		    roles      	(list role_list
			(object Role "iterator"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4ACC52B70147"
			    label      	"iterator"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "selection"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4ACC52B70149"
			    label      	"selection"
			    supplier   	"Logical View::dataaccess::query::Selection"
			    quidu      	"4ACC4F790222"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$29"
		    quid       	"4ACC97750261"
		    roles      	(list role_list
			(object Role "selectionExpr"
			    quid       	"4ACC97760213"
			    label      	"selectionExpr"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "selection"
			    quid       	"4ACC97760242"
			    label      	"selection"
			    supplier   	"Logical View::dataaccess::query::Selection"
			    quidu      	"4ACC4F790222"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$30"
		    quid       	"4B275624037A"
		    roles      	(list role_list
			(object Role "condition"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B275626034B"
			    label      	"condition"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "conditionOfOqlQuery"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B275626038A"
			    label      	"conditionOfOqlQuery"
			    supplier   	"Logical View::dataaccess::query::OqlQuery"
			    quidu      	"4B2755FC01F4"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$31"
		    quid       	"4B27566000EA"
		    roles      	(list role_list
			(object Role "fromClauses"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B275661031C"
			    label      	"fromClauses"
			    supplier   	"Logical View::dataaccess::query::FromClause"
			    quidu      	"4B275602036B"
			    client_cardinality 	(value cardinality "1..*")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "fromClauseOfOqlQuery"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B275661031E"
			    label      	"fromClauseOfOqlQuery"
			    supplier   	"Logical View::dataaccess::query::OqlQuery"
			    quidu      	"4B2755FC01F4"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$32"
		    quid       	"4B2757530203"
		    roles      	(list role_list
			(object Role "fromExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B2757550148"
			    label      	"fromExpression"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "fromClause"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B2757550186"
			    label      	"fromClause"
			    supplier   	"Logical View::dataaccess::query::FromClause"
			    quidu      	"4B275602036B"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$33"
		    quid       	"4B2757AD01B5"
		    roles      	(list role_list
			(object Role "alias"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B2757AD033C"
			    label      	"alias"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "fromClause"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B2757AD033E"
			    label      	"fromClause"
			    supplier   	"Logical View::dataaccess::query::FromClause"
			    quidu      	"4B275602036B"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$34"
		    quid       	"4B2783A7003E"
		    documentation 	"an implicit select will explicitly put all defined aliases into this association"
		    roles      	(list role_list
			(object Role "selected"
			    quid       	"4B2783A9032C"
			    label      	"selected"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1..*")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$35"
			    quid       	"4B2783A9033C"
			    supplier   	"Logical View::dataaccess::query::OqlQuery"
			    quidu      	"4B2755FC01F4"))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Selection/Filter"
		    quid       	"452BC0F50340"
		    title      	"Selection/Filter"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @641
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(798, 992)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@641
				location   	(565, 918)
				fill_color 	13434879
				nlines     	1
				max_width  	466
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	484
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @642
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1863, 1428)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@642
				location   	(1763, 1354)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    width      	218
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @643
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1144, 241)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@643
				location   	(877, 12)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @644
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@641
			    supplier   	@643
			    vertices   	(list Points
				(976, 906)
				(976, 481))
			    line_style 	3
			    origin_attachment 	(976, 906)
			    terminal_attachment 	(976, 481))
			(object AssociationViewNew "$UNNAMED$2" @645
			    location   	(706, 479)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @646
				    Parent_View 	@645
				    location   	(-438, 291)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @647
					Parent_View 	@646
					location   	(665, 820)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@645
				    supplier   	@641
				    vertices   	(list Points
					(706, 479)
					(706, 906))
				    line_style 	3
				    origin_attachment 	(706, 479)
				    terminal_attachment 	(706, 906)
				    label      	(object SegLabel @648
					Parent_View 	@646
					location   	(638, 875)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.926503
					height     	69
					orientation 	1))
				(object RoleView "object" @649
				    Parent_View 	@645
				    location   	(-438, 291)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @650
					Parent_View 	@649
					location   	(783, 173)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@645
				    supplier   	@643
				    vertices   	(list Points
					(706, 479)
					(706, 214)
					(868, 214))
				    line_style 	3
				    origin_attachment 	(706, 479)
				    terminal_attachment 	(868, 214)
				    label      	(object SegLabel @651
					Parent_View 	@649
					location   	(824, 268)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::query::Selection" @652
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1119, 1431)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@652
				location   	(881, 1375)
				fill_color 	13434879
				nlines     	1
				max_width  	476
				justify    	0
				label      	"Selection")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4ACC4F790222"
			    width      	494
			    height     	137
			    annotation 	8)
			(object AssociationViewNew "$UNNAMED$28" @653
			    location   	(1560, 1431)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ACC52B7004D"
			    roleview_list 	(list RoleViews
				(object RoleView "iterator" @654
				    Parent_View 	@653
				    location   	(441, 0)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @655
					Parent_View 	@654
					location   	(1666, 1473)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	155
					justify    	0
					label      	"+iterator"
					pctDist    	0.546392
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ACC52B70147"
				    client     	@653
				    supplier   	@642
				    vertices   	(list Points
					(1560, 1431)
					(1754, 1431))
				    line_style 	3
				    origin_attachment 	(1560, 1431)
				    terminal_attachment 	(1754, 1431)
				    label      	(object SegLabel @656
					Parent_View 	@654
					location   	(1717, 1401)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.809278
					height     	30
					orientation 	0))
				(object RoleView "selection" @657
				    Parent_View 	@653
				    location   	(441, 0)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @658
					Parent_View 	@657
					location   	(1469, 1395)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	187
					justify    	0
					label      	"+selection"
					pctDist    	0.469072
					height     	36
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ACC52B70149"
				    client     	@653
				    supplier   	@652
				    vertices   	(list Points
					(1560, 1431)
					(1366, 1431))
				    line_style 	3
				    origin_attachment 	(1560, 1431)
				    terminal_attachment 	(1366, 1431)
				    label      	(object SegLabel @659
					Parent_View 	@657
					location   	(1435, 1486)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.649485
					height     	55
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$29" @660
			    location   	(1139, 921)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ACC97750261"
			    roleview_list 	(list RoleViews
				(object RoleView "selectionExpr" @661
				    Parent_View 	@660
				    location   	(20, -510)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @662
					Parent_View 	@661
					location   	(1295, 553)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	281
					justify    	0
					label      	"+selectionExpr"
					pctDist    	0.839458
					height     	156
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ACC97760213"
				    client     	@660
				    supplier   	@643
				    vertices   	(list Points
					(1139, 921)
					(1139, 481))
				    line_style 	3
				    origin_attachment 	(1139, 921)
				    terminal_attachment 	(1139, 481)
				    label      	(object SegLabel @663
					Parent_View 	@661
					location   	(1183, 508)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.940039
					height     	44
					orientation 	1))
				(object RoleView "selection" @664
				    Parent_View 	@660
				    location   	(20, -510)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @665
					Parent_View 	@664
					location   	(1256, 1273)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	187
					justify    	0
					label      	"+selection"
					pctDist    	0.798186
					height     	117
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4ACC97760242"
				    client     	@660
				    supplier   	@652
				    vertices   	(list Points
					(1139, 921)
					(1139, 1362))
				    line_style 	3
				    origin_attachment 	(1139, 921)
				    terminal_attachment 	(1139, 1362)
				    label      	(object SegLabel @666
					Parent_View 	@664
					location   	(1206, 1337)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.945841
					height     	67
					orientation 	0))))
			(object InheritView "" @667
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4ACC4F8503E7"
			    client     	@652
			    supplier   	@641
			    vertices   	(list Points
				(956, 1363)
				(956, 1078))
			    line_style 	3
			    origin_attachment 	(956, 1363)
			    terminal_attachment 	(956, 1078))))
		(object ClassDiagram "OQL"
		    quid       	"4B27561200AB"
		    title      	"OQL"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	676
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @668
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(947, 253)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@668
				location   	(799, 124)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @669
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2248, 384)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@669
				location   	(1848, 80)
				fill_color 	13434879
				nlines     	1
				max_width  	800
				justify    	0
				label      	"TypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A97A00CB"
			    width      	818
			    height     	632
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @670
			    location   	(1471, 228)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47CBF4180109"
			    roleview_list 	(list RoleViews
				(object RoleView "ownerTypedElement" @671
				    Parent_View 	@670
				    location   	(-629, -103)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @672
					Parent_View 	@671
					location   	(1316, 188)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	393
					justify    	0
					label      	"+ownerTypedElement"
					pctDist    	0.425474
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010B"
				    client     	@670
				    supplier   	@668
				    vertices   	(list Points
					(1471, 228)
					(1104, 228))
				    line_style 	3
				    origin_attachment 	(1471, 228)
				    terminal_attachment 	(1104, 228)
				    label      	(object SegLabel @673
					Parent_View 	@671
					location   	(1166, 285)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.831978
					height     	57
					orientation 	0))
				(object RoleView "ownedTypeDefinition" @674
				    Parent_View 	@670
				    location   	(-629, -103)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @675
					Parent_View 	@674
					location   	(1626, 265)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	396
					justify    	0
					label      	"+ownedTypeDefinition"
					pctDist    	0.422764
					height     	37
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010A"
				    client     	@670
				    supplier   	@669
				    vertices   	(list Points
					(1471, 228)
					(1839, 228))
				    line_style 	3
				    origin_attachment 	(1471, 228)
				    terminal_attachment 	(1839, 228)
				    label      	(object SegLabel @676
					Parent_View 	@674
					location   	(1786, 189)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.859079
					height     	40
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::SapClass" @677
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2256, 1550)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@677
				location   	(2048, 1471)
				fill_color 	13434879
				nlines     	1
				max_width  	416
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	434
			    height     	182
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @678
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2257, 1053)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@678
				location   	(1962, 924)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"ClassTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4784F7E800AB"
			    width      	608
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @679
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9A982030D"
			    client     	@678
			    supplier   	@669
			    vertices   	(list Points
				(2257, 912)
				(2257, 700))
			    line_style 	3
			    origin_attachment 	(2257, 912)
			    terminal_attachment 	(2257, 700))
			(object AssociationViewNew "" @680
			    location   	(2267, 1325)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4784F7F5005D"
			    roleview_list 	(list RoleViews
				(object RoleView "clazz" @681
				    Parent_View 	@680
				    location   	(19, 372)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @682
					Parent_View 	@681
					location   	(2178, 1420)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	136
					justify    	0
					label      	"+clazz"
					pctDist    	0.714436
					height     	90
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005F"
				    client     	@680
				    supplier   	@677
				    vertices   	(list Points
					(2267, 1325)
					(2267, 1458))
				    line_style 	3
				    origin_attachment 	(2267, 1325)
				    terminal_attachment 	(2267, 1458)
				    label      	(object SegLabel @683
					Parent_View 	@681
					location   	(2321, 1428)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.781288
					height     	54
					orientation 	0))
				(object RoleView "elementsOfType" @684
				    Parent_View 	@680
				    location   	(19, 372)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @685
					Parent_View 	@684
					location   	(2079, 1225)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	320
					justify    	0
					label      	"+elementsOfType"
					pctDist    	0.763975
					height     	189
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005E"
				    client     	@680
				    supplier   	@678
				    vertices   	(list Points
					(2267, 1325)
					(2267, 1193))
				    line_style 	3
				    origin_attachment 	(2267, 1325)
				    terminal_attachment 	(2267, 1193)
				    label      	(object SegLabel @686
					Parent_View 	@684
					location   	(2329, 1228)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.732919
					height     	62
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @687
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(947, 793)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@687
				location   	(680, 564)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "l" @688
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@688
				location   	(947, 473)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@687
			    supplier   	@668
			    vertices   	(list Points
				(947, 552)
				(947, 394))
			    line_style 	3
			    origin_attachment 	(947, 552)
			    terminal_attachment 	(947, 394))
			(object ClassView "Class" "Logical View::dataaccess::query::FromClause" @689
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(915, 1995)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@689
				location   	(787, 1944)
				fill_color 	13434879
				nlines     	1
				max_width  	256
				justify    	0
				label      	"FromClause")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B275602036B"
			    width      	274
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$32" @690
			    location   	(297, 1447)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B2757530203"
			    roleview_list 	(list RoleViews
				(object RoleView "fromExpression" @691
				    Parent_View 	@690
				    location   	(-959, -152)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @692
					Parent_View 	@691
					location   	(433, 757)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	322
					justify    	0
					label      	"+fromExpression"
					pctDist    	0.769304
					height     	37
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2757550148"
				    client     	@690
				    supplier   	@687
				    vertices   	(list Points
					(297, 1447)
					(297, 793)
					(671, 793))
				    line_style 	3
				    origin_attachment 	(297, 1447)
				    terminal_attachment 	(671, 793)
				    label      	(object SegLabel @693
					Parent_View 	@691
					location   	(631, 758)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.961868
					height     	36
					orientation 	0))
				(object RoleView "fromClause" @694
				    Parent_View 	@690
				    location   	(-959, -152)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @695
					Parent_View 	@694
					location   	(489, 2032)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	233
					justify    	0
					label      	"+fromClause"
					pctDist    	0.718780
					height     	37
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2757550186"
				    client     	@690
				    supplier   	@689
				    vertices   	(list Points
					(297, 1447)
					(297, 1995)
					(778, 1995))
				    line_style 	3
				    origin_attachment 	(297, 1447)
				    terminal_attachment 	(778, 1995)
				    label      	(object SegLabel @696
					Parent_View 	@694
					location   	(692, 2040)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.917064
					height     	45
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @697
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(915, 2336)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@697
				location   	(815, 2262)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    width      	218
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$33" @698
			    location   	(915, 2154)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B2757AD01B5"
			    roleview_list 	(list RoleViews
				(object RoleView "alias" @699
				    Parent_View 	@698
				    location   	(-341, 555)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @700
					Parent_View 	@699
					location   	(838, 2220)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	112
					justify    	0
					label      	"+alias"
					pctDist    	0.687500
					height     	78
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2757AD033C"
				    client     	@698
				    supplier   	@697
				    vertices   	(list Points
					(915, 2154)
					(915, 2250))
				    line_style 	3
				    origin_attachment 	(915, 2154)
				    terminal_attachment 	(915, 2250)
				    label      	(object SegLabel @701
					Parent_View 	@699
					location   	(957, 2220)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.687500
					height     	42
					orientation 	0))
				(object RoleView "fromClause" @702
				    Parent_View 	@698
				    location   	(-341, 555)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @703
					Parent_View 	@702
					location   	(758, 2093)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	233
					justify    	0
					label      	"+fromClause"
					pctDist    	0.635417
					height     	158
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2757AD033E"
				    client     	@698
				    supplier   	@689
				    vertices   	(list Points
					(915, 2154)
					(915, 2058))
				    line_style 	3
				    origin_attachment 	(915, 2154)
				    terminal_attachment 	(915, 2058)
				    label      	(object SegLabel @704
					Parent_View 	@702
					location   	(977, 2090)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.666667
					height     	62
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::query::OqlQuery" @705
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(931, 1508)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@705
				location   	(821, 1377)
				fill_color 	13434879
				nlines     	1
				max_width  	220
				justify    	0
				label      	"OqlQuery")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B2755FC01F4"
			    width      	238
			    height     	287
			    annotation 	8)
			(object InheritView "" @706
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B27561D0203"
			    client     	@705
			    supplier   	@687
			    vertices   	(list Points
				(934, 1365)
				(934, 1033))
			    line_style 	3
			    origin_attachment 	(934, 1365)
			    terminal_attachment 	(934, 1033))
			(object AssociationViewNew "$UNNAMED$30" @707
			    location   	(1456, 1196)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B275624037A"
			    roleview_list 	(list RoleViews
				(object RoleView "condition" @708
				    Parent_View 	@707
				    location   	(812, 193)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @709
					Parent_View 	@708
					location   	(1351, 752)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	204
					justify    	0
					label      	"+condition"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B275626034B"
				    client     	@707
				    supplier   	@687
				    vertices   	(list Points
					(1456, 1196)
					(1456, 793)
					(1223, 793))
				    line_style 	3
				    origin_attachment 	(1456, 1196)
				    terminal_attachment 	(1223, 793)
				    label      	(object SegLabel @710
					Parent_View 	@708
					location   	(1287, 847)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "conditionOfOqlQuery" @711
				    Parent_View 	@707
				    location   	(812, 193)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @712
					Parent_View 	@711
					location   	(1258, 1392)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	411
					justify    	0
					label      	"+conditionOfOqlQuery"
					pctDist    	0.674627
					height     	35
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B275626038A"
				    client     	@707
				    supplier   	@705
				    vertices   	(list Points
					(1456, 1196)
					(1456, 1426)
					(1050, 1426))
				    line_style 	3
				    origin_attachment 	(1456, 1196)
				    terminal_attachment 	(1050, 1426)
				    label      	(object SegLabel @713
					Parent_View 	@711
					location   	(1114, 1480)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$31" @714
			    location   	(937, 1791)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B27566000EA"
			    roleview_list 	(list RoleViews
				(object RoleView "fromClauses" @715
				    Parent_View 	@714
				    location   	(293, 788)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @716
					Parent_View 	@715
					location   	(769, 1909)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	250
					justify    	0
					label      	"+fromClauses"
					pctDist    	0.841629
					height     	169
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B275661031C"
				    client     	@714
				    supplier   	@689
				    vertices   	(list Points
					(937, 1791)
					(937, 1932))
				    line_style 	3
				    origin_attachment 	(937, 1791)
				    terminal_attachment 	(937, 1932)
				    label      	(object SegLabel @717
					Parent_View 	@715
					location   	(991, 1917)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.900000
					height     	54
					orientation 	0)
				    label      	(object SegLabel @718
					Parent_View 	@715
					location   	(1058, 1880)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.633484
					height     	121
					orientation 	0))
				(object RoleView "fromClauseOfOqlQuery" @719
				    Parent_View 	@714
				    location   	(293, 788)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @720
					Parent_View 	@719
					location   	(658, 1679)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+fromClauseOfOqlQuery"
					pctDist    	0.800905
					height     	280
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B275661031E"
				    client     	@714
				    supplier   	@705
				    vertices   	(list Points
					(937, 1791)
					(937, 1650))
				    line_style 	3
				    origin_attachment 	(937, 1791)
				    terminal_attachment 	(937, 1650)
				    label      	(object SegLabel @721
					Parent_View 	@719
					location   	(1006, 1679)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.800905
					height     	69
					orientation 	1))))
			(object UsesView "has value type with selected aliases' types" @722
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@722
				location   	(1545, 1560)
				anchor_loc 	1
				nlines     	1
				max_width  	785
				justify    	0
				label      	"has value type with selected aliases' types")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B27584E00AB"
			    client     	@705
			    supplier   	@677
			    vertices   	(list Points
				(1050, 1560)
				(2039, 1560))
			    line_style 	3
			    origin_attachment 	(1050, 1560)
			    terminal_attachment 	(2039, 1560))
			(object AssociationViewNew "$UNNAMED$34" @723
			    location   	(1335, 1998)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B2783A7003E"
			    roleview_list 	(list RoleViews
				(object RoleView "selected" @724
				    Parent_View 	@723
				    location   	(404, 490)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @725
					Parent_View 	@724
					location   	(1139, 2308)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	183
					justify    	0
					label      	"+selected"
					pctDist    	0.825758
					height     	39
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2783A9032C"
				    client     	@723
				    supplier   	@697
				    vertices   	(list Points
					(1335, 1998)
					(1335, 2347)
					(1024, 2347))
				    line_style 	3
				    origin_attachment 	(1335, 1998)
				    terminal_attachment 	(1024, 2347)
				    label      	(object SegLabel @726
					Parent_View 	@724
					location   	(1090, 2401)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "$UNNAMED$35" @727
				    Parent_View 	@723
				    location   	(404, 490)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B2783A9033C"
				    client     	@723
				    supplier   	@705
				    vertices   	(list Points
					(1335, 1998)
					(1335, 1623)
					(1050, 1623))
				    line_style 	3
				    origin_attachment 	(1335, 1998)
				    terminal_attachment 	(1050, 1623))))))))
	(object Class_Category "analytics"
	    quid       	"446B1F110187"
	    documentation 	"This is the home for the definitions of what InfoObjects, InfoCubes, extractors, queries and views are."
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Dimension"
		    quid       	"4717B68901E2"
		    documentation 	
|Dimensions define characteristics of the elements in a cell set according to which they may be grouped. A dimension defines a block that receives a value from the cell set's domain (its "facts" expression) and that determines the characteristic for that value in this dimension.
|
|For example, if a cell set's domain is the set of all SalesOrderItems, one dimension could be the Product, and therefore the product dimension's block would determine the product of the SalesOrderItem.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"48EA0C5E004E"
			    supplier   	"Logical View::modelmanagement::NamedElement"
			    quidu      	"45013C240030"))
		    nestedClasses 	(list nestedClasses
			(object Class "BlockSignatureMustMatch"
			    quid       	"4717E22F0387"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4717E23F0107"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Dimension
|inv:
|  self.characteristicFunction.input->size() = 1 and 
|  self.cellSet.factsType.conformsToIgnoringMultiplicity(self.characteristicFunction.input->at(1).getType())
|    -- Add the following again once we have NestedTypeDefinitions under control...
|    -- and  self.characteristicFunction.input->at(1).getType().upperMultiplicity = 1
|
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "CharacteristicFunctionMustNotBeAbstract"
			    quid       	"48EA1C710213"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48EA1C800119"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Dimension
|inv:
|  not self.characteristicFunction.isAbstract()
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "CellSet"
		    quid       	"4718603E0213"
		    documentation 	
|A cell set computes an aggregated view on a domain of values, aggregated according to the different values for the different dimensions, using the aggregation function defined by the cell set. The domain (fact base) type is specified by factsType.
|
|It subclasses FunctionSignatureImplementation. The function signature that a CellSet implements takes as its first argument a value whose type conforms to factsType, furthermore one argument per dimension and returns the aggregated cell value for the coordinate specified by the parameters. Therefore, the aggregationFunction's output type must conform to the CellSet's function signature's output type.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4A373D4D02FD"
			    supplier   	"Logical View::data::classes::FunctionSignatureImplementation"
			    quidu      	"4974995A0069"))
		    operations 	(list Operations
			(object Operation "keyFigureType"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context CellSet::keyFigureType():TypeDefinition
|body:
|  if self.valueFunction->isEmpty() then
|    self.factsType
|  else
|    self.valueFunction.output
|  endif
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"Data Modeler"
				    name       	"KeyList"
				    value      	""))
			    quid       	"4717E3CB02DC"
			    documentation 	"Determines the type over which to aggregate. If no valueFunction is provided, this is the type of the cell set's elements. Otherwise, this is the type output by the valueFunction."
			    result     	"TypeDefinition"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"47B9A97A00CB")
			(object Operation "cellType"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context CellSet::cellType():TypeDefinition
|body:
|  self.aggregationFunction.output
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"Data Modeler"
				    name       	"KeyList"
				    value      	""))
			    quid       	"4718752302EE"
			    result     	"TypeDefinition"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"47B9A97A00CB")
			(object Operation "localIsSideEffectFree"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context CellSet::localIsSideEffectFree():Boolean
|body:
|  self.dimensions->forAll(d|d.characteristicFunction.sideEffectFree) and
|  (self.valueFunction->notEmpty() implies self.valueFunction.sideEffectFree) and
|  self.aggregationFunction.sideEffectFree
				    )))
			    quid       	"4A377FAC02CE"
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392"))
		    nestedClasses 	(list nestedClasses
			(object Class "ValueFunctionSignatureMustMatch"
			    quid       	"47187338009C"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47187357036B"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context CellSet
|inv:
|  self.valueFunction->notEmpty() implies
|    (self.valueFunction.input->size() = 1 and
|     self.factsType.conformsToIgnoringMultiplicity(self.valueFunction.input->at(1).getType())
|    -- Add the following again once we have NestedTypeDefinitions under control...
|    -- and  self.valueFunction.input->at(1).getType().upperMultiplicity = 1
|    )
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "AggregationFunctionSignatureMustMatch"
			    quid       	"47187406009C"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"471874110280"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context CellSet
|inv:
|  self.aggregationFunction.input->size() = 1 and 
|  self.keyFigureType().conformsTo(self.aggregationFunction.input->at(1).getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "AggregationFunctionMustNotBeAbstract"
			    quid       	"48EA1CA100BB"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48EA1CAE0280"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context CellSet
|inv:
|  not self.aggregationFunction.isAbstract()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ValueFunctionMustNotBeAbstract"
			    quid       	"48EA1CCC02CE"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48EA1CDB000F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context CellSet
|inv:
|  self.valueFunction->forAll(vf | not vf.isAbstract())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "DimensionExpression"
		    quid       	"4718AA7E0167"
		    documentation 	
|For the given cell set, obtain all distinct characteristic values of the given dimension. For example, for a CellSet based on SalesOrderItem with one Dimension being Product, yield all products for which a SalesOrderItem exists in the CellSet.
|
|The type of this DimensionExpression is Set<self.dimension.type>
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4718AA8703D8"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"))
		    nestedClasses 	(list nestedClasses
			(object Class "FactsTypeConformsToFirstFunctionParameterType"
			    quid       	"4A3A52A8002E"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4A3A52BF001F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context DimensionExpression
|inv:
|  self.facts.getType().conformsTo(self.dimensionParameter.ownerSignature.input->at(1).getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "CellSetExpressionMustHaveFunctionSignatureType"
			    quid       	"4A3A56810399"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4A3A569C0109"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context DimensionExpression
|inv:
|  self.cellSet.getType().oclIsKindOf(data::classes::FunctionSignatureTypeDefinition)
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "DimensionParameterIsNotFirst"
			    quid       	"4A3A56B40157"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4A3A56DB0148"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context DimensionExpression
|inv:
|  self.dimensionParameter.ownerSignature.input->indexOf(self.dimensionParameter) > 1
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "GroupBy"
		    quid       	"4B8E7AA300CB"
		    documentation 	
|Groups the "object" expression's evaluation result by assigning each of its objects to the "fact" iterator, then evaluating all dimensions' expressions. Those objects having equal dimension results for all dimensions are put into one group. If no mapExpression is provided, the collection of those groups is the result of the GroupBy expression.
|
|If a mapExpression is provided, each group is assigned to the groupedFacts iterator, all dimension values for the respective group are assigned to their iterator and the mapExpression is evaluated with all these iterators in scope. The map expression's output type is raised in multiplicity by one "level". However, the GroupBy's type always has non-unique multiplicity.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B8E7AA90138"
			    supplier   	"Logical View::dataaccess::expressions::ObjectBasedExpression"
			    quidu      	"453E0FC80335"))
		    nestedClasses 	(list nestedClasses
			(object Class "GroupedFactsIteratorMustExistIfMapExpressionExists"
			    quid       	"4B8E82EC0242"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8E830601E4"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context GroupBy
|inv:
|  self.mapExpression->notEmpty() implies self.groupedFacts->notEmpty()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "MapExpressionMustBeSideEffectFree"
			    quid       	"4B8E8AC4030D"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8E8ADA0128"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context GroupBy
|inv:
|  if self.mapExpression->notEmpty() then
|    self.mapExpression.isSideEffectFree()
|  else
|    true
|  endif
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "GroupByIteratorsMustHaveDistinctNames"
			    quid       	"4B8E8B480261"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8E8B5E029F"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context GroupBy
|inv:
|  self.dimensions.iterator->asSet()->union(self.groupedFacts->asSet())->union(self.fact->asSet())->forAll(i, j | i<>j implies i.name<>j.name)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "DimensionDefinition"
		    quid       	"4B8E7B4F007D"
		    documentation 	"A dimension definition is not named. It owns a named iterator that can be used by the mapExpression."
		    operations 	(list Operations
			(object Operation "getName"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context DimensionDefinition::getName():String
|body:
|  self.iterator.name
				    )))
			    quid       	"4B8E83A102CE"
			    result     	"String"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60394"))
		    nestedClasses 	(list nestedClasses
			(object Class "DimensionExpressionMustBeSideEffectFree"
			    quid       	"4B8E8B0803A9"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4B8E8B15004E"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context DimensionDefinition
|inv:
|  self.expression.isSideEffectFree()
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Association "$UNNAMED$36"
		    quid       	"4717D8CD01F1"
		    roles      	(list role_list
			(object Role "dimensions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4717D8CE0116"
			    label      	"dimensions"
			    supplier   	"Logical View::dataaccess::analytics::Dimension"
			    quidu      	"4717B68901E2"
			    client_cardinality 	(value cardinality "1..*")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "cellSet"
			    quid       	"4717D8CE0118"
			    label      	"cellSet"
			    supplier   	"Logical View::dataaccess::analytics::CellSet"
			    quidu      	"4718603E0213"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$37"
		    quid       	"4717DDE30107"
		    documentation 	
|A dimension defines functionality that can be used to determine the value of that dimension for a particular cell's value. For example, if a cell contains a SalesOrder object, one dimension may determine the time when the order came in. Another dimension from the order who the customer was.
|
|The block specified to determined this value has to have a signature whose input type is the type of the CellSet's cells, and whose output type equals the type of the dimension.
		    
		    roles      	(list role_list
			(object Role "characteristicFunction"
			    quid       	"4717DDE30368"
			    label      	"characteristicFunction"
			    supplier   	"Logical View::data::classes::FunctionSignature"
			    quidu      	"47D67D190077"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "dimension"
			    quid       	"4717DDE30378"
			    label      	"dimension"
			    supplier   	"Logical View::dataaccess::analytics::Dimension"
			    quidu      	"4717B68901E2"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$38"
		    quid       	"4717E2C60397"
		    documentation 	"The function that is used to convert the cell set's domain values  (e.g., a SalesOrderItem object) into an aggregable value (e.g., the price of the SalesOrderItem). If not provided, the cell value is used itself, as if an identity function had been provided."
		    roles      	(list role_list
			(object Role "valueFunction"
			    quid       	"4717E2CB0210"
			    label      	"valueFunction"
			    supplier   	"Logical View::data::classes::FunctionSignature"
			    quidu      	"47D67D190077"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "cellSetForValueFunction"
			    quid       	"4717E2CB0212"
			    label      	"cellSetForValueFunction"
			    supplier   	"Logical View::dataaccess::analytics::CellSet"
			    quidu      	"4718603E0213"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$39"
		    quid       	"4718722400DA"
		    documentation 	"Defines the function that the cell set uses to aggregate values with equal characteristics in all dimensions."
		    roles      	(list role_list
			(object Role "aggregationFunction"
			    quid       	"4718722602FD"
			    label      	"aggregationFunction"
			    supplier   	"Logical View::data::classes::FunctionSignature"
			    quidu      	"47D67D190077"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "cellSetForAggregationFunction"
			    quid       	"4718722602FF"
			    label      	"cellSetForAggregationFunction"
			    supplier   	"Logical View::dataaccess::analytics::CellSet"
			    quidu      	"4718603E0213"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$40"
		    quid       	"4718AAC90290"
		    roles      	(list role_list
			(object Role "cellSet"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4718AACC0167"
			    label      	"cellSet"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "cellSetOfDimensionExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4718AACC0169"
			    label      	"cellSetOfDimensionExpression"
			    supplier   	"Logical View::dataaccess::analytics::DimensionExpression"
			    quidu      	"4718AA7E0167"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$41"
		    quid       	"4718AB170222"
		    roles      	(list role_list
			(object Role "dimensionParameter"
			    quid       	"4718AB19002E"
			    label      	"dimensionParameter"
			    supplier   	"Logical View::data::classes::Parameter"
			    quidu      	"47F12A7E0062"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$42"
			    quid       	"4718AB190030"
			    supplier   	"Logical View::dataaccess::analytics::DimensionExpression"
			    quidu      	"4718AA7E0167")))
		(object Association "$UNNAMED$43"
		    quid       	"4A37E21E022E"
		    documentation 	"The domain expression for a cell set is expected to deliver a collection of objects that form the base data over which the cell set aggregates."
		    roles      	(list role_list
			(object Role "factsType"
			    quid       	"4A37E21E022F"
			    label      	"factsType"
			    supplier   	"Logical View::data::classes::TypeDefinition"
			    quidu      	"47B9A97A00CB"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "cellSet"
			    quid       	"4A37E21E0230"
			    label      	"cellSet"
			    supplier   	"Logical View::dataaccess::analytics::CellSet"
			    quidu      	"4718603E0213"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$44"
		    quid       	"4A3A5263001F"
		    roles      	(list role_list
			(object Role "facts"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4A3A526302DE"
			    label      	"facts"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "factsOfDimensionExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4A3A5263032C"
			    label      	"factsOfDimensionExpression"
			    supplier   	"Logical View::dataaccess::analytics::DimensionExpression"
			    quidu      	"4718AA7E0167"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$45"
		    quid       	"4B8E7B5F0251"
		    roles      	(list role_list
			(object Role "dimensions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E7B60004E"
			    label      	"dimensions"
			    supplier   	"Logical View::dataaccess::analytics::DimensionDefinition"
			    quidu      	"4B8E7B4F007D"
			    client_cardinality 	(value cardinality "1..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "groupBy"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E7B600050"
			    label      	"groupBy"
			    supplier   	"Logical View::dataaccess::analytics::GroupBy"
			    quidu      	"4B8E7AA300CB"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$46"
		    quid       	"4B8E7B8C01C5"
		    roles      	(list role_list
			(object Role "expression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E7B8F02FD"
			    label      	"expression"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "dimension"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E7B8F034B"
			    label      	"dimension"
			    supplier   	"Logical View::dataaccess::analytics::DimensionDefinition"
			    quidu      	"4B8E7B4F007D"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$47"
		    quid       	"4B8E7BF9034B"
		    roles      	(list role_list
			(object Role "fact"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E7BFA01A5"
			    label      	"fact"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "factOfGroupBy"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E7BFA01B5"
			    label      	"factOfGroupBy"
			    supplier   	"Logical View::dataaccess::analytics::GroupBy"
			    quidu      	"4B8E7AA300CB"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$48"
		    quid       	"4B8E7C2C0251"
		    roles      	(list role_list
			(object Role "iterator"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E7C2D004E"
			    label      	"iterator"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "dimension"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E7C2D005D"
			    label      	"dimension"
			    supplier   	"Logical View::dataaccess::analytics::DimensionDefinition"
			    quidu      	"4B8E7B4F007D"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$49"
		    quid       	"4B8E80990000"
		    documentation 	"The mapExpression is optional. If provided, it has the groupedFacts iterator in scope, as well as all dimensions' iterators."
		    roles      	(list role_list
			(object Role "mapExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E809B01A5"
			    label      	"mapExpression"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "mapExpressionOfGroupBy"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E809B01E4"
			    label      	"mapExpressionOfGroupBy"
			    supplier   	"Logical View::dataaccess::analytics::GroupBy"
			    quidu      	"4B8E7AA300CB"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$50"
		    quid       	"4B8E8115033C"
		    documentation 	"The groupedFacts iterator exists if a mapExpression is provided and is in scope for the mapExpression. It represents the group of facts that all have the same values for all dimension expressions."
		    roles      	(list role_list
			(object Role "groupedFacts"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4B8E81160138"
			    label      	"groupedFacts"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "groupedFactsOfGroupBy"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4B8E81160148"
			    label      	"groupedFactsOfGroupBy"
			    supplier   	"Logical View::dataaccess::analytics::GroupBy"
			    quidu      	"4B8E7AA300CB"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Expressions"
		    quid       	"4718AED70119"
		    title      	"Expressions"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	669
		    origin_y   	0
		    items      	(list diagram_item_list
			(object NoteView @728
			    location   	(1485, 2455)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@728
				location   	(81, 2162)
				fill_color 	13434879
				nlines     	11
				max_width  	2772
				label      	
|TODO / Problem: CellSets are now sort of objectified. They result in an object whose type is described by a FunctionSignatureTypeDefinition and whose implementation is modeled by the CellSet element. The problem is that from a typing point of view it can no longer be recognized whether a function is implemented by a Block or by a CellSet. This also means that a DimensionExpression may get applied to a function that is not implemented by a CellSet.
|
|Also, we need to change the metamodel. The DimensionExpression can no longer refer to a CellSet but only to an Expression. Furthermore, the Dimension can not be referenced directly, but at best, a Parameter element of the function signature of which the CellSet is an implementation may be referenced.
|
|The solution would probably be to model CellSetTypeDefinition as subclass of FunctionSignatureTypeDefinition, devise special syntax (e.g., using the keyword "cube") for it and then require DimensionExpression to work only on expressions whose type is described by a CellSetTypeDefinition.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	2832
			    height     	599)
			(object ClassView "Class" "Logical View::dataaccess::analytics::Dimension" @729
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1276, 2004)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@729
				location   	(1166, 1953)
				fill_color 	13434879
				nlines     	1
				max_width  	220
				justify    	0
				label      	"Dimension")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B68901E2"
			    width      	238
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::analytics::CellSet" @730
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(443, 1968)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@730
				location   	(214, 1837)
				fill_color 	13434879
				nlines     	1
				max_width  	458
				justify    	0
				label      	"CellSet")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4718603E0213"
			    width      	476
			    height     	286
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$36" @731
			    location   	(919, 2011)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717D8CD01F1"
			    roleview_list 	(list RoleViews
				(object RoleView "dimensions" @732
				    Parent_View 	@731
				    location   	(675, 996)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @733
					Parent_View 	@732
					location   	(1028, 2042)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	236
					justify    	0
					label      	"+dimensions"
					pctDist    	0.459459
					height     	31
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D8CE0116"
				    client     	@731
				    supplier   	@729
				    vertices   	(list Points
					(919, 2011)
					(1157, 2011))
				    line_style 	3
				    origin_attachment 	(919, 2011)
				    terminal_attachment 	(1157, 2011)
				    label      	(object SegLabel @734
					Parent_View 	@732
					location   	(1107, 1976)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.795556
					height     	36
					orientation 	0)
				    label      	(object SegLabel @735
					Parent_View 	@732
					location   	(1053, 2094)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.567568
					height     	83
					orientation 	1))
				(object RoleView "cellSet" @736
				    Parent_View 	@731
				    location   	(675, 996)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @737
					Parent_View 	@736
					location   	(771, 1976)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	161
					justify    	0
					label      	"+cellSet"
					pctDist    	0.622222
					height     	36
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D8CE0118"
				    client     	@731
				    supplier   	@730
				    vertices   	(list Points
					(919, 2011)
					(681, 2011))
				    line_style 	3
				    origin_attachment 	(919, 2011)
				    terminal_attachment 	(681, 2011)
				    label      	(object SegLabel @738
					Parent_View 	@736
					location   	(705, 2065)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @739
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(479, 1173)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@739
				location   	(9, 1044)
				fill_color 	13434879
				nlines     	1
				max_width  	940
				justify    	0
				label      	"FunctionSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D190077"
			    width      	958
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::FunctionSignatureImplementation" @740
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(458, 1600)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@740
				location   	(141, 1496)
				fill_color 	13434879
				nlines     	1
				max_width  	634
				justify    	0
				label      	"FunctionSignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4974995A0069"
			    width      	652
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @741
			    location   	(463, 1399)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4975FB7F01F4"
			    roleview_list 	(list RoleViews
				(object RoleView "functionSignature" @742
				    Parent_View 	@741
				    location   	(135, 24)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @743
					Parent_View 	@742
					location   	(261, 1350)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	346
					justify    	0
					label      	"+functionSignature"
					pctDist    	0.571429
					height     	203
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F6"
				    client     	@741
				    supplier   	@739
				    vertices   	(list Points
					(463, 1399)
					(463, 1314))
				    line_style 	3
				    origin_attachment 	(463, 1399)
				    terminal_attachment 	(463, 1314)
				    label      	(object SegLabel @744
					Parent_View 	@742
					location   	(527, 1352)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.557143
					height     	64
					orientation 	1))
				(object RoleView "implementation" @745
				    Parent_View 	@741
				    location   	(135, 24)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @746
					Parent_View 	@745
					location   	(305, 1454)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	304
					justify    	0
					label      	"+implementation"
					pctDist    	0.642857
					height     	159
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F5"
				    client     	@741
				    supplier   	@740
				    vertices   	(list Points
					(463, 1399)
					(463, 1484))
				    line_style 	3
				    origin_attachment 	(463, 1399)
				    terminal_attachment 	(463, 1484)
				    label      	(object SegLabel @747
					Parent_View 	@745
					location   	(529, 1467)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.794643
					height     	66
					orientation 	0))))
			(object InheritView "" @748
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A373D4D02FD"
			    client     	@730
			    supplier   	@740
			    vertices   	(list Points
				(457, 1825)
				(457, 1716))
			    line_style 	3
			    origin_attachment 	(457, 1825)
			    terminal_attachment 	(457, 1716))
			(object NoteView @749
			    location   	(1548, 1416)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@749
				location   	(1123, 1113)
				fill_color 	13434879
				nlines     	12
				max_width  	815
				label      	
|The Parameter used by the DimensionExpression as "dimension" must belong to a FunctionSignature and not be the first parameter (because the first represents the facts base).
|
|Only at runtime (see TODO below) the interpreter can ensure that the cellSet expression actually evaluates to a CellSet. Then, if the Parameter is the n-th in the list, the Dimension can be determined by obtaining the n-1st Dimension of the CellSet.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	875
			    height     	619)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @750
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2563, 549)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@750
				location   	(2415, 420)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @751
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1718, 176)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@751
				location   	(1573, 101)
				fill_color 	13434879
				nlines     	1
				max_width  	290
				justify    	0
				label      	"TypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A97A00CB"
			    width      	308
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @752
			    location   	(2340, 165)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47CBF4180109"
			    roleview_list 	(list RoleViews
				(object RoleView "ownerTypedElement" @753
				    Parent_View 	@752
				    location   	(-552, -76)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @754
					Parent_View 	@753
					location   	(2332, 370)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	393
					justify    	0
					label      	"+ownerTypedElement"
					pctDist    	0.921053
					height     	234
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010B"
				    client     	@752
				    supplier   	@750
				    vertices   	(list Points
					(2340, 165)
					(2565, 165)
					(2565, 408))
				    line_style 	3
				    origin_attachment 	(2340, 165)
				    terminal_attachment 	(2565, 408)
				    label      	(object SegLabel @755
					Parent_View 	@753
					location   	(2619, 360)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "ownedTypeDefinition" @756
				    Parent_View 	@752
				    location   	(-552, -76)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @757
					Parent_View 	@756
					location   	(2104, 103)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	396
					justify    	0
					label      	"+ownedTypeDefinition"
					pctDist    	0.504386
					height     	63
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010A"
				    client     	@752
				    supplier   	@751
				    vertices   	(list Points
					(2340, 165)
					(1872, 165))
				    line_style 	3
				    origin_attachment 	(2340, 165)
				    terminal_attachment 	(1872, 165)
				    label      	(object SegLabel @758
					Parent_View 	@756
					location   	(1930, 211)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.877926
					height     	46
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::FunctionSignatureTypeDefinition" @759
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1737, 568)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@759
				location   	(1428, 494)
				fill_color 	13434879
				nlines     	1
				max_width  	618
				justify    	0
				label      	"FunctionSignatureTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A9AD03B9"
			    width      	636
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @760
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9A9C20109"
			    client     	@759
			    supplier   	@751
			    vertices   	(list Points
				(1727, 482)
				(1727, 262))
			    line_style 	3
			    origin_attachment 	(1727, 482)
			    terminal_attachment 	(1727, 262))
			(object ClassView "Class" "Logical View::data::classes::Signature" @761
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(475, 701)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@761
				location   	(208, 497)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Signature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432198602CB"
			    width      	552
			    height     	432
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "OutputOfSignature" @762
			    location   	(842, 150)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @763
				Parent_View 	@762
				location   	(857, 116)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"OutputOfSignature"
				pctDist    	0.750000
				height     	35
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47B9EDFD0000"
			    roleview_list 	(list RoleViews
				(object RoleView "signaturesWithOutput" @764
				    Parent_View 	@762
				    location   	(-1616, -134)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @765
					Parent_View 	@764
					location   	(679, 394)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	426
					justify    	0
					label      	"+signaturesWithOutput"
					pctDist    	0.875335
					height     	225
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9EDFD0002"
				    client     	@762
				    supplier   	@761
				    vertices   	(list Points
					(842, 150)
					(454, 150)
					(454, 485))
				    line_style 	3
				    origin_attachment 	(842, 150)
				    terminal_attachment 	(454, 485)
				    label      	(object SegLabel @766
					Parent_View 	@764
					location   	(507, 457)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.963063
					height     	53
					orientation 	0))
				(object RoleView "output" @767
				    Parent_View 	@762
				    location   	(-1616, -134)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @768
					Parent_View 	@767
					location   	(1472, 118)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	140
					justify    	0
					label      	"+output"
					pctDist    	0.874266
					height     	33
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47B9EDFD0001"
				    client     	@762
				    supplier   	@751
				    vertices   	(list Points
					(842, 150)
					(1564, 150))
				    line_style 	3
				    origin_attachment 	(842, 150)
				    terminal_attachment 	(1564, 150)
				    label      	(object SegLabel @769
					Parent_View 	@767
					location   	(1508, 194)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.923593
					height     	44
					orientation 	1))))
			(object AssociationViewNew "" @770
			    location   	(1085, 612)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48A02BD6000F"
			    roleview_list 	(list RoleViews
				(object RoleView "typeDefinition" @771
				    Parent_View 	@770
				    location   	(503, 146)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @772
					Parent_View 	@771
					location   	(1352, 571)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+typeDefinition"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6007D"
				    client     	@770
				    supplier   	@759
				    vertices   	(list Points
					(1085, 612)
					(1419, 612))
				    line_style 	3
				    origin_attachment 	(1085, 612)
				    terminal_attachment 	(1419, 612)
				    label      	(object SegLabel @773
					Parent_View 	@771
					location   	(1370, 660)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.855615
					height     	48
					orientation 	1))
				(object RoleView "signature" @774
				    Parent_View 	@770
				    location   	(503, 146)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @775
					Parent_View 	@774
					location   	(856, 563)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	206
					justify    	0
					label      	"+signature"
					pctDist    	0.686327
					height     	50
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"48A02BD6002E"
				    client     	@770
				    supplier   	@761
				    vertices   	(list Points
					(1085, 612)
					(751, 612))
				    line_style 	3
				    origin_attachment 	(1085, 612)
				    terminal_attachment 	(751, 612)
				    label      	(object SegLabel @776
					Parent_View 	@774
					location   	(784, 666)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object InheritView "" @777
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47D67D2001B3"
			    client     	@739
			    supplier   	@761
			    vertices   	(list Points
				(460, 1032)
				(460, 917))
			    line_style 	3
			    origin_attachment 	(460, 1032)
			    terminal_attachment 	(460, 917))
			(object ClassView "Class" "Logical View::data::classes::Parameter" @778
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2144, 821)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@778
				location   	(2030, 747)
				fill_color 	13434879
				nlines     	1
				max_width  	228
				justify    	0
				label      	"Parameter")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F12A7E0062"
			    width      	246
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "InputOfSignature" @779
			    location   	(1386, 801)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @780
				Parent_View 	@779
				location   	(1393, 765)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"InputOfSignature"
				pctDist    	0.633333
				height     	37
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47F12A8C021A"
			    roleview_list 	(list RoleViews
				(object RoleView "ownerSignature" @781
				    Parent_View 	@779
				    location   	(1080, -140)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @782
					Parent_View 	@781
					location   	(948, 842)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	319
					justify    	0
					label      	"+ownerSignature"
					pctDist    	0.689441
					height     	41
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F12A8C021C"
				    client     	@779
				    supplier   	@761
				    vertices   	(list Points
					(1386, 801)
					(751, 801))
				    line_style 	3
				    origin_attachment 	(1386, 801)
				    terminal_attachment 	(751, 801)
				    label      	(object SegLabel @783
					Parent_View 	@781
					location   	(834, 749)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.871118
					height     	53
					orientation 	1))
				(object RoleView "input" @784
				    Parent_View 	@779
				    location   	(1080, -140)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @785
					Parent_View 	@784
					location   	(1881, 833)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	116
					justify    	0
					label      	"+input"
					pctDist    	0.780488
					height     	32
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47F12A8C021B"
				    client     	@779
				    supplier   	@778
				    vertices   	(list Points
					(1386, 801)
					(2021, 801))
				    line_style 	3
				    origin_attachment 	(1386, 801)
				    terminal_attachment 	(2021, 801)
				    label      	(object SegLabel @786
					Parent_View 	@784
					location   	(1890, 765)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.795732
					height     	37
					orientation 	0)
				    label      	(object SegLabel @787
					Parent_View 	@784
					location   	(1832, 711)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.704268
					height     	91
					orientation 	0))))
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @788
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    location   	(2579, 1026)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@788
				location   	(2416, 954)
				fill_color 	13434879
				nlines     	1
				max_width  	326
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	344
			    height     	169
			    annotation 	8)
			(object InheritView "l" @789
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@789
				location   	(2563, 816)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@788
			    supplier   	@750
			    vertices   	(list Points
				(2563, 942)
				(2563, 690))
			    line_style 	3
			    origin_attachment 	(2563, 942)
			    terminal_attachment 	(2563, 690))
			(object ClassView "Class" "Logical View::dataaccess::analytics::DimensionExpression" @790
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2444, 2012)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@790
				location   	(2231, 1961)
				fill_color 	13434879
				nlines     	1
				max_width  	426
				justify    	0
				label      	"DimensionExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4718AA7E0167"
			    width      	444
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$41" @791
			    location   	(2242, 1428)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4718AB170222"
			    roleview_list 	(list RoleViews
				(object RoleView "dimensionParameter" @792
				    Parent_View 	@791
				    location   	(1966, -401)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @793
					Parent_View 	@792
					location   	(2025, 1013)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	404
					justify    	0
					label      	"+dimensionParameter"
					pctDist    	0.796545
					height     	217
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718AB19002E"
				    client     	@791
				    supplier   	@778
				    vertices   	(list Points
					(2242, 1428)
					(2242, 907))
				    line_style 	3
				    origin_attachment 	(2242, 1428)
				    terminal_attachment 	(2242, 907)
				    label      	(object SegLabel @794
					Parent_View 	@792
					location   	(2203, 957)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.905950
					height     	40
					orientation 	0))
				(object RoleView "$UNNAMED$42" @795
				    Parent_View 	@791
				    location   	(1966, -401)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718AB190030"
				    client     	@791
				    supplier   	@790
				    vertices   	(list Points
					(2242, 1428)
					(2242, 1949))
				    line_style 	3
				    origin_attachment 	(2242, 1428)
				    terminal_attachment 	(2242, 1949))))
			(object InheritView "" @796
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4718AA8703D8"
			    client     	@790
			    supplier   	@788
			    vertices   	(list Points
				(2549, 1948)
				(2549, 1110))
			    line_style 	3
			    origin_attachment 	(2549, 1948)
			    terminal_attachment 	(2549, 1110))
			(object AssociationViewNew "$UNNAMED$40" @797
			    location   	(2468, 1529)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4718AAC90290"
			    roleview_list 	(list RoleViews
				(object RoleView "cellSet" @798
				    Parent_View 	@797
				    location   	(2192, -300)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @799
					Parent_View 	@798
					location   	(2381, 1205)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	161
					justify    	0
					label      	"+cellSet"
					pctDist    	0.773270
					height     	88
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718AACC0167"
				    client     	@797
				    supplier   	@788
				    vertices   	(list Points
					(2468, 1529)
					(2468, 1110))
				    line_style 	3
				    origin_attachment 	(2468, 1529)
				    terminal_attachment 	(2468, 1110)
				    label      	(object SegLabel @800
					Parent_View 	@798
					location   	(2417, 1151)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.905488
					height     	52
					orientation 	0))
				(object RoleView "cellSetOfDimensionExpression" @801
				    Parent_View 	@797
				    location   	(2192, -300)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @802
					Parent_View 	@801
					location   	(2155, 1843)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	598
					justify    	0
					label      	"+cellSetOfDimensionExpression"
					pctDist    	0.747619
					height     	313
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718AACC0169"
				    client     	@797
				    supplier   	@790
				    vertices   	(list Points
					(2468, 1529)
					(2468, 1949))
				    line_style 	3
				    origin_attachment 	(2468, 1529)
				    terminal_attachment 	(2468, 1949)
				    label      	(object SegLabel @803
					Parent_View 	@801
					location   	(2411, 1910)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.907143
					height     	58
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$44" @804
			    location   	(2633, 1529)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A3A5263001F"
			    roleview_list 	(list RoleViews
				(object RoleView "facts" @805
				    Parent_View 	@804
				    location   	(189, -483)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @806
					Parent_View 	@805
					location   	(2727, 1204)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	113
					justify    	0
					label      	"+facts"
					pctDist    	0.775656
					height     	94
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3A526302DE"
				    client     	@804
				    supplier   	@788
				    vertices   	(list Points
					(2633, 1529)
					(2633, 1110))
				    line_style 	3
				    origin_attachment 	(2633, 1529)
				    terminal_attachment 	(2633, 1110)
				    label      	(object SegLabel @807
					Parent_View 	@805
					location   	(2688, 1146)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.914081
					height     	55
					orientation 	1))
				(object RoleView "factsOfDimensionExpression" @808
				    Parent_View 	@804
				    location   	(189, -483)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @809
					Parent_View 	@808
					location   	(2931, 1813)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	551
					justify    	0
					label      	"+factsOfDimensionExpression"
					pctDist    	0.677804
					height     	298
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A3A5263032C"
				    client     	@804
				    supplier   	@790
				    vertices   	(list Points
					(2633, 1529)
					(2633, 1948))
				    line_style 	3
				    origin_attachment 	(2633, 1529)
				    terminal_attachment 	(2633, 1948)
				    label      	(object SegLabel @810
					Parent_View 	@808
					location   	(2699, 1909)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.906921
					height     	66
					orientation 	0))))))
		(object ClassDiagram "Cell Set as Function Signature Implementation"
		    quid       	"4A373C860157"
		    title      	"Cell Set as Function Signature Implementation"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::SignatureImplementation" @811
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2100, 264)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@811
				location   	(1831, 160)
				fill_color 	13434879
				nlines     	1
				max_width  	538
				justify    	0
				label      	"SignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47836ECF037A"
			    width      	556
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @812
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(797, 231)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@812
				location   	(505, 102)
				fill_color 	13434879
				nlines     	1
				max_width  	584
				justify    	0
				label      	"NamedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45013C240030"
			    width      	602
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @813
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2572, 1130)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@813
				location   	(2305, 951)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    width      	552
			    height     	382
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @814
			    location   	(1784, 2402)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@814
				location   	(1097, 2180)
				fill_color 	13434879
				nlines     	8
				max_width  	1339
				label      	
|A thought: If we want to allow CellSets to leave open the facts expression, this associations multiplicity could be changed to 0..1 for the "facts" and, and a second association to TypeDefinition could be established, with a constraint that requires one of the two links (either the type or the expression) to be present. If both are present, the facts expression's type must conform to the statically declared type. If the facts expression is not provided, the function signature for the CellSet will have an additional first argument typed by the static type for the facts.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	1399
			    height     	457)
			(object ClassView "Class" "Logical View::data::classes::FunctionSignatureImplementation" @815
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2111, 654)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@815
				location   	(1794, 550)
				fill_color 	13434879
				nlines     	1
				max_width  	634
				justify    	0
				label      	"FunctionSignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4974995A0069"
			    width      	652
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @816
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4974996A0390"
			    client     	@815
			    supplier   	@811
			    vertices   	(list Points
				(2100, 538)
				(2100, 380))
			    line_style 	3
			    origin_attachment 	(2100, 538)
			    terminal_attachment 	(2100, 380))
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @817
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(272, 244)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@817
				location   	(124, 115)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::FunctionSignature" @818
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1396, 931)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@818
				location   	(926, 802)
				fill_color 	13434879
				nlines     	1
				max_width  	940
				justify    	0
				label      	"FunctionSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D190077"
			    width      	958
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @819
			    location   	(1516, 646)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4975FB7F01F4"
			    roleview_list 	(list RoleViews
				(object RoleView "functionSignature" @820
				    Parent_View 	@819
				    location   	(-463, 2)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @821
					Parent_View 	@820
					location   	(1723, 521)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	346
					justify    	0
					label      	"+functionSignature"
					pctDist    	-0.767241
					height     	126
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F6"
				    client     	@819
				    supplier   	@818
				    vertices   	(list Points
					(1516, 646)
					(1390, 646)
					(1390, 790))
				    line_style 	3
				    origin_attachment 	(1516, 646)
				    terminal_attachment 	(1390, 790)
				    label      	(object SegLabel @822
					Parent_View 	@820
					location   	(1329, 760)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.891304
					height     	62
					orientation 	1))
				(object RoleView "implementation" @823
				    Parent_View 	@819
				    location   	(-463, 2)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @824
					Parent_View 	@823
					location   	(1627, 609)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	304
					justify    	0
					label      	"+implementation"
					pctDist    	0.411215
					height     	38
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4975FB7F01F5"
				    client     	@819
				    supplier   	@815
				    vertices   	(list Points
					(1516, 646)
					(1785, 646))
				    line_style 	3
				    origin_attachment 	(1516, 646)
				    terminal_attachment 	(1785, 646)
				    label      	(object SegLabel @825
					Parent_View 	@823
					location   	(1746, 697)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.853583
					height     	51
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::analytics::Dimension" @826
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(528, 1237)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@826
				location   	(234, 1187)
				fill_color 	13434879
				nlines     	1
				max_width  	589
				justify    	0
				label      	"Dimension")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B68901E2"
			    width      	607
			    height     	125
			    annotation 	8)
			(object AssociationViewNew "$UNNAMED$37" @827
			    location   	(805, 977)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717DDE30107"
			    roleview_list 	(list RoleViews
				(object RoleView "characteristicFunction" @828
				    Parent_View 	@827
				    location   	(-189, -54)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @829
					Parent_View 	@828
					location   	(770, 912)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	429
					justify    	0
					label      	"+characteristicFunction"
					pctDist    	0.326409
					height     	36
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717DDE30368"
				    client     	@827
				    supplier   	@818
				    vertices   	(list Points
					(805, 977)
					(805, 891)
					(917, 891))
				    line_style 	3
				    origin_attachment 	(805, 977)
				    terminal_attachment 	(917, 891)
				    label      	(object SegLabel @830
					Parent_View 	@828
					location   	(901, 934)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.925837
					height     	43
					orientation 	1))
				(object RoleView "dimension" @831
				    Parent_View 	@827
				    location   	(-189, -54)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @832
					Parent_View 	@831
					location   	(943, 1133)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	220
					justify    	0
					label      	"+dimension"
					pctDist    	0.790974
					height     	138
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717DDE30378"
				    client     	@827
				    supplier   	@826
				    vertices   	(list Points
					(805, 977)
					(805, 1175))
				    line_style 	3
				    origin_attachment 	(805, 977)
				    terminal_attachment 	(805, 1175)
				    label      	(object SegLabel @833
					Parent_View 	@831
					location   	(890, 1160)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.928741
					height     	85
					orientation 	0))))
			(object InheritTreeView "" @834
			    location   	(2111, 875)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@815
			    vertices   	(list Points
				(2111, 875)
				(2111, 770)))
			(object InheritView "" @835
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4975FB74030D"
			    client     	@813
			    supplier   	@815
			    vertices   	(list Points
				(2434, 939)
				(2434, 875))
			    line_style 	3
			    origin_attachment 	(2434, 939)
			    terminal_attachment 	(2434, 875)
			    drawSupplier 	@834)
			(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @836
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(487, 2083)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@836
				location   	(87, 1779)
				fill_color 	13434879
				nlines     	1
				max_width  	800
				justify    	0
				label      	"TypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A97A00CB"
			    width      	818
			    height     	632
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @837
			    location   	(184, 1075)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47CBF4180109"
			    roleview_list 	(list RoleViews
				(object RoleView "ownerTypedElement" @838
				    Parent_View 	@837
				    location   	(-225, -1077)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @839
					Parent_View 	@838
					location   	(392, 506)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	393
					justify    	0
					label      	"+ownerTypedElement"
					pctDist    	0.823045
					height     	208
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010B"
				    client     	@837
				    supplier   	@817
				    vertices   	(list Points
					(184, 1075)
					(184, 384))
				    line_style 	3
				    origin_attachment 	(184, 1075)
				    terminal_attachment 	(184, 384)
				    label      	(object SegLabel @840
					Parent_View 	@838
					location   	(238, 454)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "ownedTypeDefinition" @841
				    Parent_View 	@837
				    location   	(-225, -1077)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @842
					Parent_View 	@841
					location   	(415, 1652)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	396
					justify    	0
					label      	"+ownedTypeDefinition"
					pctDist    	0.834019
					height     	231
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010A"
				    client     	@837
				    supplier   	@836
				    vertices   	(list Points
					(184, 1075)
					(184, 1767))
				    line_style 	3
				    origin_attachment 	(184, 1075)
				    terminal_attachment 	(184, 1767)
				    label      	(object SegLabel @843
					Parent_View 	@841
					location   	(243, 1712)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.921811
					height     	59
					orientation 	0))))
			(object ClassView "Class" "Logical View::dataaccess::analytics::CellSet" @844
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2135, 1744)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@844
				location   	(1897, 1484)
				fill_color 	13434879
				nlines     	1
				max_width  	476
				justify    	0
				label      	"CellSet")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4718603E0213"
			    width      	494
			    height     	544
			    annotation 	8)
			(object AssociationViewNew "$UNNAMED$39" @845
			    location   	(1532, 1486)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4718722400DA"
			    roleview_list 	(list RoleViews
				(object RoleView "aggregationFunction" @846
				    Parent_View 	@845
				    location   	(638, 685)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @847
					Parent_View 	@846
					location   	(1699, 1143)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	391
					justify    	0
					label      	"+aggregationFunction"
					pctDist    	0.850318
					height     	227
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718722602FD"
				    client     	@845
				    supplier   	@818
				    vertices   	(list Points
					(1532, 1486)
					(1472, 1486)
					(1472, 1072))
				    line_style 	3
				    origin_attachment 	(1532, 1486)
				    terminal_attachment 	(1472, 1072)
				    label      	(object SegLabel @848
					Parent_View 	@846
					location   	(1518, 1108)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.926000
					height     	46
					orientation 	1))
				(object RoleView "cellSetForAggregationFunction" @849
				    Parent_View 	@845
				    location   	(638, 685)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @850
					Parent_View 	@849
					location   	(1594, 1531)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	598
					justify    	0
					label      	"+cellSetForAggregationFunction"
					pctDist    	0.173913
					height     	45
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4718722602FF"
				    client     	@845
				    supplier   	@844
				    vertices   	(list Points
					(1532, 1486)
					(1888, 1486))
				    line_style 	3
				    origin_attachment 	(1532, 1486)
				    terminal_attachment 	(1888, 1486)
				    label      	(object SegLabel @851
					Parent_View 	@849
					location   	(1850, 1445)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.893281
					height     	42
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$38" @852
			    location   	(1385, 1629)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717E2C60397"
			    roleview_list 	(list RoleViews
				(object RoleView "valueFunction" @853
				    Parent_View 	@852
				    location   	(1141, 614)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @854
					Parent_View 	@853
					location   	(1177, 1160)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	286
					justify    	0
					label      	"+valueFunction"
					pctDist    	0.857729
					height     	149
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717E2CB0210"
				    client     	@852
				    supplier   	@818
				    vertices   	(list Points
					(1385, 1629)
					(1325, 1629)
					(1325, 1072))
				    line_style 	3
				    origin_attachment 	(1385, 1629)
				    terminal_attachment 	(1325, 1072)
				    label      	(object SegLabel @855
					Parent_View 	@853
					location   	(1268, 1114)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.934337
					height     	58
					orientation 	0))
				(object RoleView "cellSetForValueFunction" @856
				    Parent_View 	@852
				    location   	(1141, 614)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @857
					Parent_View 	@856
					location   	(1636, 1671)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	469
					justify    	0
					label      	"+cellSetForValueFunction"
					pctDist    	0.499029
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717E2CB0212"
				    client     	@852
				    supplier   	@844
				    vertices   	(list Points
					(1385, 1629)
					(1888, 1629))
				    line_style 	3
				    origin_attachment 	(1385, 1629)
				    terminal_attachment 	(1888, 1629)
				    label      	(object SegLabel @858
					Parent_View 	@856
					location   	(1842, 1593)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.909233
					height     	37
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$36" @859
			    location   	(1079, 1759)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717D8CD01F1"
			    roleview_list 	(list RoleViews
				(object RoleView "dimensions" @860
				    Parent_View 	@859
				    location   	(835, 744)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @861
					Parent_View 	@860
					location   	(591, 1399)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	236
					justify    	0
					label      	"+dimensions"
					pctDist    	0.877987
					height     	141
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D8CE0116"
				    client     	@859
				    supplier   	@826
				    vertices   	(list Points
					(1079, 1759)
					(731, 1759)
					(731, 1299))
				    line_style 	3
				    origin_attachment 	(1079, 1759)
				    terminal_attachment 	(731, 1299)
				    label      	(object SegLabel @862
					Parent_View 	@860
					location   	(678, 1344)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.944654
					height     	54
					orientation 	0)
				    label      	(object SegLabel @863
					Parent_View 	@860
					location   	(839, 1381)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.900000
					height     	108
					orientation 	1))
				(object RoleView "cellSet" @864
				    Parent_View 	@859
				    location   	(835, 744)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @865
					Parent_View 	@864
					location   	(1779, 1803)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	161
					justify    	0
					label      	"+cellSet"
					pctDist    	0.865409
					height     	44
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4717D8CE0118"
				    client     	@859
				    supplier   	@844
				    vertices   	(list Points
					(1079, 1759)
					(1888, 1759))
				    line_style 	3
				    origin_attachment 	(1079, 1759)
				    terminal_attachment 	(1888, 1759)
				    label      	(object SegLabel @866
					Parent_View 	@864
					location   	(1827, 1727)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.924528
					height     	33
					orientation 	0))))
			(object InheritView "" @867
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A373D4D02FD"
			    client     	@844
			    supplier   	@815
			    vertices   	(list Points
				(2068, 1472)
				(2068, 875))
			    line_style 	3
			    origin_attachment 	(2068, 1472)
			    terminal_attachment 	(2068, 875)
			    drawSupplier 	@834)
			(object AssociationViewNew "$UNNAMED$43" @868
			    location   	(1392, 1941)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @869
				Parent_View 	@868
				location   	(1392, 1882)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				hidden     	TRUE
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	""
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4A37E21E022E"
			    roleview_list 	(list RoleViews
				(object RoleView "factsType" @870
				    Parent_View 	@868
				    location   	(498, 1140)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @871
					Parent_View 	@870
					location   	(1023, 1991)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	199
					justify    	0
					label      	"+factsType"
					pctDist    	0.743028
					height     	50
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A37E21E022F"
				    client     	@868
				    supplier   	@836
				    vertices   	(list Points
					(1392, 1941)
					(896, 1941))
				    line_style 	3
				    origin_attachment 	(1392, 1941)
				    terminal_attachment 	(896, 1941)
				    label      	(object SegLabel @872
					Parent_View 	@870
					location   	(931, 1888)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.929825
					height     	54
					orientation 	1))
				(object RoleView "cellSet" @873
				    Parent_View 	@868
				    location   	(498, 1140)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @874
					Parent_View 	@873
					location   	(1791, 1986)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	161
					justify    	0
					label      	"+cellSet"
					pctDist    	0.804435
					height     	45
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4A37E21E0230"
				    client     	@868
				    supplier   	@844
				    vertices   	(list Points
					(1392, 1941)
					(1888, 1941))
				    line_style 	3
				    origin_attachment 	(1392, 1941)
				    terminal_attachment 	(1888, 1941)
				    label      	(object SegLabel @875
					Parent_View 	@873
					location   	(1845, 1902)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.912409
					height     	40
					orientation 	0))))
			(object AttachView "" @876
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@814
			    supplier   	@868
			    vertices   	(list Points
				(1590, 2173)
				(1392, 1941))
			    line_style 	0)
			(object InheritView "" @877
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48EA0C5E004E"
			    client     	@826
			    supplier   	@812
			    vertices   	(list Points
				(631, 1175)
				(631, 372))
			    line_style 	3
			    origin_attachment 	(631, 1175)
			    terminal_attachment 	(631, 372))))
		(object ClassDiagram "Group By"
		    quid       	"4B8E775A02EE"
		    title      	"Group By"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	219
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @878
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    location   	(585, 1575)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@878
				location   	(453, 1500)
				fill_color 	13434879
				nlines     	1
				max_width  	264
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    width      	282
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @879
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(453, 1206)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@879
				location   	(161, 1077)
				fill_color 	13434879
				nlines     	1
				max_width  	584
				justify    	0
				label      	"NamedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45013C240030"
			    width      	602
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @880
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45472E5E0375"
			    client     	@878
			    supplier   	@879
			    vertices   	(list Points
				(588, 1488)
				(588, 1346))
			    line_style 	3
			    origin_attachment 	(588, 1488)
			    terminal_attachment 	(588, 1346))
			(object NoteView @881
			    location   	(1581, 2247)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@881
				location   	(1122, 2153)
				fill_color 	13434879
				nlines     	3
				max_width  	883
				label      	
|If GroupBy uses a "map" clause that produces a "tuple", the anonymous value type is the GroupBy's ownedTypeDefinition.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	943
			    height     	200)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @882
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1525, 1152)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@882
				location   	(1292, 1078)
				fill_color 	13434879
				nlines     	1
				max_width  	466
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	484
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::analytics::DimensionDefinition" @883
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2323, 1888)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@883
				location   	(2122, 1807)
				fill_color 	13434879
				nlines     	1
				max_width  	402
				justify    	0
				label      	"DimensionDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8E7B4F007D"
			    width      	420
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @884
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1549, 353)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@884
				location   	(1282, 124)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$2" @885
			    location   	(869, 752)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @886
				    Parent_View 	@885
				    location   	(-812, 449)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @887
					Parent_View 	@886
					location   	(1041, 1195)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	455
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.697248
					height     	58
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@885
				    supplier   	@882
				    vertices   	(list Points
					(869, 752)
					(869, 1137)
					(1283, 1137))
				    line_style 	3
				    origin_attachment 	(869, 752)
				    terminal_attachment 	(1283, 1137)
				    label      	(object SegLabel @888
					Parent_View 	@886
					location   	(1203, 1084)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "object" @889
				    Parent_View 	@885
				    location   	(-812, 449)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @890
					Parent_View 	@889
					location   	(1191, 310)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.898623
					height     	48
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@885
				    supplier   	@884
				    vertices   	(list Points
					(869, 752)
					(869, 357)
					(1273, 357))
				    line_style 	3
				    origin_attachment 	(869, 752)
				    terminal_attachment 	(1273, 357)
				    label      	(object SegLabel @891
					Parent_View 	@889
					location   	(1238, 420)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.957447
					height     	63
					orientation 	1))))
			(object InheritView "" @892
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@882
			    supplier   	@884
			    vertices   	(list Points
				(1525, 1066)
				(1525, 593))
			    line_style 	3
			    origin_attachment 	(1525, 1066)
			    terminal_attachment 	(1525, 593))
			(object AssociationViewNew "$UNNAMED$46" @893
			    location   	(2339, 818)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E7B8C01C5"
			    roleview_list 	(list RoleViews
				(object RoleView "expression" @894
				    Parent_View 	@893
				    location   	(421, -760)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @895
					Parent_View 	@894
					location   	(2020, 315)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	234
					justify    	0
					label      	"+expression"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7B8F02FD"
				    client     	@893
				    supplier   	@884
				    vertices   	(list Points
					(2339, 818)
					(2339, 356)
					(1825, 356))
				    line_style 	3
				    origin_attachment 	(2339, 818)
				    terminal_attachment 	(1825, 356)
				    label      	(object SegLabel @896
					Parent_View 	@894
					location   	(1924, 410)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "dimension" @897
				    Parent_View 	@893
				    location   	(421, -760)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @898
					Parent_View 	@897
					location   	(2471, 1754)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	220
					justify    	0
					label      	"+dimension"
					pctDist    	0.957619
					height     	132
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7B8F034B"
				    client     	@893
				    supplier   	@883
				    vertices   	(list Points
					(2339, 818)
					(2339, 1795))
				    line_style 	3
				    origin_attachment 	(2339, 818)
				    terminal_attachment 	(2339, 1795)
				    label      	(object SegLabel @899
					Parent_View 	@897
					location   	(2393, 1697)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @900
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(584, 1878)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@900
				location   	(484, 1803)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    width      	218
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @901
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47A719D70280"
			    client     	@900
			    supplier   	@878
			    vertices   	(list Points
				(578, 1791)
				(578, 1661))
			    line_style 	3
			    origin_attachment 	(578, 1791)
			    terminal_attachment 	(578, 1661))
			(object AssociationViewNew "$UNNAMED$48" @902
			    location   	(1447, 2469)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E7C2C0251"
			    roleview_list 	(list RoleViews
				(object RoleView "iterator" @903
				    Parent_View 	@902
				    location   	(357, 572)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @904
					Parent_View 	@903
					location   	(489, 2057)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	155
					justify    	0
					label      	"+iterator"
					pctDist    	0.933574
					height     	93
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7C2D004E"
				    client     	@902
				    supplier   	@900
				    vertices   	(list Points
					(1447, 2469)
					(581, 2469)
					(581, 1965))
				    line_style 	3
				    origin_attachment 	(1447, 2469)
				    terminal_attachment 	(581, 1965)
				    label      	(object SegLabel @905
					Parent_View 	@903
					location   	(537, 2011)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.967509
					height     	45
					orientation 	0))
				(object RoleView "dimension" @906
				    Parent_View 	@902
				    location   	(357, 572)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @907
					Parent_View 	@906
					location   	(2188, 2033)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	220
					justify    	0
					label      	"+dimension"
					pctDist    	0.962832
					height     	141
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7C2D005D"
				    client     	@902
				    supplier   	@883
				    vertices   	(list Points
					(1447, 2469)
					(2328, 2469)
					(2328, 1981))
				    line_style 	3
				    origin_attachment 	(1447, 2469)
				    terminal_attachment 	(2328, 1981)
				    label      	(object SegLabel @908
					Parent_View 	@906
					location   	(2387, 2042)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.955752
					height     	59
					orientation 	1))))
			(object ClassView "Class" "Logical View::dataaccess::analytics::GroupBy" @909
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1522, 1822)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@909
				location   	(1422, 1700)
				fill_color 	13434879
				nlines     	1
				max_width  	200
				justify    	0
				label      	"GroupBy")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8E7AA300CB"
			    width      	218
			    height     	269
			    annotation 	8)
			(object InheritView "" @910
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E7AA90138"
			    client     	@909
			    supplier   	@882
			    vertices   	(list Points
				(1516, 1688)
				(1516, 1237))
			    line_style 	3
			    origin_attachment 	(1516, 1688)
			    terminal_attachment 	(1516, 1237))
			(object AssociationViewNew "$UNNAMED$45" @911
			    location   	(1872, 1917)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E7B5F0251"
			    roleview_list 	(list RoleViews
				(object RoleView "dimensions" @912
				    Parent_View 	@911
				    location   	(768, 357)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @913
					Parent_View 	@912
					location   	(1983, 1878)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	236
					justify    	0
					label      	"+dimensions"
					pctDist    	0.461538
					height     	40
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7B60004E"
				    client     	@911
				    supplier   	@883
				    vertices   	(list Points
					(1872, 1917)
					(2113, 1917))
				    line_style 	3
				    origin_attachment 	(1872, 1917)
				    terminal_attachment 	(2113, 1917)
				    label      	(object SegLabel @914
					Parent_View 	@912
					location   	(2066, 1965)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..*"
					pctDist    	0.804781
					height     	48
					orientation 	1))
				(object RoleView "groupBy" @915
				    Parent_View 	@911
				    location   	(768, 357)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @916
					Parent_View 	@915
					location   	(1725, 1881)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	176
					justify    	0
					label      	"+groupBy"
					pctDist    	0.612000
					height     	37
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7B600050"
				    client     	@911
				    supplier   	@909
				    vertices   	(list Points
					(1872, 1917)
					(1631, 1917))
				    line_style 	3
				    origin_attachment 	(1872, 1917)
				    terminal_attachment 	(1631, 1917)
				    label      	(object SegLabel @917
					Parent_View 	@915
					location   	(1665, 1971)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.860000
					height     	54
					orientation 	0))))
			(object AttachView "" @918
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@881
			    supplier   	@909
			    vertices   	(list Points
				(1566, 2146)
				(1539, 1956))
			    line_style 	0)
			(object AssociationViewNew "$UNNAMED$49" @919
			    location   	(1806, 1249)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E80990000"
			    roleview_list 	(list RoleViews
				(object RoleView "mapExpression" @920
				    Parent_View 	@919
				    location   	(284, -573)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @921
					Parent_View 	@920
					location   	(1981, 714)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	307
					justify    	0
					label      	"+mapExpression"
					pctDist    	0.816794
					height     	175
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E809B01A5"
				    client     	@919
				    supplier   	@884
				    vertices   	(list Points
					(1806, 1249)
					(1806, 593))
				    line_style 	3
				    origin_attachment 	(1806, 1249)
				    terminal_attachment 	(1806, 593)
				    label      	(object SegLabel @922
					Parent_View 	@920
					location   	(1860, 661)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "mapExpressionOfGroupBy" @923
				    Parent_View 	@919
				    location   	(284, -573)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @924
					Parent_View 	@923
					location   	(1904, 1763)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	507
					justify    	0
					label      	"+mapExpressionOfGroupBy"
					pctDist    	1.070833
					height     	98
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E809B01E4"
				    client     	@919
				    supplier   	@909
				    vertices   	(list Points
					(1806, 1249)
					(1806, 1729)
					(1631, 1729))
				    line_style 	3
				    origin_attachment 	(1806, 1249)
				    terminal_attachment 	(1631, 1729)
				    label      	(object SegLabel @925
					Parent_View 	@923
					location   	(1679, 1690)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.928244
					height     	40
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$47" @926
			    location   	(1053, 1938)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E7BF9034B"
			    roleview_list 	(list RoleViews
				(object RoleView "fact" @927
				    Parent_View 	@926
				    location   	(-35, 108)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @928
					Parent_View 	@927
					location   	(817, 1983)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	99
					justify    	0
					label      	"+fact"
					pctDist    	0.655556
					height     	45
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7BFA01A5"
				    client     	@926
				    supplier   	@900
				    vertices   	(list Points
					(1053, 1938)
					(693, 1938))
				    line_style 	3
				    origin_attachment 	(1053, 1938)
				    terminal_attachment 	(693, 1938)
				    label      	(object SegLabel @929
					Parent_View 	@927
					location   	(730, 1992)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "factOfGroupBy" @930
				    Parent_View 	@926
				    location   	(-35, 108)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @931
					Parent_View 	@930
					location   	(1152, 1988)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	291
					justify    	0
					label      	"+factOfGroupBy"
					pctDist    	0.275000
					height     	50
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E7BFA01B5"
				    client     	@926
				    supplier   	@909
				    vertices   	(list Points
					(1053, 1938)
					(1413, 1938))
				    line_style 	3
				    origin_attachment 	(1053, 1938)
				    terminal_attachment 	(1413, 1938)
				    label      	(object SegLabel @932
					Parent_View 	@930
					location   	(1366, 1992)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.869444
					height     	54
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$50" @933
			    location   	(1053, 1816)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B8E8115033C"
			    roleview_list 	(list RoleViews
				(object RoleView "groupedFacts" @934
				    Parent_View 	@933
				    location   	(-469, -6)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @935
					Parent_View 	@934
					location   	(930, 1777)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	285
					justify    	0
					label      	"+groupedFacts"
					pctDist    	0.341667
					height     	39
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E81160138"
				    client     	@933
				    supplier   	@900
				    vertices   	(list Points
					(1053, 1816)
					(693, 1816))
				    line_style 	3
				    origin_attachment 	(1053, 1816)
				    terminal_attachment 	(693, 1816)
				    label      	(object SegLabel @936
					Parent_View 	@934
					location   	(744, 1774)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.861111
					height     	43
					orientation 	1))
				(object RoleView "groupedFactsOfGroupBy" @937
				    Parent_View 	@933
				    location   	(-469, -6)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @938
					Parent_View 	@937
					location   	(1154, 1846)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	476
					justify    	0
					label      	"+groupedFactsOfGroupBy"
					pctDist    	0.283333
					height     	30
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4B8E81160148"
				    client     	@933
				    supplier   	@909
				    vertices   	(list Points
					(1053, 1816)
					(1413, 1816))
				    line_style 	3
				    origin_attachment 	(1053, 1816)
				    terminal_attachment 	(1413, 1816)
				    label      	(object SegLabel @939
					Parent_View 	@937
					location   	(1367, 1782)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.872222
					height     	34
					orientation 	0)))))))))
    logical_presentations 	(list unit_reference_list))
