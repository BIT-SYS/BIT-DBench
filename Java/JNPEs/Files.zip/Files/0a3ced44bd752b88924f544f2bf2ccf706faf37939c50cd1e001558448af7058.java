Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: Plantuml Plug-in
Bundle-SymbolicName: net.sourceforge.plantuml.eclipse; singleton:=true
Bundle-Version: 1.1.20
Bundle-Activator: net.sourceforge.plantuml.eclipse.Activator
Bundle-Vendor: PlantUML Team
Require-Bundle: org.eclipse.ui.ide;bundle-version="3.10.2",
 org.eclipse.ui;bundle-version="3.106.1",
 org.eclipse.core.resources;bundle-version="3.9.1"
Bundle-ActivationPolicy: lazy
Bundle-ClassPath: .
Bundle-RequiredExecutionEnvironment: JavaSE-1.6
Import-Package: net.sourceforge.plantuml,
 net.sourceforge.plantuml.core,
 net.sourceforge.plantuml.eclipse.imagecontrol,
 net.sourceforge.plantuml.eclipse.imagecontrol.jface,
 net.sourceforge.plantuml.eclipse.imagecontrol.jface.actions,
 org.eclipse.core.runtime,
 org.eclipse.core.runtime.jobs,
 org.eclipse.jface.action,
 org.eclipse.jface.dialogs,
 org.eclipse.jface.preference,
 org.eclipse.jface.resource,
 org.eclipse.jface.util,
 org.eclipse.jface.viewers,
 org.eclipse.swt,
 org.eclipse.swt.dnd,
 org.eclipse.swt.events,
 org.eclipse.swt.graphics,
 org.eclipse.swt.layout,
 org.eclipse.swt.printing,
 org.eclipse.swt.program,
 org.eclipse.swt.widgets,
 org.eclipse.ui,
 org.eclipse.ui.part,
 org.eclipse.ui.plugin,
 org.osgi.framework;version="1.8.0"
Export-Package: net.sourceforge.plantuml.eclipse.utils,
 net.sourceforge.plantuml.eclipse.views
