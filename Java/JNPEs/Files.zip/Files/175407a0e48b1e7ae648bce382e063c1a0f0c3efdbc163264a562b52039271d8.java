
(object Petal
    version    	50
    _written   	"Rose 8.3.0407.2800"
    charSet    	0)

(object Class_Category "behavioral"
    is_unit    	TRUE
    is_loaded  	TRUE
    quid       	"446B1EEC006B"
    documentation 	"Processes, workflows and events. This is where BPEL and BPMN should be positioned and mapped to our infrastructures. But also the Process Agent Framework and BTM has to end up here."
    stereotype 	"metamodel"
    exportControl 	"Public"
    logical_models 	(list unit_reference_list
	(object Class_Category "bpdm"
	    quid       	"4472F8220220"
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Dummy"
		    quid       	"4581611800FD"))
	    logical_presentations 	(list unit_reference_list))
	(object Class_Category "businesstasks"
	    quid       	"44D74C9A02B1"
	    documentation 	"If it turns out to be beneficial, elements in this package cover the creation and management of BTM-related objects, such as creating a business task, assigning it to specific users or roles, etc."
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "TaskAgent"
		    quid       	"44ECBFAF0253"))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Task Agents"
		    quid       	"44ECBFB50108"
		    title      	"Task Agents"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::behavioral::businesstasks::TaskAgent" @1
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(869, 731)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@1
				location   	(753, 681)
				fill_color 	13434879
				nlines     	1
				max_width  	232
				justify    	0
				label      	"TaskAgent")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44ECBFAF0253"
			    width      	250
			    height     	124
			    annotation 	8
			    autoResize 	TRUE)))))
	(object Class_Category "actions"
	    quid       	"44D74DA301E0"
	    documentation 	
|Some action language that talks in the concepts of BOs, BONodes, invoking services, sending messages, explicitly declaring that an event occurred, triggering actions, evaluating rules, ...
|
|The language can be used, e.g., to specify the behavior of an action (part of a BO or BONode) or a service implementation.
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Assignment"
		    quid       	"45229F090021"
		    documentation 	"The argument tells the value to be assigned to the variable."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4925735300FA"
			    supplier   	"Logical View::behavioral::actions::StatementWithArgument"
			    quidu      	"492573460213"))
		    nestedClasses 	(list nestedClasses
			(object Class "AssignmentCompatibility"
			    quid       	"4522A8BA0390"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4522A8CA00CC"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Assignment
|inv:
|    self.argument.getType().conformsTo(self.assignTo.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "MustHaveArgument"
			    quid       	"496DD2570213"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"496DD25F00AB"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Assignment
|inv:
|  self.argument->notEmpty()
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Statement"
		    quid       	"4545FC1D0190"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B85518E036B"
			    supplier   	"Logical View::data::classes::InScope"
			    quidu      	"4B85514B0119"))
		    operations 	(list Operations
			(object Operation "getOutermostBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Statement::getOutermostBlock():Block
|body:
|  self.block.getOutermostBlock()
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"4925638400FA"
			    result     	"Block"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"454606CB020A")
			(object Operation "isSideEffectFree"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Statement::isSideEffectFree():Boolean
|body:
|  not self.oclIsKindOf(AddLink) and
|  not self.oclIsKindOf(RemoveLink) and
|  not self.oclIsKindOf(Assignment) and
|  (self.oclIsKindOf(IfElse) implies self.oclAsType(IfElse).condition.isSideEffectFree()) and
|  (self.oclIsKindOf(WhileLoop) implies self.oclAsType(WhileLoop).condition.isSideEffectFree()) and
|  (self.oclIsKindOf(ExpressionStatement) implies self.oclAsType(ExpressionStatement).expression.isSideEffectFree()) and
|  (self.oclIsKindOf(StatementWithArgument) implies (self.oclAsType(StatementWithArgument).argument->notEmpty() implies self.oclAsType(StatementWithArgument).argument.isSideEffectFree())) and
|  (self.oclIsKindOf(StatementWithNestedBlocks) implies self.oclAsType(StatementWithNestedBlocks).nestedBlocks->forAll(b|b.isSideEffectFree()))
				    )))
			    quid       	"492566D302AF"
			    documentation 	
|A statement is said to be side effect free if it does not modify any variable declared outside the scope of the block owning the statement and if it does not modify any object's state and if it does not modify any association's link set.
|
|TODO We need a more context-sensitive definition of sideEffectFree. While assigning to a local variable disallows statement reordering within the block, the block can still overall be side effect free such that its invocation may be reordered. There seem to be at least two notions of side effect freeness: one within the block in which it occurs (and variable assignment in this context counts as a side effect because it will disallow reordering), and another one regarding side effects observable outside the block; those are all modifications that can "escape" from the block, including changing the state of an object that is reachable outside the block (even if created in the block but then returned from the block), or changing the contents of a link container visible outside the block.
			    
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392")
			(object Operation "isSideEffectFreeForBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Statement::isSideEffectFreeForBlock(block:Block):Boolean
|body:
|  not self.oclIsKindOf(AddLink) and
|  not self.oclIsKindOf(RemoveLink) and
|  (self.oclIsKindOf(Assignment) implies self.oclAsType(Assignment).assignTo.owner <> block) and
|  (self.oclIsKindOf(IfElse) implies self.oclAsType(IfElse).condition.isSideEffectFree()) and
|  (self.oclIsKindOf(WhileLoop) implies self.oclAsType(WhileLoop).condition.isSideEffectFree()) and
|  (self.oclIsKindOf(ExpressionStatement) implies self.oclAsType(ExpressionStatement).expression.isSideEffectFree()) and
|  (self.oclIsKindOf(StatementWithArgument) implies (self.oclAsType(StatementWithArgument).argument->notEmpty() implies self.oclAsType(StatementWithArgument).argument.isSideEffectFree())) and
|  (self.oclIsKindOf(StatementWithNestedBlocks) implies self.oclAsType(StatementWithNestedBlocks).nestedBlocks->forAll(b|b.isSideEffectFree()))
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"4A27EFCF0128"
			    documentation 	"Assignment statements to block-local variables do not imply a side effect w.r.t the block"
			    parameters 	(list Parameters
				(object Parameter "block"
				    quid       	"4A27F00402BF"
				    type       	"Block"
				    quidu      	"454606CB020A"))
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392")
			(object Operation "getNamedValuesInScope"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "*"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.isUnique"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Statement::getNamedValuesInScope():Set(NamedValue)
|body:
|  -- collect all NamedValue declarations introduced by statements in this statement's owning block, prior to this statement.
|  let pos:Integer = self.block.statements->indexOf(self) in
|  if pos > 1 then
|    self.addNamedValuesWithNewNames(
|    if self.block.statements->at(-1+pos).oclIsKindOf(NamedValueDeclaration) then
|      self.block.statements->at(-1+pos).oclAsType(NamedValueDeclaration).namedValue->asSet()
|    else
|      Set{}
|    endif,
|    self.block.statements->at(-1+pos).getNamedValuesInScope())
|  else
|    -- first statement in block; consider block itself
|    self.block.getNamedValuesInScope()
|  endif
				    )))
			    quid       	"4B83FCC30196"
			    result     	"NamedValue"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4522A56F0149")
			(object Operation "getOwningClass"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "0..1"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Statement::getOwningClass():SapClass
|body:
|  self.block.getOwningClass()
				    )))
			    quid       	"4B84F0E00203"
			    result     	"SapClass"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4432171B031E"))
		    abstract   	TRUE)
		(object Class "Block"
		    quid       	"454606CB020A"
		    documentation 	
|A block contains statements and provides a scope, e.g., for block-local variables. Such a scope can be used for mapping to and from an operation's signature. A block accepts a number of values for a set of variables and as such is parameterizable. Additional variables can be introduced in the block that will not be provided to the block by its surrounding context. Those are considered the block's "local variables."
|
|A block can be executed like in SmallTalk, dynamically binding its arguments at runtime.
|
|With this, an operation is only a very thin wrapper around a Block.
|
|The parameters of a block are always defined by the signature that is implemented by the block.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4975FB74030D"
			    supplier   	"Logical View::data::classes::FunctionSignatureImplementation"
			    quidu      	"4974995A0069")
			(object Inheritance_Relationship
			    quid       	"4B85518D0167"
			    supplier   	"Logical View::data::classes::InScope"
			    quidu      	"4B85514B0119"))
		    operations 	(list Operations
			(object Operation "getOutermostBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Block::getOutermostBlock():Block
|body:
|  if self.owningStatement->notEmpty() then
|    self.owningStatement.block.getOutermostBlock()
|  else
|    self
|  endif
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"4925623D029F"
			    documentation 	"Walks up the owningStatement/nestedBlocks association to find owning statements and their owning blocks transitively until it arrives at a block that is not owned by a statement. That block is then returned. Usually, such a block would be the implementation of either a function or a method signature."
			    result     	"Block"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"454606CB020A")
			(object Operation "localIsSideEffectFree"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Block::localIsSideEffectFree():Boolean
|body:
|  self.statements->forAll(s|s.isSideEffectFreeForBlock(self))
				    )))
			    quid       	"4925687402EE"
			    result     	"Boolean"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"39A2BDA60392")
			(object Operation "getNamedValuesInScope"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "*"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.isUnique"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Block::getNamedValuesInScope():Set(data::classes::NamedValue)
|body:
|  self.addNamedValuesWithNewNames(
|  -- Handle Foreach
|  let s:Set(data::classes::NamedValue)=Set{} in
|  s->union(if owningStatement.oclIsKindOf(Foreach) and owningStatement->notEmpty() then
|    owningStatement.oclAsType(Foreach).forVariable.oclAsType(data::classes::NamedValue)->asSet()
|  else
|    Set{}
|  endif)->union(
|  -- add parameters for those blocks that are used as a signature implementation
|  functionSignature->collect(input->iterate(i; result:Set(data::classes::NamedValue)=Set{} | result->including(i)))
|  )->union(
|  implements_->collect(input->iterate(i; result:Set(data::classes::NamedValue)=Set{}| result->including(i)))
|  )->asSet(),
|  -- then ascend the block composition hierarchy and add all NamedValues defined in parent blocks before the occurrence of the statement with the nested block
|  if owningStatement->notEmpty() then
|    owningStatement.getNamedValuesInScope()
|  else
|    -- add formal object parameters from owning class
|    let oc:data::classes::SapClass = self.getOwningClass() in
|    if oc->notEmpty() then
|      oc.formalObjectParameters->iterate(i; result:Set(data::classes::NamedValue)=Set{} | result->including(i))
|    else
|      let es:Set(data::classes::NamedValue) = Set{} in es
|    endif
|  endif)
				    )))
			    quid       	"4B84041C003E"
			    documentation 	
|Determines all NamedValues that are in scope for all statements of this block. For example, in the block of a Foreach statement, the Foreach Iterator is in scope for all contained statements. If the block is nested in a statement (such as for an "if" statement), the NamedValues in scope for the containing statement are added as well. Additionally, if the block occurs as a signature implementation, the signature parameters are added. If this block occurs in an object-parameterized class, the formal object parameters are also added.
|
|
			    
			    result     	"NamedValue"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4522A56F0149")
			(object Operation "getOwningClass"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true"))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.return.multiplicity"
				    value      	(value Text "0..1"))
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context Block::getOwningClass():SapClass
|body:
|  let outermost:Block = self.getOutermostBlock() in
|  let implementedSignature:data::classes::Signature = outermost.getImplementedSignature() in
|  if implementedSignature->notEmpty() then
|    implementedSignature.getOwningClass()
|  else
|    null
|  endif
				    )))
			    quid       	"4B84099F038A"
			    result     	"SapClass"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"4432171B031E"))
		    nestedClasses 	(list nestedClasses
			(object Class "DoesNotOwnIterators"
			    quid       	"47B2D480003E"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47B2D8FD0196"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Block
|inv:
|  self.variables->select(i|i.oclIsKindOf(Iterator))->isEmpty()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "IsSideEffectFreeIfImplementsSideEffectFreeSignature"
			    quid       	"492568B60399"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"492568C900CB"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Block
|inv:
|  self.implements_->notEmpty() implies
|    (self.implements_.sideEffectFree implies self.isSideEffectFree())
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "DistinctNamedValueNames"
			    quid       	"49B7F26B02D8"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"49B7F2840362"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Block
|inv:
|  self.variables->forAll( i, j | i <> j implies i.name <> j.name )
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "IfElse"
		    quid       	"45471B57000A"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"45471B7D0181"
			    supplier   	"Logical View::behavioral::actions::ConditionalStatement"
			    quidu      	"4B8518F803B9")
			(object Inheritance_Relationship
			    quid       	"45471B4C0127"
			    supplier   	"Logical View::behavioral::actions::StatementWithNestedBlocks"
			    quidu      	"49255EB1034B"))
		    operations 	(list Operations
			(object Operation "getIfBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context IfElse::getIfBlock():Block
|body:
|  self.nestedBlocks->at(1)
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"4925619E029F"
			    result     	"Block"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"454606CB020A")
			(object Operation "getElseBlock"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context IfElse::getElseBlock():Block
|body:
|  if self.nestedBlocks->size() > 1 then
|    self.nestedBlocks->at(2)
|  else
|    null
|  endif
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"492561A2036B"
			    result     	"Block"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"454606CB020A")))
		(object Class "WhileLoop"
		    quid       	"45471B58016A"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"45471B7E0219"
			    supplier   	"Logical View::behavioral::actions::ConditionalStatement"
			    quidu      	"4B8518F803B9")
			(object Inheritance_Relationship
			    quid       	"492560F10242"
			    supplier   	"Logical View::behavioral::actions::SingleBlockStatement"
			    quidu      	"4925602703B9"))
		    operations 	(list Operations
			(object Operation "getLoopBody"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.OperationCodeOcl"
				    value      	(value Text 
|context WhileLoop::getLoopBody():Block
|body:
|  self.nestedBlocks->at(1)
				    ))
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.isQuery"
				    value      	(value Text "true")))
			    quid       	"492561970399"
			    result     	"Block"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0
			    quidu      	"454606CB020A")))
		(object Class "Foreach"
		    quid       	"456DFC3C0125"
		    documentation 	"We may not need a Foreach statement if we use internal iterators in collections together with blocks. However, how would a collection class implement the internal iterator without a for statement? Could this work with a WhileLoop only?"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4925608800FA"
			    supplier   	"Logical View::behavioral::actions::SingleBlockStatement"
			    quidu      	"4925602703B9"))
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "parallel"
			    quid       	"456DFC5001F9"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public"))
		    nestedClasses 	(list nestedClasses
			(object Class "VariableOwnedByRightBlock"
			    quid       	"471DF65302FD"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"471DF6680177"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Foreach
|inv:
|  self.forVariable.owner = self.nestedBlocks->at(1)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Return"
		    quid       	"4577E38403E0"
		    documentation 	"Returns a value from a block. Must be the last statement of a block."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4577E39701D4"
			    supplier   	"Logical View::behavioral::actions::StatementWithArgument"
			    quidu      	"492573460213"))
		    nestedClasses 	(list nestedClasses
			(object Class "ReturnMustBeLastInBlock"
			    quid       	"4578381000DA"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4578382700AB"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Return
|inv:
|  self = self.block.statements->last()
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "ReturnTypeMustMatch"
			    quid       	"492562ED005D"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"492562FC003E"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Return
|inv:
|  self.argument.getType().conformsTo(self.getOutermostBlock().getImplementedSignature().output)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "AddLink"
		    quid       	"457841700027"
		    documentation 	
|Adds a link to an association. As opposed to, e.g., MOF 1.4 semantics, if a link would violate an upper multiplicity of 1 by adding a second link to an object, the existing link will implicitly be replaced by this AddLink statement.
|
|When *at* is unspecified for an ordered association, the link will be added at the "end."
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"457841A002F7"
			    supplier   	"Logical View::behavioral::actions::LinkManipulationStatement"
			    quidu      	"457841890204")))
		(object Class "RemoveLink"
		    quid       	"4578417F0187"
		    documentation 	
|Removes the link if it exists, from the association specified.
|
|If no *at* position is specified for an association with one ordered end, one occurrence of the link specified by the two *objects* will be removed at random.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"457841A403C5"
			    supplier   	"Logical View::behavioral::actions::LinkManipulationStatement"
			    quidu      	"457841890204")))
		(object Class "LinkManipulationStatement"
		    quid       	"457841890204"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4578417601F2"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190"))
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "at"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"rose2mof.multiplicity"
				    value      	(value Text "0..1")))
			    quid       	"4A6D6C030271"
			    documentation 	"An optional position specification which will be ignored for associations with no ordered ends. If not set for an association with ordered ends, a reasonable default will be chosen."
			    type       	"Integer"
			    quidu      	"3B538AB300B3"
			    exportControl 	"Public"))
		    abstract   	TRUE
		    nestedClasses 	(list nestedClasses
			(object Class "ObjectsMustConformToEndTypes"
			    quid       	"457842F1032E"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4578430B0078"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context LinkManipulationStatement
|inv:
|  Sequence{1..self.objects->size()}->forAll(i:Integer |
|    objects->at(i).getType().conformsTo(association.ends->at(i).type))
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "BlockMustNotImplementSideEffectFreeSignature"
			    quid       	"489D61BF0222"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"489D61D50138"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context LinkManipulationStatement
|inv:
|  self.block.getImplementedSignature()->notEmpty() implies
|  not self.block.getImplementedSignature().sideEffectFree
					)
				    opExportControl 	"Public"
				    uid        	0)))
			(object Class "NoValueMustBeModified"
			    quid       	"4942611D02DE"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4942615600DA"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context LinkManipulationStatement
|inv:
|  self.association.ends->forAll(ae:data::classes::AssociationEnd |
|    ae.type.clazz.valueType implies not ae.contributesToEquality)
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ExpressionStatement"
		    quid       	"45AA9A16016E"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"45AA9A530242"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190")))
		(object Class "Sort"
		    quid       	"4715E4DA0271")
		(object Class "QueryInvocation"
		    quid       	"4715E505007D")
		(object Class "Constant"
		    quid       	"47A717EE033C"
		    documentation 	
|A constant always has an initial value defined and cannot be changed after that initial assignment anymore.
|
|If a constant has no initExpression assigned, it's type needs to support a lower multiplicity of 0, and the value of the constant will be an empty multi-object.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49889B790210"
			    supplier   	"Logical View::behavioral::actions::NamedValueWithOptionalInitExpression"
			    quidu      	"49889B6400B0"))
		    nestedClasses 	(list nestedClasses
			(object Class "InitExpressionTypeMustMatchVariableType"
			    quid       	"47A72AC802FD"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47A72AC802FE"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Constant
|inv:
|  self.initExpression->notEmpty() implies self.initExpression.getType().conformsTo(self.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Variable"
		    quid       	"47A717EF035B"
		    documentation 	
|As opposed to a Constant, a Variable can be used in an Assignment.
|
|If a variable has no initExpression assigned, it's type needs to support a lower multiplicity of 0, and the value of the variable will be an empty multi-object.
		    
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49889B7F0280"
			    supplier   	"Logical View::behavioral::actions::NamedValueWithOptionalInitExpression"
			    quidu      	"49889B6400B0"))
		    operations 	(list Operations
			(object Operation "getCommonTypeOfAssignments"
			    quid       	"49063AB3032C"
			    concurrency 	"Sequential"
			    opExportControl 	"Public"
			    uid        	0))
		    nestedClasses 	(list nestedClasses
			(object Class "InitExpressionTypeMustMatchVariableType"
			    quid       	"47A72AB70109"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"47A72AB7010A"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Variable
|inv:
|  self.initExpression->notEmpty() implies self.initExpression.getType().conformsTo(self.getType())
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "Iterator"
		    quid       	"47A719D200EA"
		    documentation 	"A named value that can neither be assigned nor needs an initialization expression. It obtains its value by an iterator statement implicitly."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"47A719D70280"
			    supplier   	"Logical View::data::classes::NamedValue"
			    quidu      	"4522A56F0149")))
		(object Class "NamedValueDeclaration"
		    quid       	"48873D45021C"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"48873D610119"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190")))
		(object Class "StatementWithNestedBlocks"
		    quid       	"49255EB1034B"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49255ECF007D"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190")))
		(object Class "SingleBlockStatement"
		    quid       	"4925602703B9"
		    documentation 	"Constrains the number of blocks that this statement can own to 1."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4925608200BB"
			    supplier   	"Logical View::behavioral::actions::StatementWithNestedBlocks"
			    quidu      	"49255EB1034B"))
		    nestedClasses 	(list nestedClasses
			(object Class "OwnsExactlyOneBlock"
			    quid       	"492560530128"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"492560600242"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context SingleBlockStatement
|inv:
|  self.nestedBlocks->size() = 1
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "StatementWithArgument"
		    quid       	"492573460213"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49257357038A"
			    supplier   	"Logical View::dataaccess::expressions::WithArgument"
			    quidu      	"4577E587019C")
			(object Inheritance_Relationship
			    quid       	"49256DF60271"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190"))
		    abstract   	TRUE)
		(object Class "NamedValueWithOptionalInitExpression"
		    quid       	"49889B6400B0"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"49889B750153"
			    supplier   	"Logical View::data::classes::NamedValue"
			    quidu      	"4522A56F0149"))
		    abstract   	TRUE
		    nestedClasses 	(list nestedClasses
			(object Class "AssignmentCompatibility"
			    quid       	"49889C4B0335"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"49889C4B0336"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context NamedValueWithOptionalInitExpression
|inv:
|    self.initExpression->forAll(ie | ie.getType().conformsTo(self.getType()))
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "ConditionalStatement"
		    quid       	"4B8518F803B9"
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"4B85190101D4"
			    supplier   	"Logical View::dataaccess::expressions::Conditional"
			    quidu      	"45471B4401F7")
			(object Inheritance_Relationship
			    quid       	"4B851CA901D4"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190"))
		    abstract   	TRUE)
		(object Association "$UNNAMED$0"
		    quid       	"4522A2B7015C"
		    roles      	(list role_list
			(object Role "assignTo"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"4522A2B703D3"
			    label      	"assignTo"
			    supplier   	"Logical View::behavioral::actions::Variable"
			    quidu      	"47A717EF035B"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "assignments"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"4522A2B703D5"
			    label      	"assignments"
			    supplier   	"Logical View::behavioral::actions::Assignment"
			    quidu      	"45229F090021"
			    client_cardinality 	(value cardinality "0..*")
			    is_navigable 	TRUE)))
		(object Association "$UNNAMED$1"
		    quid       	"454606F903AA"
		    documentation 	"Statements can only occur inside blocks."
		    roles      	(list role_list
			(object Role "statements"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"454606FA01F3"
			    label      	"statements"
			    supplier   	"Logical View::behavioral::actions::Statement"
			    quidu      	"4545FC1D0190"
			    client_cardinality 	(value cardinality "0..*")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "block"
			    quid       	"454606FA01FD"
			    label      	"block"
			    supplier   	"Logical View::behavioral::actions::Block"
			    quidu      	"454606CB020A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$2"
		    quid       	"45472E2E0218"
		    roles      	(list role_list
			(object Role "variables"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"45472E2F0043"
			    label      	"variables"
			    supplier   	"Logical View::data::classes::NamedValue"
			    quidu      	"4522A56F0149"
			    client_cardinality 	(value cardinality "0..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "owner"
			    quid       	"45472E2F004D"
			    label      	"owner"
			    supplier   	"Logical View::behavioral::actions::Block"
			    quidu      	"454606CB020A"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$3"
		    quid       	"456DFC800267"
		    roles      	(list role_list
			(object Role "collection"
			    quid       	"456DFC8100CE"
			    label      	"collection"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$4"
			    quid       	"456DFC8100E2"
			    supplier   	"Logical View::behavioral::actions::Foreach"
			    quidu      	"456DFC3C0125")))
		(object Association "$UNNAMED$5"
		    quid       	"457841C601B1"
		    roles      	(list role_list
			(object Role "association"
			    quid       	"457841C701BD"
			    label      	"association"
			    supplier   	"Logical View::data::classes::Association"
			    quidu      	"44321DA40150"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$6"
			    quid       	"457841C701C7"
			    supplier   	"Logical View::behavioral::actions::LinkManipulationStatement"
			    quidu      	"457841890204"
			    client_cardinality 	(value cardinality "0..*"))))
		(object Association "$UNNAMED$7"
		    quid       	"457842A10116"
		    roles      	(list role_list
			(object Role "objects"
			    quid       	"457842A20095"
			    label      	"objects"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "2")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "$UNNAMED$8"
			    quid       	"457842A200C7"
			    supplier   	"Logical View::behavioral::actions::LinkManipulationStatement"
			    quidu      	"457841890204"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$9"
		    quid       	"45AA9A1E0301"
		    roles      	(list role_list
			(object Role "expression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"45AA9A1F00DB"
			    label      	"expression"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "expressionStatement"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"45AA9A1F010E"
			    label      	"expressionStatement"
			    supplier   	"Logical View::behavioral::actions::ExpressionStatement"
			    quidu      	"45AA9A16016E"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$10"
		    quid       	"471DF5C902AF"
		    documentation 	"For Foreach statement binds a variable in its block to the values of the collection expression, one after the other. The variable is owned by the block."
		    roles      	(list role_list
			(object Role "forVariable"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"471DF5CA0119"
			    label      	"forVariable"
			    supplier   	"Logical View::behavioral::actions::Iterator"
			    quidu      	"47A719D200EA"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "boundToFor"
			    quid       	"471DF5CA011B"
			    label      	"boundToFor"
			    supplier   	"Logical View::behavioral::actions::Foreach"
			    quidu      	"456DFC3C0125"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$11"
		    quid       	"47A71B130280"
		    roles      	(list role_list
			(object Role "initExpression"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"47A71B140109"
			    label      	"initExpression"
			    supplier   	"Logical View::dataaccess::expressions::Expression"
			    quidu      	"450E63AB03A2"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "initExpressionFor"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"47A71B140128"
			    label      	"initExpressionFor"
			    supplier   	"Logical View::behavioral::actions::NamedValueWithOptionalInitExpression"
			    quidu      	"49889B6400B0"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$12"
		    quid       	"49255F0300DA"
		    roles      	(list role_list
			(object Role "owningStatement"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"49255F0300DB"
			    label      	"owningStatement"
			    supplier   	"Logical View::behavioral::actions::StatementWithNestedBlocks"
			    quidu      	"49255EB1034B"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)
			(object Role "nestedBlocks"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"49255F030128"
			    label      	"nestedBlocks"
			    supplier   	"Logical View::behavioral::actions::Block"
			    quidu      	"454606CB020A"
			    client_cardinality 	(value cardinality "1..2")
			    Constraints 	"ordered"
			    Containment 	"By Value"
			    is_navigable 	TRUE)))
		(object Association "$UNNAMED$13"
		    quid       	"49B64B6F0008"
		    roles      	(list role_list
			(object Role "namedValue"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"49B64B6F0279"
			    label      	"namedValue"
			    supplier   	"Logical View::behavioral::actions::NamedValueWithOptionalInitExpression"
			    quidu      	"49889B6400B0"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "namedValueDeclaration"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"49B64B6F027B"
			    label      	"namedValueDeclaration"
			    supplier   	"Logical View::behavioral::actions::NamedValueDeclaration"
			    quidu      	"48873D45021C"
			    client_cardinality 	(value cardinality "0..1")
			    is_navigable 	TRUE))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Assignment"
		    quid       	"45229EF70148"
		    title      	"Assignment"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @2
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(378, 747)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@2
				location   	(111, 643)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    width      	552
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @3
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1026, 807)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@3
				location   	(759, 578)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::WithArgument" @4
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(983, 1398)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@4
				location   	(836, 1323)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"WithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E587019C"
			    width      	312
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @5
			    location   	(984, 1179)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4577E58D0258"
			    roleview_list 	(list RoleViews
				(object RoleView "argument" @6
				    Parent_View 	@5
				    location   	(771, 935)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @7
					Parent_View 	@6
					location   	(859, 1091)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	196
					justify    	0
					label      	"+argument"
					pctDist    	0.666667
					height     	126
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D025A"
				    client     	@5
				    supplier   	@3
				    vertices   	(list Points
					(984, 1179)
					(984, 1047))
				    line_style 	3
				    origin_attachment 	(984, 1179)
				    terminal_attachment 	(984, 1047)
				    label      	(object SegLabel @8
					Parent_View 	@6
					location   	(1039, 1095)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.641667
					height     	55
					orientation 	1))
				(object RoleView "argumentOf" @9
				    Parent_View 	@5
				    location   	(771, 935)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @10
					Parent_View 	@9
					location   	(1141, 1269)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+argumentOf"
					pctDist    	0.689394
					height     	157
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D0259"
				    client     	@5
				    supplier   	@4
				    vertices   	(list Points
					(984, 1179)
					(984, 1311))
				    line_style 	3
				    origin_attachment 	(984, 1179)
				    terminal_attachment 	(984, 1311)
				    label      	(object SegLabel @11
					Parent_View 	@9
					location   	(911, 1269)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.689394
					height     	74
					orientation 	1))))
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @12
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(730, 266)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@12
				location   	(582, 137)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SapClass" @13
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1955, 1015)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@13
				location   	(1471, 411)
				fill_color 	13434879
				nlines     	1
				max_width  	968
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	986
			    height     	1232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @14
			    location   	(730, 497)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@12
			    vertices   	(list Points
				(730, 497)
				(730, 407)))
			(object InheritView "l" @15
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@15
				location   	(1018, 532)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@3
			    supplier   	@12
			    vertices   	(list Points
				(1018, 566)
				(1018, 497))
			    line_style 	3
			    origin_attachment 	(1018, 566)
			    terminal_attachment 	(1018, 497)
			    drawSupplier 	@14)
			(object InheritView "" @16
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B85102FB"
			    client     	@2
			    supplier   	@12
			    vertices   	(list Points
				(355, 631)
				(355, 497))
			    line_style 	3
			    origin_attachment 	(355, 631)
			    terminal_attachment 	(355, 497)
			    drawSupplier 	@14)
			(object ClassView "Class" "Logical View::behavioral::actions::Variable" @17
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(349, 2029)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@17
				location   	(257, 1977)
				fill_color 	13434879
				nlines     	1
				max_width  	184
				justify    	0
				label      	"Variable")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A717EF035B"
			    width      	202
			    height     	128
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Assignment" @18
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1021, 2034)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@18
				location   	(896, 1983)
				fill_color 	13434879
				nlines     	1
				max_width  	250
				justify    	0
				label      	"Assignment")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45229F090021"
			    width      	268
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$0" @19
			    location   	(668, 2010)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4522A2B7015C"
			    roleview_list 	(list RoleViews
				(object RoleView "assignTo" @20
				    Parent_View 	@19
				    location   	(409, 1695)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @21
					Parent_View 	@20
					location   	(565, 2049)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	188
					justify    	0
					label      	"+assignTo"
					pctDist    	0.472637
					height     	39
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4522A2B703D3"
				    client     	@19
				    supplier   	@17
				    vertices   	(list Points
					(668, 2010)
					(450, 2010))
				    line_style 	3
				    origin_attachment 	(668, 2010)
				    terminal_attachment 	(450, 2010)
				    label      	(object SegLabel @22
					Parent_View 	@20
					location   	(521, 1964)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.675325
					height     	47
					orientation 	1))
				(object RoleView "assignments" @23
				    Parent_View 	@19
				    location   	(409, 1695)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @24
					Parent_View 	@23
					location   	(738, 1973)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	256
					justify    	0
					label      	"+assignments"
					pctDist    	0.318408
					height     	38
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4522A2B703D5"
				    client     	@19
				    supplier   	@18
				    vertices   	(list Points
					(668, 2010)
					(887, 2010))
				    line_style 	3
				    origin_attachment 	(668, 2010)
				    terminal_attachment 	(887, 2010)
				    label      	(object SegLabel @25
					Parent_View 	@23
					location   	(842, 2043)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.796020
					height     	33
					orientation 	1))))
			(object NoteView @26
			    location   	(1956, 1909)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@26
				location   	(1540, 1809)
				fill_color 	13434879
				nlines     	4
				max_width  	796
				label      	"Do we really need assignments? Not supporting them would have the benefit of not having to do complicated inference for variables without declared type.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	856
			    height     	212)
			(object ClassView "Class" "Logical View::behavioral::actions::StatementWithArgument" @27
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1018, 1769)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@27
				location   	(778, 1718)
				fill_color 	13434879
				nlines     	1
				max_width  	480
				justify    	0
				label      	"StatementWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"492573460213"
			    width      	498
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @28
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925735300FA"
			    client     	@18
			    supplier   	@27
			    vertices   	(list Points
				(1006, 1971)
				(1006, 1832))
			    line_style 	3
			    origin_attachment 	(1006, 1971)
			    terminal_attachment 	(1006, 1832))
			(object InheritView "" @29
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49257357038A"
			    client     	@27
			    supplier   	@4
			    vertices   	(list Points
				(1003, 1705)
				(1003, 1485))
			    line_style 	3
			    origin_attachment 	(1003, 1705)
			    terminal_attachment 	(1003, 1485))))
		(object ClassDiagram "Blocks and Statements"
		    quid       	"4545FBF602C1"
		    title      	"Blocks and Statements"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object NoteView @30
			    location   	(2458, 537)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@30
				location   	(2167, 387)
				fill_color 	13434879
				nlines     	6
				max_width  	546
				label      	"An expression can be used as a statement, particularly in case the expression has side effects, such as invoking an operation with side effects.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	606
			    height     	313)
			(object ClassView "Class" "Logical View::behavioral::actions::Assignment" @31
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2604, 2312)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@31
				location   	(2479, 2261)
				fill_color 	13434879
				nlines     	1
				max_width  	250
				justify    	0
				label      	"Assignment")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45229F090021"
			    width      	268
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Foreach" @32
			    ShowCompartmentStereotypes 	TRUE
			    SuppressAttribute 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(245, 1718)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@32
				location   	(153, 1667)
				fill_color 	13434879
				nlines     	1
				max_width  	184
				justify    	0
				label      	"Foreach")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"456DFC3C0125"
			    width      	202
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Return" @33
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2217, 2310)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@33
				location   	(2136, 2258)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Return")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E38403E0"
			    height     	128
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::ObjectBasedExpression" @34
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1837, 1843)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@34
				location   	(1596, 1765)
				fill_color 	13434879
				nlines     	1
				max_width  	482
				justify    	0
				label      	"ObjectBasedExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"453E0FC80335"
			    width      	500
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Conditional" @35
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(926, 1541)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@35
				location   	(793, 1466)
				fill_color 	13434879
				nlines     	1
				max_width  	266
				justify    	0
				label      	"Conditional")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B4401F7"
			    width      	284
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::WithArgument" @36
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2385, 1763)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@36
				location   	(2238, 1688)
				fill_color 	13434879
				nlines     	1
				max_width  	294
				justify    	0
				label      	"WithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4577E587019C"
			    width      	312
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @37
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2039, 1297)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@37
				location   	(1772, 1068)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @38
			    location   	(2047, 1645)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453649650215"
			    roleview_list 	(list RoleViews
				(object RoleView "objectBasedExpression" @39
				    Parent_View 	@38
				    location   	(841, 936)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @40
					Parent_View 	@39
					location   	(1793, 1722)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+objectBasedExpression"
					pctDist    	0.728000
					height     	255
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701C8"
				    client     	@38
				    supplier   	@34
				    vertices   	(list Points
					(2047, 1645)
					(2047, 1752))
				    line_style 	3
				    origin_attachment 	(2047, 1645)
				    terminal_attachment 	(2047, 1752)
				    label      	(object SegLabel @41
					Parent_View 	@39
					location   	(2123, 1718)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.688000
					height     	76
					orientation 	0))
				(object RoleView "object" @42
				    Parent_View 	@38
				    location   	(841, 936)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @43
					Parent_View 	@42
					location   	(2142, 1585)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	139
					justify    	0
					label      	"+object"
					pctDist    	0.563830
					height     	95
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4536496701B4"
				    client     	@38
				    supplier   	@37
				    vertices   	(list Points
					(2047, 1645)
					(2047, 1538))
				    line_style 	3
				    origin_attachment 	(2047, 1645)
				    terminal_attachment 	(2047, 1538)
				    label      	(object SegLabel @44
					Parent_View 	@42
					location   	(2006, 1580)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	300
					justify    	0
					label      	"1"
					pctDist    	0.606383
					height     	42
					orientation 	0))))
			(object AssociationViewNew "" @45
			    location   	(1298, 1352)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B920394"
			    roleview_list 	(list RoleViews
				(object RoleView "condition" @46
				    Parent_View 	@45
				    location   	(1019, 308)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @47
					Parent_View 	@46
					location   	(1555, 1380)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	204
					justify    	0
					label      	"+condition"
					pctDist    	0.552326
					height     	28
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B930205"
				    client     	@45
				    supplier   	@37
				    vertices   	(list Points
					(1298, 1352)
					(1763, 1352))
				    line_style 	3
				    origin_attachment 	(1298, 1352)
				    terminal_attachment 	(1763, 1352)
				    label      	(object SegLabel @48
					Parent_View 	@46
					location   	(1720, 1384)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.906977
					height     	32
					orientation 	1))
				(object RoleView "conditional" @49
				    Parent_View 	@45
				    location   	(1019, 308)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @50
					Parent_View 	@49
					location   	(893, 1361)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	224
					justify    	0
					label      	"+conditional"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45471B93020F"
				    client     	@45
				    supplier   	@35
				    vertices   	(list Points
					(1298, 1352)
					(934, 1352)
					(934, 1454))
				    line_style 	3
				    origin_attachment 	(1298, 1352)
				    terminal_attachment 	(934, 1454)
				    label      	(object SegLabel @51
					Parent_View 	@49
					location   	(997, 1410)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.905797
					height     	63
					orientation 	0))))
			(object AssociationViewNew "" @52
			    location   	(2313, 1606)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4577E58D0258"
			    roleview_list 	(list RoleViews
				(object RoleView "argument" @53
				    Parent_View 	@52
				    location   	(492, 556)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @54
					Parent_View 	@53
					location   	(2374, 3795)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	196
					justify    	0
					label      	"+argument"
					pctDist    	-32.200001
					height     	61
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D025A"
				    client     	@52
				    supplier   	@37
				    vertices   	(list Points
					(2313, 1606)
					(2313, 1538))
				    line_style 	3
				    origin_attachment 	(2313, 1606)
				    terminal_attachment 	(2313, 1538)
				    label      	(object SegLabel @55
					Parent_View 	@53
					location   	(2310, 3782)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	-32.000000
					height     	4
					orientation 	0))
				(object RoleView "argumentOf" @56
				    Parent_View 	@52
				    location   	(492, 556)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @57
					Parent_View 	@56
					location   	(2473, 1650)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"+argumentOf"
					pctDist    	0.643678
					height     	160
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4577E58D0259"
				    client     	@52
				    supplier   	@36
				    vertices   	(list Points
					(2313, 1606)
					(2313, 1675))
				    line_style 	3
				    origin_attachment 	(2313, 1606)
				    terminal_attachment 	(2313, 1675)
				    label      	(object SegLabel @58
					Parent_View 	@56
					location   	(2259, 1646)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.597701
					height     	55
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::ExpressionStatement" @59
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1004, 1250)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@59
				location   	(793, 1199)
				fill_color 	13434879
				nlines     	1
				max_width  	422
				justify    	0
				label      	"ExpressionStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45AA9A16016E"
			    width      	440
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$9" @60
			    location   	(1493, 1234)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45AA9A1E0301"
			    roleview_list 	(list RoleViews
				(object RoleView "expression" @61
				    Parent_View 	@60
				    location   	(-148, 665)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @62
					Parent_View 	@61
					location   	(1604, 1208)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	234
					justify    	0
					label      	"+expression"
					pctDist    	0.413793
					height     	27
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45AA9A1F00DB"
				    client     	@60
				    supplier   	@37
				    vertices   	(list Points
					(1493, 1234)
					(1763, 1234))
				    line_style 	3
				    origin_attachment 	(1493, 1234)
				    terminal_attachment 	(1763, 1234)
				    label      	(object SegLabel @63
					Parent_View 	@61
					location   	(1742, 1273)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.924528
					height     	39
					orientation 	1))
				(object RoleView "expressionStatement" @64
				    Parent_View 	@60
				    location   	(-148, 665)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @65
					Parent_View 	@64
					location   	(1465, 1276)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	412
					justify    	0
					label      	"+expressionStatement"
					pctDist    	0.103896
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45AA9A1F010E"
				    client     	@60
				    supplier   	@59
				    vertices   	(list Points
					(1493, 1234)
					(1224, 1234))
				    line_style 	3
				    origin_attachment 	(1493, 1234)
				    terminal_attachment 	(1224, 1234)
				    label      	(object SegLabel @66
					Parent_View 	@64
					location   	(1285, 1202)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.776515
					height     	33
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::IfElse" @67
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(739, 2276)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@67
				location   	(580, 2170)
				fill_color 	13434879
				nlines     	1
				max_width  	318
				justify    	0
				label      	"IfElse")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B57000A"
			    width      	336
			    height     	236
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::WhileLoop" @68
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(214, 2300)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@68
				location   	(56, 2219)
				fill_color 	13434879
				nlines     	1
				max_width  	316
				justify    	0
				label      	"WhileLoop")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45471B58016A"
			    width      	334
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SignatureImplementation" @69
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(397, 245)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@69
				location   	(129, 141)
				fill_color 	13434879
				nlines     	1
				max_width  	536
				justify    	0
				label      	"SignatureImplementation")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47836ECF037A"
			    width      	554
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::MethodCallExpression" @70
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1804, 2245)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@70
				location   	(1559, 2141)
				fill_color 	13434879
				nlines     	1
				max_width  	490
				justify    	0
				label      	"MethodCallExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522E05D00A8"
			    width      	508
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @71
			    location   	(1469, 256)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@71
				location   	(1053, 87)
				fill_color 	13434879
				nlines     	6
				max_width  	797
				label      	"TODO Recursively ensure that no statement violates a sideEffectFree setting of a Block's signature, in particular the subordinate Blocks of Conditional and Foreach, as well as all expressions used anywhere in a statement.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	857
			    height     	351)
			(object ClassView "Class" "Logical View::behavioral::actions::Statement" @72
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1726, 691)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@72
				location   	(1457, 510)
				fill_color 	13434879
				nlines     	1
				max_width  	538
				justify    	0
				label      	"Statement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4545FC1D0190"
			    width      	556
			    height     	386
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::StatementWithNestedBlocks" @73
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(418, 1103)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@73
				location   	(137, 1052)
				fill_color 	13434879
				nlines     	1
				max_width  	562
				justify    	0
				label      	"StatementWithNestedBlocks")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49255EB1034B"
			    width      	580
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @74
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(564, 703)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@74
				location   	(297, 547)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    compartment 	(object Compartment
				Parent_View 	@74
				location   	(297, 608)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	5
				max_width  	0)
			    width      	552
			    height     	336
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$1" @75
			    location   	(1144, 628)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"454606F903AA"
			    roleview_list 	(list RoleViews
				(object RoleView "block" @76
				    Parent_View 	@75
				    location   	(169, 218)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @77
					Parent_View 	@76
					location   	(937, 587)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	132
					justify    	0
					label      	"+block"
					pctDist    	0.680751
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454606FA01FD"
				    client     	@75
				    supplier   	@74
				    vertices   	(list Points
					(1144, 628)
					(840, 628))
				    line_style 	3
				    origin_attachment 	(1144, 628)
				    terminal_attachment 	(840, 628)
				    label      	(object SegLabel @78
					Parent_View 	@76
					location   	(882, 679)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.865169
					height     	51
					orientation 	0))
				(object RoleView "statements" @79
				    Parent_View 	@75
				    location   	(169, 218)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @80
					Parent_View 	@79
					location   	(1258, 589)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	236
					justify    	0
					label      	"+statements"
					pctDist    	0.375587
					height     	40
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454606FA01F3"
				    client     	@75
				    supplier   	@72
				    vertices   	(list Points
					(1144, 628)
					(1448, 628))
				    line_style 	3
				    origin_attachment 	(1144, 628)
				    terminal_attachment 	(1448, 628)
				    label      	(object SegLabel @81
					Parent_View 	@79
					location   	(1368, 666)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.741573
					height     	38
					orientation 	1)
				    label      	(object SegLabel @82
					Parent_View 	@79
					location   	(1288, 708)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	160
					justify    	0
					label      	"{ordered}"
					pctDist    	0.477528
					height     	80
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$12" @83
			    location   	(525, 954)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49255F0300DA"
			    roleview_list 	(list RoleViews
				(object RoleView "owningStatement" @84
				    Parent_View 	@83
				    location   	(104, -706)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @85
					Parent_View 	@84
					location   	(332, 1012)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	340
					justify    	0
					label      	"+owningStatement"
					pctDist    	0.688172
					height     	194
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49255F0300DB"
				    client     	@83
				    supplier   	@73
				    vertices   	(list Points
					(525, 954)
					(525, 1039))
				    line_style 	3
				    origin_attachment 	(525, 954)
				    terminal_attachment 	(525, 1039)
				    label      	(object SegLabel @86
					Parent_View 	@84
					location   	(595, 1009)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.645161
					height     	70
					orientation 	0))
				(object RoleView "nestedBlocks" @87
				    Parent_View 	@83
				    location   	(104, -706)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @88
					Parent_View 	@87
					location   	(362, 902)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	283
					justify    	0
					label      	"+nestedBlocks"
					pctDist    	0.630435
					height     	164
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49255F030128"
				    client     	@83
				    supplier   	@74
				    vertices   	(list Points
					(525, 954)
					(525, 870))
				    line_style 	3
				    origin_attachment 	(525, 954)
				    terminal_attachment 	(525, 870)
				    label      	(object SegLabel @89
					Parent_View 	@87
					location   	(589, 905)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..2"
					pctDist    	0.597826
					height     	64
					orientation 	1)
				    label      	(object SegLabel @90
					Parent_View 	@87
					location   	(736, 899)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.655914
					height     	211
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::SingleBlockStatement" @91
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(236, 1452)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@91
				location   	(18, 1401)
				fill_color 	13434879
				nlines     	1
				max_width  	436
				justify    	0
				label      	"SingleBlockStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4925602703B9"
			    width      	454
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @92
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925608800FA"
			    client     	@32
			    supplier   	@91
			    vertices   	(list Points
				(219, 1654)
				(219, 1515))
			    line_style 	3
			    origin_attachment 	(219, 1654)
			    terminal_attachment 	(219, 1515))
			(object ClassView "Class" "Logical View::behavioral::actions::StatementWithArgument" @93
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2441, 2004)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@93
				location   	(2202, 1953)
				fill_color 	13434879
				nlines     	1
				max_width  	478
				justify    	0
				label      	"StatementWithArgument")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"492573460213"
			    width      	496
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @94
			    location   	(2441, 2187)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@93
			    vertices   	(list Points
				(2441, 2187)
				(2441, 2067)))
			(object InheritView "" @95
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4577E39701D4"
			    client     	@33
			    supplier   	@93
			    vertices   	(list Points
				(2218, 2246)
				(2218, 2187))
			    line_style 	3
			    origin_attachment 	(2218, 2246)
			    terminal_attachment 	(2218, 2187)
			    drawSupplier 	@94)
			(object InheritView "" @96
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925735300FA"
			    client     	@31
			    supplier   	@93
			    vertices   	(list Points
				(2609, 2249)
				(2609, 2187))
			    line_style 	3
			    origin_attachment 	(2609, 2249)
			    terminal_attachment 	(2609, 2187)
			    drawSupplier 	@94)
			(object InheritView "" @97
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49257357038A"
			    client     	@93
			    supplier   	@36
			    vertices   	(list Points
				(2385, 1941)
				(2385, 1850))
			    line_style 	3
			    origin_attachment 	(2385, 1941)
			    terminal_attachment 	(2385, 1850))
			(object InheritView "" @98
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"492560F10242"
			    client     	@68
			    supplier   	@91
			    vertices   	(list Points
				(84, 2206)
				(84, 1515))
			    line_style 	3
			    origin_attachment 	(84, 2206)
			    terminal_attachment 	(84, 1515))
			(object InheritView "" @99
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47BC30F40203"
			    client     	@70
			    supplier   	@34
			    vertices   	(list Points
				(1825, 2128)
				(1825, 1933))
			    line_style 	3
			    origin_attachment 	(1825, 2128)
			    terminal_attachment 	(1825, 1933))
			(object InheritTreeView "" @100
			    location   	(418, 1350)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@73
			    vertices   	(list Points
				(418, 1350)
				(418, 1166)))
			(object InheritView "" @101
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925608200BB"
			    client     	@91
			    supplier   	@73
			    vertices   	(list Points
				(181, 1388)
				(181, 1350))
			    line_style 	3
			    origin_attachment 	(181, 1388)
			    terminal_attachment 	(181, 1350)
			    drawSupplier 	@100)
			(object InheritView "" @102
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B4C0127"
			    client     	@67
			    supplier   	@73
			    vertices   	(list Points
				(591, 2157)
				(591, 1350))
			    line_style 	3
			    origin_attachment 	(591, 2157)
			    terminal_attachment 	(591, 1350)
			    drawSupplier 	@100)
			(object ClassView "Class" "Logical View::behavioral::actions::ConditionalStatement" @103
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(933, 1821)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@103
				location   	(722, 1770)
				fill_color 	13434879
				nlines     	1
				max_width  	422
				justify    	0
				label      	"ConditionalStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4B8518F803B9"
			    width      	440
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @104
			    location   	(933, 2072)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@103
			    vertices   	(list Points
				(933, 2072)
				(933, 1884)))
			(object InheritView "" @105
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B7E0219"
			    client     	@68
			    supplier   	@103
			    vertices   	(list Points
				(256, 2206)
				(256, 2072))
			    line_style 	3
			    origin_attachment 	(256, 2206)
			    terminal_attachment 	(256, 2072)
			    drawSupplier 	@104)
			(object InheritView "" @106
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45471B7D0181"
			    client     	@67
			    supplier   	@103
			    vertices   	(list Points
				(722, 2158)
				(722, 2072))
			    line_style 	3
			    origin_attachment 	(722, 2158)
			    terminal_attachment 	(722, 2072)
			    drawSupplier 	@104)
			(object InheritView "" @107
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B85190101D4"
			    client     	@103
			    supplier   	@35
			    vertices   	(list Points
				(969, 1758)
				(969, 1628))
			    line_style 	3
			    origin_attachment 	(969, 1758)
			    terminal_attachment 	(969, 1628))
			(object InheritTreeView "" @108
			    location   	(1726, 999)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@72
			    vertices   	(list Points
				(1726, 999)
				(1726, 884)))
			(object AttachView "" @109
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@30
			    supplier   	@108
			    vertices   	(list Points
				(2360, 693)
				(2263, 853)
				(1726, 931))
			    line_style 	0)
			(object InheritView "" @110
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45AA9A530242"
			    client     	@59
			    supplier   	@72
			    vertices   	(list Points
				(934, 1187)
				(934, 999))
			    line_style 	3
			    origin_attachment 	(934, 1187)
			    terminal_attachment 	(934, 999)
			    drawSupplier 	@108)
			(object InheritView "" @111
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49255ECF007D"
			    client     	@73
			    supplier   	@72
			    vertices   	(list Points
				(688, 1040)
				(688, 999))
			    line_style 	3
			    origin_attachment 	(688, 1040)
			    terminal_attachment 	(688, 999)
			    drawSupplier 	@108)
			(object InheritView "" @112
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49256DF60271"
			    client     	@93
			    supplier   	@72
			    vertices   	(list Points
				(2628, 1941)
				(2628, 999))
			    line_style 	3
			    origin_attachment 	(2628, 1941)
			    terminal_attachment 	(2628, 999)
			    drawSupplier 	@108)
			(object InheritView "" @113
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4B851CA901D4"
			    client     	@103
			    supplier   	@72
			    vertices   	(list Points
				(759, 1758)
				(759, 999))
			    line_style 	3
			    origin_attachment 	(759, 1758)
			    terminal_attachment 	(759, 999)
			    drawSupplier 	@108)
			(object InheritView "" @114
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"453E0FF30001"
			    client     	@34
			    supplier   	@37
			    vertices   	(list Points
				(1813, 1753)
				(1813, 1538))
			    line_style 	3
			    origin_attachment 	(1813, 1753)
			    terminal_attachment 	(1813, 1538))))
		(object ClassDiagram "Blocks and Variables"
		    quid       	"45472E140198"
		    title      	"Blocks and Variables"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object NoteView @115
			    location   	(562, 1768)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@115
				location   	(155, 1662)
				fill_color 	13434879
				nlines     	4
				max_width  	778
				label      	
|TODO: Identify the argument variables.
|Model argument passing to blocks.
|Describe/specify context forwarding between blocks.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	838
			    height     	225)
			(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @116
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1764, 725)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@116
				location   	(1472, 596)
				fill_color 	13434879
				nlines     	1
				max_width  	584
				justify    	0
				label      	"NamedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45013C240030"
			    compartment 	(object Compartment
				Parent_View 	@116
				location   	(1472, 701)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	581)
			    width      	602
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @117
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(647, 1330)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@117
				location   	(380, 1101)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    compartment 	(object Compartment
				Parent_View 	@117
				location   	(380, 1206)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	7
				max_width  	531)
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @118
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1587, 1690)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@118
				location   	(1320, 1534)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    compartment 	(object Compartment
				Parent_View 	@118
				location   	(1320, 1595)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	5
				max_width  	531)
			    width      	552
			    height     	336
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @119
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1565, 1173)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@119
				location   	(1298, 1069)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    compartment 	(object Compartment
				Parent_View 	@119
				location   	(1298, 1174)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	2
				max_width  	531)
			    width      	552
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$2" @120
			    location   	(1602, 1404)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45472E2E0218"
			    roleview_list 	(list RoleViews
				(object RoleView "owner" @121
				    Parent_View 	@120
				    location   	(74, 604)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @122
					Parent_View 	@121
					location   	(1511, 1490)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	140
					justify    	0
					label      	"+owner"
					pctDist    	0.736842
					height     	92
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45472E2F004D"
				    client     	@120
				    supplier   	@118
				    vertices   	(list Points
					(1602, 1404)
					(1602, 1521))
				    line_style 	3
				    origin_attachment 	(1602, 1404)
				    terminal_attachment 	(1602, 1521)
				    label      	(object SegLabel @123
					Parent_View 	@121
					location   	(1672, 1491)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.739496
					height     	70
					orientation 	0))
				(object RoleView "variables" @124
				    Parent_View 	@120
				    location   	(74, 604)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @125
					Parent_View 	@124
					location   	(1721, 1333)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	181
					justify    	0
					label      	"+variables"
					pctDist    	0.621849
					height     	119
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"45472E2F0043"
				    client     	@120
				    supplier   	@119
				    vertices   	(list Points
					(1602, 1404)
					(1602, 1288))
				    line_style 	3
				    origin_attachment 	(1602, 1404)
				    terminal_attachment 	(1602, 1288)
				    label      	(object SegLabel @126
					Parent_View 	@124
					location   	(1550, 1324)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.693878
					height     	53
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::Multiplicity" @127
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1764, 300)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@127
				location   	(1511, 96)
				fill_color 	13434879
				nlines     	1
				max_width  	506
				justify    	0
				label      	"Multiplicity")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47554DA003A9"
			    compartment 	(object Compartment
				Parent_View 	@127
				location   	(1511, 201)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	6
				max_width  	503)
			    width      	524
			    height     	432
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @128
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1003, 763)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@128
				location   	(855, 634)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    compartment 	(object Compartment
				Parent_View 	@128
				location   	(855, 739)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	284)
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::SapClass" @129
			    ShowCompartmentStereotypes 	TRUE
			    SuppressAttribute 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(164, 318)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@129
				location   	(53, 268)
				fill_color 	13434879
				nlines     	1
				max_width  	222
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	240
			    height     	124
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::ClassTypeDefinition" @130
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1002, 312)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@130
				location   	(707, 183)
				fill_color 	13434879
				nlines     	1
				max_width  	590
				justify    	0
				label      	"ClassTypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4784F7E800AB"
			    compartment 	(object Compartment
				Parent_View 	@130
				location   	(707, 288)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	587)
			    width      	608
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @131
			    location   	(491, 313)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4784F7F5005D"
			    roleview_list 	(list RoleViews
				(object RoleView "clazz" @132
				    Parent_View 	@131
				    location   	(-494, 47)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @133
					Parent_View 	@132
					location   	(359, 284)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	136
					justify    	0
					label      	"+clazz"
					pctDist    	0.635628
					height     	30
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005F"
				    client     	@131
				    supplier   	@129
				    vertices   	(list Points
					(491, 313)
					(284, 313))
				    line_style 	3
				    origin_attachment 	(491, 313)
				    terminal_attachment 	(284, 313)
				    label      	(object SegLabel @134
					Parent_View 	@132
					location   	(313, 349)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.866397
					height     	36
					orientation 	0))
				(object RoleView "elementsOfType" @135
				    Parent_View 	@131
				    location   	(-494, 47)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @136
					Parent_View 	@135
					location   	(534, 354)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	320
					justify    	0
					label      	"+elementsOfType"
					pctDist    	0.207729
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F7F5005E"
				    client     	@131
				    supplier   	@130
				    vertices   	(list Points
					(491, 313)
					(698, 313))
				    line_style 	3
				    origin_attachment 	(491, 313)
				    terminal_attachment 	(698, 313)
				    label      	(object SegLabel @137
					Parent_View 	@135
					location   	(658, 275)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.811024
					height     	39
					orientation 	0))))
			(object InheritView "" @138
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45472E5E0375"
			    client     	@119
			    supplier   	@116
			    vertices   	(list Points
				(1681, 1057)
				(1681, 866))
			    line_style 	3
			    origin_attachment 	(1681, 1057)
			    terminal_attachment 	(1681, 866))
			(object InheritTreeView "" @139
			    location   	(1003, 1019)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@128
			    vertices   	(list Points
				(1003, 1019)
				(1003, 904)))
			(object InheritView "l" @140
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@140
				location   	(700, 1054)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@117
			    supplier   	@128
			    vertices   	(list Points
				(700, 1089)
				(700, 1019))
			    line_style 	3
			    origin_attachment 	(700, 1089)
			    terminal_attachment 	(700, 1019)
			    drawSupplier 	@139)
			(object InheritView "" @141
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B85102FB"
			    client     	@119
			    supplier   	@128
			    vertices   	(list Points
				(1512, 1057)
				(1512, 1019))
			    line_style 	3
			    origin_attachment 	(1512, 1057)
			    terminal_attachment 	(1512, 1019)
			    drawSupplier 	@139)))
		(object ClassDiagram "Foreach"
		    quid       	"456DFB5B02B6"
		    title      	"Foreach"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @142
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2484, 1071)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@142
				location   	(2336, 942)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    compartment 	(object Compartment
				Parent_View 	@142
				location   	(2336, 1047)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	284)
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @143
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2487, 1569)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@143
				location   	(2220, 1340)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    compartment 	(object Compartment
				Parent_View 	@143
				location   	(2220, 1445)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	7
				max_width  	531)
			    width      	552
			    height     	482
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @144
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1656, 1965)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@144
				location   	(1575, 1914)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Foreach" @145
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1656, 1557)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@145
				location   	(1473, 1476)
				fill_color 	13434879
				nlines     	1
				max_width  	366
				justify    	0
				label      	"Foreach")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"456DFC3C0125"
			    compartment 	(object Compartment
				Parent_View 	@145
				location   	(1473, 1537)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	2
				max_width  	363)
			    width      	384
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$3" @146
			    location   	(2029, 1569)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"456DFC800267"
			    roleview_list 	(list RoleViews
				(object RoleView "collection" @147
				    Parent_View 	@146
				    location   	(1273, 323)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @148
					Parent_View 	@147
					location   	(2080, 1610)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	195
					justify    	0
					label      	"+collection"
					pctDist    	0.282759
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"456DFC8100CE"
				    client     	@146
				    supplier   	@143
				    vertices   	(list Points
					(2029, 1569)
					(2211, 1569))
				    line_style 	3
				    origin_attachment 	(2029, 1569)
				    terminal_attachment 	(2211, 1569)
				    label      	(object SegLabel @149
					Parent_View 	@147
					location   	(2193, 1516)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "$UNNAMED$4" @150
				    Parent_View 	@146
				    location   	(1273, 323)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"456DFC8100E2"
				    client     	@146
				    supplier   	@145
				    vertices   	(list Points
					(2029, 1569)
					(1848, 1569))
				    line_style 	3
				    origin_attachment 	(2029, 1569)
				    terminal_attachment 	(1848, 1569))))
			(object AssociationViewNew "$UNNAMED$10" @151
			    location   	(1665, 1776)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"471DF5C902AF"
			    roleview_list 	(list RoleViews
				(object RoleView "forVariable" @152
				    Parent_View 	@151
				    location   	(1098, 1213)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @153
					Parent_View 	@152
					location   	(1533, 1872)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	230
					justify    	0
					label      	"+forVariable"
					pctDist    	0.761905
					height     	133
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"471DF5CA0119"
				    client     	@151
				    supplier   	@144
				    vertices   	(list Points
					(1665, 1776)
					(1665, 1902))
				    line_style 	3
				    origin_attachment 	(1665, 1776)
				    terminal_attachment 	(1665, 1902)
				    label      	(object SegLabel @154
					Parent_View 	@152
					location   	(1707, 1870)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.746032
					height     	42
					orientation 	0))
				(object RoleView "boundToFor" @155
				    Parent_View 	@151
				    location   	(1098, 1213)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @156
					Parent_View 	@155
					location   	(1803, 1680)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	239
					justify    	0
					label      	"+boundToFor"
					pctDist    	0.769841
					height     	138
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"471DF5CA011B"
				    client     	@151
				    supplier   	@145
				    vertices   	(list Points
					(1665, 1776)
					(1665, 1650))
				    line_style 	3
				    origin_attachment 	(1665, 1776)
				    terminal_attachment 	(1665, 1650)
				    label      	(object SegLabel @157
					Parent_View 	@155
					location   	(1600, 1678)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.777778
					height     	66
					orientation 	0))))
			(object ClassView "Class" "Logical View::behavioral::actions::Statement" @158
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1632, 570)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@158
				location   	(1364, 389)
				fill_color 	13434879
				nlines     	1
				max_width  	536
				justify    	0
				label      	"Statement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4545FC1D0190"
			    compartment 	(object Compartment
				Parent_View 	@158
				location   	(1364, 450)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	6
				max_width  	535)
			    width      	554
			    height     	386
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @159
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(888, 1279)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@159
				location   	(621, 1123)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    compartment 	(object Compartment
				Parent_View 	@159
				location   	(621, 1184)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	5
				max_width  	531)
			    width      	552
			    height     	336
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$1" @160
			    location   	(689, 519)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"454606F903AA"
			    roleview_list 	(list RoleViews
				(object RoleView "block" @161
				    Parent_View 	@160
				    location   	(126, 385)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @162
					Parent_View 	@161
					location   	(690, 998)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	132
					justify    	0
					label      	"+block"
					pctDist    	0.831947
					height     	76
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454606FA01FD"
				    client     	@160
				    supplier   	@159
				    vertices   	(list Points
					(689, 519)
					(614, 519)
					(614, 1111))
				    line_style 	3
				    origin_attachment 	(689, 519)
				    terminal_attachment 	(614, 1111)
				    label      	(object SegLabel @163
					Parent_View 	@161
					location   	(656, 1059)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.921797
					height     	42
					orientation 	0))
				(object RoleView "statements" @164
				    Parent_View 	@160
				    location   	(126, 385)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @165
					Parent_View 	@164
					location   	(1183, 472)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	236
					justify    	0
					label      	"+statements"
					pctDist    	0.743381
					height     	48
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"454606FA01F3"
				    client     	@160
				    supplier   	@158
				    vertices   	(list Points
					(689, 519)
					(1355, 519))
				    line_style 	3
				    origin_attachment 	(689, 519)
				    terminal_attachment 	(1355, 519)
				    label      	(object SegLabel @166
					Parent_View 	@164
					location   	(1287, 552)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.897297
					height     	33
					orientation 	1)
				    label      	(object SegLabel @167
					Parent_View 	@164
					location   	(1241, 605)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.830631
					height     	86
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::StatementWithNestedBlocks" @168
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1682, 914)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@168
				location   	(1406, 863)
				fill_color 	13434879
				nlines     	1
				max_width  	552
				justify    	0
				label      	"StatementWithNestedBlocks")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49255EB1034B"
			    width      	570
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$12" @169
			    location   	(1004, 896)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49255F0300DA"
			    roleview_list 	(list RoleViews
				(object RoleView "nestedBlocks" @170
				    Parent_View 	@169
				    location   	(332, 602)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @171
					Parent_View 	@170
					location   	(982, 1006)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	283
					justify    	0
					label      	"+nestedBlocks"
					pctDist    	0.733333
					height     	157
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49255F030128"
				    client     	@169
				    supplier   	@159
				    vertices   	(list Points
					(1004, 896)
					(825, 896)
					(825, 1111))
				    line_style 	3
				    origin_attachment 	(1004, 896)
				    terminal_attachment 	(825, 1111)
				    label      	(object SegLabel @172
					Parent_View 	@170
					location   	(773, 1050)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1..2"
					pctDist    	0.846154
					height     	53
					orientation 	1)
				    label      	(object SegLabel @173
					Parent_View 	@170
					location   	(933, 1071)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	159
					justify    	0
					label      	"{ordered}"
					pctDist    	0.900000
					height     	108
					orientation 	0))
				(object RoleView "owningStatement" @174
				    Parent_View 	@169
				    location   	(332, 602)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @175
					Parent_View 	@174
					location   	(1110, 859)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	340
					justify    	0
					label      	"+owningStatement"
					pctDist    	0.272031
					height     	38
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49255F0300DB"
				    client     	@169
				    supplier   	@168
				    vertices   	(list Points
					(1004, 896)
					(1397, 896))
				    line_style 	3
				    origin_attachment 	(1004, 896)
				    terminal_attachment 	(1397, 896)
				    label      	(object SegLabel @176
					Parent_View 	@174
					location   	(1308, 950)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.774704
					height     	54
					orientation 	1))))
			(object InheritView "" @177
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49255ECF007D"
			    client     	@168
			    supplier   	@158
			    vertices   	(list Points
				(1637, 851)
				(1637, 762))
			    line_style 	3
			    origin_attachment 	(1637, 851)
			    terminal_attachment 	(1637, 762))
			(object InheritView "l" @178
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@178
				location   	(2491, 1270)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@143
			    supplier   	@142
			    vertices   	(list Points
				(2491, 1328)
				(2491, 1212))
			    line_style 	3
			    origin_attachment 	(2491, 1328)
			    terminal_attachment 	(2491, 1212))
			(object ClassView "Class" "Logical View::behavioral::actions::SingleBlockStatement" @179
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1675, 1199)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@179
				location   	(1457, 1148)
				fill_color 	13434879
				nlines     	1
				max_width  	436
				justify    	0
				label      	"SingleBlockStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4925602703B9"
			    width      	454
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @180
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925608200BB"
			    client     	@179
			    supplier   	@168
			    vertices   	(list Points
				(1684, 1136)
				(1684, 977))
			    line_style 	3
			    origin_attachment 	(1684, 1136)
			    terminal_attachment 	(1684, 977))
			(object InheritView "" @181
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4925608800FA"
			    client     	@145
			    supplier   	@179
			    vertices   	(list Points
				(1656, 1464)
				(1656, 1261))
			    line_style 	3
			    origin_attachment 	(1656, 1464)
			    terminal_attachment 	(1656, 1261))))
		(object ClassDiagram "Association Link Manipulation"
		    quid       	"4578414E0028"
		    title      	"Association Link Manipulation"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::behavioral::actions::Statement" @182
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1156, 487)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@182
				location   	(888, 356)
				fill_color 	13434879
				nlines     	1
				max_width  	536
				justify    	0
				label      	"Statement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4545FC1D0190"
			    width      	554
			    height     	286
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::AddLink" @183
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(937, 1128)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@183
				location   	(849, 1077)
				fill_color 	13434879
				nlines     	1
				max_width  	176
				justify    	0
				label      	"AddLink")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"457841700027"
			    width      	194
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::RemoveLink" @184
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1333, 1128)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@184
				location   	(1205, 1077)
				fill_color 	13434879
				nlines     	1
				max_width  	256
				justify    	0
				label      	"RemoveLink")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4578417F0187"
			    width      	274
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::Association" @185
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2116, 846)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@185
				location   	(1990, 771)
				fill_color 	13434879
				nlines     	1
				max_width  	252
				justify    	0
				label      	"Association")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44321DA40150"
			    width      	270
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @186
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(317, 850)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@186
				location   	(96, 721)
				fill_color 	13434879
				nlines     	1
				max_width  	442
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	460
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::LinkManipulationStatement" @187
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1158, 860)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@187
				location   	(898, 779)
				fill_color 	13434879
				nlines     	1
				max_width  	520
				justify    	0
				label      	"LinkManipulationStatement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"457841890204"
			    width      	538
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @188
			    location   	(1158, 1043)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@187
			    vertices   	(list Points
				(1158, 1043)
				(1158, 953)))
			(object InheritView "" @189
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"457841A002F7"
			    client     	@183
			    supplier   	@187
			    vertices   	(list Points
				(990, 1064)
				(990, 1043))
			    line_style 	3
			    origin_attachment 	(990, 1064)
			    terminal_attachment 	(990, 1043)
			    drawSupplier 	@188)
			(object InheritView "" @190
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"457841A403C5"
			    client     	@184
			    supplier   	@187
			    vertices   	(list Points
				(1334, 1065)
				(1334, 1043))
			    line_style 	3
			    origin_attachment 	(1334, 1065)
			    terminal_attachment 	(1334, 1043)
			    drawSupplier 	@188)
			(object AssociationViewNew "$UNNAMED$5" @191
			    location   	(1704, 850)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"457841C601B1"
			    roleview_list 	(list RoleViews
				(object RoleView "association" @192
				    Parent_View 	@191
				    location   	(1089, 75)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @193
					Parent_View 	@192
					location   	(1833, 892)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	234
					justify    	0
					label      	"+association"
					pctDist    	0.465704
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"457841C701BD"
				    client     	@191
				    supplier   	@185
				    vertices   	(list Points
					(1704, 850)
					(1981, 850))
				    line_style 	3
				    origin_attachment 	(1704, 850)
				    terminal_attachment 	(1981, 850)
				    label      	(object SegLabel @194
					Parent_View 	@192
					location   	(1931, 806)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.819444
					height     	45
					orientation 	0))
				(object RoleView "$UNNAMED$6" @195
				    Parent_View 	@191
				    location   	(1089, 75)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"457841C701C7"
				    client     	@191
				    supplier   	@187
				    vertices   	(list Points
					(1704, 850)
					(1427, 850))
				    line_style 	3
				    origin_attachment 	(1704, 850)
				    terminal_attachment 	(1427, 850)
				    label      	(object SegLabel @196
					Parent_View 	@195
					location   	(1482, 889)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.805861
					height     	39
					orientation 	0))))
			(object AssociationViewNew "$UNNAMED$7" @197
			    location   	(718, 859)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"457842A10116"
			    roleview_list 	(list RoleViews
				(object RoleView "objects" @198
				    Parent_View 	@197
				    location   	(-21, 8)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @199
					Parent_View 	@198
					location   	(628, 826)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	156
					justify    	0
					label      	"+objects"
					pctDist    	0.530726
					height     	34
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"457842A20095"
				    client     	@197
				    supplier   	@186
				    vertices   	(list Points
					(718, 859)
					(547, 859))
				    line_style 	3
				    origin_attachment 	(718, 859)
				    terminal_attachment 	(547, 859)
				    label      	(object SegLabel @200
					Parent_View 	@198
					location   	(567, 906)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"2"
					pctDist    	0.882682
					height     	47
					orientation 	0)
				    label      	(object SegLabel @201
					Parent_View 	@198
					location   	(630, 961)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	3
					anchor_loc 	1
					nlines     	1
					max_width  	160
					justify    	0
					label      	"{ordered}"
					pctDist    	0.521277
					height     	102
					orientation 	0))
				(object RoleView "$UNNAMED$8" @202
				    Parent_View 	@197
				    location   	(-21, 8)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"457842A200C7"
				    client     	@197
				    supplier   	@187
				    vertices   	(list Points
					(718, 859)
					(889, 859))
				    line_style 	3
				    origin_attachment 	(718, 859)
				    terminal_attachment 	(889, 859)
				    label      	(object SegLabel @203
					Parent_View 	@202
					location   	(843, 906)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.738889
					height     	47
					orientation 	1))))
			(object InheritView "" @204
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4578417601F2"
			    client     	@187
			    supplier   	@182
			    vertices   	(list Points
				(1156, 767)
				(1156, 630))
			    line_style 	3
			    origin_attachment 	(1156, 767)
			    terminal_attachment 	(1156, 630))))
		(object ClassDiagram "BOPF Actions"
		    quid       	"4715E4D30177"
		    title      	"BOPF Actions"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::behavioral::actions::Sort" @205
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(322, 231)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@205
				location   	(241, 180)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Sort")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4715E4DA0271"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object NoteView @206
			    location   	(1022, 1387)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@206
				location   	(59, 1162)
				fill_color 	13434879
				nlines     	9
				max_width  	1890
				label      	
|Example: aggregation (max, min, sum over collections of things), looping over collections, variables, path expressions.
|
|Challenge: when are which updates performed, who can see which updates when, which events get fired when?
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	1950
			    height     	463)))
		(object ClassDiagram "Variables, Constants and Iterators"
		    quid       	"47A717D8002E"
		    title      	"Variables, Constants and Iterators"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @207
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1877, 221)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@207
				location   	(1585, 92)
				fill_color 	13434879
				nlines     	1
				max_width  	584
				justify    	0
				label      	"NamedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45013C240030"
			    compartment 	(object Compartment
				Parent_View 	@207
				location   	(1585, 197)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	582)
			    width      	602
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @208
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2049, 1001)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@208
				location   	(1968, 950)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @209
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1732, 647)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@209
				location   	(1465, 543)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    compartment 	(object Compartment
				Parent_View 	@209
				location   	(1465, 648)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	2
				max_width  	531)
			    width      	552
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @210
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1264, 237)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@210
				location   	(1116, 108)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    compartment 	(object Compartment
				Parent_View 	@210
				location   	(1116, 213)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	3
				max_width  	284)
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::Parameter" @211
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2373, 997)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@211
				location   	(2259, 923)
				fill_color 	13434879
				nlines     	1
				max_width  	228
				justify    	0
				label      	"Parameter")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47F12A7E0062"
			    width      	246
			    height     	172
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Statement" @212
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(589, 271)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@212
				location   	(320, 90)
				fill_color 	13434879
				nlines     	1
				max_width  	538
				justify    	0
				label      	"Statement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4545FC1D0190"
			    compartment 	(object Compartment
				Parent_View 	@212
				location   	(320, 151)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	6
				max_width  	535)
			    width      	556
			    height     	386
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Constant" @213
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1733, 1317)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@213
				location   	(1637, 1266)
				fill_color 	13434879
				nlines     	1
				max_width  	192
				justify    	0
				label      	"Constant")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A717EE033C"
			    width      	210
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Variable" @214
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1183, 1311)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@214
				location   	(1091, 1259)
				fill_color 	13434879
				nlines     	1
				max_width  	184
				justify    	0
				label      	"Variable")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A717EF035B"
			    width      	202
			    height     	128
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @215
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"45472E5E0375"
			    client     	@209
			    supplier   	@207
			    vertices   	(list Points
				(1832, 530)
				(1832, 361))
			    line_style 	3
			    origin_attachment 	(1832, 530)
			    terminal_attachment 	(1832, 361))
			(object InheritTreeView "" @216
			    location   	(1264, 493)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@210
			    vertices   	(list Points
				(1264, 493)
				(1264, 378)))
			(object InheritView "" @217
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B85102FB"
			    client     	@209
			    supplier   	@210
			    vertices   	(list Points
				(1666, 531)
				(1666, 493))
			    line_style 	3
			    origin_attachment 	(1666, 531)
			    terminal_attachment 	(1666, 493)
			    drawSupplier 	@216)
			(object ClassView "Class" "Logical View::dataaccess::expressions::Expression" @218
			    ShowCompartmentStereotypes 	TRUE
			    SuppressOperation 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1082, 648)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@218
				location   	(949, 573)
				fill_color 	13434879
				nlines     	1
				max_width  	266
				justify    	0
				label      	"Expression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"450E63AB03A2"
			    width      	284
			    height     	174
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "l" @219
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@219
				location   	(1073, 527)
				anchor_loc 	1
				nlines     	1
				max_width  	60
				justify    	0
				label      	"l")
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B87503E5"
			    client     	@218
			    supplier   	@210
			    vertices   	(list Points
				(1073, 560)
				(1073, 493))
			    line_style 	3
			    origin_attachment 	(1073, 560)
			    terminal_attachment 	(1073, 493)
			    drawSupplier 	@216)
			(object ClassView "Class" "Logical View::behavioral::actions::NamedValueWithOptionalInitExpression" @220
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1493, 1001)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@220
				location   	(1115, 950)
				fill_color 	13434879
				nlines     	1
				max_width  	756
				justify    	0
				label      	"NamedValueWithOptionalInitExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49889B6400B0"
			    width      	774
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @221
			    location   	(1493, 1177)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@220
			    vertices   	(list Points
				(1493, 1177)
				(1493, 1064)))
			(object InheritView "" @222
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B790210"
			    client     	@213
			    supplier   	@220
			    vertices   	(list Points
				(1707, 1254)
				(1707, 1177))
			    line_style 	3
			    origin_attachment 	(1707, 1254)
			    terminal_attachment 	(1707, 1177)
			    drawSupplier 	@221)
			(object AssociationViewNew "$UNNAMED$11" @223
			    location   	(1108, 836)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47A71B130280"
			    roleview_list 	(list RoleViews
				(object RoleView "initExpression" @224
				    Parent_View 	@223
				    location   	(-490, -48)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @225
					Parent_View 	@224
					location   	(1265, 779)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	288
					justify    	0
					label      	"+initExpression"
					pctDist    	0.566265
					height     	157
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47A71B140109"
				    client     	@223
				    supplier   	@218
				    vertices   	(list Points
					(1108, 836)
					(1108, 735))
				    line_style 	3
				    origin_attachment 	(1108, 836)
				    terminal_attachment 	(1108, 735)
				    label      	(object SegLabel @226
					Parent_View 	@224
					location   	(1037, 777)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.580645
					height     	72
					orientation 	0))
				(object RoleView "initExpressionFor" @227
				    Parent_View 	@223
				    location   	(-490, -48)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @228
					Parent_View 	@227
					location   	(1298, 902)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	352
					justify    	0
					label      	"+initExpressionFor"
					pctDist    	0.659794
					height     	190
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47A71B140128"
				    client     	@223
				    supplier   	@220
				    vertices   	(list Points
					(1108, 836)
					(1108, 938))
				    line_style 	3
				    origin_attachment 	(1108, 836)
				    terminal_attachment 	(1108, 938)
				    label      	(object SegLabel @229
					Parent_View 	@227
					location   	(1040, 894)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.578313
					height     	69
					orientation 	1))))
			(object InheritView "" @230
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B7F0280"
			    client     	@214
			    supplier   	@220
			    vertices   	(list Points
				(1185, 1247)
				(1185, 1177))
			    line_style 	3
			    origin_attachment 	(1185, 1247)
			    terminal_attachment 	(1185, 1177)
			    drawSupplier 	@221)
			(object ClassView "Class" "Logical View::behavioral::actions::NamedValueDeclaration" @231
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(607, 686)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@231
				location   	(376, 635)
				fill_color 	13434879
				nlines     	1
				max_width  	462
				justify    	0
				label      	"NamedValueDeclaration")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"48873D45021C"
			    width      	480
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @232
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48873D610119"
			    client     	@231
			    supplier   	@212
			    vertices   	(list Points
				(582, 622)
				(582, 464))
			    line_style 	3
			    origin_attachment 	(582, 622)
			    terminal_attachment 	(582, 464))
			(object AssociationViewNew "$UNNAMED$13" @233
			    location   	(726, 1011)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49B64B6F0008"
			    roleview_list 	(list RoleViews
				(object RoleView "namedValue" @234
				    Parent_View 	@233
				    location   	(323, 396)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @235
					Parent_View 	@234
					location   	(926, 970)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	250
					justify    	0
					label      	"+namedValue"
					pctDist    	0.528529
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49B64B6F0279"
				    client     	@233
				    supplier   	@220
				    vertices   	(list Points
					(726, 1011)
					(1106, 1011))
				    line_style 	3
				    origin_attachment 	(726, 1011)
				    terminal_attachment 	(1106, 1011)
				    label      	(object SegLabel @236
					Parent_View 	@234
					location   	(1067, 1065)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "namedValueDeclaration" @237
				    Parent_View 	@233
				    location   	(323, 396)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @238
					Parent_View 	@237
					location   	(370, 836)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	457
					justify    	0
					label      	"+namedValueDeclaration"
					pctDist    	0.771654
					height     	238
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"49B64B6F027B"
				    client     	@233
				    supplier   	@231
				    vertices   	(list Points
					(726, 1011)
					(607, 1011)
					(607, 749))
				    line_style 	3
				    origin_attachment 	(726, 1011)
				    terminal_attachment 	(607, 749)
				    label      	(object SegLabel @239
					Parent_View 	@237
					location   	(551, 785)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.905512
					height     	57
					orientation 	0))))
			(object InheritTreeView "" @240
			    location   	(1732, 869)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@209
			    vertices   	(list Points
				(1732, 869)
				(1732, 763)))
			(object InheritView "" @241
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47A719D70280"
			    client     	@208
			    supplier   	@209
			    vertices   	(list Points
				(2047, 938)
				(2047, 869))
			    line_style 	3
			    origin_attachment 	(2047, 938)
			    terminal_attachment 	(2047, 869)
			    drawSupplier 	@240)
			(object InheritView "" @242
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"48566FFF0196"
			    client     	@211
			    supplier   	@209
			    vertices   	(list Points
				(2375, 911)
				(2375, 869))
			    line_style 	3
			    origin_attachment 	(2375, 911)
			    terminal_attachment 	(2375, 869)
			    drawSupplier 	@240)
			(object InheritView "" @243
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B750153"
			    client     	@220
			    supplier   	@209
			    vertices   	(list Points
				(1532, 937)
				(1532, 869))
			    line_style 	3
			    origin_attachment 	(1532, 937)
			    terminal_attachment 	(1532, 869)
			    drawSupplier 	@240)))
		(object ClassDiagram "Typedefinition Ownership"
		    quid       	"47CBF54E0119"
		    title      	"Typedefinition Ownership"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::data::classes::TypeDefinition" @244
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(737, 353)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@244
				location   	(337, 49)
				fill_color 	13434879
				nlines     	1
				max_width  	800
				justify    	0
				label      	"TypeDefinition")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47B9A97A00CB"
			    width      	818
			    height     	632
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::data::classes::TypedElement" @245
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(812, 1182)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@245
				location   	(664, 1053)
				fill_color 	13434879
				nlines     	1
				max_width  	296
				justify    	0
				label      	"TypedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4717B7BC031A"
			    width      	314
			    height     	282
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "" @246
			    location   	(816, 855)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47CBF4180109"
			    roleview_list 	(list RoleViews
				(object RoleView "ownedTypeDefinition" @247
				    Parent_View 	@246
				    location   	(352, -1218)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @248
					Parent_View 	@247
					location   	(1031, 753)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	396
					justify    	0
					label      	"+ownedTypeDefinition"
					pctDist    	0.548523
					height     	215
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010A"
				    client     	@246
				    supplier   	@244
				    vertices   	(list Points
					(816, 855)
					(816, 669))
				    line_style 	3
				    origin_attachment 	(816, 855)
				    terminal_attachment 	(816, 669)
				    label      	(object SegLabel @249
					Parent_View 	@247
					location   	(874, 697)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.848101
					height     	58
					orientation 	1))
				(object RoleView "ownerTypedElement" @250
				    Parent_View 	@246
				    location   	(352, -1218)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @251
					Parent_View 	@250
					location   	(1031, 951)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	393
					justify    	0
					label      	"+ownerTypedElement"
					pctDist    	0.523256
					height     	215
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47CBF418010B"
				    client     	@246
				    supplier   	@245
				    vertices   	(list Points
					(816, 855)
					(816, 1041))
				    line_style 	3
				    origin_attachment 	(816, 855)
				    terminal_attachment 	(816, 1041)
				    label      	(object SegLabel @252
					Parent_View 	@250
					location   	(890, 1012)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.843023
					height     	74
					orientation 	0))))
			(object ClassView "Class" "Logical View::data::classes::NamedValue" @253
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(783, 1549)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@253
				location   	(516, 1445)
				fill_color 	13434879
				nlines     	1
				max_width  	534
				justify    	0
				label      	"NamedValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4522A56F0149"
			    width      	552
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @254
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"4717B85102FB"
			    client     	@253
			    supplier   	@245
			    vertices   	(list Points
				(809, 1433)
				(809, 1323))
			    line_style 	3
			    origin_attachment 	(809, 1433)
			    terminal_attachment 	(809, 1323))
			(object ClassView "Class" "Logical View::behavioral::actions::Variable" @255
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(378, 2180)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@255
				location   	(47, 2099)
				fill_color 	13434879
				nlines     	1
				max_width  	662
				justify    	0
				label      	"Variable")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A717EF035B"
			    width      	680
			    height     	186
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Constant" @256
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(908, 2168)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@256
				location   	(813, 2117)
				fill_color 	13434879
				nlines     	1
				max_width  	190
				justify    	0
				label      	"Constant")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A717EE033C"
			    width      	208
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::Iterator" @257
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1158, 1839)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@257
				location   	(1077, 1788)
				fill_color 	13434879
				nlines     	1
				max_width  	162
				justify    	0
				label      	"Iterator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47A719D200EA"
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::actions::NamedValueWithOptionalInitExpression" @258
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(562, 1843)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@258
				location   	(179, 1792)
				fill_color 	13434879
				nlines     	1
				max_width  	766
				justify    	0
				label      	"NamedValueWithOptionalInitExpression")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"49889B6400B0"
			    width      	784
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritTreeView "" @259
			    location   	(783, 1755)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@253
			    vertices   	(list Points
				(783, 1755)
				(783, 1665)))
			(object InheritView "" @260
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47A719D70280"
			    client     	@257
			    supplier   	@253
			    vertices   	(list Points
				(1073, 1776)
				(1073, 1755))
			    line_style 	3
			    origin_attachment 	(1073, 1776)
			    terminal_attachment 	(1073, 1755)
			    drawSupplier 	@259)
			(object InheritView "" @261
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B750153"
			    client     	@258
			    supplier   	@253
			    vertices   	(list Points
				(562, 1780)
				(562, 1755))
			    line_style 	3
			    origin_attachment 	(562, 1780)
			    terminal_attachment 	(562, 1755)
			    drawSupplier 	@259)
			(object InheritTreeView "" @262
			    location   	(562, 2012)
			    line_color 	3342489
			    fill_color 	13434879
			    supplier   	@258
			    vertices   	(list Points
				(562, 2012)
				(562, 1906)))
			(object InheritView "" @263
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B7F0280"
			    client     	@255
			    supplier   	@258
			    vertices   	(list Points
				(403, 2087)
				(403, 2012))
			    line_style 	3
			    origin_attachment 	(403, 2087)
			    terminal_attachment 	(403, 2012)
			    drawSupplier 	@262)
			(object InheritView "" @264
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"49889B790210"
			    client     	@256
			    supplier   	@258
			    vertices   	(list Points
				(906, 2105)
				(906, 2012))
			    line_style 	3
			    origin_attachment 	(906, 2105)
			    terminal_attachment 	(906, 2012)
			    drawSupplier 	@262)))))
	(object Class_Category "rules"
	    quid       	"44D74DBB02FD"
	    documentation 	
|A declarative rules language that uses the structural concepts (see package structural) to form expressions and conditions. Conditions may, e.g., be used to define when an event listener wants to be notified about the occurrence of specific events.
|
|Consider FDT and other expression languages.
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Dummy"
		    quid       	"4581612D0139"))
	    logical_presentations 	(list unit_reference_list))
	(object Class_Category "events"
	    quid       	"44D74DC40238"
	    documentation 	
|Talks about types of (business) events that may occur, may need to be communicated / signalled and which can be consumed by event listeners (which most likely should be an action with suitable signature). Rules (see rules package) may be used to filter for relevant events.
|
|From Holger's slides:
|
|Business Event:
|A meaningful change of the state of the enterprise (inside or outside)
|A key source of business events are business objects; there are other sources like unstructured documents, analytical sources, RSS feeds, embedded software etc.
|The term �business event� is often used interchangeably to refer to both the specification (type) of the event, and each individual occurrence (instance) of the event
|Characterized by its type, modeled in Enterprise Repository*:
|Name and/or significance
|The data that is provided with each occurrence (aka attributes or context)
|Modeled as data type
|Relationship to other event types (to be clarified)
|Like causality or aggregation
|Can carry additional pre-defined data at execution time
|Like unique occurance ID, timestamp, identification of event producer
|Must be interpretable outside the �local processing context� that produced it
|Logically self-contained in representing all the information pertinent to the situation causing the event
|May either directly contain relevant details or may enable consumers to access the relevant details (via links or subsequent service calls or other means)
|Even if it contains relevant details that doesn�t rule out the need for accessing additional data, business rules, etc. for the purposes of processing and acting upon the event
|
|
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Subscription"
		    quid       	"44ECBFF00094"
		    documentation 	"Represents an EventConsumer's interest in being notified about occurrences of events produced by one or more EventProducers. The subscription can specify rules that constrain which events the consumer is interested in. It is then the event infrastructure's task to optimize the event forwarding to the consumers appropriately."
		    superclasses 	(list inheritance_relationship_list
			(object Inheritance_Relationship
			    quid       	"47FE62950161"
			    supplier   	"Logical View::modelmanagement::NamedElement"
			    quidu      	"45013C240030"))
		    nestedClasses 	(list nestedClasses
			(object Class "SubscribingClassMatchProducer"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.violationMessageExpression"
				    value      	(value Text "'Subscribing class signatures must match producer\\'s notification signatures'")))
			    quid       	"4787844F036B"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"4787845C0196"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context Subscription
|inv:
|  self.producer.notificationSignatures->forAll(ms:data::classes::MethodSignature |
|    self.subscribingClass.allSignatures()->exists(s:data::classes::MethodSignature|s.conformsTo(ms)))
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Class "EventProducer"
		    quid       	"44ECC164016C"
		    abstract   	TRUE)
		(object Class "EventFilter"
		    quid       	"44ECC2220006"
		    documentation 	
|From Holger's slides:
|
|Event Patterns:
|An event pattern is a decision rule that describes how to match a certain set of events
|Each match is a (partially ordered) set of events that is an instance of the event pattern constructed by replacing variables in the pattern with values
|It is similar to mathematical language for logical expressions
|The main features of an event pattern language are (in order of complexity):
|Basic event patterns to express patterns that match single event types
|Content-based event matching in terms of the event type�s attributes
|Pattern operators for expressing relationships between events
|Like logical operators, set operators, structural operators (causes, is independent of, before)
|Context that restricts matches of patterns to specific contexts in which events are observed
|Context refers to information outside the events
|Temporal operators to specify the timing of events that match a pattern, or when a pattern should or should not match
|Like �at�, �after�, �during�
|
		    
		    nestedClasses 	(list nestedClasses
			(object Class "FilterBlockSignatureMatchNotificationSignature"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.violationMessageExpression"
				    value      	(value Text "'Subscribing class signatures must match producer\\'s notification signatures'")))
			    quid       	"48079526010A"
			    stereotype 	"constraint"
			    operations 	(list Operations
				(object Operation "OCL"
				    quid       	"48079526010B"
				    concurrency 	"Sequential"
				    semantics  	(object Semantic_Info
					PDL        	
|context EventFilter
|inv:
|  self.subscription.producer.notificationSignatures->exists(ms:data::classes::MethodSignature |
|    ms.conformsTo(self.test.getImplementedSignature()))
					)
				    opExportControl 	"Public"
				    uid        	0)))))
		(object Association "Producer"
		    quid       	"44ECC16A01C4"
		    roles      	(list role_list
			(object Role "producer"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 201)))
			    quid       	"44ECC16B0021"
			    label      	"producer"
			    supplier   	"Logical View::behavioral::events::EventProducer"
			    quidu      	"44ECC164016C"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)
			(object Role "subscriptions"
			    quid       	"44ECC16B0023"
			    label      	"subscriptions"
			    supplier   	"Logical View::behavioral::events::Subscription"
			    quidu      	"44ECBFF00094"
			    client_cardinality 	(value cardinality "0..*")
			    is_navigable 	TRUE)))
		(object Association "$UNNAMED$14"
		    quid       	"44ECC2320059"
		    roles      	(list role_list
			(object Role "filters"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44ECC23202DA"
			    label      	"filters"
			    supplier   	"Logical View::behavioral::events::EventFilter"
			    quidu      	"44ECC2220006"
			    client_cardinality 	(value cardinality "0..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "subscription"
			    quid       	"44ECC23202E4"
			    label      	"subscription"
			    supplier   	"Logical View::behavioral::events::Subscription"
			    quidu      	"44ECBFF00094"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "Subscriptions"
		    quid       	"47DA749E0160"
		    roles      	(list role_list
			(object Role "subscription"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"47DA749E02F6"
			    label      	"subscription"
			    supplier   	"Logical View::behavioral::events::Subscription"
			    quidu      	"44ECBFF00094"
			    client_cardinality 	(value cardinality "0..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "subscribingClass"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"47DA749E0306"
			    label      	"subscribingClass"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "$UNNAMED$15"
		    quid       	"47FE59880193"
		    roles      	(list role_list
			(object Role "test"
			    quid       	"47FE5989016F"
			    label      	"test"
			    supplier   	"Logical View::behavioral::actions::Block"
			    quidu      	"454606CB020A"
			    client_cardinality 	(value cardinality "1")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "filter"
			    quid       	"47FE5989017B"
			    label      	"filter"
			    supplier   	"Logical View::behavioral::events::EventFilter"
			    quidu      	"44ECC2220006"
			    client_cardinality 	(value cardinality "0..1")
			    is_aggregate 	TRUE)))
		(object Association "NotificationSignatures"
		    quid       	"44ECC07D023C"
		    documentation 	
|The subsciption tells the method to be called upon event receipt. The class to which the method belongs would probably have to be stateless (or at least have a default constructor) to avoid having to restore the state from a persistent store upon event receipt.
|
|Also, there needs to be a way to specify how the arguments of the method are assembled from the event.
		    
		    roles      	(list role_list
			(object Role "producer"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44ECC07E0048"
			    label      	"producer"
			    supplier   	"Logical View::behavioral::events::EventProducer"
			    quidu      	"44ECC164016C"
			    client_cardinality 	(value cardinality "0..1")
			    Containment 	"By Value"
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)
			(object Role "notificationSignatures"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"44ECC07E004A"
			    label      	"notificationSignatures"
			    supplier   	"Logical View::data::classes::MethodSignature"
			    quidu      	"47D67D15030D"
			    client_cardinality 	(value cardinality "0..*")
			    Containment 	"By Value"
			    is_navigable 	TRUE))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Eventing"
		    quid       	"44ECC0860221"
		    title      	"Eventing"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	701
		    items      	(list diagram_item_list
			(object NoteView @265
			    location   	(1171, 151)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@265
				location   	(758, 7)
				fill_color 	13434879
				nlines     	5
				max_width  	790
				label      	"We need some form of event log, history or context. This is required in order to relate events to other events. We need to understand causality and timing, in particular.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	850
			    height     	300)
			(object NoteView @266
			    location   	(2370, 157)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@266
				location   	(1939, 13)
				fill_color 	13434879
				nlines     	5
				max_width  	827
				label      	"TODO: How are the default change events described that an object shall emit? Are those classes / TypeDefinitions in a standard library?")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	887
			    height     	300)
			(object NoteView @267
			    location   	(1777, 441)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@267
				location   	(755, 338)
				fill_color 	13434879
				nlines     	4
				max_width  	2008
				label      	
|This could partly replace the PAF (Process Agent Framework) part of the programming model. Classes emit standardized change events. Subscribers (the "outbound process agents") can subscribe to such change events, optionally providing filter conditions. The event consumer has to be a (standalone) signature which will get called in case the event occurs. The event notification object will be passed as argument.
				)
			    line_color 	3342489
			    fill_color 	13434879
			    width      	2068
			    height     	219)
			(object NoteView @268
			    location   	(937, 2387)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@268
				location   	(121, 2143)
				fill_color 	13434879
				nlines     	9
				max_width  	1597
				label      	"AttributeValueFilter should reference AssociationEnd. It would probably also need some sort of expression attached to it that evaluates to a Boolean. However, let's postpone this to a second phase. For now, I could imagine having a Block attached to an EventFilter that implements a FunctionSignature that takes the same inputs as the MethodSignature of the subscriber and delivers a Boolean. If for a given set of event notification arguments this function returns true, then the event is propagated to the subscriber.")
			    line_color 	3342489
			    fill_color 	13434879
			    width      	1657
			    height     	501)
			(object ClassView "Class" "Logical View::data::classes::SapClass" @269
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1758, 1751)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@269
				location   	(1477, 1557)
				fill_color 	13434879
				nlines     	1
				max_width  	563
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	581
			    height     	412
			    annotation 	8)
			(object ClassView "Class" "Logical View::data::classes::MethodSignature" @270
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2536, 1341)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@270
				location   	(2360, 1237)
				fill_color 	13434879
				nlines     	1
				max_width  	352
				justify    	0
				label      	"MethodSignature")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"47D67D15030D"
			    width      	370
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::events::EventProducer" @271
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1800, 1084)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@271
				location   	(1650, 1033)
				fill_color 	13434879
				nlines     	1
				max_width  	300
				justify    	0
				label      	"EventProducer")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44ECC164016C"
			    width      	318
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "NotificationSignatures" @272
			    location   	(2348, 1081)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @273
				Parent_View 	@272
				location   	(2348, 1022)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"NotificationSignatures"
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44ECC07D023C"
			    roleview_list 	(list RoleViews
				(object RoleView "notificationSignatures" @274
				    Parent_View 	@272
				    location   	(1360, 612)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @275
					Parent_View 	@274
					location   	(2335, 1177)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	428
					justify    	0
					label      	"+notificationSignatures"
					pctDist    	-0.036735
					height     	96
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC07E004A"
				    client     	@272
				    supplier   	@270
				    vertices   	(list Points
					(2348, 1081)
					(2592, 1081)
					(2592, 1225))
				    line_style 	3
				    origin_attachment 	(2348, 1081)
				    terminal_attachment 	(2592, 1225)
				    label      	(object SegLabel @276
					Parent_View 	@274
					location   	(2637, 1184)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.898039
					height     	45
					orientation 	0))
				(object RoleView "producer" @277
				    Parent_View 	@272
				    location   	(1360, 612)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @278
					Parent_View 	@277
					location   	(2061, 1039)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	188
					justify    	0
					label      	"+producer"
					pctDist    	0.737789
					height     	43
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC07E0048"
				    client     	@272
				    supplier   	@271
				    vertices   	(list Points
					(2348, 1081)
					(1959, 1081))
				    line_style 	3
				    origin_attachment 	(2348, 1081)
				    terminal_attachment 	(1959, 1081)
				    label      	(object SegLabel @279
					Parent_View 	@277
					location   	(2015, 1125)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.858612
					height     	44
					orientation 	0))))
			(object InheritView "" @280
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44ED67500396"
			    client     	@269
			    supplier   	@271
			    vertices   	(list Points
				(1781, 1544)
				(1781, 1146))
			    line_style 	3
			    origin_attachment 	(1781, 1544)
			    terminal_attachment 	(1781, 1146))
			(object ClassView "Class" "Logical View::data::classes::SapClass" @281
			    ShowCompartmentStereotypes 	TRUE
			    location   	(182, 1043)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@281
				location   	(64, 965)
				fill_color 	13434879
				nlines     	1
				max_width  	236
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	254
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::events::Subscription" @282
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(957, 1071)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@282
				location   	(828, 1020)
				fill_color 	13434879
				nlines     	1
				max_width  	258
				justify    	0
				label      	"Subscription")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44ECBFF00094"
			    width      	276
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "Producer" @283
			    location   	(1368, 1046)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @284
				Parent_View 	@283
				location   	(1368, 987)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"Producer"
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44ECC16A01C4"
			    roleview_list 	(list RoleViews
				(object RoleView "producer" @285
				    Parent_View 	@283
				    location   	(123, 562)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @286
					Parent_View 	@285
					location   	(1527, 1017)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	188
					justify    	0
					label      	"+producer"
					pctDist    	0.581081
					height     	30
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC16B0021"
				    client     	@283
				    supplier   	@271
				    vertices   	(list Points
					(1368, 1046)
					(1641, 1046))
				    line_style 	3
				    origin_attachment 	(1368, 1046)
				    terminal_attachment 	(1641, 1046)
				    label      	(object SegLabel @287
					Parent_View 	@285
					location   	(1605, 1078)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.868633
					height     	32
					orientation 	1))
				(object RoleView "subscriptions" @288
				    Parent_View 	@283
				    location   	(123, 562)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @289
					Parent_View 	@288
					location   	(1239, 1091)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	268
					justify    	0
					label      	"+subscriptions"
					pctDist    	0.472973
					height     	45
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC16B0023"
				    client     	@283
				    supplier   	@282
				    vertices   	(list Points
					(1368, 1046)
					(1095, 1046))
				    line_style 	3
				    origin_attachment 	(1368, 1046)
				    terminal_attachment 	(1095, 1046)
				    label      	(object SegLabel @290
					Parent_View 	@288
					location   	(1136, 1013)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.849576
					height     	34
					orientation 	1))))
			(object AssociationViewNew "Subscriptions" @291
			    location   	(564, 1043)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @292
				Parent_View 	@291
				location   	(564, 984)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"Subscriptions"
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47DA749E0160"
			    roleview_list 	(list RoleViews
				(object RoleView "subscription" @293
				    Parent_View 	@291
				    location   	(319, 247)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @294
					Parent_View 	@293
					location   	(680, 1011)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	244
					justify    	0
					label      	"+subscription"
					pctDist    	0.453875
					height     	33
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47DA749E02F6"
				    client     	@291
				    supplier   	@282
				    vertices   	(list Points
					(564, 1043)
					(819, 1043))
				    line_style 	3
				    origin_attachment 	(564, 1043)
				    terminal_attachment 	(819, 1043)
				    label      	(object SegLabel @295
					Parent_View 	@293
					location   	(771, 1104)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.811808
					height     	61
					orientation 	1))
				(object RoleView "subscribingClass" @296
				    Parent_View 	@291
				    location   	(319, 247)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @297
					Parent_View 	@296
					location   	(496, 1088)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	347
					justify    	0
					label      	"+subscribingClass"
					pctDist    	0.265683
					height     	45
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47DA749E0306"
				    client     	@291
				    supplier   	@281
				    vertices   	(list Points
					(564, 1043)
					(309, 1043))
				    line_style 	3
				    origin_attachment 	(564, 1043)
				    terminal_attachment 	(309, 1043)
				    label      	(object SegLabel @298
					Parent_View 	@296
					location   	(338, 986)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.887160
					height     	58
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::actions::Block" @299
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(303, 1514)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@299
				location   	(34, 1410)
				fill_color 	13434879
				nlines     	1
				max_width  	538
				justify    	0
				label      	"Block")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"454606CB020A"
			    compartment 	(object Compartment
				Parent_View 	@299
				location   	(34, 1606)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	FALSE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				icon_style 	"Icon"
				fill_color 	16777215
				anchor     	2
				nlines     	5
				max_width  	0)
			    width      	556
			    height     	232
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::events::EventFilter" @300
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(938, 1517)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@300
				location   	(823, 1466)
				fill_color 	13434879
				nlines     	1
				max_width  	230
				justify    	0
				label      	"EventFilter")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44ECC2220006"
			    width      	248
			    height     	126
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "$UNNAMED$14" @301
			    location   	(965, 1294)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44ECC2320059"
			    roleview_list 	(list RoleViews
				(object RoleView "filters" @302
				    Parent_View 	@301
				    location   	(-161, 895)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @303
					Parent_View 	@302
					location   	(874, 1385)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	145
					justify    	0
					label      	"+filters"
					pctDist    	0.571429
					height     	92
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC23202DA"
				    client     	@301
				    supplier   	@300
				    vertices   	(list Points
					(965, 1294)
					(965, 1454))
				    line_style 	3
				    origin_attachment 	(965, 1294)
				    terminal_attachment 	(965, 1454)
				    label      	(object SegLabel @304
					Parent_View 	@302
					location   	(1026, 1369)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..*"
					pctDist    	0.466667
					height     	61
					orientation 	0))
				(object RoleView "subscription" @305
				    Parent_View 	@301
				    location   	(-161, 895)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @306
					Parent_View 	@305
					location   	(819, 1198)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	268
					justify    	0
					label      	"+subscription"
					pctDist    	0.606061
					height     	147
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44ECC23202E4"
				    client     	@301
				    supplier   	@282
				    vertices   	(list Points
					(965, 1294)
					(965, 1134))
				    line_style 	3
				    origin_attachment 	(965, 1294)
				    terminal_attachment 	(965, 1134)
				    label      	(object SegLabel @307
					Parent_View 	@305
					location   	(998, 1198)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.605263
					height     	33
					orientation 	1))))
			(object AssociationViewNew "$UNNAMED$15" @308
			    location   	(697, 1512)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47FE59880193"
			    roleview_list 	(list RoleViews
				(object RoleView "test" @309
				    Parent_View 	@308
				    location   	(-239, -309)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @310
					Parent_View 	@309
					location   	(609, 1440)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	100
					justify    	0
					label      	"+test"
					pctDist    	0.767857
					height     	73
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47FE5989016F"
				    client     	@308
				    supplier   	@299
				    vertices   	(list Points
					(697, 1512)
					(581, 1512))
				    line_style 	3
				    origin_attachment 	(697, 1512)
				    terminal_attachment 	(581, 1512)
				    label      	(object SegLabel @311
					Parent_View 	@309
					location   	(603, 1566)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.821429
					height     	54
					orientation 	0))
				(object RoleView "filter" @312
				    Parent_View 	@308
				    location   	(-239, -309)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @313
					Parent_View 	@312
					location   	(782, 1418)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	106
					justify    	0
					label      	"+filter"
					pctDist    	0.724551
					height     	95
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47FE5989017B"
				    client     	@308
				    supplier   	@300
				    vertices   	(list Points
					(697, 1512)
					(814, 1512))
				    line_style 	3
				    origin_attachment 	(697, 1512)
				    terminal_attachment 	(814, 1512)
				    label      	(object SegLabel @314
					Parent_View 	@312
					location   	(785, 1580)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..1"
					pctDist    	0.748503
					height     	68
					orientation 	1))))
			(object AttachView "" @315
			    stereotype 	TRUE
			    line_color 	3342489
			    client     	@268
			    supplier   	@300
			    vertices   	(list Points
				(937, 2136)
				(937, 1580))
			    line_style 	0)
			(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @316
			    ShowCompartmentStereotypes 	TRUE
			    SuppressAttribute 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(953, 752)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	TRUE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@316
				location   	(753, 674)
				fill_color 	13434879
				nlines     	1
				max_width  	400
				justify    	0
				label      	"NamedElement")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"45013C240030"
			    width      	418
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object InheritView "" @317
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"47FE62950161"
			    client     	@282
			    supplier   	@316
			    vertices   	(list Points
				(962, 1007)
				(962, 842))
			    line_style 	3
			    origin_attachment 	(962, 1007)
			    terminal_attachment 	(962, 842))))))
	(object Class_Category "transactions"
	    quid       	"44D75B700032"
	    documentation 	
|Allows modelers / developers to specify transactional boundaries, tentative updates, compensation strategies etc.
|
|Also, mark in the models how pieces of data-modifying functionality can share transactional scopes with other pieces. Make the distinction between shared transactions and compensation explicit.
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "Dummy"
		    quid       	"458161330033"))
	    logical_presentations 	(list unit_reference_list))
	(object Class_Category "status_and_action_old"
	    quid       	"44F2DC700080"
	    documentation 	"Status and Action Modeling. Must be closely related to the businessobjects package and the behavioral/actions package. Decide whether this should be under behavioral or structural."
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class "SAMAction"
		    quid       	"44F2F5E500D4"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "name"
			    quid       	"44FEACF000BF"
			    type       	"String"
			    quidu      	"39A2BDA60394"
			    exportControl 	"Public")
			(object ClassAttribute "isAgentAction"
			    quid       	"44FEACF000D3"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public")))
		(object Class "SAMStatusVariable"
		    quid       	"44F2F6C90251"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "name"
			    quid       	"44FEA801016C"
			    type       	"String"
			    quidu      	"39A2BDA60394"
			    exportControl 	"Public")
			(object ClassAttribute "isAgentVariable"
			    quid       	"44FEA92F0202"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public")))
		(object Class "SAMDerivator"
		    quid       	"44FE57E30371"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "kind"
			    quid       	"44FEAE070305"
			    type       	"SAMDerivatorKindEnum"
			    quidu      	"44FEADB80062"
			    exportControl 	"Public")))
		(object Class "SAMStatusValue"
		    quid       	"44FE5BF60070"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "name"
			    quid       	"44FEA8E401D3"
			    type       	"String"
			    quidu      	"39A2BDA60394"
			    exportControl 	"Public")))
		(object Class "SAMStatusSchema"
		    quid       	"44FE69A1022A"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "name"
			    quid       	"44FEA8D00116"
			    type       	"String"
			    quidu      	"39A2BDA60394"
			    exportControl 	"Public")))
		(object Class "SAMOperator"
		    quid       	"44FE6A3D021D"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "kind"
			    quid       	"44FEAA5901A4"
			    type       	"SAMOperatorKindEnum"
			    quidu      	"44FEA9990023"
			    exportControl 	"Public")))
		(object Class "SAMSchemaVariable"
		    quid       	"44FE6B8503A2"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "hasStateGuard"
			    quid       	"44FEAC5D000F"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public")))
		(object Class "SAMSchemaValue"
		    quid       	"44FE6C0901FA"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "isInitial"
			    quid       	"44FEAB31008A"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392"
			    exportControl 	"Public")
			(object ClassAttribute "isInhibiting"
			    quid       	"44FEAB4101E1"
			    type       	"Boolean"
			    quidu      	"39A2BDA60392")))
		(object Class "SAMSchemaAction"
		    quid       	"44FE6C1503CE")
		(object Class "SAMOperatorKindEnum"
		    quid       	"44FEA9990023"
		    stereotype 	"enumeration"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "OR"
			    quid       	"44FEAA0703D7"
			    exportControl 	"Public")
			(object ClassAttribute "AND"
			    quid       	"44FEAA0901E5"
			    exportControl 	"Public")))
		(object Class "SAMSchemaDerivator"
		    quid       	"44FEAD8A0233")
		(object Class "SAMDerivatorKindEnum"
		    quid       	"44FEADB80062"
		    stereotype 	"enumeration"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "POPULATION"
			    quid       	"44FEADCB02CC"
			    exportControl 	"Public")
			(object ClassAttribute "AGGREGATION"
			    quid       	"44FEADDE00B7"
			    exportControl 	"Public")
			(object ClassAttribute "OVERALL"
			    quid       	"44FEADEA0014"
			    exportControl 	"Public")))
		(object Class "PreconditionKindEnum"
		    quid       	"44FEBD5B0230"
		    stereotype 	"enumeration"
		    class_attributes 	(list class_attribute_list
			(object ClassAttribute "ENABLE"
			    quid       	"44FEBD6C0271"
			    exportControl 	"Public")
			(object ClassAttribute "REQUIRED"
			    quid       	"44FEBD6D0178"
			    exportControl 	"Public")
			(object ClassAttribute "INHIBIT"
			    quid       	"44FEBD6D0010"
			    exportControl 	"Public")
			(object ClassAttribute "NEUTEAL"
			    quid       	"44FEBD93010F"
			    exportControl 	"Public")))
		(object Association "SAMActionForBusinessObjectNode"
		    quid       	"44F2F5F002C6"
		    roles      	(list role_list
			(object Role "samActions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 202)))
			    quid       	"44F2F5F1012D"
			    label      	"samActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMAction"
			    quidu      	"44F2F5E500D4"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "businessObjectNode"
			    quid       	"44F2F5F1012F"
			    label      	"businessObjectNode"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMStatusVariableForBusinessObjectNode"
		    quid       	"44F2F6E50128"
		    roles      	(list role_list
			(object Role "samStatusVariables"
			    attributes 	(list Attribute_Set)
			    quid       	"44F2F6E600E4"
			    label      	"samStatusVariables"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusVariable"
			    quidu      	"44F2F6C90251"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "businessObjectNode"
			    quid       	"44F2F6E600E6"
			    label      	"businessObjectNode"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMDerivatorForBusinessObject"
		    quid       	"44FE5B2400EF"
		    roles      	(list role_list
			(object Role "samDerivators"
			    attributes 	(list Attribute_Set)
			    quid       	"44FE5B2402E4"
			    label      	"samDerivators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMDerivator"
			    quidu      	"44FE57E30371"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "businessObject"
			    quid       	"44FE5B2402E6"
			    label      	"businessObject"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMStatusValueForSAMStatusVariable"
		    quid       	"44FE5CE401A3"
		    roles      	(list role_list
			(object Role "samStatusValues"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE5CE5000A"
			    label      	"samStatusValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusValue"
			    quidu      	"44FE5BF60070"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samStatusVariable"
			    quid       	"44FE5CE5000C"
			    label      	"samStatusVariable"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusVariable"
			    quidu      	"44F2F6C90251"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMStatusSchemaForBusinessObjectNode"
		    quid       	"44FE69AF007B"
		    roles      	(list role_list
			(object Role "samStatusSchema"
			    attributes 	(list Attribute_Set)
			    quid       	"44FE69AF0392"
			    label      	"samStatusSchema"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusSchema"
			    quidu      	"44FE69A1022A"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "businessObjectNode"
			    quid       	"44FE69AF039C"
			    label      	"businessObjectNode"
			    supplier   	"Logical View::data::classes::SapClass"
			    quidu      	"4432171B031E"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMOperatorForSAMStatusSchema"
		    quid       	"44FE6ABF0276"
		    roles      	(list role_list
			(object Role "samOperators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6AC00097"
			    label      	"samOperators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMOperator"
			    quidu      	"44FE6A3D021D"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samStatusSchema"
			    quid       	"44FE6AC00099"
			    label      	"samStatusSchema"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusSchema"
			    quidu      	"44FE69A1022A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMSchemaVariableForSAMStatusSchema"
		    quid       	"44FE6C2F003D"
		    roles      	(list role_list
			(object Role "samSchemaVariables"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6C2F02BD"
			    label      	"samSchemaVariables"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaVariable"
			    quidu      	"44FE6B8503A2"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samStatusSchema"
			    quid       	"44FE6C2F02BF"
			    label      	"samStatusSchema"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusSchema"
			    quidu      	"44FE69A1022A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMSchemaValueForSAMSchemaVariable"
		    quid       	"44FE6C330331"
		    roles      	(list role_list
			(object Role "samSchemaValues"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6C340184"
			    label      	"samSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samSchemaVariable"
			    quid       	"44FE6C340186"
			    label      	"samSchemaVariable"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaVariable"
			    quidu      	"44FE6B8503A2"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMSchemaActionForSAMStatusSchema"
		    quid       	"44FE6C3700F2"
		    roles      	(list role_list
			(object Role "samSchemaActions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6C38002C"
			    label      	"samSchemaActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaAction"
			    quidu      	"44FE6C1503CE"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samStatusSchema"
			    quid       	"44FE6C38002E"
			    label      	"samStatusSchema"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusSchema"
			    quidu      	"44FE69A1022A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMSchemaActionForSAMAction"
		    quid       	"44FE6D36032C"
		    roles      	(list role_list
			(object Role "samSchemaActions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6D3702F2"
			    label      	"samSchemaActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaAction"
			    quidu      	"44FE6C1503CE"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samAction"
			    quid       	"44FE6D3702FC"
			    label      	"samAction"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMAction"
			    quidu      	"44F2F5E500D4"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)))
		(object Association "SAMSchemaVariableForSAMStatusVariable"
		    quid       	"44FE6D970034"
		    roles      	(list role_list
			(object Role "samSchemaVariables"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FE6D9703D7"
			    label      	"samSchemaVariables"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaVariable"
			    quidu      	"44FE6B8503A2"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSchemaValue"
			    quid       	"44FE6D9703D9"
			    label      	"samSchemaValue"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusVariable"
			    quidu      	"44F2F6C90251"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)))
		(object Association "SAMSchemaDerivatorForSAMDerivator"
		    quid       	"44FEAED3009B"
		    roles      	(list role_list
			(object Role "samSchemaDerivators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEAED5006C"
			    label      	"samSchemaDerivators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaDerivator"
			    quidu      	"44FEAD8A0233"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samDerivator"
			    quid       	"44FEAED5006E"
			    label      	"samDerivator"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMDerivator"
			    quidu      	"44FE57E30371"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE)))
		(object Association "SAMSchemaDerivatorForSAMStatusSchema"
		    quid       	"44FEB24F0374"
		    roles      	(list role_list
			(object Role "samSchemaDerivators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEB2510092"
			    label      	"samSchemaDerivators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaDerivator"
			    quidu      	"44FEAD8A0233"
			    client_cardinality 	(value cardinality "0..n")
			    Containment 	"By Value"
			    is_navigable 	TRUE)
			(object Role "samStatusSchema"
			    quid       	"44FEB2510094"
			    label      	"samStatusSchema"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMStatusSchema"
			    quidu      	"44FE69A1022A"
			    client_cardinality 	(value cardinality "1")
			    is_navigable 	TRUE
			    is_aggregate 	TRUE)))
		(object Association "SAMStatusTransition"
		    quid       	"44FEB45500C1"
		    roles      	(list role_list
			(object Role "samTargetSchemaValues"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEB4570100"
			    label      	"samTargetSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSourceSchemaActions"
			    quid       	"44FEB4570102"
			    label      	"samSourceSchemaActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaAction"
			    quidu      	"44FE6C1503CE"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMStatusSynchronizer"
		    quid       	"44FEB65A0222"
		    roles      	(list role_list
			(object Role "samSourceSchemaValues"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEB65C0225"
			    label      	"samSourceSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samTargetSchemaValues"
			    quid       	"44FEB65C022F"
			    label      	"samTargetSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMSchemaDerivatorForSAMSchemaVariable"
		    quid       	"44FEB9A40099"
		    roles      	(list role_list
			(object Role "samTargetSchemaDerivators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEB9A5020D"
			    label      	"samTargetSchemaDerivators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaDerivator"
			    quidu      	"44FEAD8A0233"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSourceSchemaVariables"
			    quid       	"44FEB9A50217"
			    label      	"samSourceSchemaVariables"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaVariable"
			    quidu      	"44FE6B8503A2"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMSchemaVariableForSAMSchemaDerivator"
		    quid       	"44FEB9AB03D9"
		    roles      	(list role_list
			(object Role "samTargetSchemaVariable"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEB9AC0253"
			    label      	"samTargetSchemaVariable"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaVariable"
			    quidu      	"44FE6B8503A2"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSourceSchemaDerivators"
			    quid       	"44FEB9AC0255"
			    label      	"samSourceSchemaDerivators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaDerivator"
			    quidu      	"44FEAD8A0233"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMNeutralPreconditonFromValueToOperator"
		    quid       	"44FEC2860117"
		    roles      	(list role_list
			(object Role "samOperators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEC288003D"
			    label      	"samOperators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMOperator"
			    quidu      	"44FE6A3D021D"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSchemaValues"
			    quid       	"44FEC288003F"
			    label      	"samSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE))
		    AssociationClass 	"SAMPrecondition")
		(object Association "SAMNeutralPreconditionFromOperatorToOperator"
		    quid       	"44FEC4A5007A"
		    roles      	(list role_list
			(object Role "samSourceOperators"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEC4A7031C"
			    label      	"samSourceOperators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMOperator"
			    quidu      	"44FE6A3D021D"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samTargetOperators"
			    quid       	"44FEC4A7031E"
			    label      	"samTargetOperators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMOperator"
			    quidu      	"44FE6A3D021D"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMPreconditionFromValueToAction"
		    quid       	"44FEC5DF0026"
		    roles      	(list role_list
			(object Role "samSchemaActions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEC5DF02E3"
			    label      	"samSchemaActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaAction"
			    quidu      	"44FE6C1503CE"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSchemaValues"
			    quid       	"44FEC5DF02E5"
			    label      	"samSchemaValues"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaValue"
			    quidu      	"44FE6C0901FA"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)))
		(object Association "SAMPreconditionFromOperatorToAction"
		    quid       	"44FEC6F90333"
		    roles      	(list role_list
			(object Role "samSchemaActions"
			    attributes 	(list Attribute_Set
				(object Attribute
				    tool       	"MOF"
				    name       	"sap2mof.store"
				    value      	("RoleStoreKindSet" 203)))
			    quid       	"44FEC6FA0398"
			    label      	"samSchemaActions"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMSchemaAction"
			    quidu      	"44FE6C1503CE"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE)
			(object Role "samSchemaOperators"
			    quid       	"44FEC6FA039A"
			    label      	"samSchemaOperators"
			    supplier   	"Logical View::behavioral::status_and_action_old::SAMOperator"
			    quidu      	"44FE6A3D021D"
			    client_cardinality 	(value cardinality "0..n")
			    is_navigable 	TRUE))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "StatusAndAction"
		    quid       	"44F2DCA202FB"
		    title      	"StatusAndAction"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMOperatorKindEnum" @318
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1004, 4647)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@318
				location   	(770, 4563)
				fill_color 	13434879
				nlines     	1
				max_width  	468
				justify    	0
				label      	"SAMOperatorKindEnum")
			    stereotype 	(object ItemLabel
				Parent_View 	@318
				location   	(770, 4513)
				fill_color 	13434879
				anchor     	10
				nlines     	1
				max_width  	468
				justify    	0
				label      	"<<enumeration>>")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FEA9990023"
			    width      	486
			    height     	292
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMDerivatorKindEnum" @319
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(4705, 274)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@319
				location   	(4472, 165)
				fill_color 	13434879
				nlines     	1
				max_width  	466
				justify    	0
				label      	"SAMDerivatorKindEnum")
			    stereotype 	(object ItemLabel
				Parent_View 	@319
				location   	(4472, 115)
				fill_color 	13434879
				anchor     	10
				nlines     	1
				max_width  	466
				justify    	0
				label      	"<<enumeration>>")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FEADB80062"
			    width      	484
			    height     	342
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::PreconditionKindEnum" @320
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1881, 4715)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@320
				location   	(1659, 4581)
				fill_color 	13434879
				nlines     	1
				max_width  	444
				justify    	0
				label      	"PreconditionKindEnum")
			    stereotype 	(object ItemLabel
				Parent_View 	@320
				location   	(1659, 4531)
				fill_color 	13434879
				anchor     	10
				nlines     	1
				max_width  	444
				justify    	0
				label      	"<<enumeration>>")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FEBD5B0230"
			    width      	462
			    height     	392
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMSchemaValue" @321
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2304, 3533)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@321
				location   	(2108, 3431)
				fill_color 	13434879
				nlines     	1
				max_width  	392
				justify    	0
				label      	"SAMSchemaValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE6C0901FA"
			    width      	410
			    height     	228
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMStatusSynchronizer" @322
			    location   	(2494, 3758)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @323
				Parent_View 	@322
				location   	(2358, 3722)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"SAMStatusSynchronizer"
				pctDist    	-1.783333
				height     	37
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEB65A0222"
			    roleview_list 	(list RoleViews
				(object RoleView "samSourceSchemaValues" @324
				    Parent_View 	@322
				    location   	(655, 216)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @325
					Parent_View 	@324
					location   	(2400, 3957)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	507
					justify    	0
					label      	"+samSourceSchemaValues"
					pctDist    	0.311961
					height     	199
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB65C0225"
				    client     	@322
				    supplier   	@321
				    vertices   	(list Points
					(2494, 3758)
					(2304, 3758)
					(2304, 3647))
				    line_style 	3
				    origin_attachment 	(2494, 3758)
				    terminal_attachment 	(2304, 3647)
				    label      	(object SegLabel @326
					Parent_View 	@324
					location   	(2252, 3660)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.955497
					height     	53
					orientation 	0))
				(object RoleView "samTargetSchemaValues" @327
				    Parent_View 	@322
				    location   	(655, 216)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @328
					Parent_View 	@327
					location   	(2531, 3650)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	491
					justify    	0
					label      	"+samTargetSchemaValues"
					pctDist    	0.513317
					height     	24
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB65C022F"
				    client     	@322
				    supplier   	@321
				    vertices   	(list Points
					(2494, 3758)
					(2554, 3758)
					(2554, 3533)
					(2509, 3533))
				    line_style 	3
				    origin_attachment 	(2494, 3758)
				    terminal_attachment 	(2509, 3533)
				    label      	(object SegLabel @329
					Parent_View 	@327
					location   	(2542, 3493)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.899872
					height     	41
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMOperator" @330
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(930, 3793)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@330
				location   	(646, 3715)
				fill_color 	13434879
				nlines     	1
				max_width  	568
				justify    	0
				label      	"SAMOperator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE6A3D021D"
			    width      	586
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMNeutralPreconditionFromOperatorToOperator" @331
			    location   	(141, 4204)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @332
				Parent_View 	@331
				location   	(256, 4254)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	905
				justify    	0
				label      	"SAMNeutralPreconditionFromOperatorToOperator"
				pctDist    	2.416667
				height     	50
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEC4A5007A"
			    roleview_list 	(list RoleViews
				(object RoleView "samSourceOperators" @333
				    Parent_View 	@331
				    location   	(-324, 402)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @334
					Parent_View 	@333
					location   	(651, 3983)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	425
					justify    	0
					label      	"+samSourceOperators"
					pctDist    	0.896809
					height     	129
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC4A7031C"
				    client     	@331
				    supplier   	@330
				    vertices   	(list Points
					(141, 4204)
					(779, 4204)
					(779, 3883))
				    line_style 	3
				    origin_attachment 	(141, 4204)
				    terminal_attachment 	(779, 3883)
				    label      	(object SegLabel @335
					Parent_View 	@333
					location   	(726, 3930)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.951715
					height     	54
					orientation 	0))
				(object RoleView "samTargetOperators" @336
				    Parent_View 	@331
				    location   	(-324, 402)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @337
					Parent_View 	@336
					location   	(406, 3812)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	394
					justify    	0
					label      	"+samTargetOperators"
					pctDist    	0.779825
					height     	41
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC4A7031E"
				    client     	@331
				    supplier   	@330
				    vertices   	(list Points
					(141, 4204)
					(81, 4204)
					(81, 3771)
					(637, 3771))
				    line_style 	3
				    origin_attachment 	(141, 4204)
				    terminal_attachment 	(637, 3771)
				    label      	(object SegLabel @338
					Parent_View 	@336
					location   	(541, 3741)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.909796
					height     	31
					orientation 	0))))
			(object AssociationViewNew "SAMNeutralPreconditonFromValueToOperator" @339
			    location   	(1742, 4019)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @340
				Parent_View 	@339
				location   	(1645, 4059)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	837
				justify    	0
				label      	"SAMNeutralPreconditonFromValueToOperator"
				pctDist    	-1.116667
				height     	40
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEC2860117"
			    roleview_list 	(list RoleViews
				(object RoleView "samOperators" @341
				    Parent_View 	@339
				    location   	(-97, 477)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @342
					Parent_View 	@341
					location   	(1068, 3911)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	290
					justify    	0
					label      	"+samOperators"
					pctDist    	0.966318
					height     	8
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC288003D"
				    client     	@339
				    supplier   	@330
				    vertices   	(list Points
					(1742, 4019)
					(1075, 4019)
					(1075, 3883))
				    line_style 	3
				    origin_attachment 	(1742, 4019)
				    terminal_attachment 	(1075, 3883)
				    label      	(object SegLabel @343
					Parent_View 	@341
					location   	(997, 3959)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.905923
					height     	79
					orientation 	0))
				(object RoleView "samSchemaValues" @344
				    Parent_View 	@339
				    location   	(-97, 477)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @345
					Parent_View 	@344
					location   	(1952, 3677)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	378
					justify    	0
					label      	"+samSchemaValues"
					pctDist    	0.962386
					height     	222
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC288003F"
				    client     	@339
				    supplier   	@321
				    vertices   	(list Points
					(1742, 4019)
					(2173, 4019)
					(2173, 3647))
				    line_style 	3
				    origin_attachment 	(1742, 4019)
				    terminal_attachment 	(2173, 3647)
				    label      	(object SegLabel @346
					Parent_View 	@344
					location   	(2114, 3728)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.899072
					height     	60
					orientation 	0))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMSchemaAction" @347
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2273, 1925)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@347
				location   	(2077, 1875)
				fill_color 	13434879
				nlines     	1
				max_width  	392
				justify    	0
				label      	"SAMSchemaAction")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE6C1503CE"
			    width      	410
			    height     	124
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMPreconditionFromOperatorToAction" @348
			    location   	(1894, 3135)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @349
				Parent_View 	@348
				location   	(1684, 3099)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	729
				justify    	0
				label      	"SAMPreconditionFromOperatorToAction"
				pctDist    	-3.000000
				height     	37
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEC6F90333"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaActions" @350
				    Parent_View 	@348
				    location   	(1429, -667)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @351
					Parent_View 	@350
					location   	(1918, 2091)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	405
					justify    	0
					label      	"+samSchemaActions"
					pctDist    	0.925110
					height     	213
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC6FA0398"
				    client     	@348
				    supplier   	@347
				    vertices   	(list Points
					(1894, 3135)
					(2130, 3135)
					(2130, 1987))
				    line_style 	3
				    origin_attachment 	(1894, 3135)
				    terminal_attachment 	(2130, 1987)
				    label      	(object SegLabel @352
					Parent_View 	@350
					location   	(2175, 2021)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.975820
					height     	45
					orientation 	1))
				(object RoleView "samSchemaOperators" @353
				    Parent_View 	@348
				    location   	(1429, -667)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @354
					Parent_View 	@353
					location   	(1001, 3577)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	440
					justify    	0
					label      	"+samSchemaOperators"
					pctDist    	0.909159
					height     	78
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC6FA039A"
				    client     	@348
				    supplier   	@330
				    vertices   	(list Points
					(1894, 3135)
					(1078, 3135)
					(1078, 3703))
				    line_style 	3
				    origin_attachment 	(1894, 3135)
				    terminal_attachment 	(1078, 3703)
				    label      	(object SegLabel @355
					Parent_View 	@353
					location   	(1121, 3637)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.951952
					height     	43
					orientation 	0))))
			(object AssociationViewNew "SAMStatusTransition" @356
			    location   	(2432, 2703)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @357
				Parent_View 	@356
				location   	(2523, 3050)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	450
				justify    	0
				label      	"SAMStatusTransition"
				pctDist    	2.033333
				height     	347
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEB45500C1"
			    roleview_list 	(list RoleViews
				(object RoleView "samTargetSchemaValues" @358
				    Parent_View 	@356
				    location   	(608, 394)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @359
					Parent_View 	@358
					location   	(2579, 3270)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	493
					justify    	0
					label      	"+samTargetSchemaValues"
					pctDist    	0.792426
					height     	147
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB4570100"
				    client     	@356
				    supplier   	@321
				    vertices   	(list Points
					(2432, 2703)
					(2432, 3419))
				    line_style 	3
				    origin_attachment 	(2432, 2703)
				    terminal_attachment 	(2432, 3419)
				    label      	(object SegLabel @360
					Parent_View 	@358
					location   	(2486, 3347)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "samSourceSchemaActions" @361
				    Parent_View 	@356
				    location   	(608, 394)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @362
					Parent_View 	@361
					location   	(2644, 2126)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	520
					justify    	0
					label      	"+samSourceSchemaActions"
					pctDist    	0.806452
					height     	212
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB4570102"
				    client     	@356
				    supplier   	@347
				    vertices   	(list Points
					(2432, 2703)
					(2432, 1987))
				    line_style 	3
				    origin_attachment 	(2432, 2703)
				    terminal_attachment 	(2432, 1987)
				    label      	(object SegLabel @363
					Parent_View 	@361
					location   	(2485, 2030)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.940341
					height     	53
					orientation 	1))))
			(object AssociationViewNew "SAMPreconditionFromValueToAction" @364
			    location   	(2251, 2702)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @365
				Parent_View 	@364
				location   	(2302, 2559)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	688
				justify    	0
				label      	"SAMPreconditionFromValueToAction"
				pctDist    	1.350000
				height     	144
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEC5DF0026"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaActions" @366
				    Parent_View 	@364
				    location   	(412, -840)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @367
					Parent_View 	@366
					location   	(2276, 2171)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	405
					justify    	0
					label      	"+samSchemaActions"
					pctDist    	0.741573
					height     	25
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC5DF02E3"
				    client     	@364
				    supplier   	@347
				    vertices   	(list Points
					(2251, 2702)
					(2251, 1986))
				    line_style 	3
				    origin_attachment 	(2251, 2702)
				    terminal_attachment 	(2251, 1986)
				    label      	(object SegLabel @368
					Parent_View 	@366
					location   	(2318, 2028)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.940952
					height     	67
					orientation 	1))
				(object RoleView "samSchemaValues" @369
				    Parent_View 	@364
				    location   	(412, -840)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @370
					Parent_View 	@369
					location   	(2067, 3284)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	378
					justify    	0
					label      	"+samSchemaValues"
					pctDist    	0.812062
					height     	185
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEC5DF02E5"
				    client     	@364
				    supplier   	@321
				    vertices   	(list Points
					(2251, 2702)
					(2251, 3419))
				    line_style 	3
				    origin_attachment 	(2251, 2702)
				    terminal_attachment 	(2251, 3419)
				    label      	(object SegLabel @371
					Parent_View 	@369
					location   	(2305, 3347)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMStatusValue" @372
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3743, 2198)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@372
				location   	(3573, 2120)
				fill_color 	13434879
				nlines     	1
				max_width  	340
				justify    	0
				label      	"SAMStatusValue")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE5BF60070"
			    width      	358
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMSchemaVariable" @373
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3031, 2840)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@373
				location   	(2791, 2762)
				fill_color 	13434879
				nlines     	1
				max_width  	480
				justify    	0
				label      	"SAMSchemaVariable")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE6B8503A2"
			    width      	498
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMSchemaValueForSAMSchemaVariable" @374
			    location   	(3019, 3439)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @375
				Parent_View 	@374
				location   	(3080, 3360)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	785
				justify    	0
				label      	"SAMSchemaValueForSAMSchemaVariable"
				pctDist    	1.533333
				height     	80
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6C330331"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaValues" @376
				    Parent_View 	@374
				    location   	(1322, 861)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @377
					Parent_View 	@376
					location   	(2741, 3464)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	375
					justify    	0
					label      	"+samSchemaValues"
					pctDist    	0.595122
					height     	36
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C340184"
				    client     	@374
				    supplier   	@321
				    vertices   	(list Points
					(3019, 3439)
					(3019, 3499)
					(2509, 3499))
				    line_style 	3
				    origin_attachment 	(3019, 3439)
				    terminal_attachment 	(2509, 3499)
				    label      	(object SegLabel @378
					Parent_View 	@376
					location   	(2557, 3433)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.916667
					height     	67
					orientation 	1))
				(object RoleView "samSchemaVariable" @379
				    Parent_View 	@374
				    location   	(1322, 861)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @380
					Parent_View 	@379
					location   	(2984, 3052)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	397
					justify    	0
					label      	"+samSchemaVariable"
					pctDist    	0.762646
					height     	36
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C340186"
				    client     	@374
				    supplier   	@373
				    vertices   	(list Points
					(3019, 3439)
					(3019, 2930))
				    line_style 	3
				    origin_attachment 	(3019, 3439)
				    terminal_attachment 	(3019, 2930)
				    label      	(object SegLabel @381
					Parent_View 	@379
					location   	(3073, 2982)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMSchemaDerivator" @382
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(4387, 2484)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@382
				location   	(4173, 2434)
				fill_color 	13434879
				nlines     	1
				max_width  	428
				justify    	0
				label      	"SAMSchemaDerivator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FEAD8A0233"
			    width      	446
			    height     	124
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMSchemaDerivatorForSAMSchemaVariable" @383
			    location   	(3884, 2777)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @384
				Parent_View 	@383
				location   	(4028, 2677)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	859
				justify    	0
				label      	"SAMSchemaDerivatorForSAMSchemaVariable"
				pctDist    	2.900000
				height     	101
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEB9A40099"
			    roleview_list 	(list RoleViews
				(object RoleView "samTargetSchemaDerivators" @385
				    Parent_View 	@383
				    location   	(1318, -72)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @386
					Parent_View 	@385
					location   	(3998, 2602)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	575
					justify    	0
					label      	"+samTargetSchemaDerivators"
					pctDist    	0.188216
					height     	176
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB9A5020D"
				    client     	@383
				    supplier   	@382
				    vertices   	(list Points
					(3884, 2777)
					(4258, 2777)
					(4258, 2546))
				    line_style 	3
				    origin_attachment 	(3884, 2777)
				    terminal_attachment 	(4258, 2546)
				    label      	(object SegLabel @387
					Parent_View 	@385
					location   	(4318, 2584)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.937807
					height     	60
					orientation 	1))
				(object RoleView "samSourceSchemaVariables" @388
				    Parent_View 	@383
				    location   	(1318, -72)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @389
					Parent_View 	@388
					location   	(3650, 2742)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	555
					justify    	0
					label      	"+samSourceSchemaVariables"
					pctDist    	0.389525
					height     	36
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB9A50217"
				    client     	@383
				    supplier   	@373
				    vertices   	(list Points
					(3884, 2777)
					(3280, 2777))
				    line_style 	3
				    origin_attachment 	(3884, 2777)
				    terminal_attachment 	(3280, 2777)
				    label      	(object SegLabel @390
					Parent_View 	@388
					location   	(3336, 2737)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.908197
					height     	41
					orientation 	1))))
			(object AssociationViewNew "SAMSchemaVariableForSAMSchemaDerivator" @391
			    location   	(4085, 2893)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @392
				Parent_View 	@391
				location   	(4467, 2932)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	852
				justify    	0
				label      	"SAMSchemaVariableForSAMSchemaDerivator"
				pctDist    	6.883333
				height     	39
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEB9AB03D9"
			    roleview_list 	(list RoleViews
				(object RoleView "samTargetSchemaVariable" @393
				    Parent_View 	@391
				    location   	(163, 400)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @394
					Parent_View 	@393
					location   	(3669, 2937)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	525
					justify    	0
					label      	"+samTargetSchemaVariable"
					pctDist    	0.518610
					height     	44
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB9AC0253"
				    client     	@391
				    supplier   	@373
				    vertices   	(list Points
					(4085, 2893)
					(3280, 2893))
				    line_style 	3
				    origin_attachment 	(4085, 2893)
				    terminal_attachment 	(3280, 2893)
				    label      	(object SegLabel @395
					Parent_View 	@393
					location   	(3342, 2924)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.923077
					height     	31
					orientation 	0))
				(object RoleView "samSourceSchemaDerivators" @396
				    Parent_View 	@391
				    location   	(163, 400)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @397
					Parent_View 	@396
					location   	(4803, 2638)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	575
					justify    	0
					label      	"+samSourceSchemaDerivators"
					pctDist    	0.887097
					height     	259
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB9AC0255"
				    client     	@391
				    supplier   	@382
				    vertices   	(list Points
					(4085, 2893)
					(4544, 2893)
					(4544, 2546))
				    line_style 	3
				    origin_attachment 	(4085, 2893)
				    terminal_attachment 	(4544, 2546)
				    label      	(object SegLabel @398
					Parent_View 	@396
					location   	(4595, 2581)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.956576
					height     	51
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMStatusSchema" @399
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(1031, 2375)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@399
				location   	(835, 2297)
				fill_color 	13434879
				nlines     	1
				max_width  	392
				justify    	0
				label      	"SAMStatusSchema")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE69A1022A"
			    width      	410
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMSchemaDerivatorForSAMStatusSchema" @400
			    location   	(2700, 2435)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @401
				Parent_View 	@400
				location   	(3125, 2391)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	817
				justify    	0
				label      	"SAMSchemaDerivatorForSAMStatusSchema"
				pctDist    	7.600000
				height     	45
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEB24F0374"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaDerivators" @402
				    Parent_View 	@400
				    location   	(2079, 91)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @403
					Parent_View 	@402
					location   	(3871, 2394)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	440
					justify    	0
					label      	"+samSchemaDerivators"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB2510092"
				    client     	@400
				    supplier   	@382
				    vertices   	(list Points
					(2700, 2435)
					(4164, 2435))
				    line_style 	3
				    origin_attachment 	(2700, 2435)
				    terminal_attachment 	(4164, 2435)
				    label      	(object SegLabel @404
					Parent_View 	@402
					location   	(4108, 2460)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.962432
					height     	25
					orientation 	1))
				(object RoleView "samStatusSchema" @405
				    Parent_View 	@400
				    location   	(2079, 91)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @406
					Parent_View 	@405
					location   	(1477, 2396)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	372
					justify    	0
					label      	"+samStatusSchema"
					pctDist    	0.835383
					height     	40
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEB2510094"
				    client     	@400
				    supplier   	@399
				    vertices   	(list Points
					(2700, 2435)
					(1236, 2435))
				    line_style 	3
				    origin_attachment 	(2700, 2435)
				    terminal_attachment 	(1236, 2435)
				    label      	(object SegLabel @407
					Parent_View 	@405
					location   	(1383, 2489)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object AssociationViewNew "SAMSchemaActionForSAMStatusSchema" @408
			    location   	(1458, 1940)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @409
				Parent_View 	@408
				location   	(1492, 1836)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	774
				justify    	0
				label      	"SAMSchemaActionForSAMStatusSchema"
				pctDist    	1.066667
				height     	105
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6C3700F2"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaActions" @410
				    Parent_View 	@408
				    location   	(750, -426)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @411
					Parent_View 	@410
					location   	(1815, 1906)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	405
					justify    	0
					label      	"+samSchemaActions"
					pctDist    	0.584590
					height     	35
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C38002C"
				    client     	@408
				    supplier   	@347
				    vertices   	(list Points
					(1458, 1940)
					(2068, 1940))
				    line_style 	3
				    origin_attachment 	(1458, 1940)
				    terminal_attachment 	(2068, 1940)
				    label      	(object SegLabel @412
					Parent_View 	@410
					location   	(1971, 1969)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.843234
					height     	29
					orientation 	1))
				(object RoleView "samStatusSchema" @413
				    Parent_View 	@408
				    location   	(750, -426)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @414
					Parent_View 	@413
					location   	(1241, 2034)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	369
					justify    	0
					label      	"+samStatusSchema"
					pctDist    	0.588138
					height     	48
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C38002E"
				    client     	@408
				    supplier   	@399
				    vertices   	(list Points
					(1458, 1940)
					(1193, 1940)
					(1193, 2285))
				    line_style 	3
				    origin_attachment 	(1458, 1940)
				    terminal_attachment 	(1193, 2285)
				    label      	(object SegLabel @415
					Parent_View 	@413
					location   	(1247, 2224)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))
			(object AssociationViewNew "SAMOperatorForSAMStatusSchema" @416
			    location   	(919, 3083)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @417
				Parent_View 	@416
				location   	(908, 3096)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	658
				justify    	0
				label      	"SAMOperatorForSAMStatusSchema"
				pctDist    	0.316667
				height     	13
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6ABF0276"
			    roleview_list 	(list RoleViews
				(object RoleView "samOperators" @418
				    Parent_View 	@416
				    location   	(152, 1139)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @419
					Parent_View 	@418
					location   	(778, 3591)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	291
					justify    	0
					label      	"+samOperators"
					pctDist    	0.822086
					height     	142
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6AC00097"
				    client     	@416
				    supplier   	@330
				    vertices   	(list Points
					(919, 3083)
					(919, 3702))
				    line_style 	3
				    origin_attachment 	(919, 3083)
				    terminal_attachment 	(919, 3702)
				    label      	(object SegLabel @420
					Parent_View 	@418
					location   	(870, 3652)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.918712
					height     	50
					orientation 	1))
				(object RoleView "samStatusSchema" @421
				    Parent_View 	@416
				    location   	(152, 1139)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @422
					Parent_View 	@421
					location   	(844, 2661)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	372
					justify    	0
					label      	"+samStatusSchema"
					pctDist    	0.682451
					height     	76
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6AC00099"
				    client     	@416
				    supplier   	@399
				    vertices   	(list Points
					(919, 3083)
					(919, 2465))
				    line_style 	3
				    origin_attachment 	(919, 3083)
				    terminal_attachment 	(919, 2465)
				    label      	(object SegLabel @423
					Parent_View 	@421
					location   	(877, 2591)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.796012
					height     	43
					orientation 	0))))
			(object AssociationViewNew "SAMSchemaVariableForSAMStatusSchema" @424
			    location   	(1815, 2793)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @425
				Parent_View 	@424
				location   	(1682, 2743)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	800
				justify    	0
				label      	"SAMSchemaVariableForSAMStatusSchema"
				pctDist    	-1.733333
				height     	51
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6C2F003D"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaVariables" @426
				    Parent_View 	@424
				    location   	(1107, 427)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @427
					Parent_View 	@426
					location   	(2507, 2821)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	437
					justify    	0
					label      	"+samSchemaVariables"
					pctDist    	0.716033
					height     	28
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C2F02BD"
				    client     	@424
				    supplier   	@373
				    vertices   	(list Points
					(1815, 2793)
					(2782, 2793))
				    line_style 	3
				    origin_attachment 	(1815, 2793)
				    terminal_attachment 	(2782, 2793)
				    label      	(object SegLabel @428
					Parent_View 	@426
					location   	(2692, 2748)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.906902
					height     	46
					orientation 	0))
				(object RoleView "samStatusSchema" @429
				    Parent_View 	@424
				    location   	(1107, 427)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @430
					Parent_View 	@429
					location   	(1168, 2600)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	369
					justify    	0
					label      	"+samStatusSchema"
					pctDist    	0.861702
					height     	8
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6C2F02BF"
				    client     	@424
				    supplier   	@399
				    vertices   	(list Points
					(1815, 2793)
					(1175, 2793)
					(1175, 2465))
				    line_style 	3
				    origin_attachment 	(1815, 2793)
				    terminal_attachment 	(1175, 2465)
				    label      	(object SegLabel @431
					Parent_View 	@429
					location   	(1134, 2534)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.928465
					height     	42
					orientation 	0))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMAction" @432
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(2446, 918)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@432
				location   	(2220, 816)
				fill_color 	13434879
				nlines     	1
				max_width  	452
				justify    	0
				label      	"SAMAction")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44F2F5E500D4"
			    width      	470
			    height     	228
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMSchemaActionForSAMAction" @433
			    location   	(2466, 1447)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @434
				Parent_View 	@433
				location   	(2460, 1467)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	620
				justify    	0
				label      	"SAMSchemaActionForSAMAction"
				pctDist    	0.400000
				height     	20
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6D36032C"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaActions" @435
				    Parent_View 	@433
				    location   	(346, 535)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @436
					Parent_View 	@435
					location   	(2430, 1785)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	405
					justify    	0
					label      	"+samSchemaActions"
					pctDist    	0.815534
					height     	37
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6D3702F2"
				    client     	@433
				    supplier   	@347
				    vertices   	(list Points
					(2466, 1447)
					(2466, 1862))
				    line_style 	3
				    origin_attachment 	(2466, 1447)
				    terminal_attachment 	(2466, 1862)
				    label      	(object SegLabel @437
					Parent_View 	@435
					location   	(2519, 1831)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.928230
					height     	53
					orientation 	0))
				(object RoleView "samAction" @438
				    Parent_View 	@433
				    location   	(346, 535)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @439
					Parent_View 	@438
					location   	(2425, 1115)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	222
					justify    	0
					label      	"+samAction"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6D3702FC"
				    client     	@433
				    supplier   	@432
				    vertices   	(list Points
					(2466, 1447)
					(2466, 1032))
				    line_style 	3
				    origin_attachment 	(2466, 1447)
				    terminal_attachment 	(2466, 1032)
				    label      	(object SegLabel @440
					Parent_View 	@438
					location   	(2520, 1074)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMStatusVariable" @441
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3161, 1424)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@441
				location   	(2916, 1322)
				fill_color 	13434879
				nlines     	1
				max_width  	490
				justify    	0
				label      	"SAMStatusVariable")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44F2F6C90251"
			    width      	508
			    height     	228
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMStatusValueForSAMStatusVariable" @442
			    location   	(3379, 1860)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @443
				Parent_View 	@442
				location   	(3385, 1907)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	737
				justify    	0
				label      	"SAMStatusValueForSAMStatusVariable"
				pctDist    	0.600000
				height     	47
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE5CE401A3"
			    roleview_list 	(list RoleViews
				(object RoleView "samStatusValues" @444
				    Parent_View 	@442
				    location   	(1561, 404)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @445
					Parent_View 	@444
					location   	(3604, 2021)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	361
					justify    	0
					label      	"+samStatusValues"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE5CE5000A"
				    client     	@442
				    supplier   	@372
				    vertices   	(list Points
					(3379, 1860)
					(3562, 1860)
					(3562, 2108))
				    line_style 	3
				    origin_attachment 	(3379, 1860)
				    terminal_attachment 	(3562, 2108)
				    label      	(object SegLabel @446
					Parent_View 	@444
					location   	(3616, 2064)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "samStatusVariable" @447
				    Parent_View 	@442
				    location   	(1561, 404)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @448
					Parent_View 	@447
					location   	(3288, 1624)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	371
					justify    	0
					label      	"+samStatusVariable"
					pctDist    	0.800781
					height     	19
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE5CE5000C"
				    client     	@442
				    supplier   	@441
				    vertices   	(list Points
					(3379, 1860)
					(3269, 1860)
					(3269, 1538))
				    line_style 	3
				    origin_attachment 	(3379, 1860)
				    terminal_attachment 	(3269, 1538)
				    label      	(object SegLabel @449
					Parent_View 	@447
					location   	(3323, 1582)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object AssociationViewNew "SAMSchemaVariableForSAMStatusVariable" @450
			    location   	(3006, 2207)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @451
				Parent_View 	@450
				location   	(3032, 2131)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	803
				justify    	0
				label      	"SAMSchemaVariableForSAMStatusVariable"
				pctDist    	0.950000
				height     	77
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE6D970034"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaVariables" @452
				    Parent_View 	@450
				    location   	(950, 654)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @453
					Parent_View 	@452
					location   	(2906, 2630)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	437
					justify    	0
					label      	"+samSchemaVariables"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6D9703D7"
				    client     	@450
				    supplier   	@373
				    vertices   	(list Points
					(3006, 2207)
					(2947, 2207)
					(2947, 2750))
				    line_style 	3
				    origin_attachment 	(3006, 2207)
				    terminal_attachment 	(2947, 2750)
				    label      	(object SegLabel @454
					Parent_View 	@452
					location   	(3001, 2690)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "samSchemaValue" @455
				    Parent_View 	@450
				    location   	(950, 654)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @456
					Parent_View 	@455
					location   	(3026, 1806)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	359
					justify    	0
					label      	"+samSchemaValue"
					pctDist    	0.634409
					height     	41
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE6D9703D9"
				    client     	@450
				    supplier   	@441
				    vertices   	(list Points
					(3006, 2207)
					(3066, 2207)
					(3066, 1538))
				    line_style 	3
				    origin_attachment 	(3006, 2207)
				    terminal_attachment 	(3066, 1538)
				    label      	(object SegLabel @457
					Parent_View 	@455
					location   	(3120, 1612)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::behavioral::status_and_action_old::SAMDerivator" @458
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(3884, 216)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@458
				location   	(3599, 138)
				fill_color 	13434879
				nlines     	1
				max_width  	570
				justify    	0
				label      	"SAMDerivator")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"44FE57E30371"
			    width      	588
			    height     	180
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMSchemaDerivatorForSAMDerivator" @459
			    location   	(4239, 1298)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @460
				Parent_View 	@459
				location   	(4228, 1489)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	715
				justify    	0
				label      	"SAMSchemaDerivatorForSAMDerivator"
				pctDist    	0.333333
				height     	191
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FEAED3009B"
			    roleview_list 	(list RoleViews
				(object RoleView "samSchemaDerivators" @461
				    Parent_View 	@459
				    location   	(1884, 1073)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @462
					Parent_View 	@461
					location   	(4198, 2197)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	440
					justify    	0
					label      	"+samSchemaDerivators"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEAED5006C"
				    client     	@459
				    supplier   	@382
				    vertices   	(list Points
					(4239, 1298)
					(4239, 2422))
				    line_style 	3
				    origin_attachment 	(4239, 1298)
				    terminal_attachment 	(4239, 2422)
				    label      	(object SegLabel @463
					Parent_View 	@461
					location   	(4293, 2310)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "samDerivator" @464
				    Parent_View 	@459
				    location   	(1884, 1073)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @465
					Parent_View 	@464
					location   	(4198, 399)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	260
					justify    	0
					label      	"+samDerivator"
					pctDist    	0.800000
					height     	42
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FEAED5006E"
				    client     	@459
				    supplier   	@458
				    vertices   	(list Points
					(4239, 1298)
					(4239, 227)
					(4178, 227))
				    line_style 	3
				    origin_attachment 	(4239, 1298)
				    terminal_attachment 	(4178, 227)
				    label      	(object SegLabel @466
					Parent_View 	@464
					location   	(4293, 286)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	1))))
			(object ClassView "Class" "Logical View::data::classes::SapClass" @467
			    ShowCompartmentStereotypes 	TRUE
			    IncludeAttribute 	TRUE
			    IncludeOperation 	TRUE
			    location   	(899, 767)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@467
				location   	(554, 309)
				fill_color 	13434879
				nlines     	1
				max_width  	690
				justify    	0
				label      	"SapClass")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4432171B031E"
			    width      	708
			    height     	940
			    annotation 	8
			    autoResize 	TRUE)
			(object AssociationViewNew "SAMStatusSchemaForBusinessObjectNode" @468
			    location   	(369, 1807)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @469
				Parent_View 	@468
				location   	(369, 1748)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	797
				justify    	0
				label      	"SAMStatusSchemaForBusinessObjectNode"
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE69AF007B"
			    roleview_list 	(list RoleViews
				(object RoleView "samStatusSchema" @470
				    Parent_View 	@468
				    location   	(-70, 776)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @471
					Parent_View 	@470
					location   	(611, 2349)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	372
					justify    	0
					label      	"+samStatusSchema"
					pctDist    	0.800000
					height     	42
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE69AF0392"
				    client     	@468
				    supplier   	@399
				    vertices   	(list Points
					(369, 1807)
					(309, 1807)
					(309, 2307)
					(826, 2307))
				    line_style 	3
				    origin_attachment 	(369, 1807)
				    terminal_attachment 	(826, 2307)
				    label      	(object SegLabel @472
					Parent_View 	@470
					location   	(718, 2254)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "businessObjectNode" @473
				    Parent_View 	@468
				    location   	(-70, 776)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @474
					Parent_View 	@473
					location   	(632, 1322)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	400
					justify    	0
					label      	"+businessObjectNode"
					pctDist    	0.921912
					height     	240
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE69AF039C"
				    client     	@468
				    supplier   	@467
				    vertices   	(list Points
					(369, 1807)
					(871, 1807)
					(871, 1237))
				    line_style 	3
				    origin_attachment 	(369, 1807)
				    terminal_attachment 	(871, 1237)
				    label      	(object SegLabel @475
					Parent_View 	@473
					location   	(926, 1309)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.933865
					height     	55
					orientation 	1))))
			(object AssociationViewNew "SAMActionForBusinessObjectNode" @476
			    location   	(1828, 721)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @477
				Parent_View 	@476
				location   	(1858, 785)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	651
				justify    	0
				label      	"SAMActionForBusinessObjectNode"
				pctDist    	1.000000
				height     	64
				orientation 	1)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44F2F5F002C6"
			    roleview_list 	(list RoleViews
				(object RoleView "samActions" @478
				    Parent_View 	@476
				    location   	(1319, 443)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @479
					Parent_View 	@478
					location   	(2258, 683)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	238
					justify    	0
					label      	"+samActions"
					pctDist    	0.751004
					height     	39
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44F2F5F1012D"
				    client     	@476
				    supplier   	@432
				    vertices   	(list Points
					(1828, 721)
					(2319, 721)
					(2319, 804))
				    line_style 	3
				    origin_attachment 	(1828, 721)
				    terminal_attachment 	(2319, 804)
				    label      	(object SegLabel @480
					Parent_View 	@478
					location   	(2373, 747)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	0))
				(object RoleView "businessObjectNode" @481
				    Parent_View 	@476
				    location   	(1319, 443)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @482
					Parent_View 	@481
					location   	(1496, 675)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	411
					justify    	0
					label      	"+businessObjectNode"
					pctDist    	0.576541
					height     	47
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44F2F5F1012F"
				    client     	@476
				    supplier   	@467
				    vertices   	(list Points
					(1828, 721)
					(1253, 721))
				    line_style 	3
				    origin_attachment 	(1828, 721)
				    terminal_attachment 	(1253, 721)
				    label      	(object SegLabel @483
					Parent_View 	@481
					location   	(1316, 759)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.891129
					height     	38
					orientation 	0))))
			(object AssociationViewNew "SAMStatusVariableForBusinessObjectNode" @484
			    location   	(1887, 1394)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @485
				Parent_View 	@484
				location   	(2037, 1310)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	809
				justify    	0
				label      	"SAMStatusVariableForBusinessObjectNode"
				pctDist    	3.000000
				height     	85
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44F2F6E50128"
			    roleview_list 	(list RoleViews
				(object RoleView "samStatusVariables" @486
				    Parent_View 	@484
				    location   	(1359, 988)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @487
					Parent_View 	@486
					location   	(2517, 1372)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	407
					justify    	0
					label      	"+samStatusVariables"
					pctDist    	0.619048
					height     	23
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44F2F6E600E4"
				    client     	@484
				    supplier   	@441
				    vertices   	(list Points
					(1887, 1394)
					(2907, 1394))
				    line_style 	3
				    origin_attachment 	(1887, 1394)
				    terminal_attachment 	(2907, 1394)
				    label      	(object SegLabel @488
					Parent_View 	@486
					location   	(2816, 1426)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.912230
					height     	32
					orientation 	1))
				(object RoleView "businessObjectNode" @489
				    Parent_View 	@484
				    location   	(1359, 988)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @490
					Parent_View 	@489
					location   	(1103, 1433)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	411
					justify    	0
					label      	"+businessObjectNode"
					pctDist    	0.769038
					height     	39
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44F2F6E600E6"
				    client     	@484
				    supplier   	@467
				    vertices   	(list Points
					(1887, 1394)
					(1024, 1394)
					(1024, 1237))
				    line_style 	3
				    origin_attachment 	(1887, 1394)
				    terminal_attachment 	(1024, 1237)
				    label      	(object SegLabel @491
					Parent_View 	@489
					location   	(983, 1271)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.966527
					height     	42
					orientation 	0))))
			(object AssociationViewNew "SAMDerivatorForBusinessObject" @492
			    location   	(2421, 485)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object SegLabel @493
				Parent_View 	@492
				location   	(2421, 426)
				font       	(object Font
				    size       	10
				    face       	"Arial"
				    bold       	FALSE
				    italics    	TRUE
				    underline  	FALSE
				    strike     	FALSE
				    color      	0
				    default_color 	TRUE)
				anchor     	1
				anchor_loc 	1
				nlines     	1
				max_width  	601
				justify    	0
				label      	"SAMDerivatorForBusinessObject"
				pctDist    	0.500000
				height     	60
				orientation 	0)
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"44FE5B2400EF"
			    roleview_list 	(list RoleViews
				(object RoleView "samDerivators" @494
				    Parent_View 	@492
				    location   	(1977, 270)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @495
					Parent_View 	@494
					location   	(3374, 269)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	280
					justify    	0
					label      	"+samDerivators"
					pctDist    	0.821949
					height     	41
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE5B2402E4"
				    client     	@492
				    supplier   	@458
				    vertices   	(list Points
					(2421, 485)
					(3589, 269))
				    line_style 	0
				    label      	(object SegLabel @496
					Parent_View 	@494
					location   	(3482, 344)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"0..n"
					pctDist    	0.900000
					height     	54
					orientation 	1))
				(object RoleView "businessObject" @497
				    Parent_View 	@492
				    location   	(1977, 270)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @498
					Parent_View 	@497
					location   	(1465, 626)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	317
					justify    	0
					label      	"+businessObject"
					pctDist    	0.813464
					height     	37
					orientation 	1)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"44FE5B2402E6"
				    client     	@492
				    supplier   	@467
				    vertices   	(list Points
					(2421, 485)
					(1253, 700))
				    line_style 	0
				    label      	(object SegLabel @499
					Parent_View 	@497
					location   	(1380, 732)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	FALSE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	2
					anchor_loc 	1
					nlines     	1
					max_width  	15
					justify    	0
					label      	"1"
					pctDist    	0.900000
					height     	54
					orientation 	0))))))))
	(object Class_Category "status_and_action"
	    attributes 	(list Attribute_Set)
	    quid       	"474A122E006C"
	    documentation 	
|S&AM is mostly about pre- and post-conditions for invocation of signatures. The abstraction that S&AM adds over simple pre/post constraints is that it groups parts of an object's state into what is called a status variable. Status variables furthermore are expected to have a finite set of possible values.
|
|Synchronizers are used to set the status of a status variable. This means that for those status variables (if they are implemented only by a signature) there must be a writing signature that allows for setting the value. Conceptually, synchronizers seem a bit like an event subscription with the condition that a status variable assumes a certain value, and the event listener sets the value of another status variable to a given value.
|
|Status population also does a setting of status variables. Viewn from the other side, this looks like a status variable is derived from the values of other status variables. Again, this could be expressed as a signature with a corresponding implementation that acts as a status variable signature. Impact analysis could be performed for the implementation to determine when the value changes.
|
|Given a full-blown boolean expression algebra, only a subset of the expressions can be modeled in S&AM. Also, if the type of a status variable has an infinite (or very large) value set, modeling with the S&AM notation gets unwieldy.
|
|From a distance, it seems that S&AM is a graphical notation for a specific subset of pre/post constraints over "status functions" and invocable signatures.
|
|S&AM could be regarded a view on other constraint and event registration metadata, but that would be difficult to bring, e.g., into a graphical notation.
	    
	    exportControl 	"Public"
	    logical_models 	(list unit_reference_list
		(object Class_Category "design"
		    quid       	"4743818802D4"
		    exportControl 	"Public"
		    logical_models 	(list unit_reference_list
			(object Class "BusinessObject"
			    quid       	"474381C1025F"
			    used_nodes 	(list uses_relationship_list
				(object Uses_Relationship
				    quid       	"474381E80189"
				    supplier   	"Logical View::behavioral::status_and_action::design::BusinessObjectNode"
				    quidu      	"474381D302BF")))
			(object Class "BusinessObjectNode"
			    quid       	"474381D302BF"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"479580FA0128"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030")))
			(object Class "StatusVariable"
			    quid       	"474382660242"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"474A0AC70112"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusVariable"
				    quidu      	"474A08690112")))
			(object Class "StatusValue"
			    quid       	"474384A700EC"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"474A0AC001FD"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusValue"
				    quidu      	"474A091C02AC")))
			(object Class "Action"
			    quid       	"4743854A01DA"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"474A0A270236"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractAction"
				    quidu      	"474A09310202")))
			(object Class "AbstractStatusVariable"
			    quid       	"474A08690112"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47958101008C"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030"))
			    class_attributes 	(list class_attribute_list
				(object ClassAttribute "isAgent"
				    quid       	"474A087800C7"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public")
				(object ClassAttribute "isStateGuarded"
				    quid       	"474A087D003C"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public"))
			    abstract   	TRUE)
			(object Class "AbstractStatusValue"
			    quid       	"474A091C02AC"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"479580FE0119"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030"))
			    class_attributes 	(list class_attribute_list
				(object ClassAttribute "isInitial"
				    quid       	"474A0A8C016E"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public")
				(object ClassAttribute "isInhibiting"
				    quid       	"474A0A920065"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public")
				(object ClassAttribute "isStateGuarded"
				    quid       	"474A0A980334"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public"))
			    abstract   	TRUE)
			(object Class "AbstractAction"
			    quid       	"474A09310202"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"479580F200DA"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030"))
			    class_attributes 	(list class_attribute_list
				(object ClassAttribute "isAgent"
				    quid       	"474A0A300071"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public")
				(object ClassAttribute "isPreconditionFixed"
				    quid       	"474A0A35012D"
				    type       	"Boolean"
				    quidu      	"39A2BDA60392"
				    exportControl 	"Public"))
			    abstract   	TRUE)
			(object Association "BusinessObjectHasNodes"
			    quid       	"4743821A02B7"
			    roles      	(list role_list
				(object Role "nodes"
				    quid       	"4743821B00D3"
				    label      	"nodes"
				    supplier   	"Logical View::behavioral::status_and_action::design::BusinessObjectNode"
				    quidu      	"474381D302BF"
				    client_cardinality 	(value cardinality "0..n")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "businessObject"
				    quid       	"4743821B00D5"
				    label      	"businessObject"
				    supplier   	"Logical View::behavioral::status_and_action::design::BusinessObject"
				    quidu      	"474381C1025F"
				    client_cardinality 	(value cardinality "1")
				    is_aggregate 	TRUE)))
			(object Association "NodeHasVariables"
			    quid       	"4743826F0282"
			    roles      	(list role_list
				(object Role "variables"
				    quid       	"474382700178"
				    label      	"variables"
				    supplier   	"Logical View::behavioral::status_and_action::design::StatusVariable"
				    quidu      	"474382660242"
				    client_cardinality 	(value cardinality "0..n")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "node"
				    quid       	"47438270017A"
				    label      	"node"
				    supplier   	"Logical View::behavioral::status_and_action::design::BusinessObjectNode"
				    quidu      	"474381D302BF"
				    client_cardinality 	(value cardinality "1")
				    is_aggregate 	TRUE)))
			(object Association "NodeHasActions"
			    quid       	"4743854F0312"
			    roles      	(list role_list
				(object Role "actions"
				    quid       	"47438550012E"
				    label      	"actions"
				    supplier   	"Logical View::behavioral::status_and_action::design::Action"
				    quidu      	"4743854A01DA"
				    client_cardinality 	(value cardinality "0..n")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "node"
				    quid       	"474385500130"
				    label      	"node"
				    supplier   	"Logical View::behavioral::status_and_action::design::BusinessObjectNode"
				    quidu      	"474381D302BF"
				    client_cardinality 	(value cardinality "1")
				    is_aggregate 	TRUE)))
			(object Association "VariableHasValues"
			    quid       	"474D300E0253"
			    roles      	(list role_list
				(object Role "values"
				    quid       	"474D300E0254"
				    label      	"values"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusValue"
				    quidu      	"474A091C02AC"
				    client_cardinality 	(value cardinality "0..n")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "variable"
				    quid       	"474D300E0255"
				    label      	"variable"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusVariable"
				    quidu      	"474A08690112"
				    client_cardinality 	(value cardinality "1")
				    is_aggregate 	TRUE))))
		    logical_presentations 	(list unit_reference_list
			(object ClassDiagram "Main"
			    quid       	"474381B802FA"
			    title      	"Main"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	775
			    origin_y   	0
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::StatusValue" @500
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1497, 1321)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@500
					location   	(1369, 1271)
					fill_color 	13434879
					nlines     	1
					max_width  	256
					justify    	0
					label      	"StatusValue")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474384A700EC"
				    width      	274
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::BusinessObject" @501
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(425, 239)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@501
					location   	(262, 189)
					fill_color 	13434879
					nlines     	1
					max_width  	326
					justify    	0
					label      	"BusinessObject")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474381C1025F"
				    width      	344
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::Action" @502
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(449, 1258)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@502
					location   	(368, 1208)
					fill_color 	13434879
					nlines     	1
					max_width  	162
					justify    	0
					label      	"Action")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743854A01DA"
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::StatusVariable" @503
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1507, 721)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@503
					location   	(1358, 671)
					fill_color 	13434879
					nlines     	1
					max_width  	298
					justify    	0
					label      	"StatusVariable")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474382660242"
				    width      	316
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::BusinessObjectNode" @504
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(434, 728)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@504
					location   	(225, 678)
					fill_color 	13434879
					nlines     	1
					max_width  	418
					justify    	0
					label      	"BusinessObjectNode")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474381D302BF"
				    width      	436
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "BusinessObjectHasNodes" @505
				    location   	(468, 483)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @506
					Parent_View 	@505
					location   	(468, 424)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	478
					justify    	0
					label      	"BusinessObjectHasNodes"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743821A02B7"
				    roleview_list 	(list RoleViews
					(object RoleView "nodes" @507
					    Parent_View 	@505
					    location   	(71, 258)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @508
						Parent_View 	@507
						location   	(470, 620)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	136
						justify    	0
						label      	"+nodes"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743821B00D3"
					    client     	@505
					    supplier   	@504
					    vertices   	(list Points
						(468, 483)
						(511, 483)
						(511, 666))
					    line_style 	3
					    origin_attachment 	(468, 483)
					    terminal_attachment 	(511, 666)
					    label      	(object SegLabel @509
						Parent_View 	@507
						location   	(458, 642)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "businessObject" @510
					    Parent_View 	@505
					    location   	(71, 258)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @511
						Parent_View 	@510
						location   	(384, 347)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	317
						justify    	0
						label      	"+businessObject"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743821B00D5"
					    client     	@505
					    supplier   	@501
					    vertices   	(list Points
						(468, 483)
						(425, 483)
						(425, 301))
					    line_style 	3
					    origin_attachment 	(468, 483)
					    terminal_attachment 	(425, 301)
					    label      	(object SegLabel @512
						Parent_View 	@510
						location   	(479, 325)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object AssociationViewNew "NodeHasActions" @513
				    location   	(475, 993)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @514
					Parent_View 	@513
					location   	(471, 993)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"NodeHasActions"
					pctDist    	0.450000
					height     	1
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743854F0312"
				    roleview_list 	(list RoleViews
					(object RoleView "actions" @515
					    Parent_View 	@513
					    location   	(41, 265)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @516
						Parent_View 	@515
						location   	(465, 1149)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	156
						justify    	0
						label      	"+actions"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47438550012E"
					    client     	@513
					    supplier   	@502
					    vertices   	(list Points
						(475, 993)
						(506, 993)
						(506, 1196))
					    line_style 	3
					    origin_attachment 	(475, 993)
					    terminal_attachment 	(506, 1196)
					    label      	(object SegLabel @517
						Parent_View 	@515
						location   	(560, 1172)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "node" @518
					    Parent_View 	@513
					    location   	(41, 265)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @519
						Parent_View 	@518
						location   	(403, 837)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	128
						justify    	0
						label      	"+node"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474385500130"
					    client     	@513
					    supplier   	@504
					    vertices   	(list Points
						(475, 993)
						(444, 993)
						(444, 790))
					    line_style 	3
					    origin_attachment 	(475, 993)
					    terminal_attachment 	(444, 790)
					    label      	(object SegLabel @520
						Parent_View 	@518
						location   	(498, 814)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object AssociationViewNew "NodeHasVariables" @521
				    location   	(1000, 724)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @522
					Parent_View 	@521
					location   	(1000, 665)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	470
					justify    	0
					label      	"NodeHasVariables"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743826F0282"
				    roleview_list 	(list RoleViews
					(object RoleView "variables" @523
					    Parent_View 	@521
					    location   	(569, 446)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @524
						Parent_View 	@523
						location   	(1278, 683)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	181
						justify    	0
						label      	"+variables"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474382700178"
					    client     	@521
					    supplier   	@503
					    vertices   	(list Points
						(1000, 724)
						(1349, 724))
					    line_style 	3
					    origin_attachment 	(1000, 724)
					    terminal_attachment 	(1349, 724)
					    label      	(object SegLabel @525
						Parent_View 	@523
						location   	(1313, 778)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "node" @526
					    Parent_View 	@521
					    location   	(569, 446)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @527
						Parent_View 	@526
						location   	(722, 683)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	128
						justify    	0
						label      	"+node"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47438270017A"
					    client     	@521
					    supplier   	@504
					    vertices   	(list Points
						(1000, 724)
						(652, 724))
					    line_style 	3
					    origin_attachment 	(1000, 724)
					    terminal_attachment 	(652, 724)
					    label      	(object SegLabel @528
						Parent_View 	@526
						location   	(688, 778)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractAction" @529
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(451, 1771)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@529
					location   	(173, 1669)
					fill_color 	13434879
					nlines     	1
					max_width  	556
					justify    	0
					label      	"AbstractAction")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A09310202"
				    width      	574
				    height     	228
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @530
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A0A270236"
				    client     	@502
				    supplier   	@529
				    vertices   	(list Points
					(449, 1320)
					(450, 1656))
				    line_style 	0)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractStatusValue" @531
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2139, 1317)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@531
					location   	(1895, 1192)
					fill_color 	13434879
					nlines     	1
					max_width  	488
					justify    	0
					label      	"AbstractStatusValue")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A091C02AC"
				    width      	506
				    height     	274
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @532
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A0AC001FD"
				    client     	@500
				    supplier   	@531
				    vertices   	(list Points
					(1634, 1320)
					(1885, 1318))
				    line_style 	0)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractStatusVariable" @533
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2359, 726)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@533
					location   	(2115, 624)
					fill_color 	13434879
					nlines     	1
					max_width  	488
					justify    	0
					label      	"AbstractStatusVariable")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A08690112"
				    width      	506
				    height     	228
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @534
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A0AC70112"
				    client     	@503
				    supplier   	@533
				    vertices   	(list Points
					(1665, 721)
					(2105, 723))
				    line_style 	0)
				(object AssociationViewNew "VariableHasValues" @535
				    location   	(2329, 1009)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @536
					Parent_View 	@535
					location   	(2329, 950)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"VariableHasValues"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474D300E0253"
				    roleview_list 	(list RoleViews
					(object RoleView "values" @537
					    Parent_View 	@535
					    location   	(1206, 391)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @538
						Parent_View 	@537
						location   	(2288, 1145)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	144
						justify    	0
						label      	"+values"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D300E0254"
					    client     	@535
					    supplier   	@531
					    vertices   	(list Points
						(2329, 1009)
						(2329, 1179))
					    line_style 	3
					    origin_attachment 	(2329, 1009)
					    terminal_attachment 	(2329, 1179)
					    label      	(object SegLabel @539
						Parent_View 	@537
						location   	(2383, 1161)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "variable" @540
					    Parent_View 	@535
					    location   	(1206, 391)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @541
						Parent_View 	@540
						location   	(2288, 875)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	173
						justify    	0
						label      	"+variable"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D300E0255"
					    client     	@535
					    supplier   	@533
					    vertices   	(list Points
						(2329, 1009)
						(2329, 840))
					    line_style 	3
					    origin_attachment 	(2329, 1009)
					    terminal_attachment 	(2329, 840)
					    label      	(object SegLabel @542
						Parent_View 	@540
						location   	(2383, 858)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))))))
		(object Class_Category "assembly"
		    quid       	"4743819403C0"
		    visible_categories 	(list visibility_relationship_list
			(object Visibility_Relationship
			    quid       	"474381AF0153"
			    supplier   	"Logical View::behavioral::status_and_action::design"
			    quidu      	"4743818802D4"))
		    exportControl 	"Public"
		    logical_models 	(list unit_reference_list
			(object Class "StatusSchema"
			    quid       	"4743828E0312"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4746305401B8"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030")))
			(object Class "Connector"
			    quid       	"4743829B0267"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4746305B00ED"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::SchemaElement"
				    quidu      	"4757375B0119"))
			    abstract   	TRUE)
			(object Class "Operator"
			    quid       	"474384F803AD"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743C65B030E"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191")))
			(object Class "ConnectableElement"
			    quid       	"4743C60C0191"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"474630580264"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::SchemaElement"
				    quidu      	"4757375B0119"))
			    abstract   	TRUE)
			(object Class "ActionProxy"
			    quid       	"4743C61903A6"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743C65F03AB"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191")
				(object Inheritance_Relationship
				    quid       	"47463356001A"
				    supplier   	"Logical View::behavioral::status_and_action::design::Action"
				    quidu      	"4743854A01DA")
				(object Inheritance_Relationship
				    quid       	"474A109C000D"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractAction"
				    quidu      	"474A09310202")))
			(object Class "StatusValueProxy"
			    quid       	"4743C621004B"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743C667031E"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191")
				(object Inheritance_Relationship
				    quid       	"4746335101A0"
				    supplier   	"Logical View::behavioral::status_and_action::design::StatusValue"
				    quidu      	"474384A700EC")
				(object Inheritance_Relationship
				    quid       	"474A10B601AE"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusValue"
				    quidu      	"474A091C02AC")))
			(object Class "Transition"
			    quid       	"4743C6F302DA"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743C7060155"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Connector"
				    quidu      	"4743829B0267")))
			(object Class "Synchroniser"
			    quid       	"4743C6FA0338"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743C7080349"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Connector"
				    quidu      	"4743829B0267")))
			(object Class "Precondition"
			    quid       	"4743CBA202B3"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743CC2700D4"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Connector"
				    quidu      	"4743829B0267")))
			(object Class "StatusVariableProxy"
			    quid       	"4743D31502E7"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4743D32A033B"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191")
				(object Inheritance_Relationship
				    quid       	"4746333E0037"
				    supplier   	"Logical View::behavioral::status_and_action::design::StatusVariable"
				    quidu      	"474382660242")
				(object Inheritance_Relationship
				    quid       	"474A10DF0077"
				    supplier   	"Logical View::behavioral::status_and_action::design::AbstractStatusVariable"
				    quidu      	"474A08690112")))
			(object Class "AndOperator"
			    quid       	"47462DBC030D"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462DD003A8"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Operator"
				    quidu      	"474384F803AD")))
			(object Class "OrOperator"
			    quid       	"47462DC40077"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462DCD03BA"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Operator"
				    quidu      	"474384F803AD")))
			(object Class "RequiredStrategy"
			    quid       	"47462E2601E2"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462F690214"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Strategy"
				    quidu      	"474D276E01D5")))
			(object Class "NeutralStrategy"
			    quid       	"47462E33023D"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462F71007E"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Strategy"
				    quidu      	"474D276E01D5")))
			(object Class "EnablingStrategy"
			    quid       	"47462E3F00D4"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462F6D01F5"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Strategy"
				    quidu      	"474D276E01D5")))
			(object Class "InhibitingStrategy"
			    quid       	"47462E4E0322"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"47462F7601F5"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Strategy"
				    quidu      	"474D276E01D5")))
			(object Class "Strategy"
			    quid       	"474D276E01D5"
			    abstract   	TRUE)
			(object Class "SchemaElement"
			    quid       	"4757375B0119"
			    superclasses 	(list inheritance_relationship_list
				(object Inheritance_Relationship
				    quid       	"4757379A01DD"
				    supplier   	"Logical View::modelmanagement::NamedElement"
				    quidu      	"45013C240030"))
			    abstract   	TRUE)
			(object Association "ProxyRepresentsAction"
			    quid       	"4743C681037E"
			    roles      	(list role_list
				(object Role "action"
				    quid       	"4743C68201A9"
				    label      	"action"
				    supplier   	"Logical View::data::classes::Signature"
				    quidu      	"4432198602CB"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE)
				(object Role "proxy"
				    quid       	"4743C68201AB"
				    label      	"proxy"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ActionProxy"
				    quidu      	"4743C61903A6"
				    client_cardinality 	(value cardinality "0..n"))))
			(object Association "ProxyRepresentsValue"
			    quid       	"4743C6840217"
			    roles      	(list role_list
				(object Role "value"
				    quid       	"4743C68403CC"
				    label      	"value"
				    supplier   	"Logical View::behavioral::status_and_action::design::StatusValue"
				    quidu      	"474384A700EC"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE)
				(object Role "proxy"
				    quid       	"4743C68403DC"
				    label      	"proxy"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::StatusValueProxy"
				    quidu      	"4743C621004B"
				    client_cardinality 	(value cardinality "0..n"))))
			(object Association "ProxyRepresentsVariable"
			    quid       	"4743D34700A3"
			    roles      	(list role_list
				(object Role "variable"
				    quid       	"4743D3470384"
				    label      	"variable"
				    supplier   	"Logical View::behavioral::status_and_action::design::StatusVariable"
				    quidu      	"474382660242"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE)
				(object Role "proxy"
				    quid       	"4743D3470386"
				    label      	"proxy"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::StatusVariableProxy"
				    quidu      	"4743D31502E7"
				    client_cardinality 	(value cardinality "0..n"))))
			(object Association "NodeHasSchemas"
			    quid       	"47462CE500D9"
			    roles      	(list role_list
				(object Role "node"
				    quid       	"47462CE70119"
				    label      	"node"
				    supplier   	"Logical View::data::classes::SapClass"
				    quidu      	"4432171B031E"
				    client_cardinality 	(value cardinality "0..1")
				    is_navigable 	TRUE)
				(object Role "behaviouralModel"
				    attributes 	(list Attribute_Set
					(object Attribute
					    tool       	"MOF"
					    name       	"sap2mof.store"
					    value      	("RoleStoreKindSet" 202)))
				    quid       	"47462CE7011B"
				    label      	"behaviouralModel"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::StatusSchema"
				    quidu      	"4743828E0312"
				    client_cardinality 	(value cardinality "0..n")
				    is_navigable 	TRUE)))
			(object Association "ConnectorHasSource"
			    quid       	"474D2651030B"
			    roles      	(list role_list
				(object Role "source"
				    quid       	"474D26520137"
				    label      	"source"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "outgoing"
				    quid       	"474D26520139"
				    label      	"outgoing"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Connector"
				    quidu      	"4743829B0267"
				    client_cardinality 	(value cardinality "0..1"))))
			(object Association "ConnectorHasTarget"
			    quid       	"474D26D90016"
			    roles      	(list role_list
				(object Role "target"
				    quid       	"474D26D90304"
				    label      	"target"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::ConnectableElement"
				    quidu      	"4743C60C0191"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "incoming"
				    quid       	"474D26D90306"
				    label      	"incoming"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Connector"
				    quidu      	"4743829B0267"
				    client_cardinality 	(value cardinality "0..1"))))
			(object Association "PreconditionHasStrategy"
			    quid       	"474D2801021A"
			    roles      	(list role_list
				(object Role "strategy"
				    quid       	"474D280200E1"
				    label      	"strategy"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Strategy"
				    quidu      	"474D276E01D5"
				    client_cardinality 	(value cardinality "1")
				    is_navigable 	TRUE)
				(object Role "owner"
				    quid       	"474D280200E3"
				    label      	"owner"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::Precondition"
				    quidu      	"4743CBA202B3"
				    client_cardinality 	(value cardinality "1"))))
			(object Association "SchemaOwnsElements"
			    quid       	"475736DE0114"
			    roles      	(list role_list
				(object Role "elements"
				    quid       	"475736E50115"
				    label      	"elements"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::SchemaElement"
				    quidu      	"4757375B0119"
				    client_cardinality 	(value cardinality "0..n")
				    Containment 	"By Value"
				    is_navigable 	TRUE)
				(object Role "schema"
				    quid       	"475736E50117"
				    label      	"schema"
				    supplier   	"Logical View::behavioral::status_and_action::assembly::StatusSchema"
				    quidu      	"4743828E0312"
				    client_cardinality 	(value cardinality "1")
				    is_aggregate 	TRUE))))
		    logical_presentations 	(list unit_reference_list
			(object ClassDiagram "Main"
			    quid       	"4743828801D9"
			    title      	"Main"
			    zoom       	100
			    max_height 	28350
			    max_width  	21600
			    origin_x   	250
			    origin_y   	1863
			    items      	(list diagram_item_list
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Operator" @543
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1741, 1471)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@543
					location   	(1646, 1421)
					fill_color 	13434879
					nlines     	1
					max_width  	190
					justify    	0
					label      	"Operator")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474384F803AD"
				    width      	208
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Transition" @544
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1896, 1010)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@544
					location   	(1795, 960)
					fill_color 	13434879
					nlines     	1
					max_width  	202
					justify    	0
					label      	"Transition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743C6F302DA"
				    width      	220
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Synchroniser" @545
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2173, 1010)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@545
					location   	(2035, 960)
					fill_color 	13434879
					nlines     	1
					max_width  	276
					justify    	0
					label      	"Synchroniser")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743C6FA0338"
				    width      	294
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object NoteView @546
				    location   	(722, 1262)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@546
					location   	(450, 1140)
					fill_color 	13434879
					nlines     	4
					max_width  	509
					label      	"Constraints should verify that no values are added that are not defined in the original design model")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	569
				    height     	257)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::AndOperator" @547
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2449, 1768)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@547
					location   	(2318, 1718)
					fill_color 	13434879
					nlines     	1
					max_width  	262
					justify    	0
					label      	"AndOperator")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462DBC030D"
				    width      	280
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::OrOperator" @548
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1959, 1887)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@548
					location   	(1840, 1837)
					fill_color 	13434879
					nlines     	1
					max_width  	238
					justify    	0
					label      	"OrOperator")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462DC40077"
				    width      	256
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @549
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462DCD03BA"
				    client     	@548
				    supplier   	@543
				    vertices   	(list Points
					(1924, 1824)
					(1772, 1533))
				    line_style 	0)
				(object InheritView "" @550
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462DD003A8"
				    client     	@547
				    supplier   	@543
				    vertices   	(list Points
					(2308, 1707)
					(1845, 1514))
				    line_style 	0)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::RequiredStrategy" @551
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2564, 1271)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@551
					location   	(2384, 1221)
					fill_color 	13434879
					nlines     	1
					max_width  	360
					justify    	0
					label      	"RequiredStrategy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462E2601E2"
				    width      	378
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::NeutralStrategy" @552
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(3059, 1284)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@552
					location   	(2902, 1234)
					fill_color 	13434879
					nlines     	1
					max_width  	314
					justify    	0
					label      	"NeutralStrategy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462E33023D"
				    width      	332
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::EnablingStrategy" @553
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2553, 1500)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@553
					location   	(2384, 1450)
					fill_color 	13434879
					nlines     	1
					max_width  	338
					justify    	0
					label      	"EnablingStrategy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462E3F00D4"
				    width      	356
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::InhibitingStrategy" @554
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(3179, 1503)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@554
					location   	(3009, 1453)
					fill_color 	13434879
					nlines     	1
					max_width  	340
					justify    	0
					label      	"InhibitingStrategy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"47462E4E0322"
				    width      	358
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object NoteView @555
				    location   	(3604, 1078)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@555
					location   	(3410, 950)
					fill_color 	13434879
					nlines     	5
					max_width  	353
					label      	"Source is a status value or an operator and the target is always an operator")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	413
				    height     	269)
				(object AttachView "" @556
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@552
				    supplier   	@555
				    vertices   	(list Points
					(3221, 1221)
					(3397, 1155))
				    line_style 	0)
				(object NoteView @557
				    location   	(3278, 1925)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@557
					location   	(3109, 1765)
					fill_color 	13434879
					nlines     	6
					max_width  	303
					label      	"Source is either a value or an operator and target is always an action")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	363
				    height     	332)
				(object AttachView "" @558
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@554
				    supplier   	@557
				    vertices   	(list Points
					(3193, 1565)
					(3237, 1758))
				    line_style 	0)
				(object AttachView "" @559
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@553
				    supplier   	@557
				    vertices   	(list Points
					(2659, 1562)
					(3096, 1818))
				    line_style 	0)
				(object AttachView "" @560
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@551
				    supplier   	@557
				    vertices   	(list Points
					(2632, 1333)
					(3096, 1758))
				    line_style 	0)
				(object NoteView @561
				    location   	(2372, 336)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@561
					location   	(2210, 205)
					fill_color 	13434879
					nlines     	5
					max_width  	289
					label      	"Source and target are always values")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	349
				    height     	275)
				(object AttachView "" @562
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@545
				    supplier   	@561
				    vertices   	(list Points
					(2190, 947)
					(2330, 473))
				    line_style 	0)
				(object NoteView @563
				    location   	(1883, 227)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@563
					location   	(1714, 89)
					fill_color 	13434879
					nlines     	5
					max_width  	303
					label      	"Source is always an action and target is always a value")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	363
				    height     	288)
				(object AttachView "" @564
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@544
				    supplier   	@563
				    vertices   	(list Points
					(1894, 947)
					(1884, 371))
				    line_style 	0)
				(object NoteView @565
				    location   	(3333, 650)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@565
					location   	(3161, 494)
					fill_color 	13434879
					nlines     	6
					max_width  	309
					label      	"We will use a strategy pattern to implement specific constraints.")
				    line_color 	3342489
				    fill_color 	13434879
				    width      	369
				    height     	325)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractAction" @566
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2348, 2237)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@566
					location   	(2070, 2108)
					fill_color 	13434879
					nlines     	1
					max_width  	556
					justify    	0
					label      	"AbstractAction")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A09310202"
				    width      	574
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Strategy" @567
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2862, 1053)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@567
					location   	(2770, 1003)
					fill_color 	13434879
					nlines     	1
					max_width  	184
					justify    	0
					label      	"Strategy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474D276E01D5"
				    width      	202
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @568
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462F71007E"
				    client     	@552
				    supplier   	@567
				    vertices   	(list Points
					(3004, 1221)
					(2915, 1115))
				    line_style 	0)
				(object InheritView "" @569
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462F7601F5"
				    client     	@554
				    supplier   	@567
				    vertices   	(list Points
					(3135, 1440)
					(2905, 1115))
				    line_style 	0)
				(object InheritView "" @570
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462F6D01F5"
				    client     	@553
				    supplier   	@567
				    vertices   	(list Points
					(2595, 1437)
					(2818, 1115))
				    line_style 	0)
				(object AttachView "" @571
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@567
				    supplier   	@565
				    vertices   	(list Points
					(2932, 990)
					(3148, 806))
				    line_style 	0)
				(object InheritView "" @572
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462F690214"
				    client     	@551
				    supplier   	@567
				    vertices   	(list Points
					(2648, 1208)
					(2773, 1115))
				    line_style 	0)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Precondition" @573
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(2632, 715)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@573
					location   	(2501, 665)
					fill_color 	13434879
					nlines     	1
					max_width  	262
					justify    	0
					label      	"Precondition")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743CBA202B3"
				    width      	280
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "PreconditionHasStrategy" @574
				    location   	(2745, 883)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @575
					Parent_View 	@574
					location   	(2751, 871)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"PreconditionHasStrategy"
					pctDist    	0.600000
					height     	13
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474D2801021A"
				    roleview_list 	(list RoleViews
					(object RoleView "strategy" @576
					    Parent_View 	@574
					    location   	(263, -127)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @577
						Parent_View 	@576
						location   	(2825, 929)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	177
						justify    	0
						label      	"+strategy"
						pctDist    	0.641291
						height     	41
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D280200E1"
					    client     	@574
					    supplier   	@567
					    vertices   	(list Points
						(2745, 883)
						(2817, 990))
					    line_style 	0
					    label      	(object SegLabel @578
						Parent_View 	@576
						location   	(2744, 985)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.656151
						height     	59
						orientation 	1))
					(object RoleView "owner" @579
					    Parent_View 	@574
					    location   	(263, -127)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @580
						Parent_View 	@579
						location   	(2723, 776)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	140
						justify    	0
						label      	"+owner"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D280200E3"
					    client     	@574
					    supplier   	@573
					    vertices   	(list Points
						(2745, 883)
						(2673, 777))
					    line_style 	0
					    label      	(object SegLabel @581
						Parent_View 	@579
						location   	(2636, 818)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::StatusValue" @582
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1290, 3152)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@582
					location   	(1162, 3074)
					fill_color 	13434879
					nlines     	1
					max_width  	256
					justify    	0
					label      	"StatusValue")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474384A700EC"
				    width      	274
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::StatusValueProxy" @583
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1248, 2226)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@583
					location   	(1063, 2176)
					fill_color 	13434879
					nlines     	1
					max_width  	370
					justify    	0
					label      	"StatusValueProxy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743C621004B"
				    width      	388
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object AttachView "" @584
				    stereotype 	TRUE
				    line_color 	3342489
				    client     	@583
				    supplier   	@546
				    vertices   	(list Points
					(1213, 2163)
					(791, 1390))
				    line_style 	0)
				(object AssociationViewNew "ProxyRepresentsValue" @585
				    location   	(1351, 2674)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @586
					Parent_View 	@585
					location   	(1415, 2490)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"ProxyRepresentsValue"
					pctDist    	1.566667
					height     	185
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C6840217"
				    roleview_list 	(list RoleViews
					(object RoleView "value" @587
					    Parent_View 	@585
					    location   	(232, 1478)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @588
						Parent_View 	@587
						location   	(1345, 2897)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	132
						justify    	0
						label      	"+value"
						pctDist    	0.577320
						height     	7
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743C68403CC"
					    client     	@585
					    supplier   	@582
					    vertices   	(list Points
						(1351, 2674)
						(1351, 3062))
					    line_style 	3
					    origin_attachment 	(1351, 2674)
					    terminal_attachment 	(1351, 3062)
					    label      	(object SegLabel @589
						Parent_View 	@587
						location   	(1405, 3022)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "proxy" @590
					    Parent_View 	@585
					    location   	(232, 1478)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @591
						Parent_View 	@590
						location   	(1310, 2364)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	136
						justify    	0
						label      	"+proxy"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743C68403DC"
					    client     	@585
					    supplier   	@583
					    vertices   	(list Points
						(1351, 2674)
						(1351, 2287))
					    line_style 	3
					    origin_attachment 	(1351, 2674)
					    terminal_attachment 	(1351, 2287)
					    label      	(object SegLabel @592
						Parent_View 	@590
						location   	(1405, 2326)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractStatusVariable" @593
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(362, 1731)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@593
					location   	(118, 1602)
					fill_color 	13434879
					nlines     	1
					max_width  	488
					justify    	0
					label      	"AbstractStatusVariable")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A08690112"
				    width      	506
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::AbstractStatusValue" @594
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1081, 1743)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@594
					location   	(837, 1590)
					fill_color 	13434879
					nlines     	1
					max_width  	488
					justify    	0
					label      	"AbstractStatusValue")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474A091C02AC"
				    width      	506
				    height     	330
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @595
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A10B601AE"
				    client     	@583
				    supplier   	@594
				    vertices   	(list Points
					(1232, 2164)
					(1232, 1907))
				    line_style 	3
				    origin_attachment 	(1232, 2164)
				    terminal_attachment 	(1232, 1907))
				(object AssociationViewNew "VariableHasValues" @596
				    location   	(721, 1736)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @597
					Parent_View 	@596
					location   	(727, 1615)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"VariableHasValues"
					pctDist    	0.600000
					height     	122
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474D300E0253"
				    roleview_list 	(list RoleViews
					(object RoleView "variable" @598
					    Parent_View 	@596
					    location   	(-245, -908)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @599
						Parent_View 	@598
						location   	(636, 1776)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	173
						justify    	0
						label      	"+variable"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D300E0255"
					    client     	@596
					    supplier   	@593
					    vertices   	(list Points
						(721, 1736)
						(615, 1733))
					    line_style 	0
					    label      	(object SegLabel @600
						Parent_View 	@598
						location   	(628, 1681)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "values" @601
					    Parent_View 	@596
					    location   	(-245, -908)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @602
						Parent_View 	@601
						location   	(806, 1780)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	140
						justify    	0
						label      	"+values"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D300E0254"
					    client     	@596
					    supplier   	@594
					    vertices   	(list Points
						(721, 1736)
						(827, 1737))
					    line_style 	0
					    label      	(object SegLabel @603
						Parent_View 	@601
						location   	(816, 1685)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::ConnectableElement" @604
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1450, 910)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@604
					location   	(1245, 860)
					fill_color 	13434879
					nlines     	1
					max_width  	410
					justify    	0
					label      	"ConnectableElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743C60C0191"
				    width      	428
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @605
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C65B030E"
				    client     	@543
				    supplier   	@604
				    vertices   	(list Points
					(1667, 1408)
					(1667, 971))
				    line_style 	3
				    origin_attachment 	(1667, 1408)
				    terminal_attachment 	(1667, 971))
				(object InheritView "" @606
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C667031E"
				    client     	@583
				    supplier   	@604
				    vertices   	(list Points
					(1284, 2164)
					(1284, 1991)
					(1383, 1991)
					(1383, 972))
				    line_style 	3
				    origin_attachment 	(1284, 2164)
				    terminal_attachment 	(1383, 972))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::Connector" @607
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1804, 518)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@607
					location   	(1692, 468)
					fill_color 	13434879
					nlines     	1
					max_width  	224
					justify    	0
					label      	"Connector")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743829B0267"
				    width      	242
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @608
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C7080349"
				    client     	@545
				    supplier   	@607
				    vertices   	(list Points
					(2091, 948)
					(2091, 579)
					(1925, 579))
				    line_style 	3
				    origin_attachment 	(2091, 948)
				    terminal_attachment 	(1925, 579))
				(object InheritView "" @609
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C7060155"
				    client     	@544
				    supplier   	@607
				    vertices   	(list Points
					(1879, 948)
					(1879, 580))
				    line_style 	3
				    origin_attachment 	(1879, 948)
				    terminal_attachment 	(1879, 580))
				(object InheritView "" @610
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743CC2700D4"
				    client     	@573
				    supplier   	@607
				    vertices   	(list Points
					(2510, 653)
					(2510, 579)
					(1925, 579))
				    line_style 	3
				    origin_attachment 	(2510, 653)
				    terminal_attachment 	(1925, 579))
				(object AssociationViewNew "ConnectorHasSource" @611
				    location   	(1578, 697)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @612
					Parent_View 	@611
					location   	(1451, 661)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"ConnectorHasSource"
					pctDist    	-1.633333
					height     	37
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474D2651030B"
				    roleview_list 	(list RoleViews
					(object RoleView "source" @613
					    Parent_View 	@611
					    location   	(30, 162)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @614
						Parent_View 	@613
						location   	(1476, 706)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	147
						justify    	0
						label      	"+source"
						pctDist    	0.363217
						height     	33
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D26520137"
					    client     	@611
					    supplier   	@604
					    vertices   	(list Points
						(1578, 697)
						(1508, 697)
						(1508, 848))
					    line_style 	3
					    origin_attachment 	(1578, 697)
					    terminal_attachment 	(1508, 848)
					    label      	(object SegLabel @615
						Parent_View 	@613
						location   	(1562, 825)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "outgoing" @616
					    Parent_View 	@611
					    location   	(30, 162)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @617
						Parent_View 	@616
						location   	(1649, 658)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	213
						justify    	0
						label      	"+outgoing"
						pctDist    	0.644839
						height     	34
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D26520139"
					    client     	@611
					    supplier   	@607
					    vertices   	(list Points
						(1578, 697)
						(1682, 697)
						(1682, 580))
					    line_style 	3
					    origin_attachment 	(1578, 697)
					    terminal_attachment 	(1682, 580)
					    label      	(object SegLabel @618
						Parent_View 	@616
						location   	(1736, 602)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object AssociationViewNew "ConnectorHasTarget" @619
				    location   	(1725, 712)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @620
					Parent_View 	@619
					location   	(1789, 712)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"ConnectorHasTarget"
					pctDist    	1.583333
					height     	0
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474D26D90016"
				    roleview_list 	(list RoleViews
					(object RoleView "target" @621
					    Parent_View 	@619
					    location   	(177, 177)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @622
						Parent_View 	@621
						location   	(1715, 797)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	133
						justify    	0
						label      	"+target"
						pctDist    	0.527250
						height     	8
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D26D90304"
					    client     	@619
					    supplier   	@604
					    vertices   	(list Points
						(1725, 712)
						(1725, 772)
						(1707, 772)
						(1707, 846)
						(1664, 846))
					    line_style 	3
					    origin_attachment 	(1725, 712)
					    terminal_attachment 	(1664, 846)
					    label      	(object SegLabel @623
						Parent_View 	@621
						location   	(1684, 900)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "incoming" @624
					    Parent_View 	@619
					    location   	(177, 177)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @625
						Parent_View 	@624
						location   	(1713, 615)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	195
						justify    	0
						label      	"+incoming"
						pctDist    	0.737696
						height     	13
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474D26D90306"
					    client     	@619
					    supplier   	@607
					    vertices   	(list Points
						(1725, 712)
						(1725, 580))
					    line_style 	3
					    origin_attachment 	(1725, 712)
					    terminal_attachment 	(1725, 580)
					    label      	(object SegLabel @626
						Parent_View 	@624
						location   	(1790, 633)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.598609
						height     	65
						orientation 	1))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::Action" @627
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1769, 3163)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@627
					location   	(1661, 3085)
					fill_color 	13434879
					nlines     	1
					max_width  	216
					justify    	0
					label      	"Action")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743854A01DA"
				    width      	234
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::StatusVariableProxy" @628
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(559, 2215)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@628
					location   	(355, 2165)
					fill_color 	13434879
					nlines     	1
					max_width  	408
					justify    	0
					label      	"StatusVariableProxy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743D31502E7"
				    width      	426
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @629
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A10DF0077"
				    client     	@628
				    supplier   	@593
				    vertices   	(list Points
					(533, 2152)
					(419, 1872))
				    line_style 	0)
				(object InheritView "" @630
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743D32A033B"
				    client     	@628
				    supplier   	@604
				    vertices   	(list Points
					(537, 2153)
					(537, 1407)
					(1268, 1407)
					(1268, 972))
				    line_style 	3
				    origin_attachment 	(537, 2153)
				    terminal_attachment 	(1268, 972))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::BusinessObjectNode" @631
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(559, 3871)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@631
					location   	(350, 3793)
					fill_color 	13434879
					nlines     	1
					max_width  	418
					justify    	0
					label      	"BusinessObjectNode")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474381D302BF"
				    width      	436
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "NodeHasActions" @632
				    location   	(1181, 3505)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @633
					Parent_View 	@632
					location   	(1181, 3446)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"NodeHasActions"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743854F0312"
				    roleview_list 	(list RoleViews
					(object RoleView "node" @634
					    Parent_View 	@632
					    location   	(-97, 1666)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @635
						Parent_View 	@634
						location   	(827, 3761)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+node"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474385500130"
					    client     	@632
					    supplier   	@631
					    vertices   	(list Points
						(1181, 3505)
						(710, 3780))
					    line_style 	0
					    label      	(object SegLabel @636
						Parent_View 	@634
						location   	(785, 3800)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "actions" @637
					    Parent_View 	@632
					    location   	(-97, 1666)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @638
						Parent_View 	@637
						location   	(1440, 3695)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+actions"
						pctDist    	0.234794
						height     	296
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47438550012E"
					    client     	@632
					    supplier   	@627
					    vertices   	(list Points
						(1181, 3505)
						(1651, 3229))
					    line_style 	0
					    label      	(object SegLabel @639
						Parent_View 	@637
						location   	(1476, 3688)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.297852
						height     	307
						orientation 	1))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::design::StatusVariable" @640
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(555, 3168)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@640
					location   	(406, 3090)
					fill_color 	13434879
					nlines     	1
					max_width  	298
					justify    	0
					label      	"StatusVariable")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"474382660242"
				    width      	316
				    height     	180
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "ProxyRepresentsVariable" @641
				    location   	(520, 2679)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @642
					Parent_View 	@641
					location   	(521, 2674)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	470
					justify    	0
					label      	"ProxyRepresentsVariable"
					pctDist    	0.533333
					height     	6
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743D34700A3"
				    roleview_list 	(list RoleViews
					(object RoleView "variable" @643
					    Parent_View 	@641
					    location   	(195, 1411)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @644
						Parent_View 	@643
						location   	(512, 2991)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	168
						justify    	0
						label      	"+variable"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743D3470384"
					    client     	@641
					    supplier   	@640
					    vertices   	(list Points
						(520, 2679)
						(553, 2679)
						(553, 3078))
					    line_style 	3
					    origin_attachment 	(520, 2679)
					    terminal_attachment 	(553, 3078)
					    label      	(object SegLabel @645
						Parent_View 	@643
						location   	(607, 3034)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "proxy" @646
					    Parent_View 	@641
					    location   	(195, 1411)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @647
						Parent_View 	@646
						location   	(447, 2364)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	136
						justify    	0
						label      	"+proxy"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743D3470386"
					    client     	@641
					    supplier   	@628
					    vertices   	(list Points
						(520, 2679)
						(488, 2679)
						(488, 2277))
					    line_style 	3
					    origin_attachment 	(520, 2679)
					    terminal_attachment 	(488, 2277)
					    label      	(object SegLabel @648
						Parent_View 	@646
						location   	(542, 2321)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object AssociationViewNew "NodeHasVariables" @649
				    location   	(556, 3519)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @650
					Parent_View 	@649
					location   	(556, 3460)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	470
					justify    	0
					label      	"NodeHasVariables"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743826F0282"
				    roleview_list 	(list RoleViews
					(object RoleView "node" @651
					    Parent_View 	@649
					    location   	(283, 1665)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @652
						Parent_View 	@651
						location   	(600, 3728)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+node"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47438270017A"
					    client     	@649
					    supplier   	@631
					    vertices   	(list Points
						(556, 3519)
						(557, 3780))
					    line_style 	0
					    label      	(object SegLabel @653
						Parent_View 	@651
						location   	(612, 3753)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "variables" @654
					    Parent_View 	@649
					    location   	(283, 1665)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @655
						Parent_View 	@654
						location   	(597, 3310)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	450
						justify    	0
						label      	"+variables"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"474382700178"
					    client     	@649
					    supplier   	@640
					    vertices   	(list Points
						(556, 3519)
						(555, 3258))
					    line_style 	0
					    label      	(object SegLabel @656
						Parent_View 	@654
						location   	(609, 3285)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object ClassView "Class" "Logical View::modelmanagement::NamedElement" @657
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1182, 159)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@657
					location   	(904, 30)
					fill_color 	13434879
					nlines     	1
					max_width  	556
					justify    	0
					label      	"NamedElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"45013C240030"
				    width      	574
				    height     	282
				    annotation 	8
				    autoResize 	TRUE)
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::ActionProxy" @658
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1657, 2234)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@658
					location   	(1528, 2184)
					fill_color 	13434879
					nlines     	1
					max_width  	258
					justify    	0
					label      	"ActionProxy")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743C61903A6"
				    width      	276
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @659
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474A109C000D"
				    client     	@658
				    supplier   	@566
				    vertices   	(list Points
					(1795, 2234)
					(2060, 2235))
				    line_style 	0)
				(object InheritView "" @660
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C65F03AB"
				    client     	@658
				    supplier   	@604
				    vertices   	(list Points
					(1610, 2171)
					(1610, 972))
				    line_style 	3
				    origin_attachment 	(1610, 2171)
				    terminal_attachment 	(1610, 972))
				(object ClassView "Class" "Logical View::data::classes::Signature" @661
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(3410, 3203)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@661
					location   	(3177, 3024)
					fill_color 	13434879
					nlines     	1
					max_width  	466
					justify    	0
					label      	"Signature")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432198602CB"
				    width      	484
				    height     	382
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "ProxyRepresentsAction" @662
				    location   	(2547, 2588)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @663
					Parent_View 	@662
					location   	(2547, 2529)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"ProxyRepresentsAction"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4743C681037E"
				    roleview_list 	(list RoleViews
					(object RoleView "action" @664
					    Parent_View 	@662
					    location   	(1794, 1392)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @665
						Parent_View 	@664
						location   	(3210, 2803)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	139
						justify    	0
						label      	"+action"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743C68201A9"
					    client     	@662
					    supplier   	@661
					    vertices   	(list Points
						(2547, 2588)
						(3168, 2588)
						(3168, 3012))
					    line_style 	3
					    origin_attachment 	(2547, 2588)
					    terminal_attachment 	(3168, 3012)
					    label      	(object SegLabel @666
						Parent_View 	@664
						location   	(3222, 2907)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	0))
					(object RoleView "proxy" @667
					    Parent_View 	@662
					    location   	(1794, 1392)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @668
						Parent_View 	@667
						location   	(1752, 2506)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	136
						justify    	0
						label      	"+proxy"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4743C68201AB"
					    client     	@662
					    supplier   	@658
					    vertices   	(list Points
						(2547, 2588)
						(1793, 2588)
						(1793, 2296))
					    line_style 	3
					    origin_attachment 	(2547, 2588)
					    terminal_attachment 	(1793, 2296)
					    label      	(object SegLabel @669
						Parent_View 	@667
						location   	(1740, 2401)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::SchemaElement" @670
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1178, 523)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	TRUE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@670
					location   	(1012, 473)
					fill_color 	13434879
					nlines     	1
					max_width  	332
					justify    	0
					label      	"SchemaElement")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4757375B0119"
				    width      	350
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object InheritView "" @671
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"474630580264"
				    client     	@604
				    supplier   	@670
				    vertices   	(list Points
					(1406, 847)
					(1221, 585))
				    line_style 	0)
				(object InheritView "" @672
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4746305B00ED"
				    client     	@607
				    supplier   	@670
				    vertices   	(list Points
					(1682, 518)
					(1353, 520))
				    line_style 	0)
				(object InheritView "" @673
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4757379A01DD"
				    client     	@670
				    supplier   	@657
				    vertices   	(list Points
					(1178, 460)
					(1180, 300))
				    line_style 	0)
				(object ClassView "Class" "Logical View::data::classes::SapClass" @674
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(1500, 3925)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@674
					location   	(1155, 3467)
					fill_color 	13434879
					nlines     	1
					max_width  	690
					justify    	0
					label      	"SapClass")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4432171B031E"
				    width      	708
				    height     	940
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "SignaturesOfType" @675
				    location   	(2510, 3541)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @676
					Parent_View 	@675
					location   	(2510, 3482)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"SignaturesOfType"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4784F76B00DA"
				    roleview_list 	(list RoleViews
					(object RoleView "signatures" @677
					    Parent_View 	@675
					    location   	(506, -293)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @678
						Parent_View 	@677
						location   	(3021, 3306)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	222
						justify    	0
						label      	"+signatures"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4784F76B00DC"
					    client     	@675
					    supplier   	@661
					    vertices   	(list Points
						(2510, 3541)
						(3167, 3292))
					    line_style 	0
					    label      	(object SegLabel @679
						Parent_View 	@677
						location   	(3120, 3370)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..*"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "exposedBy" @680
					    Parent_View 	@675
					    location   	(506, -293)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @681
						Parent_View 	@680
						location   	(1972, 3701)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	228
						justify    	0
						label      	"+exposedBy"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"4784F76B00DB"
					    client     	@675
					    supplier   	@674
					    vertices   	(list Points
						(2510, 3541)
						(1854, 3790))
					    line_style 	0
					    label      	(object SegLabel @682
						Parent_View 	@680
						location   	(1939, 3815)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	0))))
				(object ClassView "Class" "Logical View::behavioral::status_and_action::assembly::StatusSchema" @683
				    ShowCompartmentStereotypes 	TRUE
				    IncludeAttribute 	TRUE
				    IncludeOperation 	TRUE
				    location   	(206, 162)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object ItemLabel
					Parent_View 	@683
					location   	(49, 112)
					fill_color 	13434879
					nlines     	1
					max_width  	314
					justify    	0
					label      	"StatusSchema")
				    icon_style 	"Icon"
				    line_color 	3342489
				    fill_color 	13434879
				    quidu      	"4743828E0312"
				    width      	332
				    height     	124
				    annotation 	8
				    autoResize 	TRUE)
				(object AssociationViewNew "SchemaOwnsElements" @684
				    location   	(500, 550)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @685
					Parent_View 	@684
					location   	(500, 491)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"SchemaOwnsElements"
					pctDist    	0.500000
					height     	60
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"475736DE0114"
				    roleview_list 	(list RoleViews
					(object RoleView "elements" @686
					    Parent_View 	@684
					    location   	(-59, 38)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @687
						Parent_View 	@686
						location   	(904, 593)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	191
						justify    	0
						label      	"+elements"
						pctDist    	0.802859
						height     	43
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475736E50115"
					    client     	@684
					    supplier   	@670
					    vertices   	(list Points
						(500, 550)
						(1003, 550))
					    line_style 	3
					    origin_attachment 	(500, 550)
					    terminal_attachment 	(1003, 550)
					    label      	(object SegLabel @688
						Parent_View 	@686
						location   	(953, 604)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "schema" @689
					    Parent_View 	@684
					    location   	(-59, 38)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @690
						Parent_View 	@689
						location   	(281, 325)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	179
						justify    	0
						label      	"+schema"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"475736E50117"
					    client     	@684
					    supplier   	@683
					    vertices   	(list Points
						(500, 550)
						(322, 550)
						(322, 224))
					    line_style 	3
					    origin_attachment 	(500, 550)
					    terminal_attachment 	(322, 224)
					    label      	(object SegLabel @691
						Parent_View 	@689
						location   	(376, 275)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"1"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object InheritView "" @692
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"4746305401B8"
				    client     	@683
				    supplier   	@657
				    vertices   	(list Points
					(372, 161)
					(894, 159))
				    line_style 	0)
				(object AssociationViewNew "NodeHasSchemas" @693
				    location   	(138, 2114)
				    font       	(object Font
					size       	10
					face       	"Arial"
					bold       	FALSE
					italics    	FALSE
					underline  	FALSE
					strike     	FALSE
					color      	0
					default_color 	TRUE)
				    label      	(object SegLabel @694
					Parent_View 	@693
					location   	(166, 2040)
					font       	(object Font
					    size       	10
					    face       	"Arial"
					    bold       	FALSE
					    italics    	TRUE
					    underline  	FALSE
					    strike     	FALSE
					    color      	0
					    default_color 	TRUE)
					anchor     	1
					anchor_loc 	1
					nlines     	1
					max_width  	450
					justify    	0
					label      	"NodeHasSchemas"
					pctDist    	0.966667
					height     	75
					orientation 	0)
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47462CE500D9"
				    roleview_list 	(list RoleViews
					(object RoleView "node" @695
					    Parent_View 	@693
					    location   	(-525, 1951)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @696
						Parent_View 	@695
						location   	(904, 3281)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	128
						justify    	0
						label      	"+node"
						pctDist    	0.800000
						height     	42
						orientation 	0)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47462CE70119"
					    client     	@693
					    supplier   	@674
					    vertices   	(list Points
						(138, 2114)
						(122, 2569)
						(1145, 3576))
					    line_style 	0
					    label      	(object SegLabel @697
						Parent_View 	@695
						location   	(973, 3481)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..1"
						pctDist    	0.900000
						height     	54
						orientation 	1))
					(object RoleView "behaviouralModel" @698
					    Parent_View 	@693
					    location   	(-525, 1951)
					    font       	(object Font
						size       	10
						face       	"Arial"
						bold       	FALSE
						italics    	FALSE
						underline  	FALSE
						strike     	FALSE
						color      	0
						default_color 	TRUE)
					    label      	(object SegLabel @699
						Parent_View 	@698
						location   	(232, 604)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	1
						anchor_loc 	1
						nlines     	1
						max_width  	345
						justify    	0
						label      	"+behaviouralModel"
						pctDist    	0.800000
						height     	42
						orientation 	1)
					    stereotype 	TRUE
					    line_color 	3342489
					    quidu      	"47462CE7011B"
					    client     	@693
					    supplier   	@683
					    vertices   	(list Points
						(138, 2114)
						(202, 224))
					    line_style 	0
					    label      	(object SegLabel @700
						Parent_View 	@698
						location   	(250, 415)
						font       	(object Font
						    size       	10
						    face       	"Arial"
						    bold       	FALSE
						    italics    	FALSE
						    underline  	FALSE
						    strike     	FALSE
						    color      	0
						    default_color 	TRUE)
						anchor     	2
						anchor_loc 	1
						nlines     	1
						max_width  	15
						justify    	0
						label      	"0..n"
						pctDist    	0.900000
						height     	54
						orientation 	1))))
				(object InheritView "" @701
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"479580F200DA"
				    client     	@566
				    supplier   	@657
				    vertices   	(list Points
					(2267, 2095)
					(1260, 300))
				    line_style 	0)
				(object InheritView "" @702
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"479580FA0128"
				    client     	@631
				    supplier   	@657
				    vertices   	(list Points
					(573, 3780)
					(1157, 300))
				    line_style 	0)
				(object InheritView "" @703
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"479580FE0119"
				    client     	@594
				    supplier   	@657
				    vertices   	(list Points
					(1090, 1577)
					(1172, 300))
				    line_style 	0)
				(object InheritView "" @704
				    stereotype 	TRUE
				    line_color 	3342489
				    quidu      	"47958101008C"
				    client     	@593
				    supplier   	@657
				    vertices   	(list Points
					(434, 1589)
					(1106, 300))
				    line_style 	0))))))
	    logical_presentations 	(list unit_reference_list
		(object ClassDiagram "Main"
		    quid       	"474381440379"
		    title      	"Main"
		    zoom       	100
		    max_height 	28350
		    max_width  	21600
		    origin_x   	0
		    origin_y   	0
		    items      	(list diagram_item_list
			(object CategoryView "Logical View::behavioral::status_and_action::design" @705
			    location   	(689, 559)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@705
				location   	(545, 475)
				fill_color 	13434879
				nlines     	2
				max_width  	288
				justify    	0
				label      	"design")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4743818802D4"
			    width      	300
			    height     	180)
			(object CategoryView "Logical View::behavioral::status_and_action::assembly" @706
			    location   	(688, 1006)
			    font       	(object Font
				size       	10
				face       	"Arial"
				bold       	FALSE
				italics    	FALSE
				underline  	FALSE
				strike     	FALSE
				color      	0
				default_color 	TRUE)
			    label      	(object ItemLabel
				Parent_View 	@706
				location   	(544, 922)
				fill_color 	13434879
				nlines     	2
				max_width  	288
				justify    	0
				label      	"assembly")
			    icon_style 	"Icon"
			    line_color 	3342489
			    fill_color 	13434879
			    quidu      	"4743819403C0"
			    width      	300
			    height     	180)
			(object ImportView "" @707
			    stereotype 	TRUE
			    line_color 	3342489
			    quidu      	"474381AF0153"
			    client     	@706
			    supplier   	@705
			    vertices   	(list Points
				(688, 861)
				(688, 649))
			    line_style 	3
			    origin_attachment 	(688, 861)
			    terminal_attachment 	(688, 649)))))))
    logical_presentations 	(list unit_reference_list))
