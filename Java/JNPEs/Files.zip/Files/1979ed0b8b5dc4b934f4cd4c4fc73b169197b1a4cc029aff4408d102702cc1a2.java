<dataset>

  <file_sources id="101" project_uuid="PRJ_UUID" file_uuid="FILE1_UUID"
                binary_data="[ignore]"
                data_hash="NEW_DATA_HASH"
                line_hashes="NEW_LINE_HASHES"
                line_count="1"
                src_hash="NEW_FILE_HASH" revision="987654321"
                created_at="1500000000000" updated_at="1500000000002"
                line_hashes_version="1" />


</dataset>
