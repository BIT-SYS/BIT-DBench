verbose=print extra information
show-updates=display update information
non-recursive=obsolete; try --depth=files or --depth=immediates
depth=pass depth ('empty', 'files', 'immediates', or 'infinity') as ARG
quiet=print as little as possible
no-ignore=disregard default and svn:ignore property ignores
incremental=give output suitable for concatenation
xml=output in XML
config-dir=read user configuration files from directory ARG
ignore-externals=ignore externals definitions
changelist=operate only on members of changelist ARG
username=specify a username ARG
password=specify a password ARG
no-auth-cache=do not cache authentication tokens
non-interactive=do no interactive prompting
help=show help on a subcommand
version=show program version information
recursive=descend recursively, same as --depth=infinity
revision=\
ARG (some commands also take ARG1:ARG2 range)\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ A revision argument can be one of:\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ NUMBER       revision number\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ '{' DATE '}' revision at start\ of\ the\ date\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ 'HEAD'       latest in repository\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ 'BASE'       base rev of item's working copy\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ 'COMMITTED'  last commit at or before BASE\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ 'PREV'       revision just before COMMITTED
revprop=operate on a revision property (use with -r)
change=the change made by revision ARG (like -r ARG-1:ARG)\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ If ARG is negative this is like -r ARG:ARG-1
strict=use strict semantics
file=read log message from file ARG
file.propset=read property value from file ARG
encoding=treat value as being in charset encoding ARG
targets=pass contents of file ARG as additional args
force=force operation to run
force-log=force validity of log message source
message=specify log message ARG
with-revprop=set revision property ARG in new revision\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ using the name=value format
editor-cmd=use ARG as external editor
no-unlock=don't unlock the targets
dyr-run=try operation but make no changes
record-only=mark revisions as merged (use with -r)
use-merge-history=\
use/display additional information from merge\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ history
ignore-ancestry=ignore ancestry when calculating merges
extensions=\
Default: '-u'. When Subversion is invoking an\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ external diff program, ARG is simply passed along\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ to the program. But when Subversion is using its\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ default internal diff implementation, or when\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ Subversion is displaying blame annotations, ARG\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ could be any of the following:\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ -u (--unified):\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ \ \ \ Output 3 lines of unified context.\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ -b (--ignore-space-change):\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ \ \ \ Ignore changes in the amount of white space.\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ -w (--ignore-all-space):\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ \ \ \ Ignore all white space.\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ --ignore-eol-style:\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
\ \ \ \ \ \ \ Ignore changes in EOL style
native-eol=\
use\ a\ different\ EOL\ marker\ than\ the\ standard\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
system\ marker\ for\ files\ with\ the\ svn:eol-style\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
property\ set\ to\ 'native'.\n\
\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
ARG\ may\ be\ one\ of\ 'LF',\ 'CR',\ 'CRLF'
relocate=relocate via URL-rewriting
auto-props=enable automatic properties
no-auto-props=disable automatic properties
keep-changelist=don't delete changelist after commit