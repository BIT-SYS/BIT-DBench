Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: Plantuml Java Support Test
Bundle-SymbolicName: net.sourceforge.plantuml.jdt.tests
Bundle-Version: 1.1.20
Bundle-Vendor: PlantUML Team
Require-Bundle: org.eclipse.core.runtime;bundle-version="3.3.1",
 org.eclipse.core.resources;bundle-version="3.3.1",
 net.sourceforge.plantuml.eclipse;bundle-version="1.1.20",
 org.junit,
 org.eclipse.ui;bundle-version="3.106.1",
 org.eclipse.ui.editors;bundle-version="3.8.200",
 org.eclipse.ui.ide;bundle-version="3.10.2",
 net.sourceforge.plantuml.jdt;bundle-version="1.1.20",
 org.eclipse.jdt.core;bundle-version="3.10.2",
 net.sourceforge.plantuml.eclipse.tests;bundle-version="1.1.20",
 org.eclipse.jdt.ui;bundle-version="3.10.2",
 org.eclipse.jdt.launching;bundle-version="3.7.102"
Bundle-ClassPath: .
Bundle-RequiredExecutionEnvironment: JavaSE-1.6
Import-Package: net.sourceforge.plantuml.eclipse.test.util
