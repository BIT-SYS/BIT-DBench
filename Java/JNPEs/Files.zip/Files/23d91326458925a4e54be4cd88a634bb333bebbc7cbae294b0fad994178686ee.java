<?xml version="1.0" encoding="utf-8"?>

<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
	    android:orientation="vertical"
         android:layout_width="fill_parent"
         android:layout_height="fill_parent">
     
	<LinearLayout android:id="@+id/allListItems"
	    android:orientation="horizontal"
         android:layout_width="fill_parent"
         android:layout_height="?android:attr/listPreferredItemHeight">
		<TextView 
				android:text="@string/label_all_bookmarks"
		    android:layout_width="wrap_content"
		    android:layout_height="fill_parent"
		    android:textAppearance="?android:attr/textAppearanceLarge"
		    android:gravity="left|center_vertical"
		    android:paddingLeft="10dip"
		    android:singleLine="true" 
		    android:layout_weight='1' />
		<TextView android:id="@+id/totalCount"
				android:text="@string/label_sub_all_bookmarks"
		    android:layout_width="wrap_content"
		    android:layout_height="fill_parent"
		    android:textAppearance="?android:attr/textAppearanceMedium"
		    android:textColor='#666'
		    android:gravity="right|center_vertical"
		    android:paddingRight="10dip"
		    android:paddingLeft="10dip"
		    android:singleLine="true" />
	</LinearLayout>

  <ListView android:id="@id/android:list"
      android:layout_width="fill_parent"
      android:layout_height="fill_parent"
      android:layout_weight="1"
      android:textFilterEnabled="true" 
      android:drawSelectorOnTop="false"/>
      
	<LinearLayout android:id='@id/android:empty'
   	android:layout_width='fill_parent'
   	android:layout_height='fill_parent'
   	android:orientation='vertical'>
   	
   	<TextView android:id='@+id/welcome_msg'
   		android:text='@string/welcome_msg'
 			android:layout_width='fill_parent'
			android:layout_height='wrap_content'
			android:linksClickable='true' 
			android:paddingTop='10dip' />
   		
		<Button android:id="@+id/loginBtn"
			android:text='@string/menu_login_long'
			android:layout_width='fill_parent'
			android:layout_height='wrap_content' />
		<Button android:id="@+id/syncBtn"
			android:text='@string/btn_first_sync'
			android:layout_width='fill_parent'
			android:layout_height='wrap_content' />
		<TextView android:id='@+id/add_new_instructions'
			android:text='@string/add_bookmark_msg'
			android:layout_width='fill_parent'
			android:layout_height='wrap_content'
			android:paddingTop='10dip' />
	</LinearLayout>
</LinearLayout>
