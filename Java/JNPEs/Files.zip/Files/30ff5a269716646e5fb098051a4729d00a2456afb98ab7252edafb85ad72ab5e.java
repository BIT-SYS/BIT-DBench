<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">

	<parent>
		<groupId>org.jboss.ejb3.timerservice</groupId>
		<artifactId>jboss-ejb3-timerservice-parent</artifactId>
		<version>1.0.0-SNAPSHOT</version>
		<relativePath>../pom.xml</relativePath>
	</parent>

	<!-- Maven POM Model Version -->
	<modelVersion>4.0.0</modelVersion>

	<!-- Artifact Information -->
	<groupId>org.jboss.ejb3.timerservice</groupId>
	<artifactId>ejb31-calendar-expr-parser</artifactId>
	<packaging>jar</packaging>

	<name>EJB3.1 Calendar expression (ScheduleExpression) parser</name>
	<description>
    A parser for EJB3.1 timerservice calendar expressions (a.k.a ScheduleExpression)
  </description>
	<url>http://labs.jboss.com/jbossejb3/</url>

	
	<build>
		<plugins>
			<plugin>
				<artifactId>maven-compiler-plugin</artifactId>
				<configuration>
					<source>1.6</source>
					<target>1.6</target>
				</configuration>
			</plugin>

			<plugin>
				<artifactId>maven-enforcer-plugin</artifactId>
				<executions>
					<execution>
						<id>enforce-jdk6</id>
						<goals>
							<goal>enforce</goal>
						</goals>
						<configuration>
							<rules>
								<requireJavaVersion>
									<version>[1.6,)</version>
								</requireJavaVersion>
							</rules>
						</configuration>
					</execution>
				</executions>
			</plugin>

		</plugins>
	</build>

	<dependencies>

		<dependency>
			<groupId>org.jboss.spec.javax.ejb</groupId>
			<artifactId>jboss-ejb-api_3.1_spec</artifactId>
			<version>1.0.0.Beta2</version>
		</dependency>
		<dependency>
			<groupId>org.jboss.logging</groupId>
			<artifactId>jboss-logging-spi</artifactId>
		</dependency>

		<dependency>
			<groupId>junit</groupId>
			<artifactId>junit</artifactId>
			<scope>test</scope>
		</dependency>

	</dependencies>

</project>
