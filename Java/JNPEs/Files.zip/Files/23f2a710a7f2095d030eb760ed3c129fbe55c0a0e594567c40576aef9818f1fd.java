<?xml version='1.0' encoding='UTF-8'?>
<?compositeMetadataRepository version='1.0.0'?>
<repository name='PlantUML composite site'
	type='org.eclipse.equinox.internal.p2.metadata.repository.CompositeMetadataRepository'
	version='1.0.0'>
	<properties size='1'>
	<!-- 
		<property name='p2.timestamp' value='1421600341270' />
		<property name='p2.atomic.composite.loading' value='true' />
	 -->
	</properties>
	<children size='2'>
		<child location='plantuml.lib/1.2018.9' />
		<child location='plantuml.eclipse/1.1.20' />
	</children>
</repository>
