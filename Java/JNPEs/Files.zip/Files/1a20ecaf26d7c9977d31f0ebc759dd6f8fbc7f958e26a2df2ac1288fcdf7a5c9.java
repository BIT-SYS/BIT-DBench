Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: %pluginName
Bundle-SymbolicName: org.eclipse.emf.query2.test;singleton:=true
Bundle-Version: 1.0.0.qualifier
Bundle-ClassPath: .
Bundle-Vendor: %providerName
Bundle-Localization: plugin
Bundle-RequiredExecutionEnvironment: JavaSE-1.6
Require-Bundle: org.junit4;bundle-version="[4.0.0,5.0.0)",
 org.eclipse.emf.ecore.xmi;bundle-version="[2.4.0,3.0.0)",
 org.eclipse.core.runtime;bundle-version="3.5.0",
 org.eclipse.emf.query2.core;bundle-version="1.0.0",
 org.eclipse.emf.query2.index;bundle-version="1.0.0",
 org.eclipse.emf.query2.index.ui;bundle-version="1.0.0"
Bundle-Activator: org.eclipse.emf.query2.test.QueryTestsPlugin
Bundle-ActivationPolicy: lazy
