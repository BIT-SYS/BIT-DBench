#Mon Mar 24 18:55:50 EDT 2008
eclipse.preferences.version=1
line.separator=\n
