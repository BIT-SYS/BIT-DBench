package me.rothes.jsonconverter.convertmethods;

import me.rothes.jsonconverter.EnLocale;

import java.util.HashMap;

public interface ConvertMethod {

    HashMap<String, EnLocale> getEnLocalization();

}
