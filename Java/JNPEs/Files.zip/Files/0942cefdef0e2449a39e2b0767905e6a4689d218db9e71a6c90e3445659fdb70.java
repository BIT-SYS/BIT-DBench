<div class="modal-head">
  <h2>Issues Help</h2>
</div>

<div class="modal-body doc">
  <h3>Shortcuts</h3>
  <p>To control results</p>
  <ul>
    <li><span class="shortcut-button">&uparrow;</span> <span class="shortcut-button">&darr;</span> &nbsp;&nbsp; to navigate between issues</li>
    <li><span class="shortcut-button">&rarr;</span> &nbsp;&nbsp; to go from the list of issues to the source code</li>
    <li><span class="shortcut-button">&larr;</span> &nbsp;&nbsp; to return back to the list</li>
  </ul>
  <p>To control selected issue</p>
  <ul>
    <li><span class="shortcut-button">c</span> &nbsp;&nbsp; to confirm/unconfirm</li>
    <li><span class="shortcut-button">r</span> &nbsp;&nbsp; to resolve/reopen</li>
    <li><span class="shortcut-button">f</span> &nbsp;&nbsp; to mark as false-positive</li>
    <li><span class="shortcut-button">a</span> &nbsp;&nbsp; to assign</li>
    <li><span class="shortcut-button">m</span> &nbsp;&nbsp; to assign to the current user</li>
    <li><span class="shortcut-button">p</span> &nbsp;&nbsp; to plan</li>
    <li><span class="shortcut-button">i</span> &nbsp;&nbsp; to change severity</li>
    <li><span class="shortcut-button">o</span> &nbsp;&nbsp; to comment</li>
    <li><span class="shortcut-button">t</span> &nbsp;&nbsp; to change tags</li>
  </ul>
</div>

<div class="modal-foot">
  <a class="js-modal-close">{{t 'close'}}</a>
</div>
