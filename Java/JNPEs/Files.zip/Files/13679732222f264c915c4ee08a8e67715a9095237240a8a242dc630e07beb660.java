#Sat Apr 06 06:41:29 CEST 2013
activeProfiles=
eclipse.preferences.version=1
resolveWorkspaceProjects=true
version=1
