<div>
  <%= @root_characteristic.name %>&nbsp;&gt;&nbsp;<%= @characteristic.name %>
</div>

